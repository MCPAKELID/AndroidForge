# BlockRush Live Game v15 — AndroidForge Source

## Changes in v15

### App icon
- Replaced launcher icons in all Android mipmap densities with the exact supplied BlockRush Live Game logo.
- Both standard and round launcher icon resources are updated.

### Arena and grid
- Replaced the arena background with the newly supplied blue-sky, stone-frame map.
- The playable grid is exactly 10 columns x 40 rows (400 cells).
- Grid cells are square (43 x 43 world units) and aligned inside the new map frame.
- The background artwork is scaled vertically to fit the 40-row playfield while preserving the side frame and caution barrier.
- The top HUD is fixed; the arena camera scrolls independently below it.

### HUD and counters
- Replaced the old HUD with the supplied top HUD strip.
- Left counter shows completed horizontal rows: `0/40`.
- One row counts only when all 10 cells in that row contain blocks.
- Right counter shows occupied area percentage: occupied blocks / 400 total cells.
- The segmented green progress bar follows the occupied-area percentage.
- Trophy panel remains icon-only; WIN counter/logic is not active.
- Heart/HP panel is not drawn as a live system yet.

### Font
- Uses the supplied outlined pixel-font atlas for digits, slash, and percent sign in the HUD.
- No Android system font is used for the HUD counters.

### Blocks
- Replaced the old block textures with 48 textures extracted from the supplied block atlas.
- Each five vertical layers use one fixed block texture before advancing to the next texture, retaining the earlier non-random material rule.
- Placed block textures are drawn to the full grid cell with pixel filtering disabled.

## Build
1. Extract `BlockRush_Live_Game_v15_AndroidForge.zip`.
2. Open `BlockRush_Live_Game_v15` in AndroidForge.
3. Build the `app` module.
4. Use JDK 17 and Android SDK Platform 35.
5. Application ID: `com.mcpakel.blockarea`.

Version: 1.5 (versionCode 15)

The Java source is checked for syntax/API compatibility using local Android stubs. A full AndroidForge APK build and on-device gameplay test have not been run in this environment.
