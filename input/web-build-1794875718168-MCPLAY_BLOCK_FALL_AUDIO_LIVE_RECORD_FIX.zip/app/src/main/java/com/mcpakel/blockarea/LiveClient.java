package com.mcpakel.blockarea;

import java.io.InputStream;
import java.io.OutputStream;
import java.net.InetSocketAddress;
import java.net.Socket;
import java.security.SecureRandom;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentLinkedQueue;

/**
 * Minimal WebSocket client (RFC 6455) built into the game, no extra library and no separate Node server.
 * Two modes:
 *  - MODE_DIRECT: wss://ws.eulerstream.com?uniqueId=<user>&apiKey=<key> (TLS), the JSON events are mapped to {@link Event}s;
 *  - MODE_BRIDGE: plain ws:// to the user's Node.js bridge (TMine.js): subscribe + host_start.
 * Events are polled by the game thread. Reconnects automatically while started.
 */
public final class LiveClient {
    /** One TikTok event. type: gift, like, follow, share, join, chat, subscribe. */
    public static final class Event {
        public String type = "", user = "", giftName = "", text = "", giftPic = "";
        public int giftId, count = 1, coin;
        public long totalCoin;
    }

    public static final int MODE_DIRECT = 0, MODE_BRIDGE = 1;
    public static final String DIRECT_HOST = "ws.eulerstream.com";

    public volatile String status = "MATI";       // MATI, MENGHUBUNGKAN, TERHUBUNG, LIVE, OFFLINE, ERROR, TERPUTUS
    public volatile String message = "";
    public volatile int viewers = 0;
    private final ConcurrentLinkedQueue<Event> queue = new ConcurrentLinkedQueue<>();
    private volatile boolean wanted = false;
    private volatile Socket socket;
    private Thread thread;
    private String host = "127.0.0.1", user = "", apiKey = "";
    private int port = 25601, mode = MODE_BRIDGE;
    private int generation = 0;
    private final Map<String, long[]> streaks = new HashMap<>();

    private static final class CloseEx extends Exception {
        final int code;
        CloseEx(int code, String reason) { super(reason); this.code = code; }
    }

    public boolean isRunning() { return wanted; }

    /** Bridge mode (kept for compatibility). */
    public synchronized void start(String host, int port, String user) {
        start(MODE_BRIDGE, host, port, user, "");
    }

    public synchronized void start(int mode, String host, int port, String user, String apiKey) {
        stop();
        this.mode = mode;
        this.apiKey = apiKey == null ? "" : apiKey.trim();
        this.host = mode == MODE_DIRECT ? DIRECT_HOST : (host == null ? "" : host.trim());
        this.port = mode == MODE_DIRECT ? 443 : port;
        this.user = user == null ? "" : user.trim().replace("@", "");
        streaks.clear();
        if (this.host.length() == 0 || this.user.length() == 0) {
            status = "ERROR"; message = this.user.length() == 0 ? "Isi username TikTok dulu." : "Isi host dulu.";
            return;
        }
        wanted = true;
        status = "MENGHUBUNGKAN"; message = "";
        final int gen = ++generation;
        thread = new Thread(new Runnable() { @Override public void run() { loop(gen); } }, "LiveClient");
        thread.setDaemon(true);
        thread.start();
    }

    public synchronized void stop() {
        wanted = false;
        generation++;
        Socket s = socket;
        socket = null;
        if (s != null) {
            try { s.close(); } catch (Throwable ignored) { }
        }
        status = "MATI"; message = "";
        viewers = 0;
    }

    public Event poll() { return queue.poll(); }

    /** Test / manual injection (also used by the "TES" button). */
    public void inject(Event e) {
        queue.add(e);
        trim();
    }

    private void trim() {
        while (queue.size() > 300) queue.poll();
    }

    private boolean alive(int gen) { return wanted && gen == generation; }

    private void loop(int gen) {
        int delay = 2000;
        while (alive(gen)) {
            Socket s = null;
            try {
                status = "MENGHUBUNGKAN"; message = mode == MODE_DIRECT ? "TikTok @" + user : host + ":" + port;
                Socket raw = new Socket();
                raw.connect(new InetSocketAddress(host, port), 10000);
                raw.setTcpNoDelay(true);
                socket = raw;
                if (mode == MODE_DIRECT) {
                    javax.net.ssl.SSLSocket ssl = (javax.net.ssl.SSLSocket) ((javax.net.ssl.SSLSocketFactory)
                            javax.net.ssl.SSLSocketFactory.getDefault()).createSocket(raw, host, port, true);
                    ssl.startHandshake();
                    s = ssl;
                } else s = raw;
                s.setSoTimeout(mode == MODE_DIRECT ? 20000 : 70000);
                socket = s;
                if (!alive(gen)) break;
                handshake(s);
                status = "TERHUBUNG"; message = "Menunggu live @" + user;
                delay = 2000;
                if (mode == MODE_BRIDGE) {
                    send(s, "{\"type\":\"subscribe\",\"playerName\":\"BlockRush\",\"playerUUID\":\"\",\"tiktok\":\""
                            + esc(user) + "\"}");
                    send(s, "{\"type\":\"host_start\",\"tiktok\":\"" + esc(user) + "\"}");
                }
                readLoop(s, gen);
            } catch (CloseEx c) {
                if (alive(gen)) {
                    if (c.code == 4404) { status = "OFFLINE"; message = "@" + user + " belum live"; delay = 9000; }
                    else if (c.code == 4401) { status = "ERROR"; message = "Server minta API key (gratis di eulerstream.com) - isi di menu"; delay = 15000; }
                    else if (c.code == 4429) { status = "ERROR"; message = "Terlalu banyak koneksi (batas akun)"; delay = 15000; }
                    else { status = "TERPUTUS"; message = "Ditutup server (" + c.code + ") " + c.getMessage(); }
                }
            } catch (javax.net.ssl.SSLException t) {
                if (alive(gen)) { status = "TERPUTUS"; message = "TLS gagal: " + t.getMessage(); }
            } catch (Throwable t) {
                if (alive(gen)) { status = "TERPUTUS"; message = String.valueOf(t.getMessage()); }
            } finally {
                if (s != null) try { s.close(); } catch (Throwable ignored) { }
            }
            if (!alive(gen)) break;
            if (!"ERROR".equals(status) && !"OFFLINE".equals(status)) status = "TERPUTUS";
            for (int waited = 0; waited < delay && alive(gen); waited += 100) {
                try { Thread.sleep(100); } catch (InterruptedException e) { return; }
            }
            delay = Math.min(10000, delay + 1500);
        }
    }

    // ---- WebSocket framing -------------------------------------------------------------
    private static final SecureRandom RND = new SecureRandom();

    private void handshake(Socket s) throws Exception {
        byte[] k = new byte[16];
        RND.nextBytes(k);
        String key = b64(k);
        String path = "/";
        if (mode == MODE_DIRECT) {
            path = "/?uniqueId=" + enc(user) + (apiKey.length() > 0 ? "&apiKey=" + enc(apiKey) : "");
        }
        String req = "GET " + path + " HTTP/1.1\r\nHost: " + host + (mode == MODE_DIRECT ? "" : ":" + port)
                + "\r\nUpgrade: websocket\r\n"
                + "Connection: Upgrade\r\nSec-WebSocket-Key: " + key + "\r\nSec-WebSocket-Version: 13\r\n"
                + "Origin: https://" + host + "\r\nUser-Agent: BlockRush\r\n\r\n";
        OutputStream out = s.getOutputStream();
        out.write(req.getBytes("UTF-8"));
        out.flush();
        InputStream in = s.getInputStream();
        StringBuilder head = new StringBuilder();
        int c;
        while ((c = in.read()) >= 0) {
            head.append((char) c);
            int n = head.length();
            if (n >= 4 && head.charAt(n - 1) == '\n' && head.charAt(n - 2) == '\r'
                    && head.charAt(n - 3) == '\n' && head.charAt(n - 4) == '\r') break;
            if (n > 8192) throw new Exception("Header terlalu panjang");
        }
        if (head.indexOf(" 101") < 0) {
            String line = head.toString().split("\r\n")[0];
            if (mode == MODE_DIRECT) {
                if (line.contains("401") || line.contains("403")) {
                    status = "ERROR"; throw new Exception("API key salah / ditolak (" + line.trim() + ")");
                }
                if (line.contains("404")) throw new Exception("Server menolak: " + line.trim());
                throw new Exception("Server menolak: " + line.trim());
            }
            throw new Exception("Bukan server WebSocket (bridge TikTok?)");
        }
    }

    private void readLoop(Socket s, int gen) throws Exception {
        InputStream in = s.getInputStream();
        StringBuilder text = new StringBuilder();
        java.io.ByteArrayOutputStream frag = new java.io.ByteArrayOutputStream();
        long lastPing = System.currentTimeMillis();
        while (alive(gen)) {
            int b0;
            try { b0 = in.read(); } catch (java.net.SocketTimeoutException e) {
                if (mode == MODE_DIRECT) sendFrame(s, 0x9, new byte[0]); else send(s, "{\"type\":\"ping\"}");
                continue;
            }
            if (b0 < 0) throw new Exception("Koneksi ditutup server");
            int b1 = in.read();
            if (b1 < 0) throw new Exception("Koneksi ditutup server");
            boolean fin = (b0 & 0x80) != 0;
            int op = b0 & 0x0f;
            long len = b1 & 0x7f;
            if (len == 126) len = (in.read() << 8) | in.read();
            else if (len == 127) { len = 0; for (int i = 0; i < 8; i++) len = (len << 8) | in.read(); }
            boolean masked = (b1 & 0x80) != 0;
            byte[] mask = new byte[4];
            if (masked) readFully(in, mask, 4);
            if (len > 4_000_000L) throw new Exception("Frame terlalu besar");
            byte[] data = new byte[(int) len];
            readFully(in, data, data.length);
            if (masked) for (int i = 0; i < data.length; i++) data[i] ^= mask[i & 3];
            if (op == 0x8) {
                int code = data.length >= 2 ? ((data[0] & 255) << 8) | (data[1] & 255) : 1005;
                String why = data.length > 2 ? new String(data, 2, data.length - 2, "UTF-8") : "";
                throw new CloseEx(code, why);
            }
            if (op == 0x9) { sendFrame(s, 0xA, data); continue; }
            if (op == 0xA) continue;
            if (op == 0x1 || op == 0x0) {
                if (op == 0x1) frag.reset();
                frag.write(data, 0, data.length);
                if (fin) {
                    String msg = new String(frag.toByteArray(), "UTF-8");
                    if (mode == MODE_DIRECT) handleDirect(msg); else handle(msg);
                    frag.reset();
                }
            }
            long now = System.currentTimeMillis();
            if (now - lastPing > 25000) {
                lastPing = now;
                if (mode == MODE_DIRECT) sendFrame(s, 0x9, new byte[0]); else send(s, "{\"type\":\"ping\"}");
            }
        }
    }

    private static void readFully(InputStream in, byte[] b, int n) throws Exception {
        int off = 0;
        while (off < n) {
            int r = in.read(b, off, n - off);
            if (r < 0) throw new Exception("Koneksi ditutup server");
            off += r;
        }
    }

    private void send(Socket s, String text) throws Exception { sendFrame(s, 0x1, text.getBytes("UTF-8")); }

    private synchronized void sendFrame(Socket s, int op, byte[] payload) throws Exception {
        OutputStream out = s.getOutputStream();
        byte[] mask = new byte[4];
        RND.nextBytes(mask);
        int n = payload.length;
        java.io.ByteArrayOutputStream f = new java.io.ByteArrayOutputStream(n + 14);
        f.write(0x80 | op);
        if (n < 126) f.write(0x80 | n);
        else if (n < 65536) { f.write(0x80 | 126); f.write(n >> 8); f.write(n & 255); }
        else { f.write(0x80 | 127); for (int i = 7; i >= 0; i--) f.write((int) (((long) n >> (8 * i)) & 255)); }
        f.write(mask, 0, 4);
        for (int i = 0; i < n; i++) f.write(payload[i] ^ mask[i & 3]);
        out.write(f.toByteArray());
        out.flush();
    }

    private static final String B64 = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/";

    static String b64(byte[] d) {
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < d.length; i += 3) {
            int v = (d[i] & 255) << 16 | (i + 1 < d.length ? (d[i + 1] & 255) << 8 : 0) | (i + 2 < d.length ? d[i + 2] & 255 : 0);
            sb.append(B64.charAt((v >> 18) & 63)).append(B64.charAt((v >> 12) & 63));
            sb.append(i + 1 < d.length ? B64.charAt((v >> 6) & 63) : '=');
            sb.append(i + 2 < d.length ? B64.charAt(v & 63) : '=');
        }
        return sb.toString();
    }

    private static String enc(String s) {
        try { return java.net.URLEncoder.encode(s, "UTF-8"); } catch (Exception e) { return s; }
    }

    private static String esc(String s) {
        return s.replace("\\", "\\\\").replace("\"", "\\\"");
    }

    // ---- bridge messages ------------------------------------------------------------------
    void handle(String json) {
        Map<String, String> m = parseFlat(json);
        String ev = m.get("event");
        if (ev == null) ev = m.get("type");
        if (ev == null) return;
        ev = ev.toLowerCase();
        if (ev.equals("host_status") || ev.equals("live_status")) {
            String st = m.get("status");
            String live = m.get("live");
            String user2 = m.get("tiktok");
            if ("true".equals(live) || "live".equals(st)) { status = "LIVE"; message = "@" + (user2 == null ? user : user2); }
            else if ("false".equals(live) || "offline".equals(st)) { status = "OFFLINE"; message = m.get("message") == null ? "Live tidak aktif" : m.get("message"); }
            else if ("error".equals(st)) { status = "ERROR"; message = m.get("message") == null ? "Error dari bridge" : m.get("message"); }
            else if ("connecting".equals(st) || "reconnecting".equals(st)) { status = "MENGHUBUNGKAN"; message = "TikTok @" + user; }
            else if ("stopped".equals(st)) { status = "TERHUBUNG"; message = "Dihentikan"; }
            return;
        }
        if (ev.equals("viewers")) { viewers = toInt(m.get("viewerCount"), toInt(m.get("count"), viewers)); return; }
        Event e = new Event();
        e.type = ev;
        if (ev.equals("sub") || ev.equals("subscribe") || ev.equals("subscription")) e.type = "subscribe";
        else if (!(ev.equals("gift") || ev.equals("like") || ev.equals("follow") || ev.equals("share")
                || ev.equals("join") || ev.equals("chat") || ev.equals("member"))) return;
        if (ev.equals("member")) e.type = "join";
        e.user = firstNonEmpty(m.get("username"), m.get("uniqueId"), m.get("nickname"), "anonymous");
        e.giftName = firstNonEmpty(m.get("giftName"), "", "", "");
        e.giftId = toInt(m.get("giftId"), 0);
        e.giftPic = firstNonEmpty(m.get("giftPictureUrl"), m.get("giftImage"), m.get("giftIcon"), m.get("pictureUrl"));
        e.count = Math.max(1, toInt(m.get("count"), toInt(m.get("repeatCount"), toInt(m.get("likeCount"), 1))));
        e.coin = toInt(m.get("coin"), toInt(m.get("diamondCount"), 0));
        e.totalCoin = e.coin * (long) e.count;
        e.text = firstNonEmpty(m.get("message"), m.get("comment"), "", "");
        // Gift packets without a delta flag duplicate combo steps; the bridge already de-duplicates.
        queue.add(e);
        trim();
    }

    // ---- direct mode (EulerStream JSON) ---------------------------------------------------
    /** Tolerant mapping: accepts {"messages":[...]}, a single message, or an array; type names like "gift" or "WebcastGiftMessage". */
    void handleDirect(String json) {
        Object root;
        try { root = new Json(json).read(); } catch (Exception e) { return; }
        List<Object> list = new ArrayList<>();
        if (root instanceof List) list.addAll((List<?>) root);
        else if (root instanceof Map) {
            Object ms = ((Map<?, ?>) root).get("messages");
            if (ms instanceof List) list.addAll((List<?>) ms); else list.add(root);
        }
        for (Object o : list) if (o instanceof Map) one((Map<?, ?>) o);
    }

    private void one(Map<?, ?> m) {
        String type = str(m, "type");
        if (type.length() == 0) type = str(m, "event");
        if (type.length() == 0) type = str(m, "messageType");
        type = type.toLowerCase().replace("webcast", "").replace("message", "").replace("_", "").replace("-", "");
        Map<?, ?> d = m.get("data") instanceof Map ? (Map<?, ?>) m.get("data") : m;
        if (type.equals("roomuserseq") || type.equals("roomuser") || type.equals("roomuserupdate")) {
            int v = toInt(str(d, "viewerCount"), toInt(str(m, "viewerCount"), viewers));
            viewers = v; return;
        }
        Event e = new Event();
        Map<?, ?> u = d.get("user") instanceof Map ? (Map<?, ?>) d.get("user")
                : m.get("user") instanceof Map ? (Map<?, ?>) m.get("user") : d;
        String nick = str(u, "nickname"), uid = str(u, "uniqueId");
        if (uid.length() == 0) uid = str(u, "username");
        e.user = nick.length() > 0 ? nick : uid.length() > 0 ? uid : "anonymous";
        if (type.equals("chat") || type.equals("comment")) {
            e.type = "chat"; e.text = firstNonEmpty(str(d, "comment"), str(d, "content"), str(d, "text"), "");
        } else if (type.equals("gift")) {
            e.type = "gift";
            Map<?, ?> g = d.get("gift") instanceof Map ? (Map<?, ?>) d.get("gift")
                    : d.get("giftDetails") instanceof Map ? (Map<?, ?>) d.get("giftDetails") : d;
            e.giftName = firstNonEmpty(str(g, "name"), str(g, "giftName"), str(d, "giftName"), "");
            e.giftId = toInt(firstNonEmpty(str(d, "giftId"), str(g, "id"), str(g, "giftId"), ""), 0);
            e.giftPic = pictureOf(g, d);
            e.coin = toInt(firstNonEmpty(str(g, "diamondCount"), str(g, "coins"), str(d, "diamondCount"), ""), 0);
            int rep = Math.max(1, toInt(firstNonEmpty(str(d, "repeatCount"), str(g, "repeatCount"), str(m, "repeatCount"), ""), 1));
            boolean end = "true".equals(str(d, "repeatEnd")) || "true".equals(str(m, "repeatEnd"));
            int gtype = toInt(firstNonEmpty(str(g, "type"), str(g, "giftType"), str(d, "giftType"), ""), 1);
            int delta = rep;
            if (gtype == 1) {                      // streakable gift: the count grows 1,2,3... -> only the new part counts
                String key = uid + "|" + e.giftName;
                long now = System.currentTimeMillis();
                long[] st = streaks.get(key);
                if (st != null && now - st[1] > 12000) st = null;
                if (st != null && rep >= st[0]) delta = (int) (rep - st[0]);
                else if (st != null && rep < st[0]) delta = rep;
                if (end) streaks.remove(key); else streaks.put(key, new long[]{rep, now});
                if (delta <= 0) return;
            }
            e.count = delta;
            e.totalCoin = (long) e.coin * delta;
        } else if (type.equals("like")) {
            e.type = "like"; e.count = Math.max(1, toInt(firstNonEmpty(str(d, "likeCount"), str(d, "count"), "", ""), 1));
        } else if (type.equals("follow")) e.type = "follow";
        else if (type.equals("share")) e.type = "share";
        else if (type.equals("member") || type.equals("join")) {
            e.type = "join";
            int v = toInt(str(d, "viewerCount"), -1); if (v >= 0) viewers = v;
        } else if (type.equals("sub") || type.equals("subscribe") || type.equals("subscription")) e.type = "subscribe";
        else if (type.equals("social")) {
            String dt = (str(d, "displayType") + str(d, "label")).toLowerCase();
            if (dt.contains("follow")) e.type = "follow"; else if (dt.contains("share")) e.type = "share"; else return;
        } else return;
        if (!"LIVE".equals(status)) { status = "LIVE"; message = "@" + user; }
        queue.add(e);
        trim();
    }

    /** Gift picture URL from whatever field the server uses (string, {url}, or {url_list:[..]}). */
    private static String pictureOf(Map<?, ?> g, Map<?, ?> d) {
        String[] keys = {"giftPictureUrl", "pictureUrl", "imageUrl", "iconUrl", "image", "icon", "picture"};
        for (Map<?, ?> src : new Map<?, ?>[]{g, d}) {
            for (String k : keys) {
                Object o = src.get(k);
                if (o instanceof String && ((String) o).startsWith("http")) return (String) o;
                if (o instanceof Map) {
                    Map<?, ?> im = (Map<?, ?>) o;
                    String u = str(im, "url");
                    if (u.startsWith("http")) return u;
                    Object ul = im.get("url_list");
                    if (ul == null) ul = im.get("urlList");
                    if (ul instanceof List && !((List<?>) ul).isEmpty() && ((List<?>) ul).get(0) instanceof String) return (String) ((List<?>) ul).get(0);
                }
            }
        }
        return "";
    }

    private static String str(Map<?, ?> m, String k) {
        Object o = m.get(k);
        if (o == null || o instanceof Map || o instanceof List) return "";
        if (o instanceof Double) { double v = (Double) o; return v == Math.rint(v) ? String.valueOf((long) v) : String.valueOf(v); }
        return String.valueOf(o);
    }

    /** Small recursive JSON parser: objects -> Map, arrays -> List, numbers -> Double, true/false -> Boolean. */
    static final class Json {
        private final String s;
        private int i;
        Json(String s) { this.s = s; }
        Object read() throws Exception {
            ws();
            if (i >= s.length()) throw new Exception("empty");
            char c = s.charAt(i);
            if (c == '{') {
                i++;
                Map<String, Object> o = new HashMap<>();
                ws();
                if (peek() == '}') { i++; return o; }
                while (true) {
                    ws();
                    String k = string();
                    ws(); expect(':');
                    o.put(k, read());
                    ws();
                    char d = next();
                    if (d == '}') return o;
                    if (d != ',') throw new Exception("json");
                }
            }
            if (c == '[') {
                i++;
                List<Object> l = new ArrayList<>();
                ws();
                if (peek() == ']') { i++; return l; }
                while (true) {
                    l.add(read());
                    ws();
                    char d = next();
                    if (d == ']') return l;
                    if (d != ',') throw new Exception("json");
                }
            }
            if (c == '"') return string();
            if (s.startsWith("true", i)) { i += 4; return Boolean.TRUE; }
            if (s.startsWith("false", i)) { i += 5; return Boolean.FALSE; }
            if (s.startsWith("null", i)) { i += 4; return null; }
            int j = i;
            while (j < s.length() && "+-0123456789.eE".indexOf(s.charAt(j)) >= 0) j++;
            if (j == i) throw new Exception("json");
            double v = Double.parseDouble(s.substring(i, j));
            i = j;
            return v;
        }
        private char peek() { return i < s.length() ? s.charAt(i) : 0; }
        private char next() throws Exception { if (i >= s.length()) throw new Exception("eof"); return s.charAt(i++); }
        private void expect(char c) throws Exception { if (next() != c) throw new Exception("json"); }
        private void ws() { while (i < s.length() && s.charAt(i) <= ' ') i++; }
        private String string() throws Exception {
            expect('"');
            StringBuilder b = new StringBuilder();
            while (true) {
                char c = next();
                if (c == '"') return b.toString();
                if (c == '\\') {
                    char d = next();
                    if (d == 'u') { b.append((char) Integer.parseInt(s.substring(i, i + 4), 16)); i += 4; }
                    else b.append(d == 'n' ? '\n' : d == 't' ? '\t' : d == 'r' ? '\r' : d);
                } else b.append(c);
            }
        }
    }

    private static String firstNonEmpty(String a, String b, String c, String d) {
        if (a != null && a.length() > 0) return a;
        if (b != null && b.length() > 0) return b;
        if (c != null && c.length() > 0) return c;
        return d == null ? "" : d;
    }

    private static int toInt(String s, int def) {
        if (s == null) return def;
        try { return (int) Math.round(Double.parseDouble(s.trim())); } catch (Exception e) { return def; }
    }

    /** Reads the top-level key/values of a JSON object (nested values are skipped). */
    static Map<String, String> parseFlat(String s) {
        Map<String, String> out = new HashMap<>();
        int i = 0, n = s.length();
        while (i < n && s.charAt(i) != '{') i++;
        i++;
        while (i < n) {
            while (i < n && (s.charAt(i) == ' ' || s.charAt(i) == ',' || s.charAt(i) == '\n' || s.charAt(i) == '\r' || s.charAt(i) == '\t')) i++;
            if (i >= n || s.charAt(i) == '}') break;
            if (s.charAt(i) != '"') { i++; continue; }
            int[] end = new int[1];
            String key = readString(s, i, end);
            i = end[0];
            while (i < n && (s.charAt(i) == ' ' || s.charAt(i) == ':')) i++;
            if (i >= n) break;
            char c = s.charAt(i);
            if (c == '"') {
                String v = readString(s, i, end);
                i = end[0];
                out.put(key, v);
            } else if (c == '{' || c == '[') {
                i = skipNested(s, i);
            } else {
                int j = i;
                while (j < n && s.charAt(j) != ',' && s.charAt(j) != '}') j++;
                out.put(key, s.substring(i, j).trim());
                i = j;
            }
        }
        return out;
    }

    private static String readString(String s, int start, int[] end) {
        StringBuilder b = new StringBuilder();
        int i = start + 1, n = s.length();
        while (i < n) {
            char c = s.charAt(i);
            if (c == '"') { i++; break; }
            if (c == '\\' && i + 1 < n) {
                char d = s.charAt(i + 1);
                if (d == 'u' && i + 5 < n) {
                    try { b.append((char) Integer.parseInt(s.substring(i + 2, i + 6), 16)); } catch (Exception e) { b.append('?'); }
                    i += 6;
                    continue;
                }
                b.append(d == 'n' ? '\n' : d == 't' ? '\t' : d == 'r' ? '\r' : d);
                i += 2;
                continue;
            }
            b.append(c);
            i++;
        }
        end[0] = i;
        return b.toString();
    }

    private static int skipNested(String s, int start) {
        int depth = 0, i = start, n = s.length();
        boolean inStr = false;
        while (i < n) {
            char c = s.charAt(i);
            if (inStr) {
                if (c == '\\') i++;
                else if (c == '"') inStr = false;
            } else if (c == '"') inStr = true;
            else if (c == '{' || c == '[') depth++;
            else if (c == '}' || c == ']') { depth--; if (depth == 0) return i + 1; }
            i++;
        }
        return n;
    }
}
