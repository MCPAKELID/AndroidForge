# BlockRush Live Game v24 — AndroidForge Source

Game Minecraft 2D untuk live TikTok: penonton kirim gift / follow / like, dan game langsung bereaksi (TNT, petir, tornado, robot, meteor, monster, dll).

## Hubungkan ke TikTok Live

**Mode LANGSUNG (bawaan, tanpa Node.js):** menu **TIKTOK LIVE** → isi **Username** (yang sedang LIVE) → **MULAI TERHUBUNG**. Game membuka WebSocket sendiri ke `wss://ws.eulerstream.com`. **API KEY opsional** — dikosongkan dulu; isi (gratis di eulerstream.com) hanya bila server menolak tanpa key.
> Mode ini belum bisa dites dari sini (butuh internet + akun live). Format pesan dibaca secara toleran; kalau ada yang tidak cocok, kirim isi status/pesannya.

**Mode NODE.JS BRIDGE:** tetap tersedia (tombol NODE.JS BRIDGE). Di bridge TIKTOMC: `MINECRAFT_OUTBOUND_ENABLED=false`, `WS_PORT=25601`; di game isi host/port. Mode ini sudah diuji dengan `TMine.js` asli.

**HUBUNG OTOMATIS** = langsung tersambung saat game dibuka. **TES** = kirim follow + gift palsu.

## Hadiah & Event

- **HADIAH** (24 slot): satu slot = satu gift TikTok → **tepat** satu efek yang kamu atur (mis. Mawar = 1 TNT → hanya 1 TNT). Atur nama gift (pilih dari ±750 gift Indonesia / cari / ketik), gambar, efek, jumlah, teks, ON/OFF, TAMPIL/SEMBUNYI (maks 8 tampil; yang disembunyikan tetap memicu efek) dan tombol **TES** per baris. Mengetuk gambar gift di atas layar juga memicu efeknya.
- Notifikasi: "asep mengirim 1x mawar". Nama pengirim juga tampil di atas robot, tornado, dan monster yang ia panggil.
- **Gambar gift** diambil otomatis dari streamtoearn.io (daftar gift Indonesia) dan dari gambar yang ikut terkirim saat live; disimpan di cache HP, jadi cukup online sekali. Tanpa internet dipakai gambar bawaan / kotak hadiah. Ketuk gambar di baris gift untuk memilih gambar lain (AUTO = dari web).
- Setiap gift di atas layar punya lencana kecil gambar efeknya (petir, tornado, dll).
- **EVENT**: follow, share, masuk, like, komentar, subscribe, gift lain → efek + jumlah + TES.
- **Efek**: BLOK (blok langsung muncul di arena, lapisan paling bawah dulu, mis. 1 mawar = 5 blok), TNT, HUJAN TNT, TURBO, NYAWA (nyawa tambahan), PERISAI, PETIR (menembus dalam), TORNADO (muncul di atas lalu jatuh; hanya menghancurkan maks. 5 blok yang menghalangi jalannya, tidak menggali ke bawah), ROBOT (tiap robot punya kolom sendiri, terbang ke atas & hilang bila selesai), METEOR, MONSTER.

## Aturan

- Blok per **lapisan**: 10 blok ke samping = 1 lapisan, HUD menampilkan `N/40`. 40 lapisan penuh → hitung mundur → menang.
- Hitung mundur **batal** kalau ada blok hancur. Mulai hitungan, kecepatan, dan target menang bisa diatur.
- Pemain bisa mati (PENGATURAN > GAME). Saat mati tidak ada menu: pemain hilang beberapa detik (**HIDUP LAGI** bisa diatur) lalu hidup lagi otomatis dengan perlindungan 3 detik.
- Blok hanya bisa dipasang bila menempel tanah/blok; lalu jatuh sampai bertumpu (**BLOK JATUH** bisa dimatikan di PENGATURAN > GAME). Tombol **DEPAN** (atau F) memasang blok di depan player seperti Minecraft Bedrock.
- **MAP & KARAKTER** hanya dari menu utama.

## Pengaturan

- **UMUM**: tombol layar, notif TikTok, blok tak terbatas, **HUD transparan** (arena terlihat di belakang HUD; matikan untuk latar biru), kecepatan pasang, HUD turun.
- **GAME**: bisa mati, tampilkan nyawa, hidup lagi (detik), blok jatuh, target menang, hitungan mundur, gift tampil.
- **EFEK**: durasi tornado / robot / monster / perisai.
- **SUARA**: efek suara on/off + volume, musik latar on/off + volume, suara klik tombol.

## Mod

Menu utama → **MOD** (atau tombol M). Folder mod ada di `Android/data/com.mcpakel.blockarea/files/mods/` (satu folder = satu mod; sebagian file manager butuh akses khusus ke Android/data). Saat pertama dibuka dibuat folder `contoh_mod` berisi `mod.json` dan `README.txt` contoh.

- **Ganti texture / suara**: taruh file dengan path yang SAMA seperti di `assets` (mis. `ui/fx_tnt.png`, `blocks/block_00.png`, `sounds/sfx_place.wav`, `music/bgm.wav`, `menu/background.jpg`) di dalam folder mod.
- **Tambah fitur**: `mod.json`:
```json
{ "name": "Mod Saya", "version": "1.0", "author": "aku",
  "gifts":  [ { "name": "Lion", "label": "BADAI", "icon": "gift/lion.png",
                "actions": [ {"effect": "TNT", "amount": 3}, {"effect": "METEOR", "amount": 1} ] } ],
  "events": { "share": [ {"effect": "PETIR", "amount": 1} ] } }
```
  effect: BLOK, TNT, HUJAN TNT, TURBO, NYAWA, PERISAI, PETIR, TORNADO, ROBOT, METEOR, MONSTER. Gift yang kamu atur sendiri di menu HADIAH tetap diutamakan; aksi event mod berjalan tambahan.
- Aktif/nonaktifkan tiap mod di menu MOD; setelah mengubah file tekan **MUAT ULANG**.

## Kontrol

| Aksi | Sentuh | Keyboard | Mouse |
|---|---|---|---|
| Jalan | ◀ ▶ | A / D | – |
| Lompat | ⬆ | W / Spasi | – |
| Lari | tombol lari | Shift | – |
| Blok di bawah | tombol blok | E / Enter | – |
| Blok di depan | DEPAN | F | – |
| Pasang / gali | ketuk / mode beliung | X / Z, S | klik kiri / kanan |
| Hadiah (uji) | ketuk ikon | 1–8 | klik ikon |
| Jeda | tombol jeda, Back | Esc / P | – |
| Menu | – | O / G / T / L / M | – |

## Build

Ekstrak ke workspace AndroidForge, build modul `app` dengan JDK 17, Android SDK 35. Application ID `com.mcpakel.blockarea` — Versi 2.4 (versionCode 24). Izin INTERNET sudah ada.

Diuji dengan API Android tiruan (logika, input, tampilan). APK asli / TikTok live asli belum dites di perangkat.
