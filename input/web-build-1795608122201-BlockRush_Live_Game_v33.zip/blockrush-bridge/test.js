/* Tes mandiri tanpa internet: connector TikTok palsu + klien WebSocket sungguhan. Jalankan: npm test */
'use strict';
const { EventEmitter } = require('events');
const WebSocket = require('ws');
const { start, userOf } = require('./bridge');

let pass = 0, fail = 0;
const check = (ok, name) => { if (ok) { pass++; console.log('PASS', name); } else { fail++; console.log('FAIL', name); } };
const sleep = ms => new Promise(r => setTimeout(r, ms));

let live = true, last = null;
class Fake extends EventEmitter {
  constructor(user) { super(); this.user = user; last = this; }
  async connect() { if (!live) { const e = new Error('The requested user isn\'t online :('); e.name = 'UserOfflineError'; throw e; } return {}; }
  disconnect() { this.emit('disconnected'); }
}

(async () => {
  // ---- userOf: semua bentuk data yang mungkin
  const U = [
    [{ user: { userId: '1', uniqueId: 'budi', nickname: 'Budi S' } }, 'budi'],                  // connector v2
    [{ uniqueId: 'sari', nickname: 'Sari' }, 'sari'],                                          // format lama
    [{ user: { nickname: 'Dewi' } }, 'Dewi'],                                                   // hanya nickname
    [{ userInfo: { unique_id: 'ayu_99' } }, 'ayu_99'],
    [{ user: { displayId: 'rian' } }, 'rian'],
    [{ sender: { nickName: 'Joko' } }, 'Joko'],
    [{ data: { user: { uniqueId: 'dalam' } } }, 'dalam'],
    [{ user: 'teks_langsung' }, 'teks_langsung'],
    [{ uniqueId: 'anonymous', user: { uniqueId: 'asli' } }, 'asli'],
    [{}, ''],
  ];
  for (const [d, want] of U) { const u = userOf(d); check((u.uniqueId || u.nickname) === want, 'userOf -> "' + want + '"'); }

  const srv = await start({ ConnectionClass: Fake, port: 0, quiet: true, apiKey: '' });
  const url = 'ws://127.0.0.1:' + srv.port;
  const got = [];
  const ws = new WebSocket(url);
  await new Promise(r => ws.on('open', r));
  ws.on('message', m => got.push(JSON.parse(m.toString())));
  const find = (t, f) => got.filter(x => x.type === t && (!f || f(x)));

  ws.send(JSON.stringify({ type: 'subscribe', playerName: 'BlockRush', playerUUID: '', tiktok: 'streamer1' }));
  ws.send(JSON.stringify({ type: 'host_start', tiktok: 'streamer1' }));
  await sleep(200);
  check(find('host_status', x => x.status === 'live' && x.live === true).length === 1, 'host_status live terkirim');

  ws.send(JSON.stringify({ type: 'ping' })); await sleep(50);
  check(find('pong').length === 1, 'ping -> pong');

  // ---- event berbentuk connector v2 (user di dalam objek user)
  const mk = (id, extra) => ({ common: { msgId: id }, user: { userId: '42', uniqueId: 'budi', nickname: 'Budi S' }, ...extra });
  last.emit('chat', mk('c1', { comment: 'halo bro' }));
  last.emit('follow', mk('f1', {}));
  last.emit('follow', mk('f2', {}));                                  // orang yang sama: tidak dobel
  last.emit('share', mk('s1', {}));
  last.emit('member', mk('m1', {}));
  last.emit('like', mk('l1', { likeCount: 5, totalLikeCount: 100 }));
  last.emit('subscribe', mk('sb1', {}));
  last.emit('roomUser', { viewerCount: 321 });
  await sleep(150);
  const c = find('chat')[0];
  check(c && c.username === 'budi' && c.message === 'halo bro' && c.comment === 'halo bro' && c.text === 'halo bro', 'chat: nama + komentar terbaca');
  check(find('follow').length === 1 && find('follow')[0].username === 'budi', 'follow: nama terbaca, tidak dobel');
  check(find('share')[0] && find('share')[0].username === 'budi', 'share: nama terbaca');
  check(find('join')[0] && find('join')[0].username === 'budi', 'join: nama terbaca');
  check(find('like')[0] && find('like')[0].username === 'budi' && find('like')[0].count === 5, 'like: nama + jumlah');
  check(find('subscribe')[0] && find('subscribe')[0].username === 'budi', 'subscribe: nama terbaca');
  check(find('viewers')[0] && find('viewers')[0].viewerCount === 321, 'viewers terkirim');
  check(!JSON.stringify(got).toLowerCase().includes('anonymous'), 'tidak ada kata "anonymous" sama sekali');

  // format lama (uniqueId di luar)
  last.emit('chat', { uniqueId: 'sari', nickname: 'Sari', comment: 'format lama', msgId: 'old1' });
  await sleep(50);
  check(find('chat', x => x.username === 'sari' && x.text === 'format lama').length === 1, 'format lama tetap terbaca');

  // nama kosong total -> "Penonton", bukan anonymous
  last.emit('chat', { comment: 'tanpa nama', msgId: 'x1' });
  await sleep(50);
  check(find('chat', x => x.username === 'Penonton').length === 1, 'tanpa nama -> "Penonton"');

  // ---- gift
  const gd = (id, rep, end, gid) => ({ common: { msgId: id }, user: { userId: '7', uniqueId: 'rina', nickname: 'Rina' }, giftId: 5655, repeatCount: rep, repeatEnd: end, groupId: gid || 'g1',
    giftDetails: { giftName: 'Rose', diamondCount: 1, giftType: 1, giftImage: { urlList: ['https://p16.example/rose.png'] } } });
  last.emit('gift', gd('g-a', 1, false));
  last.emit('gift', gd('g-b', 2, false));
  last.emit('gift', gd('g-c', 5, false));
  last.emit('gift', gd('g-d', 5, true));                              // penutup streak: tidak dobel
  last.emit('gift', gd('g-c', 5, false));                             // msgId sama: diabaikan
  await sleep(100);
  const gifts = find('gift');
  check(gifts.length === 3 && gifts.map(x => x.count).join(',') === '1,1,3', 'gift beruntun: 1,1,3 (total 5) -> ' + gifts.map(x => x.count).join(','));
  check(gifts[0].username === 'rina' && gifts[0].giftName === 'Rose' && gifts[0].coin === 1 && gifts[0].giftPictureUrl.startsWith('https://'), 'gift: nama, nama gift, koin, gambar');
  last.emit('gift', { common: { msgId: 'big' }, user: { uniqueId: 'raja' }, giftId: 6000, repeatCount: 1, giftDetails: { giftName: 'Lion', diamondCount: 29999, giftType: 2 } });
  await sleep(50);
  const lion = find('gift', x => x.giftName === 'Lion')[0];
  check(lion && lion.count === 1 && lion.totalCoin === 29999, 'gift non-beruntun (Lion) 1x');

  // ---- game kedua ikut ruang yang sama tanpa konek ulang
  const created = []; const OrigNew = last;
  const ws2 = new WebSocket(url); await new Promise(r => ws2.on('open', r));
  const got2 = []; ws2.on('message', m => got2.push(JSON.parse(m.toString())));
  ws2.send(JSON.stringify({ type: 'host_start', tiktok: 'Streamer1' }));
  await sleep(100);
  check(last === OrigNew && got2.some(x => x.type === 'host_status' && x.status === 'live'), 'game kedua ikut ruang yang sama (status langsung live)');
  last.emit('chat', mk('c9', { comment: 'untuk dua game' })); await sleep(50);
  check(got2.some(x => x.type === 'chat') && find('chat', x => x.text === 'untuk dua game').length === 1, 'event sampai ke dua game');
  ws2.close();

  // ---- akun belum live -> offline lalu otomatis konek saat sudah live
  live = false;
  const ws3 = new WebSocket(url); await new Promise(r => ws3.on('open', r));
  const got3 = []; ws3.on('message', m => got3.push(JSON.parse(m.toString())));
  ws3.send(JSON.stringify({ type: 'host_start', tiktok: 'belumlive' }));
  await sleep(300);
  check(got3.some(x => x.type === 'host_status' && x.status === 'offline' && /belum live/.test(x.message)), 'akun belum live -> status offline');
  ws3.send(JSON.stringify({ type: 'host_stop' })); await sleep(50);
  check(got3.some(x => x.status === 'stopped'), 'host_stop -> stopped');

  // ---- putus dari TikTok -> status connecting lalu live lagi
  live = true; got.length = 0;
  OrigNew.emit('disconnected');
  await sleep(100);
  check(find('host_status', x => x.status === 'connecting').length >= 1, 'terputus -> status menyambung ulang');

  ws.close(); srv.close();
  console.log('\n' + pass + ' PASS, ' + fail + ' FAIL');
  process.exit(fail ? 1 : 0);
})().catch(e => { console.error(e); process.exit(1); });
