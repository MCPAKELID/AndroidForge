#!/usr/bin/env node
/*
 * Block Rush Live - Jembatan TikTok LIVE
 * Hak Cipta (c) 2026 MCPAKEL. Semua hak dilindungi.
 * Hanya untuk game Block Rush Live.
 */
'use strict';
const major = Number(process.versions.node.split('.')[0]);
if (!Number.isFinite(major) || major < 20) {
  console.error('\nBlock Rush Bridge butuh Node.js 20 atau lebih baru. Sekarang: ' + process.versions.node);
  console.error('Disarankan Node.js 22 LTS.\n');
  process.exit(1);
}
const { start, loadEnv } = require('./bridge');
loadEnv(require('path').join(__dirname, '.env'));
const mod = require('tiktok-live-connector');
const TikTokLiveConnection = mod.TikTokLiveConnection || (mod.default && mod.default.TikTokLiveConnection);
if (!TikTokLiveConnection) { console.error('tiktok-live-connector tidak ditemukan. Jalankan: npm install'); process.exit(1); }
start({
  ConnectionClass: TikTokLiveConnection,
  port: Number(process.env.PORT || process.env.WS_PORT || 25601),
  apiKey: (process.env.TIKTOK_API_KEY || '').trim(),
  debug: ['1', 'true', 'ya'].includes(String(process.env.DEBUG || '').toLowerCase())
});
