# Block Rush Bridge

Jembatan TikTok LIVE **khusus game Block Rush Live**. Game tidak bisa membaca TikTok langsung,
jadi file ini menjalankan koneksi TikTok lalu meneruskan gift, like, follow, share, komentar,
dan penonton masuk ke game lewat WebSocket.

Tidak ada fitur lain di sini (tanpa Minecraft, WhatsApp, atau dashboard). Hanya jembatan ke game.

## Cara pakai

1. Pasang Node.js 20 atau lebih baru (disarankan 22). Di Termux: `pkg install nodejs`.
2. Di folder ini jalankan sekali: `npm install`
3. Jalankan: `npm start`
4. Layar akan menampilkan alamat, misalnya `Host 192.168.1.5  Port 25601`.
5. Di game: menu **TIKTOK LIVE** -> mode **JEMBATAN** -> isi Host, Port, dan username TikTok yang sedang live -> **HUBUNGKAN**.
   - Game dan bridge di satu HP (Termux): Host `127.0.0.1`.
   - Bridge di PC / HP lain: pakai IP yang tampil di layar (harus satu Wi-Fi).

Pengaturan opsional ada di file `.env` (salin dari `.env.example`): `PORT`, `TIKTOK_API_KEY`, `DEBUG`.

## Yang dilakukan bridge

- Nama penonton dibaca dari semua bentuk data TikTok (connector baru dan lama). Kalau TikTok memang tidak memberi nama, ditulis `Penonton`, bukan `anonymous`.
- Gift beruntun (Rose x1, x2, x3...) dihitung selisihnya saja, jadi tidak dihitung dobel.
- Follow dan join hanya dikirim sekali per orang per sesi live; share dibatasi 5 detik per orang.
- Dua game bisa ikut akun TikTok yang sama tanpa koneksi ganda ke TikTok.
- Kalau akun belum live, bridge mencoba lagi otomatis dan game ikut tersambung begitu live dimulai.
- Buka `http://<alamat-bridge>:25601` di browser untuk cek status.

## Kalau nama masih kosong

Isi `DEBUG=1` di `.env`, jalankan ulang, lalu kirim baris `[DEBUG] nama kosong...` yang muncul agar bentuk datanya bisa dicek.

## Tes tanpa internet

`npm test` (memakai connector TikTok palsu, 30 pengecekan).

Hak Cipta (c) 2026 MCPAKEL. Semua hak dilindungi.
