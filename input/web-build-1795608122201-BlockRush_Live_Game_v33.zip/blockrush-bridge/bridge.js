/*
 * Block Rush Live - Jembatan TikTok LIVE (logika)
 * Hak Cipta (c) 2026 MCPAKEL. Semua hak dilindungi.
 *
 * Protokol (sama dengan yang dipakai game, mode JEMBATAN):
 *   game -> bridge : {type:"subscribe",tiktok:"user"} , {type:"host_start",tiktok:"user"} , {type:"host_stop"} , {type:"ping"}
 *   bridge -> game : host_status / viewers / gift / like / follow / share / join / chat / subscribe
 */
'use strict';
const http = require('http');
const os = require('os');
const fs = require('fs');
const WebSocket = require('ws');

// ---------------------------------------------------------------- util
function loadEnv(file) {
  try {
    for (const line of fs.readFileSync(file, 'utf8').split(/\r?\n/)) {
      const m = line.match(/^\s*([A-Za-z_][A-Za-z0-9_]*)\s*=\s*(.*?)\s*$/);
      if (m && process.env[m[1]] === undefined) process.env[m[1]] = m[2].replace(/^["']|["']$/g, '');
    }
  } catch (_) { /* tidak ada .env, tidak masalah */ }
}

const log = (...a) => console.log(new Date().toLocaleTimeString('id-ID'), ...a);
const str = v => (v === undefined || v === null || typeof v === 'object') ? '' : String(v).trim();
const num = v => { const n = Number(v); return Number.isFinite(n) ? n : 0; };
const isObj = v => v && typeof v === 'object' && !Array.isArray(v);

// Nama pengguna: connector v2 menaruhnya di data.user.{uniqueId,nickname}, versi lama di data.{uniqueId,nickname}.
// Dicari di semua tempat yang mungkin supaya tidak pernah jatuh ke "anonymous".
const UID_KEYS = ['uniqueId', 'unique_id', 'displayId', 'display_id', 'username', 'userName'];
const NICK_KEYS = ['nickname', 'nickName', 'nick_name', 'displayName', 'display_name'];
const ID_KEYS = ['userId', 'user_id', 'idStr', 'id_str'];
function pick(o, keys) { for (const k of keys) { const v = str(o[k]); if (v && v.toLowerCase() !== 'anonymous') return v; } return ''; }

function userOf(d) {
  const out = { uniqueId: '', nickname: '', userId: '' };
  const fill = o => {
    if (!isObj(o)) return;
    if (!out.uniqueId) out.uniqueId = pick(o, UID_KEYS);
    if (!out.nickname) out.nickname = pick(o, NICK_KEYS);
    if (!out.userId) out.userId = pick(o, ID_KEYS);
  };
  if (!isObj(d)) return out;
  if (typeof d.user === 'string') out.uniqueId = d.user.trim();
  for (const k of ['user', 'userInfo', 'userDetails', 'sender', 'fromUser']) fill(d[k]);
  fill(d);
  if (!out.uniqueId && !out.nickname) {          // cari lebih dalam (maks 4 tingkat), lewati penerima gift
    const seen = new Set();
    const walk = (o, depth) => {
      if (!isObj(o) || depth > 4 || seen.has(o) || out.uniqueId || out.nickname) return;
      seen.add(o);
      fill(o);
      for (const [k, v] of Object.entries(o)) if (k !== 'toUser' && k !== 'receiver') walk(v, depth + 1);
    };
    walk(d, 0);
  }
  return out;
}
function nameOf(u) { return u.uniqueId || u.nickname || 'Penonton'; }

function commentOf(d) {
  for (const k of ['comment', 'message', 'content', 'text']) {
    const v = d && d[k];
    if (typeof v === 'string' && v.trim()) return v;
  }
  for (const c of [d && d.data, d && d.message, d && d.comment]) {
    if (isObj(c)) for (const k of ['comment', 'message', 'content', 'text']) if (typeof c[k] === 'string' && c[k].trim()) return c[k];
  }
  return '';
}

function eventId(d) {
  const c = (d && d.common) || {};
  return str(d && (d.msgId || d.messageId || d.eventId)) || str(c.msgId) || str(c.eventId);
}

function urlOf(v, depth = 0) {
  if (!v || depth > 3) return '';
  if (typeof v === 'string') return /^https?:\/\//.test(v) ? v : '';
  if (Array.isArray(v)) { for (const x of v) { const r = urlOf(x, depth + 1); if (r) return r; } return ''; }
  if (isObj(v)) {
    for (const k of ['giftPictureUrl', 'url', 'imageUrl', 'urlList', 'url_list']) { const r = urlOf(v[k], depth + 1); if (r) return r; }
  }
  return '';
}

function giftOf(d) {
  const det = isObj(d.giftDetails) ? d.giftDetails : isObj(d.gift) ? d.gift : isObj(d.extendedGiftInfo) ? d.extendedGiftInfo : {};
  const id = num(d.giftId || det.id || det.giftId);
  const name = str(d.giftName) || str(det.giftName) || str(det.name) || str(d.extendedGiftInfo && d.extendedGiftInfo.name) || (id ? 'Gift ' + id : 'Gift');
  const coin = num(det.diamondCount || det.diamond_count || d.diamondCount || (d.extendedGiftInfo && d.extendedGiftInfo.diamond_count));
  const type = num(det.giftType || det.type || d.giftType);
  const pic = urlOf(det.giftImage) || urlOf(det.image) || urlOf(det.icon) || urlOf(d.giftPictureUrl) || urlOf(d.extendedGiftInfo && d.extendedGiftInfo.image);
  return { id, name, coin, type, pic };
}

// ---------------------------------------------------------------- satu ruang = satu akun TikTok
class Room {
  constructor(hub, tiktok) {
    this.hub = hub; this.tiktok = tiktok;
    this.clients = new Set();
    this.status = 'connecting'; this.message = '';
    this.conn = null; this.timer = null; this.idle = null; this.closed = false;
    this.delay = 5000;
    this.followed = new Set(); this.joined = new Set(); this.subscribed = new Set();
    this.shares = new Map(); this.streaks = new Map(); this.seen = new Map();
    this.likes = 0;
  }
  broadcast(type, data = {}) {
    const msg = JSON.stringify({ type, event: type, tiktok: this.tiktok, ...data });
    for (const ws of this.clients) if (ws.readyState === WebSocket.OPEN) { try { ws.send(msg); } catch (_) { } }
  }
  setStatus(status, message = '', extra = {}) {
    this.status = status; this.message = message;
    this.broadcast('host_status', { status, live: status === 'live', message, ...extra });
  }
  sendStatusTo(ws) {
    try { ws.send(JSON.stringify({ type: 'host_status', event: 'host_status', tiktok: this.tiktok, status: this.status, live: this.status === 'live', message: this.message })); } catch (_) { }
  }
  dup(type, d, ttl = 120000) {
    const id = eventId(d); if (!id) return false;
    const now = Date.now(), k = type + ':' + id;
    for (const [key, exp] of this.seen) if (exp <= now) this.seen.delete(key);
    if (this.seen.has(k)) return true;
    this.seen.set(k, now + ttl);
    if (this.seen.size > 4000) this.seen.delete(this.seen.keys().next().value);
    return false;
  }

  async start() {
    if (this.closed) return;
    clearTimeout(this.timer);
    this.setStatus('connecting', 'Menghubungkan ke @' + this.tiktok);
    const conn = new this.hub.ConnectionClass(this.tiktok, {
      processInitialData: false,
      ...(this.hub.apiKey ? { signApiKey: this.hub.apiKey } : {})
    });
    this.conn = conn;
    this.wire(conn);
    let t;
    try {
      await Promise.race([conn.connect(), new Promise((_, rej) => { t = setTimeout(() => rej(new Error('Timeout koneksi TikTok (20 detik)')), 20000); })]);
      clearTimeout(t);
      if (this.closed || this.conn !== conn) return;
      this.delay = 5000;
      this.setStatus('live', '@' + this.tiktok);
      log('LIVE terhubung: @' + this.tiktok);
    } catch (e) {
      clearTimeout(t);
      if (this.closed || this.conn !== conn) return;
      const why = (e && e.message) || String(e);
      const offline = /offline|not (currently )?live|isn'?t online|not online|room id|no live/i.test(why) || /UserOffline/i.test((e && e.name) || '');
      this.kill(conn);
      log((offline ? '@' + this.tiktok + ' belum live: ' : 'Gagal konek: ') + why);
      this.setStatus(offline ? 'offline' : 'error', offline ? '@' + this.tiktok + ' belum live' : why);
      this.retry(offline ? 10000 : this.delay);
      this.delay = Math.min(30000, this.delay + 5000);
    }
  }
  kill(conn) {
    if (!conn) return;
    try { conn.removeAllListeners && conn.removeAllListeners(); } catch (_) { }
    try { conn.on && conn.on('error', () => { }); } catch (_) { }
    try { conn.disconnect && conn.disconnect(); } catch (_) { }
    if (this.conn === conn) this.conn = null;
  }
  retry(ms) {
    clearTimeout(this.timer);
    if (this.closed) return;
    this.timer = setTimeout(() => this.start(), ms);
  }
  stop() {
    this.closed = true; clearTimeout(this.timer); clearTimeout(this.idle);
    this.kill(this.conn);
  }

  wire(c) {
    const on = (name, fn) => c.on(name, d => { if (this.conn !== c || this.closed) return; try { fn(d || {}); } catch (e) { log('Error handler ' + name + ':', e.message); } });
    const who = d => { const u = userOf(d); if (this.hub.debug && !u.uniqueId && !u.nickname) log('[DEBUG] nama kosong, data mentah:', JSON.stringify(d).slice(0, 800)); return { u, username: nameOf(u), extra: { uniqueId: u.uniqueId, nickname: u.nickname, userId: u.userId } }; };
    const dbg = (n, d) => { if (this.hub.debug) log('[DEBUG]', n, JSON.stringify(d).slice(0, 1200)); };

    on('chat', d => {
      dbg('chat', d);
      if (this.dup('chat', d)) return;
      const w = who(d), text = commentOf(d);
      this.broadcast('chat', { username: w.username, ...w.extra, message: text, comment: text, text });
    });
    on('gift', d => { dbg('gift', d); this.gift(d, who(d)); });
    on('like', d => {
      dbg('like', d);
      if (this.dup('like', d)) return;
      const w = who(d), count = Math.max(1, num(d.likeCount) || num(d.count) || 1);
      this.likes += count;
      this.broadcast('like', { username: w.username, ...w.extra, count, likeCount: count, totalLikes: this.likes });
    });
    on('follow', d => {
      dbg('follow', d);
      if (this.dup('follow', d)) return;
      const w = who(d), key = (w.u.userId || w.u.uniqueId || w.u.nickname).toLowerCase();
      if (key) { if (this.followed.has(key)) return; this.followed.add(key); }
      this.broadcast('follow', { username: w.username, ...w.extra });
    });
    on('share', d => {
      dbg('share', d);
      if (this.dup('share', d)) return;
      const w = who(d), key = (w.u.userId || w.u.uniqueId || w.u.nickname).toLowerCase(), now = Date.now();
      if (key) { if (now - (this.shares.get(key) || 0) < 5000) return; this.shares.set(key, now); }
      this.broadcast('share', { username: w.username, ...w.extra });
    });
    on('member', d => {
      if (this.dup('join', d)) return;
      const w = who(d), key = (w.u.userId || w.u.uniqueId || w.u.nickname).toLowerCase();
      if (key) { if (this.joined.has(key)) return; this.joined.add(key); }
      this.broadcast('join', { username: w.username, ...w.extra });
    });
    on('subscribe', d => {
      if (this.dup('subscribe', d)) return;
      const w = who(d), key = (w.u.userId || w.u.uniqueId || w.u.nickname).toLowerCase();
      if (key) { if (this.subscribed.has(key)) return; this.subscribed.add(key); }
      this.broadcast('subscribe', { username: w.username, ...w.extra });
    });
    on('roomUser', d => { const v = num(d.viewerCount); if (v > 0) this.broadcast('viewers', { viewerCount: v, count: v }); });
    on('streamEnd', () => {
      log('Live @' + this.tiktok + ' selesai.');
      this.followed.clear(); this.joined.clear(); this.subscribed.clear(); this.streaks.clear();
      const dead = this.conn; this.kill(dead);
      this.setStatus('offline', '@' + this.tiktok + ' live selesai');
      this.retry(10000);
    });
    c.on('disconnected', () => {
      if (this.conn !== c || this.closed) return;
      log('Terputus dari TikTok, mencoba lagi...');
      this.kill(c);
      this.setStatus('connecting', 'Terputus, menyambung ulang...');
      this.retry(this.delay);
    });
    c.on('error', e => { if (this.conn === c && !this.closed) { log('Error TikTok:', (e && e.message) || e); if (this.hub.debug) this.broadcast('host_status', { status: this.status, live: this.status === 'live', message: String((e && e.message) || e) }); } });
  }

  gift(d, w) {
    if (this.dup('gift', d)) return;
    const g = giftOf(d);
    const repeat = Math.max(1, num(d.repeatCount) || 1);
    const end = d.repeatEnd === true || d.repeatEnd === 1 || d.repeatEnd === 'true';
    let count = repeat;
    if (g.type === 1) {                       // gift beruntun: repeatCount naik 1,2,3... -> hanya bagian barunya
      const key = (w.u.userId || w.username) + '|' + (g.id || g.name) + '|' + str(d.groupId || d.giftGroupId);
      const now = Date.now();
      for (const [k, s] of this.streaks) if (now - s.t > 30000) this.streaks.delete(k);
      const last = this.streaks.get(key);
      count = last && repeat >= last.n ? repeat - last.n : repeat;
      if (end) this.streaks.delete(key); else this.streaks.set(key, { n: repeat, t: now });
      if (count <= 0) return;
    }
    log('GIFT ' + w.username + ' -> ' + g.name + ' x' + count);
    this.broadcast('gift', {
      username: w.username, ...w.extra, giftName: g.name, giftId: g.id,
      count, repeatCount: count, coin: g.coin, diamondCount: g.coin, totalCoin: g.coin * count,
      giftPictureUrl: g.pic
    });
  }
}

// ---------------------------------------------------------------- server
function start(opts) {
  const hub = {
    ConnectionClass: opts.ConnectionClass, apiKey: opts.apiKey || '', debug: !!opts.debug,
    rooms: new Map()
  };
  const server = http.createServer((req, res) => {
    res.writeHead(200, { 'Content-Type': 'text/plain; charset=utf-8' });
    const rows = [...hub.rooms.values()].map(r => '@' + r.tiktok + ' : ' + r.status + ' (' + r.clients.size + ' game)');
    res.end('Block Rush Bridge aktif.\n' + (rows.length ? rows.join('\n') : 'Belum ada game yang tersambung.') + '\n');
  });
  const wss = new WebSocket.Server({ server });

  const leave = ws => {
    const r = ws.room; ws.room = null;
    if (!r) return;
    r.clients.delete(ws);
    if (r.clients.size === 0) {
      clearTimeout(r.idle);
      r.idle = setTimeout(() => { if (r.clients.size === 0) { r.stop(); hub.rooms.delete(r.tiktok.toLowerCase()); log('Ruang @' + r.tiktok + ' ditutup.'); } }, 15000);
    }
  };
  const join = (ws, tiktok) => {
    tiktok = String(tiktok || '').replace(/^@/, '').trim();
    if (!tiktok) { ws.send(JSON.stringify({ type: 'host_status', event: 'host_status', status: 'error', live: false, message: 'Username TikTok kosong.' })); return; }
    if (ws.room && ws.room.tiktok.toLowerCase() === tiktok.toLowerCase()) { ws.room.sendStatusTo(ws); return; }
    leave(ws);
    const key = tiktok.toLowerCase();
    let r = hub.rooms.get(key);
    if (!r || r.closed) { r = new Room(hub, tiktok); hub.rooms.set(key, r); r.clients.add(ws); ws.room = r; r.start(); }
    else { clearTimeout(r.idle); r.clients.add(ws); ws.room = r; r.sendStatusTo(ws); }
    log('Game bergabung ke @' + tiktok + ' (' + r.clients.size + ' game)');
  };

  wss.on('connection', (ws, req) => {
    ws.isAlive = true; ws.room = null; ws.wantUser = '';
    log('Game tersambung dari ' + (req.socket.remoteAddress || '?').replace('::ffff:', ''));
    ws.on('pong', () => { ws.isAlive = true; });
    ws.on('message', raw => {
      let m; try { m = JSON.parse(raw.toString()); } catch (_) { return; }
      const t = String(m.type || m.event || '').toLowerCase();
      if (t === 'ping') ws.send(JSON.stringify({ type: 'pong', event: 'pong', timestamp: Date.now() }));
      else if (t === 'subscribe') { if (m.tiktok) ws.wantUser = String(m.tiktok); ws.send(JSON.stringify({ type: 'subscribed', event: 'subscribed' })); }
      else if (t === 'host_start') join(ws, m.tiktok || ws.wantUser);
      else if (t === 'host_stop') { leave(ws); ws.send(JSON.stringify({ type: 'host_status', event: 'host_status', status: 'stopped', live: false })); }
    });
    ws.on('close', () => leave(ws));
    ws.on('error', () => { });
  });
  const hb = setInterval(() => {
    for (const ws of wss.clients) { if (!ws.isAlive) { ws.terminate(); continue; } ws.isAlive = false; try { ws.ping(); } catch (_) { } }
  }, 25000);
  if (hb.unref) hb.unref();

  const port = opts.port;
  return new Promise(resolve => {
    server.listen(port, '0.0.0.0', () => {
      const p = server.address().port;
      if (!opts.quiet) {
        console.log('\n=== BLOCK RUSH BRIDGE ===');
        console.log('Di game: menu TIKTOK LIVE -> mode JEMBATAN, isi Host dan Port:');
        const ips = [];
        for (const list of Object.values(os.networkInterfaces())) for (const i of list || []) if (i.family === 'IPv4' && !i.internal) ips.push(i.address);
        for (const ip of ips) console.log('   Host ' + ip + '   Port ' + p);
        console.log('   (satu HP/Termux: Host 127.0.0.1   Port ' + p + ')');
        console.log('Menunggu game tersambung...\n');
      }
      resolve({ server, wss, hub, port: p, close() { for (const r of hub.rooms.values()) r.stop(); clearInterval(hb); wss.clients.forEach(c => c.terminate()); server.close(); } });
    });
  });
}

module.exports = { start, loadEnv, userOf, nameOf, giftOf, commentOf, Room };
