/*
 * Block Rush Live Game
 * Hak Cipta (c) 2026 MCPAKEL. Semua hak dilindungi.
 * Copyright (c) 2026 MCPAKEL. All rights reserved.
 */
package com.mcpakel.blockarea;

import android.content.Context;
import android.content.SharedPreferences;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.Map;

/**
 * Update notice. Fetches a small JSON file (AppConfig.UPDATE_URL):
 * {"versionCode":33,"versionName":"3.3","url":"https://...apk","notes":"Yang baru...","force":false}
 * and shows a banner in the menu when versionCode is higher than the installed one.
 */
final class UpdateChecker {
    static final class Info {
        int code; String name = "", url = "", notes = ""; boolean force;
    }

    private final SharedPreferences prefs;
    private final int installed;
    private volatile Info info;

    UpdateChecker(Context c) {
        SharedPreferences p = null;
        try { p = c.getSharedPreferences("blockrush_update", Context.MODE_PRIVATE); } catch (Throwable ignored) { }
        prefs = p;
        installed = Platform.versionCode(c);
        if (prefs != null) {
            Info i = new Info();
            i.code = prefs.getInt("upd_code", 0);
            i.name = prefs.getString("upd_name", "");
            i.url = prefs.getString("upd_url", "");
            i.notes = prefs.getString("upd_notes", "");
            i.force = prefs.getBoolean("upd_force", false);
            if (i.code > 0) info = i;
        }
    }

    static boolean isNewer(Info i, int installedCode) { return i != null && i.code > installedCode && installedCode > 0; }

    /** null when the text is not a valid update file. */
    static Info parse(String json) {
        try {
            Object o = new LiveClient.Json(json).read();
            if (!(o instanceof Map)) return null;
            Map<?, ?> m = (Map<?, ?>) o;
            Info i = new Info();
            Object vc = m.get("versionCode");
            if (vc instanceof Number) i.code = ((Number) vc).intValue();
            else if (vc != null) i.code = Integer.parseInt(String.valueOf(vc).trim());
            if (i.code <= 0) return null;
            i.name = str(m.get("versionName"), 16);
            i.notes = str(m.get("notes"), 400);
            String u = str(m.get("url"), 300);
            i.url = (u.startsWith("https://") || u.startsWith("http://")) ? u : "";
            i.force = Boolean.TRUE.equals(m.get("force"));
            return i;
        } catch (Exception e) { return null; }
    }

    private static String str(Object o, int max) {
        String s = o == null ? "" : String.valueOf(o).trim();
        return s.length() > max ? s.substring(0, max) : s;
    }

    static String fetch(String url) throws Exception {
        HttpURLConnection c = (HttpURLConnection) new URL(url).openConnection();
        c.setConnectTimeout(6000);
        c.setReadTimeout(6000);
        c.setRequestProperty("Cache-Control", "no-cache");
        try {
            if (c.getResponseCode() != 200) throw new Exception("HTTP " + c.getResponseCode());
            InputStream in = c.getInputStream();
            ByteArrayOutputStream bo = new ByteArrayOutputStream();
            byte[] b = new byte[2048]; int n;
            while ((n = in.read(b)) > 0 && bo.size() < 65536) bo.write(b, 0, n);
            return new String(bo.toByteArray(), "UTF-8");
        } finally { c.disconnect(); }
    }

    /** One quiet background check per start; offline or a bad file simply changes nothing. */
    void refreshAsync() {
        final String url = AppConfig.UPDATE_URL;
        if (url == null || url.length() == 0) return;
        Thread t = new Thread(new Runnable() {
            @Override public void run() {
                try {
                    Info i = parse(fetch(url));
                    if (i == null) return;
                    info = i;
                    if (prefs != null) prefs.edit().putInt("upd_code", i.code).putString("upd_name", i.name).putString("upd_url", i.url)
                            .putString("upd_notes", i.notes).putBoolean("upd_force", i.force).apply();
                } catch (Throwable ignored) { }
            }
        }, "update-check");
        t.setDaemon(true);
        t.start();
    }

    /** Test hook: use this info as if it had been fetched. */
    void setInfo(Info i) { info = i; }

    Info info() { return info; }

    boolean pending() {
        Info i = info;
        if (!isNewer(i, installed)) return false;
        if (i.force) return true;
        return prefs == null || prefs.getInt("upd_dismiss", 0) < i.code;
    }

    void dismiss() {
        Info i = info;
        if (i != null && prefs != null) prefs.edit().putInt("upd_dismiss", i.code).apply();
    }
}
