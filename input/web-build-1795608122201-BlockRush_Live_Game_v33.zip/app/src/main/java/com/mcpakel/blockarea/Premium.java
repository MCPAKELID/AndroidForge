/*
 * Block Rush Live Game
 * Hak Cipta (c) 2026 MCPAKEL. Semua hak dilindungi.
 * Copyright (c) 2026 MCPAKEL. All rights reserved.
 */
package com.mcpakel.blockarea;

import android.content.Context;
import android.content.SharedPreferences;

import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.UUID;
import javax.crypto.Mac;
import javax.crypto.spec.SecretKeySpec;

/**
 * Premium per HP. Pembeli mengirim "ID perangkat" (XXXX-XXXX-XXXX), penjual membuat kunci dengan
 * tools/keygen.js, pembeli memasukkan kunci (XXXX-XXXX-XXXX-XXXX). Kunci hanya berlaku di HP itu.
 * Ganti rahasia sebelum jual: node tools/set_secret.js RAHASIAMU
 */
final class Premium {
    // SECRET-BEGIN
    private static final int[] S = {107, 18, 1, 13, 15, 76, 67, 5, 56, 86, 76, 37, 55, 105, 86, 123, 94, 73, 117, 187, 190, 158, 165, 203, 190, 152, 185, 222, 166, 220, 249, 211};
    // SECRET-END
    private static final int MASK = 0x5A;
    private static final String B32 = "0123456789ABCDEFGHJKMNPQRSTVWXYZ";

    private final SharedPreferences prefs;
    private final String id;
    private boolean on;

    Premium(Context c) {
        SharedPreferences p = null;
        try { p = c.getSharedPreferences("blockrush_premium", Context.MODE_PRIVATE); } catch (Throwable ignored) { }
        prefs = p;
        String aid = Platform.androidId(c);
        if (aid == null || aid.trim().length() < 8 || aid.equals("9774d56d682e549c")) {
            aid = prefs == null ? "" : prefs.getString("prem_iid", "");
            if (aid.length() < 8) {
                aid = UUID.randomUUID().toString();
                if (prefs != null) prefs.edit().putString("prem_iid", aid).apply();
            }
        }
        id = idFor(aid);
        on = prefs != null && verify(id, prefs.getString("prem_key", ""));
    }

    boolean isOn() { return on; }
    String deviceId() { return id; }

    /** Returns true and unlocks premium when the key belongs to this phone. */
    boolean activate(String key) {
        if (!verify(id, key)) return false;
        on = true;
        if (prefs != null) prefs.edit().putString("prem_key", normalize(key)).apply();
        return true;
    }

    /** Effects that need premium (the big ones). */
    static boolean locked(int effect) {
        return effect == GameSettings.E_TORNADO || effect == GameSettings.E_ROBOT || effect == GameSettings.E_MONSTER
                || effect == GameSettings.E_MISSILE || effect == GameSettings.E_THROWER || effect == GameSettings.E_BOSS
                || effect == GameSettings.E_DRILL;
    }

    // ---- ID and key (the same maths as tools/keygen.js) --------------------------------------
    static String idFor(String androidId) {
        try {
            MessageDigest md = MessageDigest.getInstance("SHA-256");
            byte[] h = md.digest((androidId + "|BlockRush").getBytes(StandardCharsets.UTF_8));
            StringBuilder sb = new StringBuilder();
            for (int i = 0; i < 6; i++) sb.append(String.format("%02X", h[i] & 255));
            String s = sb.toString();
            return s.substring(0, 4) + "-" + s.substring(4, 8) + "-" + s.substring(8, 12);
        } catch (Exception e) { return "0000-0000-0000"; }
    }

    private static String secret() {
        char[] c = new char[S.length];
        for (int i = 0; i < S.length; i++) c[i] = (char) (S[i] ^ MASK ^ ((i * 7) & 255));
        return new String(c);
    }

    static String keyFor(String deviceId) {
        try {
            String raw = deviceId.toUpperCase().replaceAll("[^0-9A-Z]", "");
            Mac mac = Mac.getInstance("HmacSHA256");
            mac.init(new SecretKeySpec(secret().getBytes(StandardCharsets.UTF_8), "HmacSHA256"));
            byte[] d = mac.doFinal(("BR1|" + raw).getBytes(StandardCharsets.UTF_8));
            StringBuilder sb = new StringBuilder();
            long buf = 0; int bits = 0;
            for (int i = 0; i < 10; i++) {
                buf = (buf << 8) | (d[i] & 255); bits += 8;
                while (bits >= 5) { sb.append(B32.charAt((int) ((buf >> (bits - 5)) & 31))); bits -= 5; }
            }
            String k = sb.toString();
            return k.substring(0, 4) + "-" + k.substring(4, 8) + "-" + k.substring(8, 12) + "-" + k.substring(12, 16);
        } catch (Exception e) { return ""; }
    }

    /** Upper case, no spaces or dashes; O -> 0 and I/L -> 1 (typing mistakes). */
    static String normalize(String key) {
        if (key == null) return "";
        String s = key.toUpperCase().replaceAll("[^0-9A-Z]", "").replace('O', '0').replace('I', '1').replace('L', '1');
        if (s.length() != 16) return s;
        return s.substring(0, 4) + "-" + s.substring(4, 8) + "-" + s.substring(8, 12) + "-" + s.substring(12, 16);
    }

    static boolean verify(String deviceId, String key) {
        String n = normalize(key);
        if (n.length() != 19) return false;
        String want = keyFor(deviceId);
        if (want.length() != 19) return false;
        int diff = 0;
        for (int i = 0; i < 19; i++) diff |= n.charAt(i) ^ want.charAt(i);
        return diff == 0;
    }
}
