/*
 * Block Rush Live Game
 * Hak Cipta (c) 2026 MCPAKEL. Semua hak dilindungi.
 * Copyright (c) 2026 MCPAKEL. All rights reserved.
 */
package com.mcpakel.blockarea;

/** Pengaturan penjual. Kosong = fitur tidak aktif. */
final class AppConfig {
    /** Alamat file JSON update (lihat tools/update.json). Kosong = notif update mati. */
    static final String UPDATE_URL = "";
    /** Alamat beli / kontak penjual, mis. https://wa.me/628xxxx. Kosong = tombol BELI tidak tampil. */
    static final String BUY_URL = "";

    private AppConfig() { }
}
