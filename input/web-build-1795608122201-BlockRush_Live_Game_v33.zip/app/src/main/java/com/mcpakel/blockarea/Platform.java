/*
 * Block Rush Live Game
 * Hak Cipta (c) 2026 MCPAKEL. Semua hak dilindungi.
 * Copyright (c) 2026 MCPAKEL. All rights reserved.
 */
package com.mcpakel.blockarea;

import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageInfo;
import android.provider.Settings;

/** Small Android helpers (all safe: they never throw). */
final class Platform {
    private Platform() { }

    static String androidId(Context c) {
        try { return Settings.Secure.getString(c.getContentResolver(), Settings.Secure.ANDROID_ID); }
        catch (Throwable t) { return ""; }
    }

    @SuppressWarnings("deprecation")
    static int versionCode(Context c) {
        try {
            PackageInfo pi = c.getPackageManager().getPackageInfo(c.getPackageName(), 0);
            return pi.versionCode;
        } catch (Throwable t) { return 0; }
    }

    static boolean copy(Context c, String label, String text) {
        try {
            ClipboardManager cm = (ClipboardManager) c.getSystemService(Context.CLIPBOARD_SERVICE);
            cm.setPrimaryClip(ClipData.newPlainText(label, text));
            return true;
        } catch (Throwable t) { return false; }
    }

    static void share(Context c, String title, String text) {
        try {
            Intent send = new Intent(Intent.ACTION_SEND);
            send.setType("text/plain");
            send.putExtra(Intent.EXTRA_TEXT, text);
            Intent ch = Intent.createChooser(send, title);
            ch.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            c.startActivity(ch);
        } catch (Throwable ignored) { }
    }
}
