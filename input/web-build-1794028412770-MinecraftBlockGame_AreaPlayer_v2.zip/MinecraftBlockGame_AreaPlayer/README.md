# Minecraft Block Game - Area + Player

Android Native Java project for AndroidForge.

## This stage
- Uses the exact supplied arena reference image as the arena artwork.
- Arena artwork is a separate asset: `app/src/main/assets/area/arena_reference.jpg`.
- The control deck is separate below the arena frame.
- Uses your supplied Steve sprite sheet, split into 15 transparent PNGs:
  - `walk_0.png` ... `walk_4.png`
  - `run_0.png` ... `run_4.png`
  - `jump_0.png` ... `jump_4.png`
- Left/right movement, sprint and jump buttons.
- Supports multi-touch so direction + jump/sprint can be held together.
- Grid remains empty. No block placement, inventory, level system or HUD yet.

## Build in AndroidForge
1. Extract the ZIP.
2. Open the `MinecraftBlockGame_AreaPlayer` folder as an Android Gradle project.
3. Use JDK 17 and Android SDK Platform 35.
4. Build the `app` module.

Application ID: `com.mcpakel.blockarea`
No WebView and no external libraries.
