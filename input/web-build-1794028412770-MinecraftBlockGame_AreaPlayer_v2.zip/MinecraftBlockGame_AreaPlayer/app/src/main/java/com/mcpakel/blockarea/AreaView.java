package com.mcpakel.blockarea;

import android.content.Context;
import android.graphics.*;
import android.view.MotionEvent;
import android.view.View;
import java.io.IOException;

/**
 * Area + player prototype.
 * The supplied arena reference is used as the actual arena artwork.
 * Sprite-sheet frames are separate PNG assets in assets/character/.
 */
public class AreaView extends View {
    private final Paint p = new Paint();
    private final Bitmap[][] frames = new Bitmap[3][5]; // walk, run, jump
    private Bitmap arenaBitmap;

    private static final float W = 864f, H = 1920f;
    private static final float ARENA_H = 1536f;
    private static final float PLAYER_GROUND = 1410f;

    private float playerX = 220f;
    private float playerY = PLAYER_GROUND;
    private float velocityY = 0f;
    private boolean leftPressed, rightPressed, runPressed, jumpPressed;
    private boolean facingRight = true;
    private boolean onGround = true;
    private long lastTime = 0L;
    private float animationClock = 0f;
    private int action = 0; // 0 walk/idle, 1 run, 2 jump
    private int walkFrame = 0, runFrame = 0, jumpFrame = 0;
    private final RectF target = new RectF();

    private final RectF leftButton  = new RectF(58, 1590, 178, 1710);
    private final RectF rightButton = new RectF(198, 1590, 318, 1710);
    private final RectF runButton   = new RectF(338, 1590, 458, 1710);
    private final RectF jumpButton  = new RectF(630, 1570, 810, 1740);

    public AreaView(Context context) {
        super(context);
        setLayerType(View.LAYER_TYPE_SOFTWARE, null);
        loadAssets(context);
    }

    private void loadAssets(Context context) {
        try {
            arenaBitmap = BitmapFactory.decodeStream(
                    context.getAssets().open("area/arena_reference.jpg"));
        } catch (IOException ignored) { }
        String[] actions = {"walk", "run", "jump"};
        for (int a = 0; a < actions.length; a++) {
            for (int i = 0; i < 5; i++) {
                try {
                    frames[a][i] = BitmapFactory.decodeStream(context.getAssets().open(
                            "character/" + actions[a] + "_" + i + ".png"));
                } catch (IOException ignored) { }
            }
        }
    }

    @Override protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        float scale = Math.min(getWidth() / W, getHeight() / H);
        float ox = (getWidth() - W * scale) / 2f;
        float oy = (getHeight() - H * scale) / 2f;
        canvas.save();
        canvas.translate(ox, oy);
        canvas.scale(scale, scale);

        drawArena(canvas);
        drawPlayer(canvas);
        drawControlDeck(canvas);

        canvas.restore();
        updatePlayer();
        postInvalidateDelayed(16);
    }

    private void drawArena(Canvas c) {
        if (arenaBitmap != null) {
            p.setAlpha(255);
            p.setFilterBitmap(false);
            // Exact supplied arena artwork, kept separate from the control deck.
            c.drawBitmap(arenaBitmap, null, new RectF(0, 0, W, ARENA_H), p);
        } else {
            p.setColor(Color.rgb(24, 27, 32));
            c.drawRect(0, 0, W, ARENA_H, p);
        }
    }

    private void drawPlayer(Canvas c) {
        Bitmap sprite;
        if (action == 2) sprite = frames[2][jumpFrame];
        else if (action == 1) sprite = frames[1][runFrame];
        else sprite = frames[0][walkFrame];
        if (sprite == null) return;

        float height = 116f;
        float width = height * sprite.getWidth() / sprite.getHeight();
        float x = playerX - width / 2f;
        float y = playerY - height;
        target.set(x, y, x + width, y + height);

        c.save();
        if (!facingRight) c.scale(-1f, 1f, playerX, 0f);
        p.setAlpha(255);
        p.setFilterBitmap(false);
        c.drawBitmap(sprite, null, target, p);
        c.restore();
    }

    private void drawControlDeck(Canvas c) {
        // The movement area is below the arena frame, not over the grid.
        p.setShader(new LinearGradient(0, ARENA_H, 0, H,
                0xfff5f7fa, 0xffd9dfe7, Shader.TileMode.CLAMP));
        c.drawRect(0, ARENA_H, W, H, p);
        p.setShader(null);
        p.setColor(0xff8793a1);
        c.drawRect(0, ARENA_H, W, ARENA_H + 7, p);

        drawButton(c, leftButton, "‹", leftPressed);
        drawButton(c, rightButton, "›", rightPressed);
        drawButton(c, runButton, "RUN", runPressed);
        drawButton(c, jumpButton, "↑", jumpPressed);

        p.setColor(0xff3b4654);
        p.setTextAlign(Paint.Align.CENTER);
        p.setTypeface(Typeface.create("sans-serif", Typeface.BOLD));
        p.setTextSize(18f);
        c.drawText("MOVE", 208, 1760, p);
        c.drawText("SPRINT", 398, 1760, p);
        c.drawText("JUMP", 720, 1760, p);
        p.setTextSize(14f);
        p.setColor(0xff647080);
        c.drawText("HOLD LEFT / RIGHT TO MOVE", 432, 1850, p);
    }

    private void drawButton(Canvas c, RectF r, String text, boolean pressed) {
        p.setShader(new LinearGradient(r.left, r.top, r.left, r.bottom,
                pressed ? 0xff62788f : 0xff596575,
                pressed ? 0xff263746 : 0xff242a34, Shader.TileMode.CLAMP));
        c.drawRoundRect(r, 18, 18, p);
        p.setShader(null);
        p.setStyle(Paint.Style.STROKE);
        p.setStrokeWidth(5);
        p.setColor(pressed ? 0xff34d5f4 : 0xff080c12);
        c.drawRoundRect(r, 18, 18, p);
        p.setStyle(Paint.Style.FILL);
        p.setColor(Color.WHITE);
        p.setTextAlign(Paint.Align.CENTER);
        p.setTypeface(Typeface.create("sans-serif-black", Typeface.BOLD));
        p.setTextSize(text.equals("RUN") ? 29 : 68);
        Paint.FontMetrics fm = p.getFontMetrics();
        float baseline = r.centerY() - (fm.ascent + fm.descent) / 2f;
        c.drawText(text, r.centerX(), baseline, p);
    }

    private void updatePlayer() {
        long now = System.nanoTime();
        if (lastTime == 0L) lastTime = now;
        float dt = Math.min((now - lastTime) / 1_000_000_000f, 0.04f);
        lastTime = now;

        float speed = runPressed ? 260f : 165f;
        if (leftPressed) {
            playerX -= speed * dt;
            facingRight = false;
        }
        if (rightPressed) {
            playerX += speed * dt;
            facingRight = true;
        }
        playerX = Math.max(112f, Math.min(750f, playerX));

        if (jumpPressed && onGround) {
            velocityY = -500f;
            onGround = false;
            jumpFrame = 0;
            animationClock = 0f;
        }
        if (!onGround) {
            velocityY += 1120f * dt;
            playerY += velocityY * dt;
            if (playerY >= PLAYER_GROUND) {
                playerY = PLAYER_GROUND;
                velocityY = 0f;
                onGround = true;
            }
        }

        animationClock += dt;
        if (!onGround) {
            action = 2;
            if (animationClock >= 0.11f) {
                jumpFrame = (jumpFrame + 1) % 5;
                animationClock = 0f;
            }
        } else if (leftPressed || rightPressed) {
            action = runPressed ? 1 : 0;
            float delay = runPressed ? 0.075f : 0.13f;
            if (animationClock >= delay) {
                if (action == 1) runFrame = (runFrame + 1) % 5;
                else walkFrame = (walkFrame + 1) % 5;
                animationClock = 0f;
            }
        } else {
            action = 0;
            walkFrame = 0;
            animationClock = 0f;
        }
    }

    private void updateTouches(MotionEvent event) {
        leftPressed = rightPressed = runPressed = jumpPressed = false;
        int action = event.getActionMasked();
        int skip = (action == MotionEvent.ACTION_POINTER_UP ||
                    action == MotionEvent.ACTION_UP) ? event.getActionIndex() : -1;
        for (int i = 0; i < event.getPointerCount(); i++) {
            if (i == skip) continue;
            float x = event.getX(i), y = event.getY(i);
            float scale = Math.min(getWidth() / W, getHeight() / H);
            float ox = (getWidth() - W * scale) / 2f;
            float oy = (getHeight() - H * scale) / 2f;
            x = (x - ox) / scale;
            y = (y - oy) / scale;
            if (leftButton.contains(x, y)) leftPressed = true;
            if (rightButton.contains(x, y)) rightPressed = true;
            if (runButton.contains(x, y)) runPressed = true;
            if (jumpButton.contains(x, y)) jumpPressed = true;
        }
    }

    @Override public boolean onTouchEvent(MotionEvent event) {
        int a = event.getActionMasked();
        if (a == MotionEvent.ACTION_DOWN || a == MotionEvent.ACTION_POINTER_DOWN ||
            a == MotionEvent.ACTION_MOVE || a == MotionEvent.ACTION_POINTER_UP) {
            updateTouches(event);
            return true;
        }
        if (a == MotionEvent.ACTION_UP || a == MotionEvent.ACTION_CANCEL) {
            leftPressed = rightPressed = runPressed = jumpPressed = false;
            return true;
        }
        return true;
    }
}
