package com.mcpakel.blockarea;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Rect;
import android.graphics.RectF;
import android.graphics.Typeface;
import android.util.SparseArray;
import android.view.MotionEvent;
import android.view.View;

import java.io.IOException;
import java.util.Random;

public class AreaView extends View {
    private static final float WORLD_W = 864f;
    private static final float BOARD_H = 1536f;
    private static final float MAX_CONTROL_H = 384f;
    private static final float MIN_CONTROL_H = 140f;
    private static final int COLS = 14, ROWS = 28, BLOCK_TYPES = 28;
    private static final int BUILD_LIMIT_ROW = 4;
    private static final int LAYERS_PER_LEVEL = 5, MAX_LEVEL = 10;
    private static final float GRID_X = 94f, GRID_Y = 90f, CELL = 48.25f;
    private static final float PLAYER_H = 112f;
    private static final float GRAVITY = 1850f, JUMP_SPEED = 720f;
    private static final float HUD_HEIGHT = 350f;
    private static final float PLAYER_SCREEN_RATIO = 0.72f;

    private static final int ROLE_NONE=0, ROLE_LEFT=1, ROLE_RIGHT=2, ROLE_JUMP=3,
            ROLE_RUN=4, ROLE_PICK=5, ROLE_BUILD=6, ROLE_GRID=7;

    private static final class TouchPoint {
        int role;
        float x,y;
        TouchPoint(int role,float x,float y){this.role=role;this.x=x;this.y=y;}
    }

    private final Paint paint = new Paint();
    private final int[][] blocks = new int[ROWS][COLS];
    private final Bitmap[] blockTextures = new Bitmap[BLOCK_TYPES];
    private final Bitmap[][] characterFrames = new Bitmap[3][5];
    private final SparseArray<TouchPoint> touches = new SparseArray<>();

    private Bitmap arena, hud, placementFrame;
    private Bitmap leftImage,rightImage,runImage,pickImage,blockImage,jumpImage;

    // Visible control images and larger touch hitboxes.
    private final RectF[] hit = new RectF[6];
    private final RectF[] icon = new RectF[6];

    private float playerX, playerFeet, velocityY;
    private float cameraY, cameraTarget;
    private final float spawnFeet=GRID_Y+ROWS*CELL;
    private float animationClock;
    private long lastFrameNanos;
    private boolean grounded=true, sprint=false, facingRight=true;
    private boolean leftHeld=false,rightHeld=false,jumpHeld=false,jumpRequested=false;
    private boolean buildMode=false,breakMode=false;
    private int walkFrame=0,runFrame=0,jumpFrame=0;
    private int targetCol=-1,targetRow=-1,previewBlock=0;
    private int maxStackReached=0,brokenCount=0,totalPlaced=0;
    private final Random random=new Random();

    public AreaView(Context context) {
        super(context);
        setLayerType(View.LAYER_TYPE_SOFTWARE,null);
        arena=load("area/arena_reference.jpg");
        hud=load("ui/hud_top.png");
        placementFrame=load("blocks/placement_frame.png");
        leftImage=load("ui/control_left.png");
        rightImage=load("ui/control_right.png");
        runImage=load("ui/control_run.png");
        pickImage=load("ui/control_pickaxe.png");
        blockImage=load("ui/control_block.png");
        jumpImage=load("ui/control_jump.png");

        for(int i=0;i<BLOCK_TYPES;i++){
            blockTextures[i]=load(String.format(java.util.Locale.US,"blocks/block_%02d.png",i));
        }
        String[] actions={"walk","run","jump"};
        for(int a=0;a<3;a++){
            for(int f=0;f<5;f++){
                characterFrames[a][f]=load("character/"+actions[a]+"_"+f+".png");
            }
        }
        for(int r=0;r<ROWS;r++) for(int c=0;c<COLS;c++) blocks[r][c]=-1;

        playerX=GRID_X+7.5f*CELL;
        playerFeet=GRID_Y+ROWS*CELL;
        for(int i=0;i<6;i++){hit[i]=new RectF();icon[i]=new RectF();}
        paint.setFilterBitmap(false);
        paint.setAntiAlias(false);
    }

    private Bitmap load(String path){
        try{return BitmapFactory.decodeStream(getContext().getAssets().open(path));}
        catch(IOException e){return null;}
    }

    private float scale(){return getWidth()/WORLD_W;}
    private float logicalHeight(){return getHeight()/Math.max(0.001f,scale());}
    private float controlHeight(){return Math.min(MAX_CONTROL_H,Math.max(MIN_CONTROL_H,logicalHeight()-BOARD_H));}
    private float controlTop(){return logicalHeight()-controlHeight();}
    private float areaTop(){return Math.min(HUD_HEIGHT,controlTop()-420f);}
    private float boardViewportHeight(){return Math.max(360f,controlTop()-areaTop());}
    private float worldToScreenY(float y){return areaTop()+y-cameraY;}
    private int clamp(int value,int min,int max){return Math.max(min,Math.min(max,value));}
    private int playerColumn(){return clamp((int)((playerX-GRID_X)/CELL),0,COLS-1);}

    private int topBlockRow(int col){
        for(int r=BUILD_LIMIT_ROW;r<ROWS;r++) if(blocks[r][col]>=0)return r;
        return ROWS;
    }
    private float supportY(int col){return GRID_Y+topBlockRow(col)*CELL;}
    private int stackHeight(int col){
        int n=0;for(int r=BUILD_LIMIT_ROW;r<ROWS;r++)if(blocks[r][col]>=0)n++;
        return n;
    }
    private int maxStack(){
        int m=0;for(int c=0;c<COLS;c++)m=Math.max(m,stackHeight(c));
        return m;
    }
    private int blockCount(){
        int n=0;for(int[] row:blocks)for(int v:row)if(v>=0)n++;
        return n;
    }
    // Five placed blocks advance one level; ten levels require fifty placed blocks.
    private int currentLevel(){return Math.min(MAX_LEVEL,1+totalPlaced/LAYERS_PER_LEVEL);}
    private int levelPercent(){return Math.min(100,Math.round(totalPlaced*100f/(MAX_LEVEL*LAYERS_PER_LEVEL)));}
    private int areaPercent(){
        return Math.min(100,Math.round(blockCount()*100f/(COLS*(ROWS-BUILD_LIMIT_ROW))));
    }

    private void layoutControls(){
        float y=controlTop()+(controlHeight()-132f)/2f;
        // Broad margins and a clear central gap keep controls away from phone edges.
        float[] xs={24,148,272,480,604,728};
        Bitmap[] imgs={leftImage,rightImage,runImage,pickImage,blockImage,jumpImage};
        for(int i=0;i<6;i++){
            hit[i].set(xs[i]-7,y-8,xs[i]+119,y+124);
            float iw=104,ih=108;
            icon[i].set(xs[i]+4,y+4,xs[i]+4+iw,y+4+ih);
        }
    }

    private void drawBitmap(Canvas canvas,Bitmap bitmap,RectF dst){
        if(bitmap==null)return;
        paint.setAlpha(255);paint.setFilterBitmap(false);paint.clearShadowLayer();
        canvas.drawBitmap(bitmap,null,dst,paint);
    }

    @Override protected void onDraw(Canvas canvas){
        super.onDraw(canvas);
        if(getWidth()<=0)return;
        float sc=scale(),boardH=boardViewportHeight();
        layoutControls();
        if(lastFrameNanos==0){
            cameraY=clampFloat(spawnFeet-boardViewportHeight()*PLAYER_SCREEN_RATIO,
                    0f,Math.max(0f,BOARD_H-boardViewportHeight()));
        }

        canvas.save();
        canvas.scale(sc,sc);
        canvas.drawColor(Color.WHITE);

        // Arena camera scrolls vertically in a viewport reserved below the fixed HUD.
        canvas.save();
        canvas.clipRect(0,areaTop(),WORLD_W,controlTop());
        if(arena!=null){
            drawBitmap(canvas,arena,new RectF(0,areaTop()-cameraY,
                    WORLD_W,areaTop()+BOARD_H-cameraY));
        }else{
            paint.setColor(0xff20232a);
            canvas.drawRect(0,areaTop(),WORLD_W,controlTop(),paint);
        }
        drawPlacedBlocks(canvas);
        drawPlacementTarget(canvas);
        drawPlayer(canvas);
        canvas.restore();

        drawHud(canvas);
        drawControls(canvas);
        canvas.restore();

        updatePhysics();
        postInvalidateDelayed(16);
    }

    private void drawPlacedBlocks(Canvas canvas){
        for(int row=BUILD_LIMIT_ROW;row<ROWS;row++){
            float y=worldToScreenY(GRID_Y+row*CELL);
            if(y>boardViewportHeight()||y+CELL<0)continue;
            for(int col=0;col<COLS;col++){
                int type=blocks[row][col];
                if(type<0)continue;
                float x=GRID_X+col*CELL;
                drawBitmap(canvas,blockTextures[type],new RectF(x-0.8f,y-0.8f,x+CELL+0.8f,y+CELL+0.8f));
            }
        }
    }

    private void drawPlacementTarget(Canvas canvas){
        if(!breakMode||targetCol<0||targetRow<BUILD_LIMIT_ROW||targetRow>=ROWS)return;
        float x=GRID_X+targetCol*CELL;
        float y=worldToScreenY(GRID_Y+targetRow*CELL);
        RectF cell=new RectF(x,y,x+CELL,y+CELL);
        if(buildMode&&blocks[targetRow][targetCol]<0&&blockTextures[previewBlock]!=null){
            paint.setAlpha(115);paint.setFilterBitmap(false);
            canvas.drawBitmap(blockTextures[previewBlock],null,cell,paint);
            paint.setAlpha(255);
        }
        if(placementFrame!=null)drawBitmap(canvas,placementFrame,cell);
        paint.setStyle(Paint.Style.STROKE);
        paint.setStrokeWidth(2.5f);
        paint.setColor(buildMode?0xff42ef69:0xffff5555);
        canvas.drawRect(cell,paint);
        paint.setStyle(Paint.Style.FILL);
    }

    private void drawPlayer(Canvas canvas){
        int action=!grounded?2:((leftHeld||rightHeld)?(sprint?1:0):0);
        int frame=action==2?jumpFrame:(action==1?runFrame:walkFrame);
        Bitmap sprite=characterFrames[action][frame];
        if(sprite==null)return;
        float h=PLAYER_H,w=h*sprite.getWidth()/Math.max(1f,sprite.getHeight());
        float feet=worldToScreenY(playerFeet);
        RectF dst=new RectF(playerX-w/2,feet-h,playerX+w/2,feet);
        canvas.save();
        if(!facingRight)canvas.scale(-1,1,playerX,0);
        drawBitmap(canvas,sprite,dst);
        canvas.restore();
    }

    private void drawHud(Canvas canvas){
        if(hud==null)return;
        // HUD is a fixed top panel, outside the scrolling arena viewport.
        float x=20f, y=0f, w=824f, h=Math.min(HUD_HEIGHT-8f,w*650f/1536f);
        Rect src=new Rect(0,0,hud.getWidth(),hud.getHeight());
        paint.setFilterBitmap(false);
        canvas.drawBitmap(hud,src,new RectF(x,y,x+w,y+h),paint);

        // Green fill is drawn INSIDE the long empty bar already present in the supplied HUD.
        float barX=x+w*(282f/1536f);
        float barY=y+h*(314f/650f);
        float barW=w*(1180f/1536f);
        float barH=h*(58f/650f);
        float ratio=levelPercent()/100f;
        // Fill the existing 20 small cells from left to right; keep their dark dividers visible.
        final int segments=20;
        float segmentW=barW/segments;
        float filled=ratio*segments;
        paint.setColor(0xff39e64f);
        for(int i=0;i<segments;i++){
            float part=Math.max(0f,Math.min(1f,filled-i));
            if(part<=0f)continue;
            float left=barX+i*segmentW+2f;
            float right=barX+i*segmentW+segmentW*part-2f;
            if(right>left){
                canvas.drawRoundRect(new RectF(left,barY+5f,right,barY+barH-5f),4,4,paint);
            }
        }

        // 5x7 pixel glyphs match the block-game artwork; no Android system font is used.
        float nameX=x+w*(400f/1536f);
        drawPixelText(canvas,"PLAYER",nameX,y+h*(143f/650f),2.15f,Color.WHITE);
        drawPixelText(canvas,"ONLINE",nameX,y+h*(178f/650f),1.55f,0xffe9e9e9);
        drawPixelText(canvas,currentLevel()+"/10",x+w*(770f/1536f),
                y+h*(145f/650f),2.25f,Color.WHITE);
        drawPixelText(canvas,areaPercent()+"%",x+w*(1250f/1536f),
                y+h*(145f/650f),2.15f,Color.WHITE);
    }

    private String glyph(char ch){
        switch(Character.toUpperCase(ch)){
            case 'A': return "01110/10001/10001/11111/10001/10001/10001";
            case 'B': return "11110/10001/10001/11110/10001/10001/11110";
            case 'C': return "01111/10000/10000/10000/10000/10000/01111";
            case 'D': return "11110/10001/10001/10001/10001/10001/11110";
            case 'E': return "11111/10000/10000/11110/10000/10000/11111";
            case 'I': return "11111/00100/00100/00100/00100/00100/11111";
            case 'L': return "10000/10000/10000/10000/10000/10000/11111";
            case 'N': return "10001/11001/10101/10011/10001/10001/10001";
            case 'O': return "01110/10001/10001/10001/10001/10001/01110";
            case 'P': return "11110/10001/10001/11110/10000/10000/10000";
            case 'R': return "11110/10001/10001/11110/10100/10010/10001";
            case 'Y': return "10001/10001/01010/00100/00100/00100/00100";
            case '0': return "01110/10001/10011/10101/11001/10001/01110";
            case '1': return "00100/01100/00100/00100/00100/00100/01110";
            case '2': return "01110/10001/00001/00010/00100/01000/11111";
            case '3': return "11110/00001/00001/01110/00001/00001/11110";
            case '4': return "00010/00110/01010/10010/11111/00010/00010";
            case '5': return "11111/10000/10000/11110/00001/00001/11110";
            case '6': return "01110/10000/10000/11110/10001/10001/01110";
            case '7': return "11111/00001/00010/00100/01000/01000/01000";
            case '8': return "01110/10001/10001/01110/10001/10001/01110";
            case '9': return "01110/10001/10001/01111/00001/00001/01110";
            case '/': return "00001/00010/00010/00100/01000/01000/10000";
            case '%': return "11001/11010/00100/01000/10110/00110/00000";
            case ' ': return "00000/00000/00000/00000/00000/00000/00000";
            default: return "00000/00000/00000/00000/00000/00000/00000";
        }
    }

    private void drawPixelText(Canvas canvas,String text,float centerX,float baselineY,float unit,int color){
        float charAdvance=6f*unit;
        float start=centerX-(text.length()*charAdvance-unit)/2f;
        float top=baselineY-7f*unit;
        paint.setColor(color);
        paint.setStyle(Paint.Style.FILL);
        paint.clearShadowLayer();
        for(int i=0;i<text.length();i++){
            String[] rows=glyph(text.charAt(i)).split("/");
            for(int row=0;row<7;row++){
                for(int col=0;col<5;col++){
                    if(rows[row].charAt(col)=='1'){
                        float px=start+i*charAdvance+col*unit;
                        float py=top+row*unit;
                        canvas.drawRect(px,py,px+unit,py+unit,paint);
                    }
                }
            }
        }
    }

    private void drawControls(Canvas canvas){
        float top=controlTop();
        paint.setColor(Color.WHITE);
        canvas.drawRect(0,top,WORLD_W,logicalHeight(),paint);
        Bitmap[] images={leftImage,rightImage,runImage,pickImage,blockImage,jumpImage};
        for(int i=0;i<6;i++){
            boolean active=(i==2&&sprint)||(i==3&&breakMode);
            if(active){
                paint.setColor(i==3?0x5537cfff:0x55ffc928);
                paint.setShadowLayer(10,0,0,i==3?0xff37cfff:0xffffc928);
                canvas.drawRoundRect(icon[i],18,18,paint);
                paint.clearShadowLayer();
            }
            drawBitmap(canvas,images[i],icon[i]);
        }
    }

    private boolean withinRange(int col,int row){
        float playerRow=(playerFeet-GRID_Y)/CELL;
        float dx=col-playerColumn(),dy=row-playerRow;
        return Math.sqrt(dx*dx+dy*dy)<=10.0;
    }

    private boolean supportedCell(int row,int col){
        // No floating blocks: every placed block must sit on the floor or directly on another block.
        return row==ROWS-1||blocks[row+1][col]>=0;
    }

    private boolean placeAtCell(int col,int row,boolean liftPlayer){
        if(col<0||col>=COLS||row<BUILD_LIMIT_ROW||row>=ROWS)return false;
        if(blocks[row][col]>=0||!supportedCell(row,col))return false;
        if(!withinRange(col,row))return false;

        float top=GRID_Y+row*CELL;
        float bottom=top+CELL;
        // The player cannot be embedded inside a newly placed tile.
        float playerTop=playerFeet-PLAYER_H;
        boolean sameColumn=col==playerColumn();
        boolean underPlayer=sameColumn&&Math.abs(bottom-playerFeet)<CELL*0.35f;

        if(underPlayer){
            float newFeet=top;
            float newTop=newFeet-PLAYER_H;
            if(intersectsBlocks(col,newTop,newFeet))return false;
            if(!liftPlayer)return false;
        }

        blocks[row][col]=previewBlock;
        totalPlaced++;
        maxStackReached=Math.max(maxStackReached,maxStack());
        previewBlock=random.nextInt(BLOCK_TYPES);

        if(underPlayer&&liftPlayer){
            playerFeet=top;
            velocityY=0f;
            grounded=true;
        }
        return true;
    }

    // Main Block button: place one solid tile directly beneath the player, then step onto it.
    private void placeUnderPlayer(){
        if(!grounded)return;
        int col=playerColumn();
        int surfaceRow=clamp(Math.round((playerFeet-GRID_Y)/CELL),BUILD_LIMIT_ROW,ROWS);
        int row=surfaceRow-1;
        if(row<BUILD_LIMIT_ROW)return;
        placeAtCell(col,row,true);
    }

    private void breakBlock(){
        int col=targetCol,row=targetRow;
        if(col<0||row<BUILD_LIMIT_ROW||row>=ROWS)return;
        if(blocks[row][col]<0||!withinRange(col,row))return;
        blocks[row][col]=-1;
        brokenCount++;
        maxStackReached=maxStack();

        // If the removed tile was the player's floor, release support and let gravity take over.
        if(grounded&&!hasSurfaceAtFeet(playerX,playerFeet)){
            grounded=false;
            velocityY=0f;
        }
    }

    private boolean intersectsBlocks(int col,float top,float feet){
        for(int row=BUILD_LIMIT_ROW;row<ROWS;row++){
            if(blocks[row][col]<0)continue;
            float blockTop=GRID_Y+row*CELL;
            float blockBottom=blockTop+CELL;
            if(feet>blockTop+1f&&top<blockBottom-1f)return true;
        }
        return false;
    }

    private boolean hasSurfaceAtFeet(float x,float feet){
        if(Math.abs(feet-(GRID_Y+ROWS*CELL))<2f)return true;
        float half=PLAYER_H*0.22f;
        float left=x-half,right=x+half;
        int first=clamp((int)((left-GRID_X)/CELL),0,COLS-1);
        int last=clamp((int)((right-GRID_X)/CELL),0,COLS-1);
        for(int col=first;col<=last;col++){
            for(int row=BUILD_LIMIT_ROW;row<ROWS;row++){
                if(blocks[row][col]<0)continue;
                float top=GRID_Y+row*CELL;
                if(Math.abs(feet-top)<2f)return true;
            }
        }
        return false;
    }

    private float landingSurface(float x,float oldFeet,float newFeet){
        float best=Float.POSITIVE_INFINITY;
        float half=PLAYER_H*0.22f;
        float left=x-half,right=x+half;
        int first=clamp((int)((left-GRID_X)/CELL),0,COLS-1);
        int last=clamp((int)((right-GRID_X)/CELL),0,COLS-1);

        // The arena floor is the final solid surface.
        float floor=GRID_Y+ROWS*CELL;
        if(oldFeet<=floor&&newFeet>=floor)best=floor;

        // Only collide with the TOP face of a block when descending through it.
        // Blocks above the player's head never trap a falling player.
        for(int col=first;col<=last;col++){
            for(int row=BUILD_LIMIT_ROW;row<ROWS;row++){
                if(blocks[row][col]<0)continue;
                float top=GRID_Y+row*CELL;
                if(oldFeet<=top+1f&&newFeet>=top-1f&&top<best)best=top;
            }
        }
        return best;
    }

    private float ceilingSurface(float x,float oldTop,float newTop){
        float best=Float.NEGATIVE_INFINITY;
        float half=PLAYER_H*0.22f;
        float left=x-half,right=x+half;
        int first=clamp((int)((left-GRID_X)/CELL),0,COLS-1);
        int last=clamp((int)((right-GRID_X)/CELL),0,COLS-1);
        // On upward motion, collide with the underside only if the player's head crosses it.
        for(int col=first;col<=last;col++){
            for(int row=BUILD_LIMIT_ROW;row<ROWS;row++){
                if(blocks[row][col]<0)continue;
                float bottom=GRID_Y+(row+1)*CELL;
                if(oldTop>=bottom-1f&&newTop<=bottom+1f&&bottom>best)best=bottom;
            }
        }
        return best;
    }

    private boolean blockedAt(float x,float top,float feet){
        float half=PLAYER_H*0.22f;
        float left=x-half,right=x+half;
        int first=clamp((int)((left-GRID_X)/CELL),0,COLS-1);
        int last=clamp((int)((right-GRID_X)/CELL),0,COLS-1);
        for(int col=first;col<=last;col++){
            for(int row=BUILD_LIMIT_ROW;row<ROWS;row++){
                if(blocks[row][col]<0)continue;
                float l=GRID_X+col*CELL,r=l+CELL;
                float t=GRID_Y+row*CELL,b=t+CELL;
                if(right>l+1f&&left<r-1f&&feet>t+1f&&top<b-1f)return true;
            }
        }
        return false;
    }

    private void updatePhysics(){
        long now=System.nanoTime();
        if(lastFrameNanos==0)lastFrameNanos=now;
        float dt=Math.min(0.032f,(now-lastFrameNanos)/1_000_000_000f);
        lastFrameNanos=now;

        float speed=sprint?245f:145f;
        float dx=0f;
        if(leftHeld&&!rightHeld){dx=-speed*dt;facingRight=false;}
        if(rightHeld&&!leftHeld){dx=speed*dt;facingRight=true;}

        // Horizontal collision uses the complete player body, not a guessed column support.
        float candidateX=clampFloat(playerX+dx,GRID_X+CELL*.5f,GRID_X+(COLS-.5f)*CELL);
        if(!blockedAt(candidateX,playerFeet-PLAYER_H,playerFeet)){
            playerX=candidateX;
        }

        if(grounded&&!hasSurfaceAtFeet(playerX,playerFeet)){
            grounded=false;
        }

        if(jumpRequested&&grounded){
            velocityY=-JUMP_SPEED;
            grounded=false;
        }
        jumpRequested=false;

        if(!grounded){
            float oldFeet=playerFeet;
            float oldTop=oldFeet-PLAYER_H;
            velocityY+=GRAVITY*dt;
            float nextFeet=oldFeet+velocityY*dt;
            float nextTop=nextFeet-PLAYER_H;

            if(velocityY<0f){
                float ceiling=ceilingSurface(playerX,oldTop,nextTop);
                if(ceiling!=Float.NEGATIVE_INFINITY){
                    nextFeet=ceiling+PLAYER_H;
                    velocityY=0f;
                }
            }else{
                float landing=landingSurface(playerX,oldFeet,nextFeet);
                if(landing!=Float.POSITIVE_INFINITY){
                    nextFeet=landing;
                    velocityY=0f;
                    grounded=true;
                }
            }
            playerFeet=nextFeet;
        }else{
            velocityY=0f;
        }

        // Camera follows the player vertically: climbing moves the arena down on screen.
        // HUD stays fixed above the arena and the bottom controls remain fixed below it.
        float desiredCamera=playerFeet-boardViewportHeight()*PLAYER_SCREEN_RATIO;
        cameraTarget=clampFloat(desiredCamera,0f,Math.max(0f,BOARD_H-boardViewportHeight()));
        cameraY+=(cameraTarget-cameraY)*Math.min(1f,dt*7f);

        animationClock+=dt;
        if(!grounded){
            if(animationClock>0.11f){jumpFrame=(jumpFrame+1)%5;animationClock=0f;}
        }else if(leftHeld||rightHeld){
            float delay=sprint?0.075f:0.13f;
            if(animationClock>delay){
                if(sprint)runFrame=(runFrame+1)%5;
                else walkFrame=(walkFrame+1)%5;
                animationClock=0f;
            }
        }else{
            walkFrame=0;animationClock=0f;
        }
    }

    private float clampFloat(float v,float min,float max){return Math.max(min,Math.min(max,v));}
    private float toLogicalX(float px){return px/Math.max(0.001f,scale());}
    private float toLogicalY(float py){return py/Math.max(0.001f,scale());}

    private int roleAt(float x,float y){
        // Image order is left, right, run, pickaxe, block, jump;
        // role IDs keep jump separate so it can be held together with movement.
        final int[] roles={ROLE_LEFT,ROLE_RIGHT,ROLE_RUN,ROLE_PICK,ROLE_BUILD,ROLE_JUMP};
        for(int i=0;i<6;i++)if(hit[i].contains(x,y))return roles[i];
        if(y>=areaTop()&&y<controlTop()&&x>=GRID_X&&x<GRID_X+COLS*CELL)return ROLE_GRID;
        return ROLE_NONE;
    }

    private void addPointer(MotionEvent e,int index){
        int id=e.getPointerId(index);
        float x=toLogicalX(e.getX(index)),y=toLogicalY(e.getY(index));
        int role=roleAt(x,y);
        TouchPoint t=new TouchPoint(role,x,y);
        touches.put(id,t);
        if(role==ROLE_RUN)sprint=!sprint;
        else if(role==ROLE_PICK){breakMode=!breakMode;buildMode=false;}
        else if(role==ROLE_BUILD){buildMode=false;breakMode=false;placeUnderPlayer();}
        else if(role==ROLE_JUMP)jumpRequested=true;
        if(role==ROLE_GRID)updateTarget(x,y);
        refreshHeldButtons();
    }

    private void updatePointers(MotionEvent e){
        for(int i=0;i<e.getPointerCount();i++){
            int id=e.getPointerId(i);
            TouchPoint t=touches.get(id);
            if(t==null)continue;
            t.x=toLogicalX(e.getX(i));
            t.y=toLogicalY(e.getY(i));
            if(t.role==ROLE_GRID)updateTarget(t.x,t.y);
        }
        refreshHeldButtons();
    }

    private void releasePointer(MotionEvent e,int index){
        int id=e.getPointerId(index);
        TouchPoint t=touches.get(id);
        if(t!=null&&t.role==ROLE_GRID){
            float x=toLogicalX(e.getX(index)),y=toLogicalY(e.getY(index));
            updateTarget(x,y);
            if(breakMode)breakBlock();
            else placeAtCell(targetCol,targetRow,true);
        }
        touches.remove(id);
        refreshHeldButtons();
    }

    private void refreshHeldButtons(){
        leftHeld=rightHeld=jumpHeld=false;
        for(int i=0;i<touches.size();i++){
            int role=touches.valueAt(i).role;
            if(role==ROLE_LEFT)leftHeld=true;
            if(role==ROLE_RIGHT)rightHeld=true;
            if(role==ROLE_JUMP)jumpHeld=true;
        }
    }

    private void updateTarget(float x,float y){
        int col=(int)((x-GRID_X)/CELL);
        int row=(int)((y-areaTop()+cameraY-GRID_Y)/CELL);
        targetCol=(col>=0&&col<COLS)?col:-1;
        targetRow=(row>=0&&row<ROWS)?row:-1;
    }

    @Override public boolean onTouchEvent(MotionEvent event){
        int action=event.getActionMasked();
        int index=event.getActionIndex();

        if(action==MotionEvent.ACTION_DOWN||action==MotionEvent.ACTION_POINTER_DOWN){
            addPointer(event,index);
            invalidate();
            return true;
        }
        if(action==MotionEvent.ACTION_MOVE){
            updatePointers(event);
            invalidate();
            return true;
        }
        if(action==MotionEvent.ACTION_POINTER_UP){
            releasePointer(event,index);
            invalidate();
            return true;
        }
        if(action==MotionEvent.ACTION_UP){
            releasePointer(event,index);
            touches.clear();
            refreshHeldButtons();
            invalidate();
            return true;
        }
        if(action==MotionEvent.ACTION_CANCEL){
            touches.clear();
            refreshHeldButtons();
            jumpRequested=false;
            invalidate();
            return true;
        }
        return true;
    }
}
