# BlockRush Live Game v13 — AndroidForge Source

This revision replaces the v12 camera and placement behavior with a scrolling arena camera and direct player-relative block placement.

## v13 changes

### Arena camera and HUD
- HUD stays fixed at the top of the screen, above the arena viewport.
- The arena has its own viewport between the HUD and bottom controls.
- When the player climbs, the camera moves the world downward on screen so the player remains visible.
- When the player falls, the camera follows downward naturally.
- The arena background, placed blocks, target cell, and player share the same camera offset.
- The arena bottom is visible at spawn; the top is revealed as the player climbs.
- Controls remain fixed below the arena and do not move with the camera.

### Block placement
- Tapping the Block button places a block directly beneath the player.
- The player immediately steps onto the newly placed block.
- Tapping a grid cell in the arena also places a block there, if it is empty and directly supported.
- The Pickaxe button toggles break mode; tapping a block cell removes that block.
- Block button exits break mode automatically.
- Blocks use the same 48.25 world-grid spacing as the arena and overlap slightly when drawn to avoid hairline gaps.
- A block cannot be placed inside the player or without a supporting block/floor.

### Collision and falling
- Landing checks only the top faces crossed while the player is descending.
- Blocks above the player do not act as invisible floors when the player is falling beneath them.
- Removing the block supporting the player releases support; gravity then moves the player down naturally.
- Horizontal movement checks the player body against solid blocks.
- Jumping is required to clear raised blocks; no instant support teleporting is used.

### Controls
- Multi-touch pointer tracking is retained.
- Left/right can be held while another finger presses Jump.
- Run remains tap-to-toggle.
- Pickaxe and direct Block actions remain mutually exclusive.

### HUD and level
- Uses the supplied HUD artwork, fixed above the arena.
- The green progress fills the existing 20-cell bar.
- Five placed blocks advance one level, up to level 10.
- Percentage remains displayed in the HUD's block panel.
- Uses custom pixel glyph text instead of Android's default font.

## Build in AndroidForge
1. Extract the ZIP.
2. Open the `BlockRush_Live_Game_v13` folder in AndroidForge.
3. Build the `app` module.
4. The project uses Java 17, compile SDK 35, min SDK 23, and application ID `com.mcpakel.blockarea`.

Version: 1.3 (versionCode 13)

The updated `AreaView.java` passed a Java syntax/API-stub compilation check. A complete Android APK build and device gameplay test have not been run in this environment; please run the build and test the controls on the target phone.
