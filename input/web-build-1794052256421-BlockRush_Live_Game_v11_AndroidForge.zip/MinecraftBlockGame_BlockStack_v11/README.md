# BlockRush Live Game — AndroidForge source (v11)

## Changes in v11
- Replaced the arena with the latest supplied map, including the yellow/black build-limit beam.
- Replaced the top HUD with the latest supplied HUD artwork. The profile/name/connection panel is currently placeholder text (`PLAYER`, `ONLINE`).
- The seven decorative hotbar slots remain empty; no block icons are inserted there.
- Replaced the app launcher icon with the exact supplied BlockRush Live Game image.
- BUILD and PICKAXE are mutually exclusive toggle modes. Tapping one turns the other off.
- In BUILD mode, tap an empty grid square to place a randomly selected block texture in that exact square.
- In PICKAXE mode, tap an occupied grid square to break that block.
- Interactions are limited to a 10-grid-cell radius from the player.
- Blocks cannot be placed above the yellow warning beam, and placement requires support from the floor or an adjacent block to avoid floating gaps.
- RUN is a tap-to-toggle mode.
- JUMP uses a higher jump arc; horizontal collision prevents the player from being teleported up onto 1–2 block steps.
- Camera and HUD position respond to player height.
- Level progression: 10 levels; 5 complete rows/layers of 14 blocks each advances one level. The green bar fills toward 10/10.
- Block percentage is calculated from occupied buildable grid cells.
- WIN screen is not included.

## Controls
- Left / Right: hold to move.
- RUN: tap to toggle sprint on/off.
- JUMP: hold/tap to jump.
- BLOCK: tap to enable/disable placement mode, then tap a grid cell.
- PICKAXE: tap to enable/disable breaking mode, then tap a grid cell.
- Selecting BLOCK automatically disables PICKAXE; selecting PICKAXE automatically disables BLOCK.

## Build in AndroidForge
1. Extract this ZIP.
2. Open the `MinecraftBlockGame_BlockStack_v11` project folder.
3. Build the `app` module.
4. Use JDK 17, Android SDK Platform 35, and the Gradle/Android plugin versions already configured in the project.

Package: `com.mcpakel.blockarea`
App label: `BlockRush Live Game`

The Java source passed a syntax compile against local Android API stubs. A complete APK build was not run in this environment; please run the final build in AndroidForge.
