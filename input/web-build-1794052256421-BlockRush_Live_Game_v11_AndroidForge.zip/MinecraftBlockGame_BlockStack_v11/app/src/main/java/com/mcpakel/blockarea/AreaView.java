package com.mcpakel.blockarea;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Rect;
import android.graphics.RectF;
import android.graphics.Typeface;
import android.view.MotionEvent;
import android.view.View;
import java.io.IOException;
import java.util.Random;

public class AreaView extends View {
    private static final float W=864f, CONTROL_H=380f;
    private static final int COLS=14, ROWS=28, TYPES=28, LEVELS=10, LAYERS_PER_LEVEL=5;
    private static final float GX=94f, GY=90f, CELL=48.25f;
    private static final int BUILD_LIMIT=4, MAX_RANGE=10;

    private final Paint p=new Paint();
    private final int[][] blocks=new int[ROWS][COLS];
    private final Bitmap[] textures=new Bitmap[TYPES];
    private final Bitmap[][] sprites=new Bitmap[3][5];
    private Bitmap arena,hudTop,ghost;
    private Bitmap leftImg,rightImg,runImg,pickImg,blockImg,jumpImg;
    private final RectF leftBtn=new RectF(),rightBtn=new RectF(),runBtn=new RectF(),
        pickBtn=new RectF(),blockBtn=new RectF(),jumpBtn=new RectF();

    private float playerX,playerFeet,cameraY,vy,animClock;
    private long lastFrame;
    private boolean grounded=true,leftDown,rightDown,jumpDown,sprint,facingRight=true;
    private boolean buildMode,breakMode;
    private boolean leftFx,rightFx,runFx,jumpFx;
    private int walkFrame,runFrame,jumpFrame,ghostBlock=0;
    private final Random blockRandom=new Random();
    private int placedTotal,brokenTotal,maxLayer;
    private float downX,downY;
    private int targetCol=-1,targetRow=-1;
    private boolean downOnGrid;

    public AreaView(Context c){
        super(c);setLayerType(View.LAYER_TYPE_SOFTWARE,null);
        arena=load(c,"area/arena_reference.jpg");
        hudTop=load(c,"ui/hud_top.png");
        ghost=load(c,"blocks/placement_frame.png");
        leftImg=load(c,"ui/control_left.png");rightImg=load(c,"ui/control_right.png");
        runImg=load(c,"ui/control_run.png");pickImg=load(c,"ui/control_pickaxe.png");
        blockImg=load(c,"ui/control_block.png");jumpImg=load(c,"ui/control_jump.png");
        for(int i=0;i<TYPES;i++)textures[i]=load(c,String.format(java.util.Locale.US,"blocks/block_%02d.png",i));
        String[] acts={"walk","run","jump"};
        for(int a=0;a<3;a++)for(int f=0;f<5;f++)sprites[a][f]=load(c,"character/"+acts[a]+"_"+f+".png");
        for(int r=0;r<ROWS;r++)for(int col=0;col<COLS;col++)blocks[r][col]=-1;
        playerX=GX+7*CELL+CELL/2f;playerFeet=GY+ROWS*CELL;
    }
    private Bitmap load(Context c,String s){try{return BitmapFactory.decodeStream(c.getAssets().open(s));}catch(IOException e){return null;}}
    private float s(){return getWidth()/W;}
    private float vh(){return getHeight()/Math.max(.001f,s());}
    private float ah(){return Math.max(200,vh()-CONTROL_H);}
    private float screenY(float worldY){return worldY-cameraY;}
    private int clamp(int n,int a,int b){return Math.max(a,Math.min(b,n));}
    private int playerCol(){return clamp((int)((playerX-GX)/CELL),0,COLS-1);}
    private int supportRow(int col){for(int r=BUILD_LIMIT;r<ROWS;r++)if(blocks[r][col]>=0)return r;return ROWS;}
    private float supportFeet(int col){return GY+supportRow(col)*CELL;}
    private int stackHeight(int col){int n=0;for(int r=BUILD_LIMIT;r<ROWS;r++)if(blocks[r][col]>=0)n++;return n;}
    private int maxStack(){int m=0;for(int c=0;c<COLS;c++)m=Math.max(m,stackHeight(c));return m;}
    private int countBlocks(){int n=0;for(int[] row:blocks)for(int b:row)if(b>=0)n++;return n;}
    private int level(){return Math.min(LEVELS,1+placedTotal/(LAYERS_PER_LEVEL*COLS));}
    private int progress(){return placedTotal%(LAYERS_PER_LEVEL*COLS);}

    private void layout(){
        float y=ah()+65;
        leftBtn.set(18,y,138,y+122);rightBtn.set(151,y,271,y+122);
        runBtn.set(284,y,404,y+122);pickBtn.set(500,y,620,y+122);
        blockBtn.set(633,y,753,y+122);jumpBtn.set(746,y,866,y+122);
    }
    private void bitmap(Canvas c,Bitmap b,RectF dst){
        if(b==null)return;p.setAlpha(255);p.setFilterBitmap(false);p.clearShadowLayer();c.drawBitmap(b,null,dst,p);
    }

    @Override protected void onDraw(Canvas c){
        super.onDraw(c);if(getWidth()<=0)return;
        float sc=s(),arenaH=ah();layout();
        c.save();c.scale(sc,sc);c.drawColor(Color.WHITE);
        c.save();c.clipRect(0,0,W,arenaH);
        if(arena!=null){
            bitmap(c,arena,new RectF(0,-cameraY,W,1536-cameraY));
            if(cameraY>0)bitmap(c,arena,new RectF(0,-cameraY-1536,W,-cameraY));
        }else{p.setColor(0xff20232a);c.drawRect(0,0,W,arenaH,p);}
        drawBlocks(c);drawTarget(c);drawPlayer(c);c.restore();
        drawHud(c,arenaH);drawControls(c,arenaH);
        c.restore();physics();postInvalidateDelayed(16);
    }
    private void drawBlocks(Canvas c){
        for(int r=BUILD_LIMIT;r<ROWS;r++){
            float y=screenY(GY+r*CELL);if(y>ah()||y+CELL<0)continue;
            for(int col=0;col<COLS;col++){
                int id=blocks[r][col];if(id>=0&&textures[id]!=null){
                    float x=GX+col*CELL;
                    bitmap(c,textures[id],new RectF(x,y,x+CELL,y+CELL));
                }
            }
        }
    }
    private void drawTarget(Canvas c){
        if(targetCol<0||targetRow<BUILD_LIMIT||targetRow>=ROWS||(!buildMode&&!breakMode))return;
        float x=GX+targetCol*CELL,y=screenY(GY+targetRow*CELL);
        RectF d=new RectF(x,y,x+CELL,y+CELL);
        if(buildMode&&blocks[targetRow][targetCol]<0&&textures[ghostBlock]!=null){
            p.setAlpha(105);p.setFilterBitmap(false);c.drawBitmap(textures[ghostBlock],null,d,p);p.setAlpha(255);
        }
        if(ghost!=null)bitmap(c,ghost,d);
        p.setStyle(Paint.Style.STROKE);p.setStrokeWidth(3);p.setColor(buildMode?0xff39ec69:0xffff5555);
        c.drawRect(d,p);p.setStyle(Paint.Style.FILL);
    }
    private void drawPlayer(Canvas c){
        int a=!grounded?2:((leftDown||rightDown)?(sprint?1:0):0);
        int f=a==2?jumpFrame:(a==1?runFrame:walkFrame);Bitmap b=sprites[a][f];if(b==null)return;
        float h=112,w=h*b.getWidth()/Math.max(1,b.getHeight()),y=screenY(playerFeet);
        RectF d=new RectF(playerX-w/2,y-h,playerX+w/2,y);
        c.save();if(!facingRight)c.scale(-1,1,playerX,0);bitmap(c,b,d);c.restore();
    }
    private void drawHud(Canvas c,float arenaH){
        // The HUD follows the player as the camera climbs, but remains inside the visible play area.
        float h=334,w=790;
        float top=Math.max(6,Math.min(arenaH-h-6,screenY(playerFeet)-arenaH*.78f));
        if(hudTop!=null){
            Rect src=new Rect(0,0,hudTop.getWidth(),hudTop.getHeight());
            p.setFilterBitmap(false);c.drawBitmap(hudTop,src,new RectF(37,top,827,top+h),p);
        }
        p.setTypeface(Typeface.create("sans-serif",Typeface.BOLD));p.setTextAlign(Paint.Align.CENTER);
        p.setColor(Color.WHITE);p.setShadowLayer(2,1,1,Color.BLACK);
        p.setTextSize(20);c.drawText("PLAYER",211,top+71,p);
        p.setTextSize(13);c.drawText("ONLINE",211,top+91,p);
        p.setTextSize(22);c.drawText(level()+"/10",490,top+69,p);
        int percent=Math.min(100,Math.round(countBlocks()*100f/(COLS*(ROWS-BUILD_LIMIT))));
        c.drawText(percent+"%",690,top+94,p);
        p.clearShadowLayer();
        // 50 layers total: every five layers advances one level.
        float bx=335,by=top+119,bw=235,bh=13;
        p.setColor(0xff101319);c.drawRoundRect(new RectF(bx,by,bx+bw,by+bh),5,5,p);
        p.setColor(0xff36df58);
        float fill=bw*Math.min(1f,placedTotal/(float)(LAYERS_PER_LEVEL*COLS*LEVELS));
        if(fill>0)c.drawRoundRect(new RectF(bx,by,bx+fill,by+bh),5,5,p);
        p.setColor(Color.WHITE);p.setTextSize(11);c.drawText("BLOCKS "+placedTotal+"/700",bx+bw/2,by+27,p);
    }
    private void drawControls(Canvas c,float arenaH){
        p.setColor(Color.WHITE);c.drawRect(0,arenaH,W,vh(),p);
        drawButton(c,leftImg,leftBtn,leftFx);drawButton(c,rightImg,rightBtn,rightFx);
        drawButton(c,runImg,runBtn,sprint||runFx);drawButton(c,pickImg,pickBtn,breakMode);
        drawButton(c,blockImg,blockBtn,buildMode);drawButton(c,jumpImg,jumpBtn,jumpFx);
    }
    private void drawButton(Canvas c,Bitmap b,RectF r,boolean active){
        if(b==null)return;
        if(active){p.setColor(0x5536cfff);p.setShadowLayer(12,0,0,0xff36cfff);
            c.drawRoundRect(r,22,22,p);p.clearShadowLayer();}
        bitmap(c,b,r);
    }

    private boolean inRange(int col,int row){
        float pr=(playerFeet-GY)/CELL;
        float dx=col-playerCol(),dy=row-pr;
        return Math.sqrt(dx*dx+dy*dy)<=MAX_RANGE;
    }
    private boolean supported(int row,int col){
        if(row==ROWS-1)return true;
        return blocks[row+1][col]>=0 || (col>0&&blocks[row][col-1]>=0)
                ||(col<COLS-1&&blocks[row][col+1]>=0);
    }
    private void build(){
        int col=targetCol,row=targetRow;
        if(col<0||row<BUILD_LIMIT||row>=ROWS||blocks[row][col]>=0||!inRange(col,row)||!supported(row,col))return;
        // The hotbar is intentionally empty for this stage; each placed tile gets a random block texture.
        blocks[row][col]=ghostBlock;placedTotal++;maxLayer=Math.max(maxLayer,maxStack());
        ghostBlock=blockRandom.nextInt(TYPES);
        updateSupport();
    }
    private void breakBlock(){
        int col=targetCol,row=targetRow;
        if(col<0||row<BUILD_LIMIT||row>=ROWS||blocks[row][col]<0||!inRange(col,row))return;
        blocks[row][col]=-1;brokenTotal++;updateSupport();
    }
    private void updateSupport(){
        float support=supportFeet(playerCol());
        if(playerFeet>support){playerFeet=support;vy=0;grounded=true;}
    }
    private void physics(){
        long now=System.nanoTime();if(lastFrame==0)lastFrame=now;
        float dt=Math.min(.04f,(now-lastFrame)/1e9f);lastFrame=now;
        float speed=sprint?260:150;
        float move=0f;
        if(leftDown&&!rightDown){move=-speed*dt;facingRight=false;}
        if(rightDown&&!leftDown){move=speed*dt;facingRight=true;}
        float candidateX=Math.max(GX+CELL/2,Math.min(GX+(COLS-.5f)*CELL,playerX+move));
        int candidateCol=clamp((int)((candidateX-GX)/CELL),0,COLS-1);
        float candidateSupport=supportFeet(candidateCol);
        // A raised neighboring column is a solid step: jump to climb it instead of teleporting.
        if(!grounded || candidateSupport>=playerFeet-CELL*.15f) playerX=candidateX;
        float support=supportFeet(playerCol());
        if(grounded)playerFeet=support;
        if(jumpDown&&grounded){vy=-650;grounded=false;}
        if(!grounded){
            vy+=1550*dt;playerFeet+=vy*dt;
            if(vy>0&&playerFeet>=support){playerFeet=support;vy=0;grounded=true;}
        }
        float targetCam=playerFeet-ah()*.68f;
        float maxCam=GY+BUILD_LIMIT*CELL-12;
        cameraY=Math.max(0,Math.min(maxCam,targetCam));
        animClock+=dt;
        if(!grounded){if(animClock>.12f){jumpFrame=(jumpFrame+1)%5;animClock=0;}}
        else if(leftDown||rightDown){float delay=sprint?.075f:.13f;if(animClock>delay){
            if(sprint)runFrame=(runFrame+1)%5;else walkFrame=(walkFrame+1)%5;animClock=0;}}
        else{walkFrame=0;animClock=0;}
    }
    private float tx(float x){return x/Math.max(.001f,s());}
    private float ty(float y){return y/Math.max(.001f,s());}
    private void updateTarget(float x,float y){
        int col=(int)((x-GX)/CELL),row=(int)((y+cameraY-GY)/CELL);
        targetCol=(col>=0&&col<COLS)?col:-1;targetRow=(row>=0&&row<ROWS)?row:-1;
    }

    @Override public boolean onTouchEvent(MotionEvent e){
        int a=e.getActionMasked(),i=e.getActionIndex();float x=tx(e.getX(i)),y=ty(e.getY(i));
        if(a==MotionEvent.ACTION_DOWN){
            downX=x;downY=y;downOnGrid=y<ah()&&x>=GX&&x<GX+COLS*CELL;
            if(downOnGrid)updateTarget(x,y);
            if(leftBtn.contains(x,y)){leftDown=true;leftFx=true;}
            else if(rightBtn.contains(x,y)){rightDown=true;rightFx=true;}
            else if(runBtn.contains(x,y)){sprint=!sprint;runFx=true;}
            else if(pickBtn.contains(x,y)){breakMode=!breakMode;if(breakMode)buildMode=false;}
            else if(blockBtn.contains(x,y)){buildMode=!buildMode;if(buildMode){breakMode=false;ghostBlock=blockRandom.nextInt(TYPES);}}
            else if(jumpBtn.contains(x,y)){jumpDown=true;jumpFx=true;}
            invalidate();return true;
        }
        if(a==MotionEvent.ACTION_MOVE){
            if(downOnGrid)updateTarget(x,y);
            leftDown=rightDown=jumpDown=false;
            for(int n=0;n<e.getPointerCount();n++){
                float px=tx(e.getX(n)),py=ty(e.getY(n));
                if(leftBtn.contains(px,py))leftDown=true;
                if(rightBtn.contains(px,py))rightDown=true;
                if(jumpBtn.contains(px,py))jumpDown=true;
            }
            invalidate();return true;
        }
        if(a==MotionEvent.ACTION_UP||a==MotionEvent.ACTION_CANCEL||a==MotionEvent.ACTION_POINTER_UP){
            if(downOnGrid&&y<ah()){updateTarget(x,y);if(buildMode)build();else if(breakMode)breakBlock();}
            leftDown=rightDown=jumpDown=false;leftFx=rightFx=runFx=jumpFx=false;downOnGrid=false;
            invalidate();return true;
        }
        return true;
    }
}
