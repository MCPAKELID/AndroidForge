# TIK MCPAKEL Android — source integrasi

## Isi
- Aplikasi Android native dengan tombol START / RESTART / STOP.
- Android Foreground Service.
- JNI runner untuk runtime Node.js Mobile.
- Source backend asli TIK dan aset banner/ikon.
- WhatsApp/Baileys tidak dimasukkan sebagai dependency.

## Runtime
Mengunduh Node.js Mobile 24.22.1-0 dari:
https://github.com/fogtape/nodejs-mobile/releases/tag/v24.22.1-0

Node.js 24 memenuhi syarat >=20 untuk TikTok LIVE Connector 2.4.4.
Gradle mengunduh archive saat preBuild, lalu mencari `libnode.so` dan `node.h`.
Jika struktur archive upstream berubah, task `downloadNodeMobile` akan berhenti dengan error eksplisit.

## Penting sebelum build
1. Build runner harus memiliki Java 17+, Android SDK/NDK, CMake 3.22.1, Node.js dan npm.
2. `npm install` dijalankan saat build untuk memaketkan dependency ke asset folder.
3. Backend asli masih memerlukan adaptasi penuh dari terminal prompt ke `settings.json`/bridge Android. Tombol native saat ini memulai Node runtime dengan `index.js`, tetapi belum mengirimkan konfigurasi UI ke backend.
4. Node mobile embedded tidak menyediakan perilaku OS desktop penuh; child_process dan native addons harus diverifikasi. Baileys sengaja dikeluarkan.
5. Foreground service pada Android 8+ dapat tetap berjalan saat activity ditutup, tetapi Android/OEM masih dapat menghentikan proses; Force Stop menghentikan aplikasi.
6. Source ini belum diuji build end-to-end pada AndroidForge atau perangkat fisik. Jangan anggap ZIP sebagai APK teruji.

## TikTok connector
`package.json` mempertahankan `tiktok-live-connector` versi tepat `2.4.4` dan engine `>=20`.
