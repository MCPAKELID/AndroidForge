# BlockRush Live Game v18 — AndroidForge Source

## v18 changes

- Added press feedback to menu/settings/pause buttons and a pressed scale animation to the touch controls.
- Removed the opaque blue control-panel effect: the scrolling arena background is now drawn behind the transparent control icons, so the map remains visible below the play viewport.
- Enlarged the top HUD counters and progress strip; the HUD PNG keeps its transparent canvas.
- Removed the placed-block pop animation. Blocks now appear immediately at full size.
- Added a short player lean/reach animation when placing a block.
- Changed material progression to one texture per three consecutive vertical layers, in order through the supplied 48 textures.
- Removed column settling after a block is broken. Blocks above a destroyed support remain in their original cells, matching the requested Minecraft-style floating behavior.
- Newly placed blocks still fall to the nearest supported position in their column when placed into open air.

## Build
Import this ZIP as a project with its contents extracted directly into the AndroidForge workspace (the ZIP root contains `settings.gradle` and `build.gradle`). Build the `app` module with JDK 17 and Android SDK Platform 35.

Application ID: `com.mcpakel.blockarea`
Version: 1.8 (versionCode 18)

Java source syntax was checked with Android API stubs. A full AndroidForge APK build and on-device test have not been run in this environment.
