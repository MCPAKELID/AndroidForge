# BlockRush Live Game v19 — AndroidForge Source

## v19 changes

- Corrected HUD scaling to preserve the supplied transparent HUD artwork aspect ratio; adjusted the 0/40 counter, percentage counter, green segmented fill, and trophy win counter positions.
- Block placement now automatically selects the nearest reachable landing cell beside the player and displays the green placement marker. Pressing the block button places at that marker without requiring a separate grid tap.
- Newly placed blocks fall smoothly from above into the selected supported cell. Existing blocks remain in place when their lower support is broken.
- Added drag-friendly left/right movement: keep a finger down and slide across the left control zone to switch direction. Multi-touch remains supported for movement plus jump.
- Aligned the arena cell pitch more closely to the supplied 10 x 40 grid and its floor edge.
- When all 400 cells are filled, gameplay pauses for a 15-to-1 countdown, followed by a slower 3-2-1 and a BOOM flash. The board then resets and the trophy counter increases by 1/10.
- The HUD and touch controls remain transparent overlays so the scrolling arena is visible behind them.

## Build
Import this ZIP as a project with its contents extracted directly into the AndroidForge workspace (the ZIP root contains `settings.gradle` and `build.gradle`). Build the `app` module with JDK 17 and Android SDK Platform 35.

Application ID: `com.mcpakel.blockarea`
Version: 1.9 (versionCode 19)

Java source syntax was checked with Android API stubs. A full AndroidForge APK build and on-device touch/gameplay test have not been run in this environment.
