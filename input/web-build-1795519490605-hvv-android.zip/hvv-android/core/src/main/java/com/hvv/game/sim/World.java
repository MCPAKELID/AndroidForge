package com.hvv.game.sim;

import java.util.ArrayList;
import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Random;
import java.util.regex.Pattern;

/**
 * Logika game HOST vs VIEWERS (tanpa libGDX, jadi bisa dites di JVM biasa).
 * Koordinat: y ke BAWAH, ukuran dunia 720 x 1280 (portrait 9:16).
 */
public final class World {
    public static final float W = 720f, H = 1280f;

    public enum Phase { INTRO, PLAY, RESULT }

    public enum UnitType {
        GRUNT(22, 3, 62, 3), RUNNER(16, 1, 140, 2), TANK(36, 12, 38, 10), BOSS(84, 100, 20, 30);
        public final float r, spd; public final int hp, dmg;
        UnitType(float r, int hp, float spd, int dmg) { this.r = r; this.hp = hp; this.spd = spd; this.dmg = dmg; }
    }

    /** Pengaturan yang bisa diubah. */
    public static final class Config {
        public float roundSeconds = 120f, hostHp = 100f, difficulty = 1f;
        public int maxUnits = 150, rushSize = 14;
        public float userCooldown = 1f, tankCooldown = 8f, rushLikes = 150f, bombCooldown = 9f;
        public float spawnY = 305f, hostY = 900f, baseY = 985f, bossY = 440f;
    }

    public interface Sfx { void play(String kind); }

    public static final class Unit {
        public UnitType type; public User user;
        public float x, y, r, spd, dmg, ph, age, shoot, hover, flash;
        public int hp, max, color; public boolean dead;
    }
    public static final class Bullet {
        public float x, y, vx, vy, r = 6f; public int dmg = 1, pierce; public boolean dead; public List<Unit> hit;
    }
    public static final class EnemyBullet {
        public float x, y, vx, vy, r = 9f; public int dmg = 4; public User user; public boolean dead;
    }
    public static final class Particle { public float x, y, vx, vy, life, max, size; public int color; }
    public static final class FloatText { public float x, y, life = 1f, size; public String text; public int color; }
    public static final class Ring { public float x, y, r, max, life, t; public int color; }
    public static final class Banner { public String text, sub; public float t, max; }
    public static final class BoardEntry { public String id, name; public int pts, total; }
    public static final class Result {
        public boolean hostWon; public int kills; public List<BoardEntry> round, session;
    }

    private static final int[] LEVELS = {0, 25, 70, 140, 240, 380};   // kill untuk naik level senjata
    private static final int[] SHOTS = {1, 2, 3, 3, 5, 5};
    private static final float[] RATE = {4f, 4.5f, 5f, 6f, 6.5f, 7f}; // tembakan / detik
    private static final Pattern TANK = Pattern.compile("\\btank\\b");
    private static final Pattern FAST = Pattern.compile("\\b(cepat|fast|run)\\b");
    private static final String[] NAMES = {"Budi", "Siti", "Rizky", "Dewi", "Agus", "Putri", "Dimas", "Nadia", "Fajar", "Ayu",
            "Bayu", "Citra", "Doni", "Eka", "Fitri", "Gilang", "Hana", "Imam", "Jihan", "Kevin", "Lina", "Mira", "Naufal",
            "Oki", "Prita", "Qori", "Rafi", "Sari", "Tegar", "Umar", "Vina", "Wawan", "Yoga", "Zahra"};

    public final Config cfg = new Config();
    public Sfx sfx = kind -> { };
    public Runnable onRoundEnd = () -> { };

    // --- state yang dibaca renderer ---
    public Phase phase = Phase.INTRO;
    public float phaseT = 3f, t, roundT, hp, hostX = W / 2, targetX = W / 2, bombCd, rage, shake, hitFlash;
    public int round, kills, level = 1, winsHost, winsViewers;
    public final List<Unit> units = new ArrayList<>();
    public final List<Bullet> bullets = new ArrayList<>();
    public final List<EnemyBullet> enemyBullets = new ArrayList<>();
    public final List<Particle> parts = new ArrayList<>();
    public final List<FloatText> floats = new ArrayList<>();
    public final List<Ring> rings = new ArrayList<>();
    public Banner banner;
    public Result result;
    public List<BoardEntry> top = new ArrayList<>();

    // --- bot (mode tes) & autopilot ---
    public float botRate;
    public boolean auto;

    private final Map<String, BoardEntry> board = new LinkedHashMap<>();
    private final List<User> recent = new ArrayList<>();
    private final Map<String, Float> lastSpawn = new java.util.HashMap<>(), lastTank = new java.util.HashMap<>();
    private final Random rnd = new Random();
    private float fireT, rankT, botAcc, lastKillSfx;

    public World() { hp = cfg.hostHp; }

    // ============================== util ==============================
    private float rand(float a, float b) { return a + rnd.nextFloat() * (b - a); }
    private static float clamp(float v, float a, float b) { return Math.max(a, Math.min(b, v)); }
    private static String clean(String n) {
        if (n == null) return "viewer";
        String s = n.replaceAll("\\p{Cntrl}", "").trim();
        if (s.isEmpty()) return "viewer";
        return s.length() > 14 ? s.substring(0, 14) : s;
    }

    private void burst(float x, float y, int color, int n, float sp, float size) {
        for (int i = 0; i < n; i++) {
            float a = rand(0, 6.283f), v = rand(.3f, 1f) * sp;
            Particle p = new Particle();
            p.x = x; p.y = y; p.vx = (float) Math.cos(a) * v; p.vy = (float) Math.sin(a) * v;
            p.life = rand(.3f, .7f); p.max = .7f; p.size = rand(size * .5f, size); p.color = color;
            parts.add(p);
        }
    }
    private void floatText(float x, float y, String text, int color, float size) {
        FloatText f = new FloatText(); f.x = x; f.y = y; f.text = text; f.color = color; f.size = size; floats.add(f);
    }
    private void banner(String text, String sub) {
        Banner b = new Banner(); b.text = text; b.sub = sub; b.t = b.max = 2.4f; banner = b;
    }

    // ============================== papan skor ==============================
    private BoardEntry entry(User u) {
        BoardEntry e = board.get(u.id);
        if (e == null) { e = new BoardEntry(); e.id = u.id; board.put(u.id, e); }
        e.name = u.name;
        return e;
    }
    private void addPts(User u, int n) { BoardEntry e = entry(u); e.pts += n; e.total += n; }
    private void rank() {
        List<BoardEntry> l = new ArrayList<>();
        for (BoardEntry e : board.values()) if (e.pts > 0) l.add(e);
        Collections.sort(l, (a, b) -> b.pts - a.pts);
        top = new ArrayList<>(l.subList(0, Math.min(5, l.size())));
    }
    private void remember(User u) {
        for (int i = 0; i < recent.size(); i++) if (recent.get(i).id.equals(u.id)) { recent.remove(i); break; }
        recent.add(u);
        if (recent.size() > 40) recent.remove(0);
    }

    // ============================== spawn ==============================
    public Unit spawn(UnitType type, User u, float x, float dy, int hpOverride, float rOverride, int pts) {
        if (type != UnitType.BOSS && units.size() >= cfg.maxUnits) return null;
        // makin lama ronde berjalan, pasukan makin kuat & cepat (boss tidak ikut)
        float prog = (phase == Phase.PLAY && type != UnitType.BOSS) ? clamp(1f - roundT / cfg.roundSeconds, 0, 1) : 0f;
        int hpv = hpOverride >= 0 ? hpOverride : Math.round(type.hp * (1f + prog * .7f));
        float r = rOverride >= 0 ? rOverride : type.r;
        Unit un = new Unit();
        un.type = type; un.user = u; un.r = r; un.hp = hpv; un.max = hpv; un.dmg = type.dmg;
        un.x = clamp(Float.isNaN(x) ? rand(70, W - 70) : x, r, W - r);
        un.y = cfg.spawnY + dy;
        un.spd = type.spd * cfg.difficulty * (1f + prog * .6f) * rand(.85f, 1.15f);
        un.color = Colors.forUser(u.id);
        un.ph = rand(0, 6.28f); un.shoot = rand(.8f, 1.4f);
        units.add(un);
        addPts(u, pts);
        burst(un.x, un.y, un.color, type == UnitType.BOSS ? 30 : 6, type == UnitType.BOSS ? 250 : 90, 3);
        return un;
    }
    private Unit spawn(UnitType type, User u) { return spawn(type, u, Float.NaN, 0, -1, -1, 1); }

    // ============================== event ==============================
    public void handle(GameEvent e) {
        if (e == null) return;
        User u = new User(e.id, clean(e.name), e.avatar);
        remember(u);
        if (phase != Phase.PLAY) return;
        switch (e.type) {
            case CHAT: onChat(u, e.text == null ? "" : e.text); break;
            case LIKE: onLike(Math.max(1, e.count)); break;
            case GIFT: onGift(u, e.giftName, Math.max(1, e.diamonds)); break;
            case FOLLOW:
                spawn(UnitType.TANK, u, Float.NaN, 0, -1, -1, 3);
                floatText(W / 2, cfg.spawnY + 30, u.name + " follow!", Colors.GOLD, 26);
                break;
            case SHARE:
                for (int i = 0; i < 3; i++) spawn(UnitType.RUNNER, u, Float.NaN, i * 18, -1, -1, 1);
                break;
        }
    }

    private void onChat(User u, String text) {
        Float last = lastSpawn.get(u.id);
        if (t - (last == null ? -99f : last) < cfg.userCooldown) return;
        lastSpawn.put(u.id, t);
        String low = text.toLowerCase();
        Float lt = lastTank.get(u.id);
        if (TANK.matcher(low).find() && t - (lt == null ? -99f : lt) >= cfg.tankCooldown) {
            lastTank.put(u.id, t);
            spawn(UnitType.TANK, u, Float.NaN, 0, -1, -1, 3);
        } else if (FAST.matcher(low).find()) {
            spawn(UnitType.RUNNER, u);
            spawn(UnitType.RUNNER, u, Float.NaN, 16, -1, -1, 1);
        } else spawn(UnitType.GRUNT, u);
    }

    private void onLike(int n) {
        rage += n;
        while (rage >= cfg.rushLikes) { rage -= cfg.rushLikes; rush(); }
    }

    private void rush() {
        banner("RUSH!", "Like penonton penuh!"); sfx.play("rush");
        User fallback = new User("rush", "Viewer", "");
        int n = cfg.rushSize;
        for (int i = 0; i < n; i++) {
            User u = recent.isEmpty() ? fallback : recent.get(rnd.nextInt(recent.size()));
            spawn(UnitType.GRUNT, u, 60 + (W - 120) * (i + .5f) / n, (i % 2) * 24, -1, -1, 1);
        }
    }

    private void onGift(User u, String name, int dia) {
        addPts(u, (int) Math.ceil(dia / 2.0));
        if (dia >= 100) {
            int bossHp = (int) Math.min(900, 60 + dia * .8);
            float r = 70 + Math.min(30, dia / 20f);
            spawn(UnitType.BOSS, u, W / 2, 0, bossHp, r, 0);
            banner("BOSS dari " + u.name, name + " · " + dia + " diamond"); sfx.play("boss"); shake = 10;
        } else if (dia >= 20) {
            int n = Math.min(4, 1 + (dia - 20) / 40);
            for (int i = 0; i < n; i++) spawn(UnitType.TANK, u, Float.NaN, 0, -1, -1, 0);
            floatText(W / 2, cfg.spawnY + 30, u.name + " kirim " + n + " TANK!", Colors.GOLD, 28); sfx.play("up");
        } else {
            int n = Math.min(12, 2 + dia);
            for (int i = 0; i < n; i++) spawn(UnitType.GRUNT, u, Float.NaN, 0, -1, -1, 0);
            floatText(W / 2, cfg.spawnY + 30, u.name + " · " + name, Colors.GOLD, 24);
        }
    }

    // ============================== ronde ==============================
    public void startRound() {
        round++; phase = Phase.INTRO; phaseT = 3f; hp = cfg.hostHp; kills = 0; level = 1; rage = 0;
        units.clear(); bullets.clear(); enemyBullets.clear(); fireT = 0; bombCd = 0; result = null;
        hostX = targetX = W / 2;
        for (BoardEntry e : board.values()) e.pts = 0;
        top = new ArrayList<>();
    }

    private void endRound(boolean hostWon) {
        hp = Math.max(0, hp);
        if (hostWon) winsHost++; else winsViewers++;
        Result r = new Result();
        r.hostWon = hostWon; r.kills = kills;
        List<BoardEntry> a = new ArrayList<>(), b = new ArrayList<>();
        for (BoardEntry e : board.values()) { if (e.pts > 0) a.add(e); if (e.total > 0) b.add(e); }
        Collections.sort(a, (x, y) -> y.pts - x.pts);
        Collections.sort(b, (x, y) -> y.total - x.total);
        r.round = new ArrayList<>(a.subList(0, Math.min(3, a.size())));
        r.session = new ArrayList<>(b.subList(0, Math.min(3, b.size())));
        // salin supaya angka di layar hasil tidak berubah saat ronde baru
        r.round = copy(r.round, true); r.session = copy(r.session, false);
        result = r;
        for (Unit u : units) burst(u.x, u.y, u.color, 8, 200, 4);
        units.clear(); bullets.clear(); enemyBullets.clear(); banner = null; floats.clear();
        phase = Phase.RESULT; phaseT = 9f;
        sfx.play(hostWon ? "win" : "lose");
        onRoundEnd.run();
    }

    private static List<BoardEntry> copy(List<BoardEntry> in, boolean useRound) {
        List<BoardEntry> out = new ArrayList<>();
        for (BoardEntry e : in) {
            BoardEntry c = new BoardEntry(); c.id = e.id; c.name = e.name; c.pts = e.pts; c.total = e.total; out.add(c);
        }
        return out;
    }

    // ============================== host ==============================
    public void bomb() {
        if (bombCd > 0 || phase != Phase.PLAY) return;
        bombCd = cfg.bombCooldown;
        float R = 330f, x = hostX, y = cfg.hostY;
        Ring ring = new Ring(); ring.x = x; ring.y = y; ring.r = 20; ring.max = R; ring.life = ring.t = .5f; ring.color = Colors.ICE;
        rings.add(ring);
        for (Unit u : new ArrayList<>(units)) if (Math.hypot(u.x - x, u.y - y) < R + u.r) hurt(u, 6);
        for (EnemyBullet b : enemyBullets) if (Math.hypot(b.x - x, b.y - y) <= R) b.dead = true;
        shake = 14; sfx.play("bomb");
    }

    private void moveHost(float dt) {
        float step = 1500f * dt;
        hostX += clamp(targetX - hostX, -step, step);
        hostX = clamp(hostX, 40, W - 40);
    }

    private void autopilot() {
        if (!auto) return;
        Unit best = null;
        for (Unit u : units) if (best == null || u.y > best.y) best = u;
        if (best != null) targetX = clamp(best.x, 40, W - 40);
        if (bombCd <= 0) {
            int c = 0;
            for (Unit u : units) if (Math.hypot(u.x - hostX, u.y - cfg.hostY) < 330) c++;
            if (c >= 7) bomb();
        }
    }

    private void hostFire(float dt) {
        fireT -= dt;
        if (fireT > 0) return;
        int L = level;
        fireT = 1f / RATE[L - 1];
        int n = SHOTS[L - 1];
        for (int i = 0; i < n; i++) {
            float a = (i - (n - 1) / 2f) * .1f;
            Bullet b = new Bullet();
            b.x = hostX + (float) Math.sin(a) * 10; b.y = cfg.hostY - 34;
            b.vx = (float) Math.sin(a) * 1100f; b.vy = -(float) Math.cos(a) * 1100f;
            b.pierce = L >= 5 ? 1 : 0;
            bullets.add(b);
        }
    }

    // ============================== bot (mode tes) ==============================
    private void bots(float dt) {
        if (botRate <= 0) return;
        botAcc += dt * botRate;
        while (botAcc >= 1f) {
            botAcc -= 1f;
            String n = NAMES[rnd.nextInt(NAMES.length)], id = n + rnd.nextInt(60);
            float r = rnd.nextFloat();
            GameEvent e;
            if (r < .84f) {
                e = new GameEvent(GameEvent.Type.CHAT);
                e.text = rnd.nextFloat() < .08f ? "tank" : rnd.nextFloat() < .12f ? "cepat" : "halo";
            } else if (r < .97f) {
                e = new GameEvent(GameEvent.Type.LIKE); e.count = 5 + rnd.nextInt(25);
            } else if (r < .992f) {
                e = new GameEvent(GameEvent.Type.GIFT); e.giftName = "Rose"; e.diamonds = 1 + rnd.nextInt(9);
            } else if (r < .998f) {
                e = new GameEvent(GameEvent.Type.GIFT); e.giftName = "Lion"; e.diamonds = 60;
            } else {
                e = new GameEvent(GameEvent.Type.GIFT); e.giftName = "Universe"; e.diamonds = 150;
            }
            handle(e.user(id, id, ""));
        }
    }

    // ============================== update ==============================
    private void hurt(Unit u, int n) {
        if (u.dead) return;
        u.hp -= n; u.flash = .08f;
        if (u.hp <= 0) killUnit(u);
    }

    private void killUnit(Unit u) {
        if (u.dead) return;
        u.dead = true; kills++;
        boolean boss = u.type == UnitType.BOSS;
        burst(u.x, u.y, u.color, boss ? 60 : 10, boss ? 420 : 170, boss ? 6 : 3);
        if (boss) {
            Ring ring = new Ring(); ring.x = u.x; ring.y = u.y; ring.r = 10; ring.max = 260; ring.life = ring.t = .6f; ring.color = u.color;
            rings.add(ring);
            hp = Math.min(cfg.hostHp, hp + 8); shake = 20;
            banner("BOSS KALAH!", "+8 HP"); sfx.play("win");
        } else if (t - lastKillSfx > .05f) { lastKillSfx = t; sfx.play("kill"); }
        int L = 0;
        for (int k : LEVELS) if (kills >= k) L++;
        if (L > level) { level = L; banner("UPGRADE!", "Senjata Lv " + L); sfx.play("up"); }
    }

    private void hitBase(Unit u) {
        u.dead = true;
        int d = (int) u.dmg;
        hp -= d; addPts(u.user, d * 2);
        shake = Math.min(18f, 6 + d); hitFlash = .35f;
        floatText(u.x, cfg.baseY - 10, "-" + d, Colors.RED, 30);
        burst(u.x, cfg.baseY, Colors.RED, 14, 220, 4); sfx.play("hit");
    }

    private void updateUnits(float dt) {
        for (Unit u : units) {
            if (u.dead) continue;
            u.age += dt; u.flash = Math.max(0, u.flash - dt);
            if (u.type == UnitType.BOSS) {
                if (u.y < cfg.bossY && u.hover == 0) u.y += 70 * dt;
                else {
                    u.hover += dt;
                    if (u.hover > 20) u.y += 40 * dt;
                    else u.x = W / 2 + (float) Math.sin(u.age * .7f) * (W / 2 - u.r - 24);
                }
                u.shoot -= dt;
                if (u.shoot <= 0 && u.hover > 0) {
                    u.shoot = 1.5f;
                    double base = Math.atan2(cfg.hostY - u.y, hostX - u.x);
                    for (float da : new float[]{-.25f, 0f, .25f}) {
                        EnemyBullet b = new EnemyBullet();
                        b.x = u.x; b.y = u.y + u.r * .6f;
                        b.vx = (float) Math.cos(base + da) * 330f; b.vy = (float) Math.sin(base + da) * 330f;
                        b.user = u.user;
                        enemyBullets.add(b);
                    }
                }
            } else {
                u.y += u.spd * dt;
                u.x = clamp(u.x + (float) Math.sin(u.age * 2.2f + u.ph) * (u.type == UnitType.RUNNER ? 36 : 18) * dt, u.r, W - u.r);
            }
            if (u.y + u.r * .2f >= cfg.baseY) hitBase(u);
        }
    }

    private void updateBullets(float dt) {
        for (Bullet b : bullets) {
            b.x += b.vx * dt; b.y += b.vy * dt;
            if (b.y < cfg.spawnY - 30 || b.x < -20 || b.x > W + 20) { b.dead = true; continue; }
            for (Unit u : units) {
                if (u.dead || (b.hit != null && b.hit.contains(u))) continue;
                float dx = u.x - b.x, dy = u.y - b.y, rad = u.r + b.r;
                if (dx * dx + dy * dy < rad * rad) {
                    hurt(u, b.dmg); burst(b.x, b.y, Colors.WHITE, 2, 90, 2);
                    if (b.pierce > 0) {
                        if (b.hit == null) b.hit = new ArrayList<>();
                        b.hit.add(u); b.pierce--;
                    } else { b.dead = true; break; }
                }
            }
        }
        bullets.removeIf(b -> b.dead);
        for (EnemyBullet b : enemyBullets) {
            b.x += b.vx * dt; b.y += b.vy * dt;
            if (b.y > H + 20 || b.x < -20 || b.x > W + 20 || b.y < 0) { b.dead = true; continue; }
            if (Math.hypot(b.x - hostX, b.y - cfg.hostY) < b.r + 26) {
                b.dead = true; hp -= b.dmg; hitFlash = .35f; shake = 8; addPts(b.user, b.dmg * 2);
                floatText(hostX, cfg.hostY - 50, "-" + b.dmg, Colors.RED, 28); sfx.play("hit");
            }
        }
        enemyBullets.removeIf(b -> b.dead);
        units.removeIf(u -> u.dead);
    }

    private void updateFx(float dt) {
        for (Particle p : parts) { p.x += p.vx * dt; p.y += p.vy * dt; p.vx *= .96f; p.vy *= .96f; p.life -= dt; }
        parts.removeIf(p -> p.life <= 0);
        while (parts.size() > 600) parts.remove(0);
        for (FloatText f : floats) { f.y -= 40 * dt; f.life -= dt * .9f; }
        floats.removeIf(f -> f.life <= 0);
        for (Ring r : rings) { r.t -= dt; r.r = r.max * (1 - r.t / r.life); }
        rings.removeIf(r -> r.t <= 0);
    }

    public void update(float dt) {
        t += dt;
        shake = Math.max(0, shake - dt * 30); hitFlash = Math.max(0, hitFlash - dt);
        if (banner != null && (banner.t -= dt) <= 0) banner = null;
        updateFx(dt);
        if (phase == Phase.INTRO) {
            phaseT -= dt; moveHost(dt);
            if (phaseT <= 0) { phase = Phase.PLAY; roundT = cfg.roundSeconds; sfx.play("rush"); }
            return;
        }
        if (phase == Phase.RESULT) {
            phaseT -= dt;
            if (phaseT <= 0) startRound();
            return;
        }
        roundT -= dt; bombCd = Math.max(0, bombCd - dt);
        bots(dt); autopilot(); moveHost(dt); hostFire(dt);
        updateUnits(dt); updateBullets(dt);
        if ((rankT -= dt) <= 0) { rankT = .4f; rank(); }
        if (hp <= 0) endRound(false); else if (roundT <= 0) endRound(true);
    }
}
