package com.hvv.game.sim;

/** Event dari TikTok LIVE (atau simulasi) yang sudah dinormalisasi. */
public final class GameEvent {
    public enum Type { CHAT, LIKE, GIFT, FOLLOW, SHARE }

    public final Type type;
    public String id = "viewer";      // uniqueId
    public String name = "viewer";    // nickname
    public String avatar = "";        // URL foto profil (boleh kosong)
    public String text = "";          // isi komen
    public String giftName = "gift";
    public int count = 1;             // jumlah like
    public int diamonds = 1;          // total diamond gift

    public GameEvent(Type type) { this.type = type; }

    public GameEvent user(String id, String name, String avatar) {
        if (id != null && !id.isEmpty()) this.id = id;
        if (name != null && !name.isEmpty()) this.name = name;
        else this.name = this.id;
        this.avatar = avatar == null ? "" : avatar;
        return this;
    }
}
