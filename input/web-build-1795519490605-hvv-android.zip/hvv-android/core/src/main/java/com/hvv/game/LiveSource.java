package com.hvv.game;

import com.hvv.game.sim.GameEvent;

/** Sumber event TikTok LIVE. Implementasi Android ada di modul :android. Semua callback boleh datang dari thread lain. */
public interface LiveSource {
    interface Listener {
        void onEvent(GameEvent event);
        /** Status koneksi untuk ditampilkan di layar. */
        void onStatus(String status, boolean connected);
        /** Teks mentah dari server yang belum dikenali (untuk membantu menyesuaikan pemetaan). */
        void onDebug(String sample);
    }

    void start(String uniqueId, String apiKey, Listener listener);

    void stop();
}
