package com.hvv.game.render;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.graphics.Color;
import com.badlogic.gdx.graphics.GL20;
import com.badlogic.gdx.graphics.OrthographicCamera;
import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.graphics.g2d.BitmapFont;
import com.badlogic.gdx.graphics.g2d.GlyphLayout;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import com.badlogic.gdx.graphics.glutils.ShapeRenderer;
import com.badlogic.gdx.math.Vector2;
import com.badlogic.gdx.utils.viewport.FitViewport;
import com.hvv.game.sim.Colors;
import com.hvv.game.sim.World;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

/**
 * Semua gambar. Koordinat API publik memakai y ke BAWAH (0 = atas layar) seperti di World;
 * konversi ke y-ke-atas milik libGDX dilakukan di sini.
 * Urutan gambar: bentuk (ShapeRenderer) -> avatar + teks (SpriteBatch), supaya hanya ada sedikit pergantian shader.
 */
public final class GameRenderer {
    public static final float W = World.W, H = World.H;
    public static final int LEFT = 0, CENTER = 1, RIGHT = 2;

    private static final String TITLE = "HOST vs VIEWERS";   // <- nama game (sementara)
    private static final String[] TICKER = {
            "KOMEN = kirim pasukan ke host!",
            "Ketik \"tank\" = pasukan TANK (cooldown 8 dtk)",
            "Ketik \"cepat\" = 2 pasukan CEPAT",
            "TAP LIKE = isi meter RUSH!",
            "GIFT = BOSS! Makin mahal makin kuat",
            "FOLLOW = TANK gratis | SHARE = 3 pasukan cepat"};

    private final ShapeRenderer sr = new ShapeRenderer();
    private final SpriteBatch batch = new SpriteBatch();
    private final BitmapFont font = new BitmapFont();
    private final GlyphLayout layout = new GlyphLayout();
    private final OrthographicCamera cam = new OrthographicCamera();
    private final FitViewport vp = new FitViewport(W, H, cam);
    private final AvatarCache avatars = new AvatarCache();
    private final Color c1 = new Color(), c2 = new Color(), c3 = new Color(), c4 = new Color();
    private final Vector2 v2 = new Vector2();

    private final float[] starX = new float[70], starY = new float[70], starR = new float[70], starP = new float[70];

    private static final class Txt { String s; float x, y, size, a; int rgb, align; }
    private static final class Av { Texture tex; float x, y, r; }
    private final ArrayList<Txt> texts = new ArrayList<>(), txtPool = new ArrayList<>();
    private final ArrayList<Av> avs = new ArrayList<>(), avPool = new ArrayList<>();

    public GameRenderer() {
        font.getRegion().getTexture().setFilter(Texture.TextureFilter.Linear, Texture.TextureFilter.Linear);
        font.setUseIntegerPositions(false);
        Random r = new Random(7);
        for (int i = 0; i < starX.length; i++) {
            starX[i] = r.nextFloat() * W; starY[i] = r.nextFloat() * H; starR[i] = .6f + r.nextFloat() * 1.2f; starP[i] = r.nextFloat() * 6.28f;
        }
    }

    // ============================== dasar ==============================
    public void resize(int w, int h) { vp.update(w, h, true); }

    /** Layar -> koordinat dunia (y ke bawah). */
    public Vector2 unproject(int sx, int sy) {
        v2.set(sx, sy);
        vp.unproject(v2);
        v2.y = H - v2.y;
        return v2;
    }

    /** Mulai frame dan mulai lapisan bentuk. */
    public void beginFrame(float shakeX, float shakeY) {
        avatars.trim();
        Gdx.gl.glClearColor(0f, 0f, 0f, 1f);
        Gdx.gl.glClear(GL20.GL_COLOR_BUFFER_BIT);
        vp.apply();
        cam.position.set(W / 2 + shakeX, H / 2 - shakeY, 0f);
        cam.update();
        sr.setProjectionMatrix(cam.combined);
        batch.setProjectionMatrix(cam.combined);
        Gdx.gl.glEnable(GL20.GL_BLEND);
        Gdx.gl.glBlendFunc(GL20.GL_SRC_ALPHA, GL20.GL_ONE_MINUS_SRC_ALPHA);
        sr.begin(ShapeRenderer.ShapeType.Filled);
    }
    public void shapesBegin() { sr.begin(ShapeRenderer.ShapeType.Filled); }
    public void shapesEnd() { sr.end(); }

    private static void set(Color c, int rgb, float a) {
        c.set(((rgb >> 16) & 255) / 255f, ((rgb >> 8) & 255) / 255f, (rgb & 255) / 255f, a);
    }

    public void rect(float x, float y, float w, float h, int rgb, float a) {
        set(c1, rgb, a); sr.setColor(c1); sr.rect(x, H - y - h, w, h);
    }
    /** Gradasi vertikal: warna atas -> warna bawah. */
    public void rectV(float x, float y, float w, float h, int topRgb, float topA, int botRgb, float botA) {
        set(c1, botRgb, botA); set(c2, topRgb, topA);
        sr.rect(x, H - y - h, w, h, c1, c1, c2, c2);
    }
    public void circle(float x, float y, float r, int rgb, float a) {
        set(c1, rgb, a); sr.setColor(c1); sr.circle(x, H - y, r, Math.max(12, Math.min(48, (int) (r * .8f))));
    }
    public void triangle(float x1, float y1, float x2, float y2, float x3, float y3, int rgb, float a) {
        set(c1, rgb, a); sr.setColor(c1); sr.triangle(x1, H - y1, x2, H - y2, x3, H - y3);
    }
    /** Cincin (atau sebagian cincin) dari segmen garis; frac 0..1 mulai dari atas searah jarum jam. */
    public void ring(float cx, float cy, float r, float frac, float width, int rgb, float a) {
        if (frac <= 0) return;
        set(c1, rgb, a); sr.setColor(c1);
        int n = Math.max(16, (int) (r / 2.5f)), k = Math.max(1, Math.round(n * Math.min(1f, frac)));
        double step = Math.PI * 2 / n, start = -Math.PI / 2;
        for (int i = 0; i < k; i++) {
            float x1 = cx + (float) Math.cos(start + i * step) * r, y1 = cy + (float) Math.sin(start + i * step) * r;
            float x2 = cx + (float) Math.cos(start + (i + 1) * step) * r, y2 = cy + (float) Math.sin(start + (i + 1) * step) * r;
            sr.rectLine(x1, H - y1, x2, H - y2, width);
        }
    }

    /** Antri teks; y = garis dasar (y ke bawah). */
    public void text(String s, float x, float baselineY, float size, int rgb, float a, int align) {
        Txt t = txtPool.isEmpty() ? new Txt() : txtPool.remove(txtPool.size() - 1);
        t.s = s; t.x = x; t.y = baselineY; t.size = size; t.rgb = rgb; t.a = a; t.align = align;
        texts.add(t);
    }
    public void text(String s, float x, float baselineY, float size, int rgb, int align) { text(s, x, baselineY, size, rgb, 1f, align); }

    private void queueAvatar(Texture tex, float x, float y, float r) {
        Av v = avPool.isEmpty() ? new Av() : avPool.remove(avPool.size() - 1);
        v.tex = tex; v.x = x; v.y = y; v.r = r; avs.add(v);
    }

    /** Gambar semua avatar dan teks yang diantri. */
    public void flushText() {
        if (avs.isEmpty() && texts.isEmpty()) return;
        batch.begin();
        batch.setColor(1f, 1f, 1f, 1f);
        for (Av v : avs) batch.draw(v.tex, v.x - v.r, H - v.y - v.r, v.r * 2, v.r * 2);
        for (Txt t : texts) {
            font.getData().setScale(t.size / 15f);
            float px = t.x;
            if (t.align != LEFT) {
                layout.setText(font, t.s);
                px = t.align == CENTER ? t.x - layout.width / 2f : t.x - layout.width;
            }
            float py = H - t.y + font.getCapHeight();
            float o = Math.max(1.5f, t.size / 12f);
            font.setColor(0f, 0f, 0f, .85f * t.a);
            font.draw(batch, t.s, px + o, py - o);
            set(c3, t.rgb, t.a); font.setColor(c3);
            font.draw(batch, t.s, px, py);
        }
        batch.end();
        avPool.addAll(avs); avs.clear();
        txtPool.addAll(texts); texts.clear();
    }

    public static String shorten(String s, int n) { return s.length() > n ? s.substring(0, n - 2) + ".." : s; }

    // ============================== game ==============================
    public void renderGame(World w, String status, boolean connected) {
        float sh = w.shake;
        beginFrame((float) (Math.random() - .5) * sh, (float) (Math.random() - .5) * sh);
        drawBackground(w);
        for (World.Unit u : w.units) drawUnit(u);
        for (World.Bullet b : w.bullets) rect(b.x - 3, b.y - 12, 6, 24, 0xC9FDFF, 1f);
        for (World.EnemyBullet b : w.enemyBullets) { circle(b.x, b.y, b.r + 5, 0xFF2D95, .35f); circle(b.x, b.y, b.r, 0xFF5FA8, 1f); }
        drawHost(w);
        for (World.Particle p : w.parts) rect(p.x - p.size / 2, p.y - p.size / 2, p.size, p.size, p.color, Math.max(0f, Math.min(1f, p.life / p.max)));
        for (World.Ring r : w.rings) ring(r.x, r.y, r.r, 1f, 8f, r.color, Math.max(0f, r.t / r.life));
        for (World.FloatText f : w.floats) text(f.text, f.x, f.y, f.size, f.color, Math.max(0f, Math.min(1f, f.life)), CENTER);
        drawHud(w, status, connected);
        sr.end();
        flushText();

        if (w.phase == World.Phase.INTRO) {
            shapesBegin(); rect(0, 0, W, H, 0x000000, .45f); shapesEnd();
            text("RONDE " + w.round, W / 2, 560, 64, 0xFFFFFF, CENTER);
            text(String.valueOf((int) Math.ceil(w.phaseT)), W / 2, 680, 120, Colors.GOLD, CENTER);
            text("Bertahan sampai waktu habis!", W / 2, 740, 26, 0x9FD0FF, CENTER);
            flushText();
        } else if (w.phase == World.Phase.RESULT && w.result != null) {
            drawResult(w);
        }
    }

    private void drawBackground(World w) {
        rectV(0, 0, W, H / 2, 0x1A0A3D, 1f, 0x0A1033, 1f);
        rectV(0, H / 2, W, H / 2, 0x0A1033, 1f, 0x03182B, 1f);
        for (int i = 0; i < starX.length; i++) {
            float a = .35f + .35f * (float) Math.sin(w.t * 1.5f + starP[i]);
            circle(starX[i], starY[i], starR[i], 0xCFE0FF, a);
        }
        for (float y = (w.t * 30f) % 60f; y < H; y += 60f) rect(0, y, W, 1, 0x78A0FF, .07f);
        for (float x = 0; x <= W; x += 90f) rect(x, 0, 1, H, 0x78A0FF, .07f);
        float sy = w.cfg.spawnY;                                   // portal viewers
        rectV(0, sy - 40, W, 35, 0xFF3CB4, 0f, 0xFF3CB4, .35f);
        rectV(0, sy - 5, W, 35, 0xFF3CB4, .35f, 0xFF3CB4, 0f);
        rect(0, sy - 3, W, 3, 0xFF4FC3, 1f);
        float by = w.cfg.baseY;                                    // base host
        rectV(0, by - 40, W, 70, 0x3CF0FF, 0f, 0x3CF0FF, .22f);
        rectV(0, by + 30, W, 170, 0x3CF0FF, .22f, 0x3CF0FF, .05f);
        rect(0, by - 6, W, 14, w.hitFlash > 0 ? Colors.RED : Colors.CYAN, .25f);
        rect(0, by, W, 4, w.hitFlash > 0 ? Colors.RED : Colors.CYAN, 1f);
    }

    private void drawUnit(World.Unit u) {
        float x = u.x, y = u.y, r = u.r;
        boolean boss = u.type == World.UnitType.BOSS, tank = u.type == World.UnitType.TANK;
        if (boss || tank) circle(x, y, r + (boss ? 18 : 10), u.color, .22f);
        if (boss) circle(x, y, r + 10, Colors.PINK, 1f);
        circle(x, y, r, 0xFFFFFF, 1f);
        circle(x, y, r - (boss ? 6 : tank ? 4 : 2.5f), u.flash > 0 ? 0xFFFFFF : u.color, 1f);
        Texture tex = avatars.get(u.user.avatar);
        if (tex != null) queueAvatar(tex, x, y, r - 3);
        else text(u.user.name.substring(0, 1).toUpperCase(), x, y + r * .36f, r * 1.05f, 0xFFFFFF, CENTER);
        if (u.max > 2) {
            float w = r * 1.8f, p = Math.max(0f, Math.min(1f, u.hp / (float) u.max)), by = y + r + 8, h = boss ? 10 : 6;
            rect(x - w / 2, by, w, h, 0x000000, .6f);
            rect(x - w / 2, by, w * p, h, p > .5f ? 0x5DFF8F : p > .25f ? Colors.GOLD : Colors.RED, 1f);
        }
        text(shorten(u.user.name, 12), x, y - r - 8, boss ? 28 : tank ? 20 : 16, 0xFFFFFF, CENTER);
    }

    private void drawHost(World w) {
        float x = w.hostX, y = w.cfg.hostY;
        float a = w.hitFlash > 0 ? .45f + .45f * (float) Math.sin(w.t * 60f) : 1f;
        circle(x, y, 56, Colors.CYAN, .12f * a);
        triangle(x, y - 38, x + 28, y + 26, x, y + 12, 0xD6FDFF, a);
        triangle(x, y - 38, x, y + 12, x - 28, y + 26, 0x14B4D6, a);
        circle(x, y - 4, 5, Colors.PINK, a);
        text("HOST", x, y + 62, 20, Colors.ICE, CENTER);
        ring(x, y, 46, 1f, 3f, 0xFFFFFF, .18f);
        float p = 1f - w.bombCd / w.cfg.bombCooldown;
        ring(x, y, 46, p, 4f, p >= 1f ? Colors.ICE : Colors.GOLD, 1f);
    }

    private void drawHud(World w, String status, boolean connected) {
        World.Config cfg = w.cfg;
        text(TITLE, W / 2, 36, 26, Colors.GOLD, CENTER);
        float left = Math.max(0f, w.roundT);
        String tstr = w.phase == World.Phase.PLAY ? ((int) (left / 60)) + ":" + String.format("%02d", (int) (left % 60)) : "--:--";
        boolean blink = left < 10 && w.phase == World.Phase.PLAY && Math.sin(w.t * 10) > 0;
        text(tstr, W / 2, 98, 60, blink ? Colors.RED : 0xFFFFFF, CENTER);
        text("RONDE " + w.round, W / 2, 126, 18, 0x9FB3FF, CENTER);
        text("HOST", 36, 70, 18, Colors.ICE, LEFT); text(String.valueOf(w.winsHost), 36, 118, 52, Colors.ICE, LEFT);
        text("VIEWERS", W - 36, 70, 18, 0xFF7FD5, RIGHT); text(String.valueOf(w.winsViewers), W - 36, 118, 52, 0xFF7FD5, RIGHT);

        float bx = 60, bw = 600;
        float p = Math.max(0f, Math.min(1f, w.hp / cfg.hostHp));
        rect(bx - 4, 146, bw + 8, 34, 0x000000, .6f);
        rect(bx, 150, bw * p, 26, p > .5f ? Colors.GREEN : p > .25f ? 0xFFC43A : 0xFF4560, 1f);
        text("HP BASE  " + (int) Math.ceil(Math.max(0f, w.hp)) + "/" + (int) cfg.hostHp, W / 2, 170, 20, 0xFFFFFF, CENTER);
        float q = Math.max(0f, Math.min(1f, w.rage / cfg.rushLikes));
        rect(bx - 4, 186, bw + 8, 28, 0x000000, .6f);
        rect(bx, 190, bw * q, 20, 0xFF8A2B, 1f);
        text("LIKE RUSH  " + (int) w.rage + "/" + (int) cfg.rushLikes, W / 2, 206, 16, 0xFFFFFF, CENTER);

        int ti = ((int) (w.t / 5f)) % TICKER.length;
        float tf = (w.t % 5f) / 5f;
        text(TICKER[ti], W / 2, 240, 22, 0xD9E4FF, Math.min(1f, Math.min(tf * 6f, (1f - tf) * 6f)), CENTER);

        List<World.BoardEntry> top = w.top;
        if (!top.isEmpty()) {
            rect(14, 340, 236, 34 + top.size() * 30, 0x060818, .72f);
            text("TOP PENONTON", 28, 366, 17, Colors.GOLD, LEFT);
            for (int i = 0; i < top.size(); i++) {
                float y = 396 + i * 30;
                World.BoardEntry e = top.get(i);
                text((i + 1) + ". " + shorten(e.name, 10), 28, y, 18, i == 0 ? 0xFFE27A : 0xFFFFFF, LEFT);
                text(String.valueOf(e.pts), 236, y, 18, Colors.ICE, RIGHT);
            }
        }

        if (w.banner != null) {
            World.Banner b = w.banner;
            float k = b.t / b.max, a = Math.max(0f, Math.min(1f, Math.min(k * 4f, (1f - k) * 8f + .2f)));
            float sc = 1f + (1f - Math.min(1f, (1f - k) * 6f)) * .4f;
            text(b.text, W / 2, 560, 58 * sc, Colors.GOLD, a, CENTER);
            if (b.sub != null && !b.sub.isEmpty()) text(b.sub, W / 2, 604, 26 * sc, 0xFFFFFF, a, CENTER);
        }

        // tombol BOM (kanan bawah)
        float cx = BOMB_X, cy = BOMB_Y;
        circle(cx, cy, BOMB_R, 0x000000, .55f);
        float bp = 1f - w.bombCd / cfg.bombCooldown;
        ring(cx, cy, BOMB_R - 5, bp, 8f, bp >= 1f ? Colors.ICE : Colors.GOLD, 1f);
        text("BOM", cx, cy + 10, 28, bp >= 1f ? Colors.ICE : 0xFFFFFF, CENTER);

        // status koneksi
        circle(20, 20, 7, connected ? Colors.GREEN : 0xFFA53C, 1f);
        if (status != null && !status.isEmpty()) text(shorten(status, 46), 36, 26, 16, 0xB8C4E8, .9f, LEFT);
    }

    public static final float BOMB_X = 628, BOMB_Y = 1110, BOMB_R = 70;

    private void drawResult(World w) {
        World.Result r = w.result;
        shapesBegin(); rect(0, 0, W, H, 0x000000, .72f); shapesEnd();
        text(r.hostWon ? "HOST MENANG!" : "VIEWERS MENANG!", W / 2, 400, 62, r.hostWon ? Colors.ICE : 0xFF7FD5, CENTER);
        text("Ronde " + w.round + " | " + r.kills + " pasukan dihancurkan", W / 2, 446, 24, 0xD9E4FF, CENTER);
        list("MVP RONDE INI", r.round, 530, true);
        list("TOP SESI", r.session, 720, false);
        text("Ronde berikutnya " + (int) Math.ceil(w.phaseT) + "...", W / 2, 1040, 24, 0x9FB3FF, CENTER);
        flushText();
    }

    private void list(String title, List<World.BoardEntry> arr, float y, boolean useRound) {
        text(title, W / 2, y, 24, Colors.GOLD, CENTER);
        if (arr.isEmpty()) text("-", W / 2, y + 40, 24, 0x9FB3FF, CENTER);
        for (int i = 0; i < arr.size(); i++) {
            World.BoardEntry e = arr.get(i);
            text((i + 1) + ". " + shorten(e.name, 14) + "  -  " + (useRound ? e.pts : e.total), W / 2, y + 40 + i * 36, 28, i == 0 ? 0xFFE27A : 0xFFFFFF, CENTER);
        }
    }

    public void dispose() { sr.dispose(); batch.dispose(); font.dispose(); avatars.dispose(); }
}
