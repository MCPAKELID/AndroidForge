package com.hvv.game.render;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.Net;
import com.badlogic.gdx.graphics.Pixmap;
import com.badlogic.gdx.graphics.Texture;

import java.util.HashMap;
import java.util.Map;

/** Mengunduh foto profil penonton, memotongnya jadi lingkaran 64x64, dan menyimpannya sebagai Texture. */
final class AvatarCache {
    private static final int SIZE = 64, MAX = 200;

    private static final class Entry { Texture tex; volatile boolean failed; }

    private final Map<String, Entry> cache = new HashMap<>();

    /** Mengembalikan texture bila sudah siap; kalau belum, mulai unduh dan kembalikan null. */
    Texture get(String url) {
        if (url == null || url.isEmpty()) return null;
        Entry e = cache.get(url);
        if (e == null) {
            if (cache.size() >= MAX + 50) return null;     // penuh: tunggu trim() di awal frame berikutnya
            e = new Entry();
            cache.put(url, e);
            load(url, e);
        }
        return e.tex;
    }

    private void load(final String url, final Entry e) {
        Net.HttpRequest req = new Net.HttpRequest(Net.HttpMethods.GET);
        req.setUrl(url);
        req.setTimeOut(8000);
        Gdx.net.sendHttpRequest(req, new Net.HttpResponseListener() {
            @Override public void handleHttpResponse(Net.HttpResponse response) {
                final byte[] bytes = response.getResult();
                Gdx.app.postRunnable(new Runnable() {
                    @Override public void run() { build(bytes, e); }
                });
            }
            @Override public void failed(Throwable t) { e.failed = true; }
            @Override public void cancelled() { e.failed = true; }
        });
    }

    /** Dijalankan di thread GL. */
    private void build(byte[] bytes, Entry e) {
        try {
            Pixmap src = new Pixmap(bytes, 0, bytes.length);
            Pixmap out = new Pixmap(SIZE, SIZE, Pixmap.Format.RGBA8888);
            out.drawPixmap(src, 0, 0, src.getWidth(), src.getHeight(), 0, 0, SIZE, SIZE);
            src.dispose();
            out.setBlending(Pixmap.Blending.None);
            out.setColor(0);                                   // transparan
            float c = (SIZE - 1) / 2f, r2 = (SIZE / 2f - 1) * (SIZE / 2f - 1);
            for (int y = 0; y < SIZE; y++)
                for (int x = 0; x < SIZE; x++)
                    if ((x - c) * (x - c) + (y - c) * (y - c) > r2) out.drawPixel(x, y);
            Texture t = new Texture(out);
            t.setFilter(Texture.TextureFilter.Linear, Texture.TextureFilter.Linear);
            out.dispose();
            e.tex = t;
        } catch (Exception ex) {
            e.failed = true;       // format tidak didukung: pakai huruf awal nama
        }
    }

    /** Dipanggil di awal frame (belum ada texture yang diantri), aman untuk membuang texture lama. */
    void trim() {
        if (cache.size() >= MAX) dispose();
    }

    void dispose() {
        for (Entry e : cache.values()) if (e.tex != null) e.tex.dispose();
        cache.clear();
    }
}
