package com.hvv.game.sim;

public final class User {
    public final String id, name, avatar;

    public User(String id, String name, String avatar) {
        this.id = id;
        this.name = name;
        this.avatar = avatar == null ? "" : avatar;
    }
}
