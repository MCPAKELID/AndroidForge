package com.hvv.game.sim;

/** Warna disimpan sebagai int RGB (0xRRGGBB) supaya sim tidak bergantung pada libGDX. */
public final class Colors {
    private Colors() {}

    public static final int WHITE = 0xFFFFFF, RED = 0xFF5470, CYAN = 0x3CF0FF, ICE = 0x7FFCFF,
            PINK = 0xFF4FC3, GOLD = 0xFFD24A, GREEN = 0x34E07A;

    /** HSL (h 0..360, s/l 0..1) -> 0xRRGGBB. */
    public static int hsl(float h, float s, float l) {
        h = ((h % 360f) + 360f) % 360f / 360f;
        float q = l < .5f ? l * (1 + s) : l + s - l * s, p = 2 * l - q;
        int r = Math.round(255 * hue(p, q, h + 1f / 3)), g = Math.round(255 * hue(p, q, h)), b = Math.round(255 * hue(p, q, h - 1f / 3));
        return (r << 16) | (g << 8) | b;
    }

    private static float hue(float p, float q, float t) {
        if (t < 0) t += 1;
        if (t > 1) t -= 1;
        if (t < 1f / 6) return p + (q - p) * 6 * t;
        if (t < .5f) return q;
        if (t < 2f / 3) return p + (q - p) * (2f / 3 - t) * 6;
        return p;
    }

    /** Warna konsisten per penonton. */
    public static int forUser(String id) {
        return hsl(Math.floorMod(id.hashCode(), 360), .85f, .58f);
    }
}
