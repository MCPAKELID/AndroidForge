package com.hvv.game;

import com.badlogic.gdx.ApplicationAdapter;
import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.Input;
import com.badlogic.gdx.InputAdapter;
import com.badlogic.gdx.Preferences;
import com.badlogic.gdx.math.Vector2;
import com.hvv.game.render.GameRenderer;
import com.hvv.game.sim.GameEvent;
import com.hvv.game.sim.World;

import java.util.concurrent.ConcurrentLinkedQueue;

/**
 * Game HOST vs VIEWERS (nama sementara).
 * Host main dengan sentuhan: geser jari = gerak, tombol BOM = ledakan. Tembakan otomatis.
 * Penonton TikTok mengirim pasukan lewat komen / like / gift (lihat World).
 */
public class HvvGame extends ApplicationAdapter {
    private static final float BOT_RATE = 1.5f;       // event bot per detik di mode tes

    private final LiveSource live;                    // null jika platform tidak punya koneksi TikTok
    private GameRenderer rend;
    private Sounds sounds;
    private Preferences prefs;
    private Menu menu;
    private World world;
    private boolean inGame, liveMode;
    private int movePointer = -1;
    private float menuT;

    private final ConcurrentLinkedQueue<GameEvent> queue = new ConcurrentLinkedQueue<>();
    private volatile String status = "";
    private volatile boolean connected;
    private float statusHideAt = -1f, clock;

    public HvvGame(LiveSource live) { this.live = live; }

    @Override public void create() {
        rend = new GameRenderer();
        sounds = new Sounds();
        prefs = Gdx.app.getPreferences("hostvsviewers");
        menu = new Menu(prefs.getString("user", ""), prefs.getString("key", ""));
        Gdx.input.setCatchKey(Input.Keys.BACK, true);
        Gdx.input.setInputProcessor(new InputAdapter() {
            @Override public boolean touchDown(int sx, int sy, int pointer, int button) { onTouchDown(sx, sy, pointer); return true; }
            @Override public boolean touchDragged(int sx, int sy, int pointer) {
                if (inGame && pointer == movePointer) world.targetX = rend.unproject(sx, sy).x;
                return true;
            }
            @Override public boolean touchUp(int sx, int sy, int pointer, int button) {
                if (pointer == movePointer) movePointer = -1;
                return true;
            }
            @Override public boolean keyDown(int keycode) {
                if (keycode == Input.Keys.BACK && inGame) { stopGame(); return true; }
                return false;
            }
        });
    }

    @Override public void resize(int width, int height) { rend.resize(width, height); }

    // ============================== input ==============================
    private void onTouchDown(int sx, int sy, int pointer) {
        Vector2 p = rend.unproject(sx, sy);
        if (!inGame) { onMenuTouch(menu.touch(p.x, p.y)); return; }
        float dx = p.x - GameRenderer.BOMB_X, dy = p.y - GameRenderer.BOMB_Y;
        if (dx * dx + dy * dy <= GameRenderer.BOMB_R * GameRenderer.BOMB_R * 1.4f) { world.bomb(); return; }
        if (movePointer == -1) { movePointer = pointer; world.targetX = p.x; }
    }

    private void onMenuTouch(int action) {
        switch (action) {
            case Menu.EDIT_USER:
                ask("Username TikTok (tanpa @)", menu.user, "contoh: namamu", new Setter() {
                    @Override public void set(String v) { menu.user = v.replace("@", "").trim(); prefs.putString("user", menu.user); prefs.flush(); }
                });
                break;
            case Menu.EDIT_KEY:
                ask("API key Euler Stream", menu.key, "tempel API key", new Setter() {
                    @Override public void set(String v) { menu.key = v.trim(); prefs.putString("key", menu.key); prefs.flush(); }
                });
                break;
            case Menu.START_LIVE:
                if (live == null) menu.message = "Koneksi TikTok tidak tersedia di platform ini.";
                else if (!menu.canStartLive()) menu.message = "Isi username dan API key dulu.";
                else startGame(true);
                break;
            case Menu.START_TEST:
                startGame(false);
                break;
            default:
                break;
        }
    }

    private interface Setter { void set(String value); }

    private void ask(String title, String current, String hint, final Setter setter) {
        Gdx.input.getTextInput(new Input.TextInputListener() {
            @Override public void input(final String text) {
                Gdx.app.postRunnable(new Runnable() { @Override public void run() { setter.set(text == null ? "" : text); menu.message = ""; } });
            }
            @Override public void canceled() { }
        }, title, current, hint);
    }

    // ============================== alur ==============================
    private void startGame(boolean liveSource) {
        liveMode = liveSource;
        world = new World();
        world.sfx = sounds;
        world.winsHost = prefs.getInteger("winsHost", 0);
        world.winsViewers = prefs.getInteger("winsViewers", 0);
        world.onRoundEnd = new Runnable() {
            @Override public void run() {
                prefs.putInteger("winsHost", world.winsHost);
                prefs.putInteger("winsViewers", world.winsViewers);
                prefs.flush();
            }
        };
        world.startRound();
        queue.clear();
        connected = false;
        if (liveSource) {
            world.botRate = 0f;
            status = "Menghubungkan...";
            live.start(menu.user.trim(), menu.key.trim(), new LiveSource.Listener() {
                @Override public void onEvent(GameEvent e) { queue.add(e); }
                @Override public void onStatus(String s, boolean ok) { status = s; connected = ok; if (ok) statusHideAt = clock + 6f; else statusHideAt = -1f; }
                @Override public void onDebug(String sample) { status = "Tak dikenali: " + sample; statusHideAt = -1f; }
            });
        } else {
            world.botRate = BOT_RATE;
            status = "Mode tes (bot)";
            connected = true;
            statusHideAt = clock + 4f;
        }
        movePointer = -1;
        inGame = true;
    }

    private void stopGame() {
        if (liveMode && live != null) live.stop();
        inGame = false; world = null; movePointer = -1; queue.clear();
    }

    @Override public void render() {
        float dt = Math.min(.05f, Gdx.graphics.getDeltaTime());
        clock += dt;
        if (!inGame) {
            menuT += dt;
            menu.draw(rend, menuT);
            return;
        }
        GameEvent e;
        while ((e = queue.poll()) != null) world.handle(e);
        world.update(dt);
        if (statusHideAt > 0 && clock > statusHideAt && connected) { status = ""; statusHideAt = -1f; }
        rend.renderGame(world, status, connected);
    }

    @Override public void dispose() {
        if (live != null) live.stop();
        if (sounds != null) sounds.dispose();
        if (rend != null) rend.dispose();
    }
}
