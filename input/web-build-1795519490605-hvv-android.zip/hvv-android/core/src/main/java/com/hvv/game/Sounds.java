package com.hvv.game;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.audio.Sound;
import com.hvv.game.sim.World;

import java.util.HashMap;
import java.util.Map;

/** Efek suara pendek dari assets/sfx/*.wav. */
final class Sounds implements World.Sfx {
    private static final String[] NAMES = {"kill", "hit", "bomb", "boss", "up", "rush", "win", "lose"};
    private final Map<String, Sound> sounds = new HashMap<>();
    boolean muted;

    Sounds() {
        for (String n : NAMES) {
            try {
                sounds.put(n, Gdx.audio.newSound(Gdx.files.internal("sfx/" + n + ".wav")));
            } catch (Exception ignored) { /* file suara hilang: game tetap jalan tanpa suara itu */ }
        }
    }

    @Override public void play(String kind) {
        if (muted) return;
        Sound s = sounds.get(kind);
        if (s != null) s.play(.7f);
    }

    void dispose() { for (Sound s : sounds.values()) s.dispose(); }
}
