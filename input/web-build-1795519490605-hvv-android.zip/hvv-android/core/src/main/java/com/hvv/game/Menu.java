package com.hvv.game;

import com.hvv.game.render.GameRenderer;
import com.hvv.game.sim.Colors;

/** Layar awal: isi username TikTok + API key Euler Stream, lalu mulai. Koordinat y ke bawah (720x1280). */
final class Menu {
    static final int NONE = 0, EDIT_USER = 1, EDIT_KEY = 2, START_LIVE = 3, START_TEST = 4;

    String user, key;
    String message = "";

    // x, y, w, h
    private static final float[] USER = {60, 350, 600, 90}, KEY = {60, 510, 600, 90},
            LIVE = {60, 670, 600, 110}, TEST = {60, 810, 600, 100};

    Menu(String user, String key) { this.user = user; this.key = key; }

    boolean canStartLive() { return !user.trim().isEmpty() && !key.trim().isEmpty(); }

    int touch(float x, float y) {
        if (hit(USER, x, y)) return EDIT_USER;
        if (hit(KEY, x, y)) return EDIT_KEY;
        if (hit(LIVE, x, y)) return START_LIVE;
        if (hit(TEST, x, y)) return START_TEST;
        return NONE;
    }

    private static boolean hit(float[] r, float x, float y) { return x >= r[0] && x <= r[0] + r[2] && y >= r[1] && y <= r[1] + r[3]; }

    void draw(GameRenderer g, float t) {
        final float W = GameRenderer.W;
        g.beginFrame(0, 0);
        g.rectV(0, 0, W, 640, 0x1A0A3D, 1f, 0x0A1033, 1f);
        g.rectV(0, 640, W, 640, 0x0A1033, 1f, 0x03182B, 1f);
        field(g, USER);
        field(g, KEY);
        button(g, LIVE, canStartLive() ? Colors.CYAN : 0x39414F, canStartLive() ? .95f : .6f);
        button(g, TEST, Colors.PINK, .9f);
        g.shapesEnd();

        g.text("HOST vs VIEWERS", W / 2, 190, 56, Colors.GOLD, GameRenderer.CENTER);
        g.text("game tembak live TikTok", W / 2, 240, 24, 0x9FB3FF, GameRenderer.CENTER);

        g.text("USERNAME TIKTOK (tanpa @)", 60, 338, 20, 0xD9E4FF, GameRenderer.LEFT);
        g.text(user.isEmpty() ? "ketuk untuk mengisi" : "@" + user, 84, 408, 34, user.isEmpty() ? 0x7F8AAA : 0xFFFFFF, GameRenderer.LEFT);
        g.text("API KEY EULER STREAM", 60, 498, 20, 0xD9E4FF, GameRenderer.LEFT);
        g.text(key.isEmpty() ? "ketuk untuk mengisi" : mask(key), 84, 568, 34, key.isEmpty() ? 0x7F8AAA : 0xFFFFFF, GameRenderer.LEFT);

        g.text("MULAI LIVE TIKTOK", W / 2, 742, 38, 0x04121A, 1f, GameRenderer.CENTER);
        g.text("MODE TES (BOT)", W / 2, 876, 34, 0xFFFFFF, 1f, GameRenderer.CENTER);

        g.text("API key gratis: eulerstream.com (akun Community)", W / 2, 990, 20, 0x9FB3FF, GameRenderer.CENTER);
        g.text("Mulai LIVE di TikTok dulu, lalu tekan MULAI.", W / 2, 1022, 20, 0x9FB3FF, GameRenderer.CENTER);
        g.text("Tombol Back = kembali ke layar ini.", W / 2, 1054, 20, 0x9FB3FF, GameRenderer.CENTER);
        if (!message.isEmpty()) g.text(message, W / 2, 1120, 22, Colors.GOLD, GameRenderer.CENTER);
        g.flushText();
    }

    private static void field(GameRenderer g, float[] r) {
        g.rect(r[0], r[1], r[2], r[3], 0x000000, .55f);
        g.rect(r[0], r[1] + r[3] - 3, r[2], 3, Colors.ICE, .8f);
    }

    private static void button(GameRenderer g, float[] r, int rgb, float a) { g.rect(r[0], r[1], r[2], r[3], rgb, a); }

    private static String mask(String k) {
        if (k.length() <= 6) return "******";
        return k.substring(0, 4) + "********" + k.substring(k.length() - 2);
    }
}
