# HOST vs VIEWERS (nama sementara) - project Android (libGDX, Java)

Game tembak 2D portrait untuk live TikTok. Host main dengan sentuhan, penonton mengirim pasukan lewat komen / like / gift. Event TikTok diterima langsung di HP.

## Build

1. Android Studio (JDK 17), pilih **Open** folder ini, tunggu Gradle sync (butuh internet).
2. Colok HP (USB debugging) lalu Run, atau **Build > Build APK(s)**. Hasilnya ada di `android/build/outputs/apk/debug/`.

Catatan: project ini belum pernah saya build (tidak ada Android SDK/internet di tempat saya membuatnya). Logika game sudah diuji di JVM dan seluruh kode sudah dicek kompilasinya terhadap stub API, tapi build Gradle pertama kali bisa meminta penyesuaian versi (AGP/Gradle) sesuai Android Studio kamu.

## Pakai

1. Buat akun gratis di eulerstream.com, ambil API key. Isi username TikTok dan API key di layar awal (tersimpan di HP).
2. Mulai LIVE di TikTok, lalu tekan **MULAI LIVE TIKTOK**. **MODE TES** memakai bot, tanpa TikTok.
3. Host: geser jari = gerak, tembak otomatis, tombol **BOM** (kanan bawah) = ledakan, cooldown 9 dtk. Tombol Back = kembali ke menu.

## Aturan

- Komen = 1 pasukan. Kata "tank" = tank (cooldown 8 dtk), kata "cepat" = 2 pasukan cepat.
- Like mengisi meter RUSH (150 like = 14 pasukan sekaligus).
- Gift kecil = squad, 20+ diamond = tank, 100+ diamond = BOSS yang menembak.
- Follow = tank gratis, share = 3 pasukan cepat.
- Timer 2 menit habis = HOST menang. HP base habis = VIEWERS menang. Pasukan makin kuat seiring ronde berjalan.

## Kalau event TikTok tidak masuk

Pemetaan JSON Euler ada di `android/src/main/java/com/hvv/game/android/EulerMapper.java`. Nama field-nya saya tulis berdasarkan skema tiktok-live-connector dan belum dicek terhadap pesan asli Euler. Kalau layar menampilkan "Tak dikenali: ..." berarti pesan masuk tapi bentuknya beda: sesuaikan fungsi `mapOne`. Kalau layar menampilkan "data biner (protobuf)", server mengirim protobuf dan `EulerLiveSource` perlu decoder.

## Struktur

- `core/.../sim/` logika game murni Java (tanpa libGDX): `World`, event, skor.
- `core/.../render/` gambar (ShapeRenderer + SpriteBatch), cache avatar.
- `core/.../HvvGame.java`, `Menu.java`, `Sounds.java` alur game, menu, suara (assets/sfx).
- `android/` launcher + koneksi Euler (OkHttp).

Ganti nama game: `TITLE` di `GameRenderer.java` dan teks judul di `Menu.java`.
Atur keseimbangan: `World.Config` (durasi ronde, HP, RUSH, cooldown) dan konstanta `LEVELS/SHOTS/RATE` di `World.java`.
