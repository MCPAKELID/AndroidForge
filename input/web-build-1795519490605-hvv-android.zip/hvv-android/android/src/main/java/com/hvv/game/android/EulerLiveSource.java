package com.hvv.game.android;

import com.hvv.game.LiveSource;
import com.hvv.game.sim.GameEvent;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;

import okhttp3.HttpUrl;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.Response;
import okhttp3.WebSocket;
import okhttp3.WebSocketListener;
import okio.ByteString;

/**
 * Menerima event TikTok LIVE langsung di HP lewat WebSocket Euler Stream:
 *   wss://ws.eulerstream.com?uniqueId=<username>&apiKey=<key>
 * Otomatis menyambung ulang (mis. kalau kreator belum LIVE).
 */
public final class EulerLiveSource implements LiveSource {
    private static final String HOST = "ws.eulerstream.com";

    private final OkHttpClient client = new OkHttpClient.Builder()
            .readTimeout(0, TimeUnit.MILLISECONDS)           // koneksi panjang
            .pingInterval(20, TimeUnit.SECONDS)
            .build();
    private final ScheduledExecutorService timer = Executors.newSingleThreadScheduledExecutor();

    private volatile boolean active;
    private volatile int generation;
    private volatile WebSocket socket;
    private String uniqueId = "", apiKey = "";
    private Listener listener;
    private int attempt;

    @Override
    public synchronized void start(String uniqueId, String apiKey, Listener listener) {
        stop();
        this.uniqueId = uniqueId.startsWith("@") ? uniqueId.substring(1) : uniqueId;
        this.apiKey = apiKey;
        this.listener = listener;
        this.attempt = 0;
        active = true;
        connect(++generation);
    }

    @Override
    public synchronized void stop() {
        active = false;
        generation++;
        WebSocket s = socket;
        socket = null;
        if (s != null) s.close(1000, "bye");
    }

    private synchronized void connect(final int gen) {
        if (!active || gen != generation) return;
        listener.onStatus("Menghubungkan ke @" + uniqueId + "...", false);
        HttpUrl url = new HttpUrl.Builder().scheme("https").host(HOST)
                .addQueryParameter("uniqueId", uniqueId)
                .addQueryParameter("apiKey", apiKey)
                .build();
        socket = client.newWebSocket(new Request.Builder().url(url).build(), new Handler(gen));
    }

    private void scheduleReconnect(final int gen, long delaySec) {
        timer.schedule(new Runnable() {
            @Override public void run() { connect(gen); }
        }, delaySec, TimeUnit.SECONDS);
    }

    private final class Handler extends WebSocketListener {
        private final int gen;
        private int mapped, unknown;
        private long lastDebug;
        private boolean warnedBinary;

        Handler(int gen) { this.gen = gen; }

        private boolean stale() { return !active || gen != generation; }

        @Override public void onOpen(WebSocket ws, Response response) {
            if (stale()) { ws.close(1000, "stale"); return; }
            attempt = 0;
            listener.onStatus("Terhubung ke @" + uniqueId + ", menunggu event...", true);
        }

        @Override public void onMessage(WebSocket ws, String text) {
            if (stale()) return;
            List<GameEvent> events = new ArrayList<>();
            int n = EulerMapper.map(text, events);
            for (GameEvent e : events) listener.onEvent(e);
            mapped += n;
            // pesan pertama biasanya info room (bukan event); tampilkan sampel hanya bila belum ada event yang dikenali
            long now = System.currentTimeMillis();
            if (n == 0 && mapped == 0 && ++unknown <= 5 && now - lastDebug > 4000) {
                lastDebug = now;
                listener.onDebug(text.length() > 70 ? text.substring(0, 70) : text);
            }
        }

        @Override public void onMessage(WebSocket ws, ByteString bytes) {
            if (stale() || warnedBinary) return;
            warnedBinary = true;
            listener.onStatus("Server kirim data biner (protobuf), belum didukung. Lihat README.", false);
        }

        @Override public void onClosing(WebSocket ws, int code, String reason) { ws.close(1000, null); }

        @Override public void onClosed(WebSocket ws, int code, String reason) { retry(code, reason); }

        @Override public void onFailure(WebSocket ws, Throwable t, Response response) {
            retry(response != null ? response.code() : -1, t.getMessage());
        }

        private void retry(int code, String reason) {
            if (stale()) return;
            long delay;
            if (code == 4404) {
                listener.onStatus("@" + uniqueId + " belum LIVE. Coba lagi 15 dtk...", false);
                delay = 15;
            } else {
                delay = Math.min(30, 3L << Math.min(attempt, 3));
                attempt++;
                String why = (reason == null || reason.isEmpty()) ? "" : ": " + reason;
                listener.onStatus("Terputus (" + code + ")" + why + ". Coba lagi " + delay + " dtk...", false);
            }
            scheduleReconnect(gen, delay);
        }
    }
}
