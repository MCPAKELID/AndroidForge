package com.hvv.game.android;

import com.hvv.game.sim.GameEvent;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.List;
import java.util.Locale;

/**
 * Mengubah pesan JSON dari WebSocket Euler Stream menjadi GameEvent.
 *
 * PENTING: nama field di sini mengikuti skema tiktok-live-connector (WebcastChatMessage, WebcastGiftMessage, ...)
 * dan ditulis toleran (beberapa kemungkinan nama). Dokumentasi Euler yang saya baca tidak merinci field JSON-nya,
 * jadi kalau event tidak muncul di game, lihat teks "Tak dikenali: ..." di pojok layar dan sesuaikan fungsi di bawah.
 */
final class EulerMapper {
    private EulerMapper() {}

    /** Mengembalikan jumlah event yang berhasil dipetakan. */
    static int map(String text, List<GameEvent> out) {
        JSONObject root;
        try {
            root = new JSONObject(text);
        } catch (JSONException e) {
            return 0;
        }
        JSONArray msgs = root.optJSONArray("messages");
        if (msgs == null) return mapOne(root, out);
        int n = 0;
        for (int i = 0; i < msgs.length(); i++) {
            JSONObject m = msgs.optJSONObject(i);
            if (m != null) n += mapOne(m, out);
        }
        return n;
    }

    private static int mapOne(JSONObject m, List<GameEvent> out) {
        String type = str(m, "type", "method", "event", "messageType", "msgType").toLowerCase(Locale.ROOT);
        JSONObject d = obj(m, "data", "payload", "message");
        if (d == null) d = m;
        JSONObject u = obj(d, "user");
        if (u == null) u = d;

        GameEvent e;
        if (type.contains("chat") || type.contains("comment")) {
            e = new GameEvent(GameEvent.Type.CHAT);
            e.text = str(d, "comment", "content", "text");
        } else if (type.contains("gift")) {
            JSONObject det = obj(d, "giftDetails", "gift", "giftInfo");
            int giftType = d.optInt("giftType", det != null ? det.optInt("giftType", 0) : 0);
            boolean repeatEnd = d.optBoolean("repeatEnd", false) || d.optInt("repeatEnd", 0) == 1;
            if (giftType == 1 && !repeatEnd) return 0;       // gift beruntun: hitung hanya di akhir streak
            int per = d.optInt("diamondCount", d.optInt("diamond_count", det != null ? det.optInt("diamondCount", det.optInt("diamond_count", 1)) : 1));
            int repeat = Math.max(1, d.optInt("repeatCount", 1));
            e = new GameEvent(GameEvent.Type.GIFT);
            String name = str(d, "giftName");
            if (name.isEmpty() && det != null) name = str(det, "giftName", "name");
            e.giftName = name.isEmpty() ? "gift" : name;
            e.diamonds = Math.max(1, per) * repeat;
        } else if (type.contains("like")) {
            e = new GameEvent(GameEvent.Type.LIKE);
            e.count = Math.max(1, d.optInt("likeCount", d.optInt("count", 1)));
        } else if (type.contains("follow")) {
            e = new GameEvent(GameEvent.Type.FOLLOW);
        } else if (type.contains("share")) {
            e = new GameEvent(GameEvent.Type.SHARE);
        } else if (type.contains("social")) {
            String kind = str(d, "displayType", "label", "action").toLowerCase(Locale.ROOT);
            if (kind.contains("follow")) e = new GameEvent(GameEvent.Type.FOLLOW);
            else if (kind.contains("share")) e = new GameEvent(GameEvent.Type.SHARE);
            else return 0;
        } else {
            return 0;
        }
        out.add(e.user(str(u, "uniqueId", "unique_id", "userId", "displayId"), str(u, "nickname", "nickName", "uniqueId"), avatar(u)));
        return 1;
    }

    // ---------------- helper JSON yang tahan field hilang / null ----------------

    private static String str(JSONObject o, String... keys) {
        for (String k : keys) {
            if (o.has(k) && !o.isNull(k)) {
                Object v = o.opt(k);
                if (v instanceof String || v instanceof Number) {
                    String s = String.valueOf(v);
                    if (!s.isEmpty()) return s;
                }
            }
        }
        return "";
    }

    private static JSONObject obj(JSONObject o, String... keys) {
        for (String k : keys) {
            JSONObject v = o.optJSONObject(k);
            if (v != null) return v;
        }
        return null;
    }

    private static String avatar(JSONObject u) {
        String direct = str(u, "profilePictureUrl", "avatarUrl", "avatar");
        if (!direct.isEmpty()) return direct;
        for (String k : new String[]{"profilePicture", "avatarThumb", "avatarMedium", "avatarLarger"}) {
            Object v = u.opt(k);
            String url = firstUrl(v);
            if (!url.isEmpty()) return url;
        }
        return "";
    }

    private static String firstUrl(Object v) {
        if (v instanceof String) return (String) v;
        if (v instanceof JSONArray) {
            JSONArray a = (JSONArray) v;
            for (int i = 0; i < a.length(); i++) {
                Object x = a.opt(i);
                if (x instanceof String) return (String) x;
            }
        }
        if (v instanceof JSONObject) {
            JSONObject o = (JSONObject) v;
            for (String k : new String[]{"url", "urls", "urlList", "url_list"}) {
                String s = firstUrl(o.opt(k));
                if (!s.isEmpty()) return s;
            }
        }
        return "";
    }
}
