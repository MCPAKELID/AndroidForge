package com.hvv.game.android;

import android.os.Bundle;

import com.badlogic.gdx.backends.android.AndroidApplication;
import com.badlogic.gdx.backends.android.AndroidApplicationConfiguration;
import com.hvv.game.HvvGame;

public class AndroidLauncher extends AndroidApplication {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        AndroidApplicationConfiguration config = new AndroidApplicationConfiguration();
        config.useImmersiveMode = true;     // sembunyikan bar navigasi
        config.useWakelock = true;          // layar tetap menyala selama live
        config.useAccelerometer = false;
        config.useCompass = false;
        initialize(new HvvGame(new EulerLiveSource()), config);
    }
}
