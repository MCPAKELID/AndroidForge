# BlockRush Live Game — AndroidForge v12

This revision fixes the control, movement, grid alignment, HUD, and arena viewport issues seen in the user's v11 gameplay recording.

## v12 fixes

### Multi-touch controls
- Uses Android pointer IDs and a SparseArray of active touches.
- Left/right can remain held while another finger presses jump.
- Movement can be combined with jump, mode buttons, and grid taps.
- Releasing one finger does not cancel the other active fingers.
- Run remains a tap-to-toggle sprint button.
- Build and Pickaxe remain mutually exclusive toggle modes.

### Movement and physics
- Replaced instant support snapping with gravity and landing-crossing detection.
- Walking off a platform now causes a visible fall.
- Breaking the block supporting the player makes the player fall naturally.
- Horizontal movement cannot pass through a raised block column.
- The player must jump high enough to clear a block stack before moving into its column.
- Jump is edge-triggered so holding the jump control does not cause repeated teleport-like jumps.

### Arena and grid
- Keeps the full supplied arena background at its original 864 x 1536 proportions.
- The arena stays fixed so its bottom border is not cropped by camera scrolling.
- Blocks and player use the same world/grid coordinates as the supplied map.
- The grid uses 14 columns and 28 rows; placement is restricted to the rows below the yellow warning line.
- Every block is placed in exactly one grid cell and must be supported directly by the floor or a block below.
- Prevents placing a block inside the player's body.
- Block textures are randomly selected for each placement.

### HUD
- Uses the supplied HUD artwork.
- The green level bar fills the existing empty 20-cell strip in the HUD; no separate progress bar is drawn.
- Five placed blocks advance one level; maximum level is 10.
- The percentage is based on currently occupied buildable cells.
- Text uses a 5x7 pixel glyph renderer rather than Android's default system font.
- HUD slides upward as the player climbs, clearing the upper playfield.
- The empty hotbar slots remain empty.

### Controls layout
- Larger touch targets and safe margins from both phone edges.
- Movement controls are grouped on the left; Pickaxe, Block, and Jump are grouped on the right.
- The white control deck remains separate from the arena.

## Build
1. Extract this ZIP.
2. Open the `BlockRush_Live_Game_v12` project in AndroidForge.
3. Build the `app` module.
4. Project uses Java 17, compile SDK 35, and application ID `com.mcpakel.blockarea`.

App label: `BlockRush Live Game`
Version: `1.2` (versionCode 12)

The updated Java source passed a syntax/API-stub compile. A full APK build has not been run in this environment; run the APK build in AndroidForge to verify device-specific rendering and touch behavior.
