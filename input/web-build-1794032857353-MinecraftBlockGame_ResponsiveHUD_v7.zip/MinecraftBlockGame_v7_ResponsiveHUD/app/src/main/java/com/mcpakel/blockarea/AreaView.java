package com.mcpakel.blockarea;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.RectF;
import android.graphics.Typeface;
import android.view.MotionEvent;
import android.view.View;
import java.io.IOException;

/**
 * Responsive game scene:
 * - Arena fills the complete screen width and all vertical space above controls.
 * - Bottom control deck remains white and is never covered by the arena.
 * - The exact HUD and button artwork supplied by the user is used as PNG assets.
 * - No hearts, red side meter, player name, level, block percentage, or win display.
 */
public class AreaView extends View {
    private static final float DESIGN_W = 864f;
    private static final float CONTROL_H = 280f;

    private final Paint paint = new Paint();
    private Bitmap arena;
    private Bitmap hud;
    private Bitmap leftImage, rightImage, pickaxeImage, blockImage, jumpImage;
    private final Bitmap[][] sprites = new Bitmap[3][5];

    private final RectF leftButton = new RectF(22, 0, 132, 0);
    private final RectF rightButton = new RectF(142, 0, 252, 0);
    private final RectF pickaxeButton = new RectF(490, 0, 598, 0);
    private final RectF blockButton = new RectF(603, 0, 711, 0);
    private final RectF jumpButton = new RectF(716, 0, 842, 0);
    private final RectF runButton = new RectF(300, 0, 430, 0);

    private float designHeight = 1536f;
    private float arenaBottom = 1256f;
    private float floorY = 1208f;

    private float playerX = 432f;
    private float playerY = floorY;
    private float velocityY = 0f;
    private boolean leftDown, rightDown, jumpDown;
    private boolean sprintMode = false;
    private boolean facingRight = true;
    private boolean grounded = true;
    private boolean runTouchConsumed = false;

    private int walkFrame, runFrame, jumpFrame;
    private float animationClock;
    private long lastTime;

    public AreaView(Context context) {
        super(context);
        setLayerType(View.LAYER_TYPE_SOFTWARE, null);
        arena = load(context, "area/arena_reference.jpg");
        hud = load(context, "ui/hud_full.png");
        leftImage = load(context, "ui/move_left.png");
        rightImage = load(context, "ui/move_right.png");
        pickaxeImage = load(context, "ui/pickaxe.png");
        blockImage = load(context, "ui/block.png");
        jumpImage = load(context, "ui/jump.png");

        String[] actionNames = {"walk", "run", "jump"};
        for (int a = 0; a < actionNames.length; a++) {
            for (int i = 0; i < 5; i++) {
                sprites[a][i] = load(context,
                        "character/" + actionNames[a] + "_" + i + ".png");
            }
        }
    }

    private Bitmap load(Context context, String path) {
        try {
            return BitmapFactory.decodeStream(context.getAssets().open(path));
        } catch (IOException ignored) {
            return null;
        }
    }

    private void updateLayout() {
        if (getWidth() <= 0 || getHeight() <= 0) return;

        // Use width-based coordinates and calculate height from the actual phone ratio.
        // This avoids stretching the game horizontally or vertically.
        designHeight = getHeight() * DESIGN_W / getWidth();
        float controlHeight = Math.min(CONTROL_H, designHeight * 0.24f);
        arenaBottom = designHeight - controlHeight;

        // Bottom inner stone-brick floor of the supplied arena reference.
        // 1474/1536 is the approximate top surface of the bottom frame.
        floorY = arenaBottom * (1474f / 1536f);
        if (grounded) playerY = floorY;

        float controlTop = arenaBottom;
        float buttonSize = Math.min(112f, controlHeight * 0.43f);
        float buttonY = controlTop + (controlHeight - buttonSize) * 0.38f;

        setRect(leftButton, 22, buttonY, 22 + buttonSize, buttonY + buttonSize);
        setRect(rightButton, 142, buttonY, 142 + buttonSize, buttonY + buttonSize);
        setRect(pickaxeButton, 490, buttonY, 490 + buttonSize, buttonY + buttonSize);
        setRect(blockButton, 610, buttonY, 610 + buttonSize, buttonY + buttonSize);
        setRect(jumpButton, 730, buttonY - 5, 730 + buttonSize, buttonY + buttonSize - 5);
        setRect(runButton, 300, buttonY + buttonSize * .18f,
                430, buttonY + buttonSize * .82f);
    }

    private void setRect(RectF rect, float l, float t, float r, float b) {
        rect.set(l, t, r, b);
    }

    private void drawBitmap(Canvas canvas, Bitmap bitmap, RectF destination) {
        if (bitmap == null) return;
        paint.setAlpha(255);
        paint.setFilterBitmap(false);
        canvas.drawBitmap(bitmap, null, destination, paint);
    }

    @Override
    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        updateLayout();

        float scale = getWidth() / DESIGN_W;
        canvas.save();
        canvas.scale(scale, scale);

        // White control deck first; the arena is drawn only above its boundary.
        canvas.drawColor(Color.WHITE);

        if (arena != null) {
            drawBitmap(canvas, arena, new RectF(0, 0, DESIGN_W, arenaBottom));
        } else {
            paint.setColor(Color.rgb(25, 28, 34));
            canvas.drawRect(0, 0, DESIGN_W, arenaBottom, paint);
        }

        // Player stands on the lower inner edge of the arena, not in mid-air.
        drawPlayer(canvas);

        // The supplied top HUD includes its own blank profile, trophy/block counters,
        // empty hotbar and settings icon. Do not add placeholder text or hearts.
        if (hud != null) {
            float hudHeight = DESIGN_W * hud.getHeight() / hud.getWidth();
            drawBitmap(canvas, hud, new RectF(0, 0, DESIGN_W, hudHeight));
        }

        // Keep the bottom deck plain white, as requested.
        paint.setColor(Color.WHITE);
        canvas.drawRect(0, arenaBottom, DESIGN_W, designHeight, paint);

        drawControls(canvas);
        canvas.restore();

        updatePlayer();
        postInvalidateDelayed(16);
    }

    private void drawPlayer(Canvas canvas) {
        int action = !grounded ? 2 : ((leftDown || rightDown) ? (sprintMode ? 1 : 0) : 0);
        int frame = action == 2 ? jumpFrame : (action == 1 ? runFrame : walkFrame);
        Bitmap sprite = sprites[action][frame];
        if (sprite == null) return;

        float spriteHeight = Math.min(112f, (arenaBottom - 250f) * 0.11f);
        float spriteWidth = spriteHeight * sprite.getWidth() / sprite.getHeight();
        RectF destination = new RectF(playerX - spriteWidth / 2f,
                playerY - spriteHeight, playerX + spriteWidth / 2f, playerY);

        canvas.save();
        if (!facingRight) canvas.scale(-1f, 1f, playerX, 0f);
        drawBitmap(canvas, sprite, destination);
        canvas.restore();
    }

    private void drawControls(Canvas canvas) {
        drawBitmap(canvas, leftImage, leftButton);
        drawBitmap(canvas, rightImage, rightButton);
        drawBitmap(canvas, pickaxeImage, pickaxeButton);
        drawBitmap(canvas, blockImage, blockButton);
        drawBitmap(canvas, jumpImage, jumpButton);

        // Small RUN toggle is placed in the empty middle space between control groups.
        paint.setColor(sprintMode ? 0xff267a3d : 0xff343b46);
        canvas.drawRoundRect(runButton, 15, 15, paint);
        paint.setStyle(Paint.Style.STROKE);
        paint.setStrokeWidth(3f);
        paint.setColor(sprintMode ? 0xff72ed8a : 0xff9ca6b4);
        canvas.drawRoundRect(runButton, 15, 15, paint);
        paint.setStyle(Paint.Style.FILL);
        paint.setColor(Color.WHITE);
        paint.setTextAlign(Paint.Align.CENTER);
        paint.setTypeface(Typeface.create("sans-serif", Typeface.BOLD));
        paint.setTextSize(23f);
        canvas.drawText(sprintMode ? "RUN ON" : "RUN OFF",
                runButton.centerX(), runButton.centerY() + 8f, paint);
    }

    private void updatePlayer() {
        long now = System.nanoTime();
        if (lastTime == 0L) lastTime = now;
        float dt = Math.min((now - lastTime) / 1_000_000_000f, 0.04f);
        lastTime = now;

        float speed = sprintMode ? 270f : 155f;
        if (leftDown && !rightDown) {
            playerX -= speed * dt;
            facingRight = false;
        } else if (rightDown && !leftDown) {
            playerX += speed * dt;
            facingRight = true;
        }
        playerX = Math.max(112f, Math.min(752f, playerX));

        if (jumpDown && grounded) {
            velocityY = -490f;
            grounded = false;
            jumpFrame = 0;
            animationClock = 0f;
        }

        if (!grounded) {
            velocityY += 1120f * dt;
            playerY += velocityY * dt;
            if (playerY >= floorY) {
                playerY = floorY;
                velocityY = 0f;
                grounded = true;
            }
        }

        animationClock += dt;
        if (!grounded) {
            if (animationClock >= 0.12f) {
                jumpFrame = (jumpFrame + 1) % 5;
                animationClock = 0f;
            }
        } else if (leftDown || rightDown) {
            float frameDelay = sprintMode ? 0.075f : 0.13f;
            if (animationClock >= frameDelay) {
                if (sprintMode) runFrame = (runFrame + 1) % 5;
                else walkFrame = (walkFrame + 1) % 5;
                animationClock = 0f;
            }
        } else {
            walkFrame = 0;
            animationClock = 0f;
        }
    }

    private float touchX(float x) {
        return x * DESIGN_W / Math.max(1f, getWidth());
    }

    private float touchY(float y) {
        return y * DESIGN_W / Math.max(1f, getWidth());
    }

    @Override
    public boolean onTouchEvent(MotionEvent event) {
        int action = event.getActionMasked();
        int actionIndex = event.getActionIndex();

        if (action == MotionEvent.ACTION_DOWN || action == MotionEvent.ACTION_POINTER_DOWN) {
            float x = touchX(event.getX(actionIndex));
            float y = touchY(event.getY(actionIndex));
            if (runButton.contains(x, y)) {
                sprintMode = !sprintMode;
                runTouchConsumed = true;
            }
        }

        if (action == MotionEvent.ACTION_UP || action == MotionEvent.ACTION_CANCEL) {
            leftDown = rightDown = jumpDown = false;
            runTouchConsumed = false;
            return true;
        }

        leftDown = rightDown = jumpDown = false;
        for (int i = 0; i < event.getPointerCount(); i++) {
            if (action == MotionEvent.ACTION_POINTER_UP && i == actionIndex) continue;
            float x = touchX(event.getX(i));
            float y = touchY(event.getY(i));
            if (leftButton.contains(x, y)) leftDown = true;
            if (rightButton.contains(x, y)) rightDown = true;
            if (jumpButton.contains(x, y)) jumpDown = true;
        }
        return true;
    }
}
