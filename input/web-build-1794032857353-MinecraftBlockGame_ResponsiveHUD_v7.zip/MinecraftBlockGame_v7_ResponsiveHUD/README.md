# Minecraft Block Game - Responsive HUD v7

Android Native Java project for AndroidForge.

## Changes
- Uses the latest user-provided HUD sheet (`hud_full.png`): blank profile panel, trophy and grass-block counters, empty hotbar, settings icon.
- Does not draw the old red side meter or hearts.
- Uses the latest user-provided movement/action button art: left, right, pickaxe, block, jump.
- White bottom control area is separate; arena never draws underneath it.
- Arena fills the full available phone width and extends from top to the control deck. Its height is calculated from the real device aspect ratio.
- Character feet are aligned to the bottom inner stone-brick floor of the arena image.
- Player sprites remain separated into 5 walk, 5 run and 5 jump PNGs.
- RUN toggle stays in the empty middle area between the left and right control groups.
- Pickaxe and block buttons are visual only; block destruction/placement logic is not included yet.
- Name/level/percentage/win text is not drawn by code.

## Build
Open this folder in AndroidForge as a Gradle project.
Use JDK 17 and Android SDK Platform 35.
Application ID: `com.mcpakel.blockarea`.
No WebView or external dependencies.
