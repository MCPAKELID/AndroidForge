/*
 * Block Rush Live Game
 * Hak Cipta (c) 2026 MCPAKEL. Semua hak dilindungi.
 * Copyright (c) 2026 MCPAKEL. All rights reserved.
 */
package com.mcpakel.blockarea;

/**
 * Daftar gift TikTok (nama + harga koin) dari https://streamtoearn.io/gifts?region=ID, tanpa duplikat.
 * Gift dikenali lewat NAMA (halaman itu tidak memberi ID gift). Gambar gift diambil dari sprite sheet
 * (assets/gift/g<sel>.png); gift yang gambarnya belum dikenali memakai kotak gift umum.
 */
public final class GiftCatalog {
    private GiftCatalog() { }

    /** Id gambar untuk sel sprite: 100 + (baris*16 + kolom). */
    public static final int SPRITE_BASE = 100;
    public static final int GENERIC_ICON = SPRITE_BASE + 255;

    public static final String[] NAMES = {
            "Rose", "You're awesome", "Ice Cream Cone", "Wink wink", "Love you so much", "TikTok",
            "Mate Melody", "GG", "Cake Slice", "Welcome Dallah", "Mirwas Beat", "Pop",
            "Oldies", "Freestyle", "Glow Stick", "Mantap", "My First Rose", "Heart Me",
            "Music on Stage", "Halloween mood", "A Shard of Hope", "LIVE FEST 26", "LUVX Cheer", "Eye for an Eye",
            "Community Heart", "Love KSA", "LUVE Cheer", "SEA Shell", "Little Acorn", "Coffee",
            "Orange Juice", "Thumbs Up", "Heart", "Love you", "Fairy wings", "Headphone",
            "Blow a kiss", "Power hug", "Fried", "Music Album", "coldy", "Red Lightning",
            "Blue Lightning", "Yellow Lightning", "Treasure Clover", "Starfish", "Palm of Protection", "Happy Twinkle",
            "Wink Charm", "Go Popular", "Community Gift", "Club Cheers", "Team Bracelet", "Finger Heart",
            "Spinning Soccer", "Overreact", "Love in Scent", "Encore Ticket", "Name shoutout", "Brown Paw",
            "Pumpkin Pie", "Padang Rice", "Star Light", "Divine Fingers", "Super Popular", "Cheer You Up",
            "Club Power", "Rosa", "Slow motion", "Friendship Necklace", "Curious Twinkle", "I Like What I See",
            "Journey Pass", "Black Paw", "Squirrel", "LIVE Ranking Ticket", "Courage potion", "DJ Vinyl",
            "Tiny Diny", "I love you", "Style Me Up", "Banana Peel", "Songs of LIVE", "Treasure's Key",
            "I'm Yours", "Magic Feather", "Gatot Kaca", "Hanoman", "Arjuna", "Heart Gaze",
            "Bravo!", "Lyric Mail", "Kudos for My Star", "Live Up Earth", "Perfume", "G.O.A.T. Busker",
            "Tiny Blush", "Rage Mode", "LOL", "No Comment", "Huh?", "Traffic Cone",
            "Mushroom", "Doughnut", "Warm Cocoa", "Capybara", "Bouquet Flower", "Energy Capsule",
            "Energy Drop", "Ghostfire", "Single Strike", "FEST Explorer", "Heart KSA", "Paper Crane",
            "Little Crown", "Cap", "Hat and Mustache", "Like-Pop", "Cupid's Bow", "Love Painting",
            "Bubble Gum", "Mark of Love", "Batik Bucket Hat", "Sundae Bowl", "Charmer Bow", "Cursed Kick",
            "Wobbler", "Stabilizer", "Singing Mushroom", "Bloom Melody", "Groove Guitar", "Fiesta Accordion",
            "Pearl Chime", "Cow-napping", "Candy Blast", "Breeze Quena", "Healing Sape", "Pad Master",
            "Palace Qanun", "Beach Crab", "Club Victory", "Level-up Sparks", "Greeting Heart", "Mishka Bear",
            "Mountain Baby", "Shell Energy", "Scooter", "Tsar", "Balloon Gift Box", "Confetti",
            "Hand Heart", "Chicken and Cola", "Bouquet", "Power Chip", "Heart My Earthling", "Gate to Treasure",
            "Wooden Rod", "Wooden Box", "Danger Door", "Hall of Stars", "Singing Magic", "Marvelous Confetti",
            "Bowknot", "Big Shout Out", "Chatting Popcorn", "Masquerade", "Balloon Crown", "Feather Tiara",
            "Caterpillar Chaos", "Catrina", "Raving Snail", "Love Glasses", "Fairy Hide", "Frog Conductor",
            "Tempo Flute", "Groove Clarinet", "Mystic Ney", "Sweetheart Macaron", "Cruiser", "Puffer Fish",
            "Song of Harvest", "Penlight", "Bruiser", "Side by Side", "Coconut", "Forest Beginnings",
            "Take the Mic", "Sunglasses", "Hearts", "Garland Headpiece", "Cheer For You", "The Crown",
            "Coffee Magic", "Cheering Crab", "Dancing Hands", "Floating Octopus", "Flower Headband", "Goalkeeper Save",
            "Sour Buddy", "Rose Hand", "Indoor Fan", "Melon Juice", "Coconut Juice", "Chirpy Kisses",
            "Juicy Smile", "Joker Ball", "Heart Hood", "Smile Latte", "Party Pony", "Fan Cat",
            "Bloom Brass", "Rhythm Bot", "Sunny Side Up", "Talking Heartbeat", "Mystic Panpipes", "Magic Bubble",
            "Gear", "Peeka-Bro", "Keyboard Tune", "Cute Bunny", "Diamond Heart necklace", "Gold necklace",
            "Balloons", "Magic Genie", "Semsemia", "Baglama", "Cat", "Pinch Face",
            "Candy Bouquet", "Ice Cream Mic", "Star Goggles", "Cheer Mic", "Music Bubbles", "Palm Breeze",
            "Forest Elf", "Face-pulling", "Treasured Voice", "Melodic birds", "Surfing Penguin", "Party Blossom",
            "Dreamy Strings", "Sweet Flutter", "Snow Bloom", "Amped Up", "Poetry Score", "Singing Frog",
            "Blast Drum", "Flower Courier", "Tiny Diny Float", "Triple Thunder", "Mysterious Mask", "FEST Energy",
            "LIVE Ranking Headband", "Rookies Cup", "Boxing Gloves", "Corgi", "Fruit Friends", "Naughty Chicken",
            "Play for You", "Rock Star", "Butterfly for You", "Starlight Compass", "Puppy Kisses", "United Heart",
            "Kicker Challenge", "Hi! Rosie!", "LIVE Ranking Crown", "Pawfect", "Go Hamster", "TikTok Crown",
            "Bat Headwear", "Melody Glasses", "Penguin Snowpal", "Music Mate", "Love Call", "Pony Lantern",
            "Spring Sprout", "Wakey Mallow", "Sax Groove", "Scroll", "Labor Power", "Cello Romance",
            "Come On!", "Cheering Towel", "Swing Cello", "Rhythm Crown", "Brazilian Vibe Cap", "Tropical Mask",
            "Cherry Scoop", "Floral Lute", "Bell", "Piano Bow", "Dreamy Penguin", "Budding Heart",
            "Diamond ring of love", "Feather Mask", "Air Dancer", "Galaxy's Bestest", "Backing Monkey", "Become Kitten",
            "Marked with Love", "Vinyl Flip", "Juicy Cap", "Batwing Hat", "Beach Maracas", "Vintage flight",
            "Gingerbread Man", "Rocking Shroom", "Sparkle Pony", "Spring Bouquet", "Craft Dreamer", "Mom's Bonnet",
            "Retro Melody", "Ukulele Player", "Chopin in the Rain", "Electro Vibes", "Retro Headset", "Butterfly Vibe",
            "Djembe Master", "Spin Seal", "Starry Seal", "Munch Monster", "Cyber Fist Bump", "Rose Wreath",
            "Rock Demon", "Desert Survivals", "Forever Rosa", "Magic Rhythm", "Relaxed Goose", "Tom's Hug",
            "Rosie the Rose Bean", "Jollie the Joy Bean", "Rocky the Rock Bean", "Sage the Smart Bean", "Sage's Slash", "Let butterfly dances",
            "Kitten Kneading", "Shoot the Apple", "Alien Buddy", "You Are Loved", "Rosie's Concert", "Tiger Lift",
            "Santa Owl Surprise", "Confetti Bear", "Singing Sax", "Fairy Locket", "Panda Snap", "Blossom Fairy",
            "Dreamy Hat", "Vocal Bear", "Cactus Shuffle", "Health Potion", "Echo Mom", "DJ Set",
            "Beat Wings", "Melody Headset", "Papa Capybara", "Aurora Groove", "Floral Serenade", "Wind on Kemenche",
            "Sing in Sync", "Starry Wish", "Jiggly Pudding", "Pull Rod", "Moped", "Cornucopia",
            "Crystal Dreams", "Wishing Cake", "Mic Champ", "Bounce Speakers", "Reindeer Milk", "Cheeky Pup",
            "DJ Wave", "Punch Cuddle", "Glorious Chef", "Rock Cats", "Magic Accordion", "Super Dad",
            "Pop Parrot", "Rock Idol", "Neon Rockstar", "Heartbeat Keys", "The Mrazhemian", "Siren's Echo",
            "Starry Sax", "Moon Serenade", "Beating Heart", "Encore Clap", "Pirate's Treasure", "Candy Loot",
            "Captured Vocals", "Batting Cutie", "Space Love", "Xmas Tree Hat", "Clown Boogie", "Electronic Love Song",
            "Rock and Roll", "Meowsic Trumpet", "Cyber Strings", "Lightning Look", "Powerful Mind", "Hat of Joy",
            "Halloween Fun Hat", "Music Conductor", "Celebration Hat", "City Pop", "Cupid Koala", "Paw Call",
            "Superwoman", "Clover Hat", "Sloth Peek", "Pink Cowboy", "Office Penguin", "Steady on the Beam",
            "Groove Straw", "Glow Chant", "Diva Feathers", "Coral", "Panda Hug", "Rose Soundwave",
            "Eye on the Ball", "Key Master", "Fuzzy Drum", "Island Uke", "Cowboy Groove", "Hands Up",
            "Mermaid", "XXXL Flowers", "Chubby Hamster", "Do Not Blow", "HeartBeats", "Autumn Leaves",
            "Shell of a Warrior", "Spark Ring Earth", "Money Gun", "You're Amazing", "VR Goggles", "DJ Glasses",
            "Dragon Crown", "Racing Helmet", "Bunny Crown", "Prince", "Magic Prop", "Heart It Out",
            "Polaris", "Cozy Xmas Set", "Roses", "Mystery Box", "Heart Guitar", "Prairie Diny",
            "Prairie Tom", "Prairie Blitzy", "Prairie Cooper", "Jungle Diny", "Jungle Tom", "Jungle Blitzy",
            "Jungle Cooper", "Prairie Nyota", "Jungle Nyota", "Starry Fluff", "Roo Mother", "Lost in Your Music",
            "Match Master", "Drum Pop", "Sound Spell", "Drum Genius", "Out Pops Jollie!", "Honey Strummer",
            "Cosmic DJ", "Iron Anchor", "Monster Box!", "Twinkle Says Hi!", "Gem Gun", "Bubbly Kiss",
            "Hive Escape", "Drum Hamster", "Purrfect Pitch", "Fruit Box", "Soccer Holo", "Join Butterflies",
            "Sakura-style DJ", "Sakura Flute", "Seahorse Pop", "Swan", "Cafe Racer", "Colorful Wings",
            "Sax Appeal", "Sunset in Bali", "Cute Cat", "Which Bro?", "Epic Pianist", "Box of destiny",
            "Kindom of Night", "Train", "Stage Wiggle", "Funky Hatter", "Travel with You", "Lucky Airdrop Box",
            "Grand show", "Uniform", "Trending Figure", "Gerry the Giraffe", "Silver Sports Car", "Giraffe",
            "Watermelon Love", "Blooming Ribbons", "Galaxy", "Glowing Jellyfish", "Match Drum", "Flamingo Groove",
            "Lightning your world", "Firepit Diny", "Firepit Tom", "Firepit Blitzy", "Firepit Cooper", "Desert Diny",
            "Desert Tom", "Desert Blitzy", "Desert Cooper", "Tundra Diny", "Tundra Tom", "Tundra Blitzy",
            "Tundra Cooper", "Firepit Nyota", "Desert Nyota", "Tundra Nyota", "Magic Potion", "Iron Rod",
            "A Garden Yonder", "Sparkle Dance", "Shiny Air Balloon", "Joy Floats", "Candy Puffs", "Pumpkin Carriage",
            "Fireworks", "Diamond Tree", "Exclusive Spark", "Umbrella of Love", "Starlight Sceptre", "Bunny DJ",
            "Halloween Drink", "Frozen Magic", "Autumn Picnic", "Party Laser", "Vibrant Stage", "Level Ship",
            "Anybody Home?", "Viking Hammer", "Chasing the Dream", "Lover's Lock", "Greeting Card", "Future Encounter",
            "Under Control", "Cherry Blossoms", "Racing Debut", "You're So Fly", "Astrobear", "Wild Mic",
            "Ignition Check", "Scepter", "Shooting Stars", "FEST Musician", "FEST Dancer", "Blooming Heart",
            "Hug It Better", "Here We Go", "Love Drop", "Fox Legend", "Getting Ready", "Star of Red Carpet",
            "Cooper Flies Home", "Mystery Firework", "Rose Busker", "Maple Fireworks", "Crystal Crown", "Sky Drift",
            "Whale Diving", "Blow Rosie Kisses", "Jollie's Heartland", "Rocky's Punch", "Sage's Coinbot", "Stargazing",
            "Wave Lights", "Spooky Rock", "Butterfly CardFire", "By the Glaziers", "Chopper Bike", "Tom Thunderfoot",
            "Animal Band", "Magic Stage", "Wanted a Treat?", "Crownfish", "Celebration Tape", "Samfaring Tom",
            "Motorcycle", "Legends Scroll", "Rosie on Stage", "FEST Showtime!", "Rhythmic Bear", "Party Bus",
            "Match Maniac", "Ray Serenade", "Beacon", "Level-up Spotlight", "Potluck", "Car Drifting",
            "Meteor Shower", "Summoning Horn", "Rotary Backpack", "Sea Diny", "Sea Tom", "Sea Blitzy",
            "Sea Cooper", "Sea Nyota", "Hip-Hop Hen", "Halloween Idol", "Look Up", "Dream Big",
            "Spark Stage Earth", "LIVE Ranking Party", "Compact EV", "Shine Bright", "Magic World", "Your Concert",
            "Private Jet", "Leon the Kitten", "Fiery Dragon", "Signature Jet", "Sugar Whiskers", "Guardian's Pledge",
            "The Trial of Sea", "Sports Car", "Sage's Venture", "Squitchy Morph", "Seaside Romance", "Arcane Card",
            "Diamond Gun", "Desert Wolf", "Community Power", "Unicorn Fantasy", "Flying Jets", "Four King",
            "Leon's Sigil Cape", "Crowd Cheering", "Mystic Rod", "Creator Survives", "Creator Travels", "Creator Picnics",
            "Creator Dazzles", "Creator Adores", "Creator Serenades", "Fluffy Buddies", "Wolf", "Cub on Clouds",
            "Valiant Odyssey", "My Dream Stage", "Devoted Heart", "Night of Yokai", "Strike a Pose", "Lovely to Have You",
            "Future City", "Sam in New City", "Work Hard Play Harder", "Strong Finish", "Rust Reforged", "Lili the Leopard",
            "Celebration Time", "Last Riff Roar", "Happy Party", "Rally Car", "Majestic Hearts", "Star Throne",
            "Jack-o' Morph", "Bird of Paradise", "Stormwave Armor", "Leon and Lili", "FEST World", "You Are Wanted!",
            "Henry", "Interstellar", "Sunset Speedway", "Crystal Rod", "Falcon", "Verified Glider",
            "Fangster Morph", "Glampire Morph", "Hall of Legend", "Hot Rods", "Legend Rider", "Level-up Spectacle",
            "Daylight Debut", "Monster Truck", "Proof of the King", "Snowmoon Parasol", "Iron Resolve", "Crystal Heart",
            "Vintage Car", "Black Wolf", "DJ Peak", "Leopard", "Legendary Aegis", "Firelight Kingdom",
            "Arabian Cheetah", "Riyadh", "Gobble Grab", "A Fun House", "Corgi's Happy Chuseok", "Rosa Nebula",
            "Future Journey", "Party On&On", "Nightshade Kingdom", "White Tiger", "Stadium", "Jet Car",
            "Amusement Park", "Shell Castle", "Rust vs World", "Super Car", "Fly Love", "Fantastic Fly Love",
            "Gyeongbokgung", "Castle Fantasy", "TikTok Shuttle", "Premium Shuttle", "Pop Out", "Legacy in Bloom",
            "Siren's Aria", "Infinite Heart", "Rin the Snowborn", "Phoenix", "Adam's Dream", "Villainy Slain",
            "Dragon Flame", "LIVE Legends", "Lion", "Community Legends", "Sam the Whale", "Magic Rod",
            "Zeus", "Leon and Lion", "TikTok Universe+", "TikTok Stars", "Thunder Falcon", "Fire Phoenix",
            "Yuki's Vigilance", "The Fair King", "Pegasus", "TikTok Universe"};
    public static final int[] COINS = {
            1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1,
            1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1,
            1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1,
            1, 1, 1, 1, 2, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 6,
            9, 9, 9, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10,
            10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 15, 15, 15, 15, 20, 20,
            20, 20, 20, 20, 20, 20, 20, 30, 30, 30, 30, 30, 30, 30, 70, 99,
            99, 99, 99, 99, 99, 99, 99, 99, 99, 99, 99, 99, 99, 99, 99, 99,
            99, 99, 99, 99, 99, 99, 99, 99, 99, 99, 99, 99, 99, 99, 99, 100,
            100, 100, 100, 100, 100, 100, 100, 100, 100, 100, 100, 100, 100, 100, 100, 100,
            100, 100, 149, 149, 149, 149, 149, 149, 149, 149, 149, 149, 149, 149, 149, 149,
            149, 149, 150, 150, 150, 150, 153, 199, 199, 199, 199, 199, 199, 199, 199, 199,
            199, 199, 199, 199, 199, 199, 199, 199, 199, 199, 199, 199, 199, 199, 199, 199,
            199, 199, 199, 199, 199, 199, 199, 199, 199, 199, 199, 200, 200, 200, 200, 200,
            200, 200, 222, 249, 249, 249, 249, 249, 249, 249, 249, 249, 249, 249, 249, 249,
            249, 249, 249, 249, 249, 249, 249, 249, 250, 289, 299, 299, 299, 299, 299, 299,
            299, 299, 299, 299, 299, 299, 299, 299, 299, 299, 299, 299, 299, 299, 299, 299,
            299, 299, 299, 299, 299, 299, 299, 299, 299, 299, 299, 299, 299, 299, 299, 299,
            299, 299, 299, 299, 299, 299, 300, 300, 300, 300, 349, 349, 349, 349, 349, 349,
            349, 349, 349, 349, 349, 349, 349, 349, 349, 349, 349, 349, 349, 349, 349, 349,
            349, 349, 349, 349, 349, 399, 399, 399, 399, 399, 399, 399, 399, 399, 399, 399,
            399, 399, 399, 399, 399, 399, 399, 399, 399, 399, 399, 399, 399, 399, 399, 399,
            399, 399, 399, 399, 399, 399, 399, 399, 399, 399, 399, 399, 400, 400, 400, 400,
            400, 400, 400, 400, 400, 400, 400, 400, 400, 400, 400, 400, 400, 400, 400, 400,
            400, 400, 449, 449, 449, 449, 449, 449, 449, 449, 449, 449, 449, 449, 449, 449,
            450, 450, 450, 450, 450, 450, 450, 450, 450, 450, 450, 450, 450, 450, 450, 450,
            450, 499, 499, 499, 499, 499, 499, 499, 499, 499, 500, 500, 500, 500, 500, 500,
            500, 500, 500, 500, 500, 500, 500, 500, 500, 500, 500, 500, 500, 500, 500, 500,
            500, 500, 500, 500, 500, 500, 500, 500, 500, 500, 500, 500, 500, 500, 500, 500,
            500, 500, 500, 500, 500, 500, 500, 500, 500, 530, 549, 549, 550, 599, 599, 600,
            600, 600, 649, 699, 700, 700, 700, 799, 799, 799, 800, 899, 899, 899, 899, 900,
            999, 999, 999, 999, 999, 1000, 1000, 1000, 1000, 1000, 1000, 1000, 1000, 1000, 1000, 1000,
            1000, 1000, 1000, 1000, 1000, 1000, 1000, 1000, 1000, 1000, 1000, 1000, 1000, 1000, 1000, 1000,
            1000, 1000, 1000, 1000, 1030, 1030, 1031, 1088, 1088, 1099, 1200, 1200, 1200, 1299, 1299, 1300,
            1300, 1400, 1500, 1500, 1500, 1500, 1500, 1500, 1500, 1500, 1500, 1500, 1500, 1500, 1500, 1500,
            1500, 1599, 1599, 1599, 1600, 1799, 1800, 1800, 1999, 1999, 1999, 1999, 1999, 2000, 2000, 2000,
            2150, 2199, 2199, 2199, 2199, 2200, 2200, 2200, 2200, 2380, 2499, 2499, 2500, 2599, 2599, 2800,
            2800, 2850, 2988, 2999, 2999, 2999, 2999, 2999, 2999, 2999, 2999, 2999, 3000, 3000, 3000, 3000,
            3000, 3088, 3088, 3088, 3088, 3088, 3200, 3200, 3350, 3350, 3999, 3999, 4000, 4088, 4088, 4500,
            4888, 4888, 4888, 4888, 4918, 4999, 4999, 4999, 4999, 4999, 4999, 5000, 5000, 5000, 5000, 5000,
            5000, 5000, 5000, 5000, 5000, 5000, 5000, 5000, 5000, 5000, 5000, 5388, 5500, 5888, 5888, 5999,
            5999, 6000, 6000, 6000, 6000, 6000, 6000, 6000, 6000, 6599, 6999, 6999, 6999, 7000, 7238, 7999,
            7999, 8000, 8999, 9699, 9999, 9999, 10000, 10000, 10000, 10000, 10999, 10999, 11999, 11999, 11999, 12000,
            12999, 12999, 13999, 14000, 14999, 14999, 14999, 14999, 15000, 15000, 15000, 15000, 15000, 15000, 15000, 15000,
            15000, 15000, 15000, 15000, 15000, 15000, 15000, 15999, 15999, 17000, 17000, 18000, 18999, 19000, 19999, 19999,
            20000, 20000, 20000, 20000, 21000, 21000, 22500, 23999, 25999, 25999, 25999, 25999, 26999, 29999, 29999, 30000,
            30000, 30000, 34000, 34000, 34999, 39999, 39999, 41999, 42999, 42999, 42999, 44999};

    /** Nama gift -> sel sprite yang sudah dicocokkan dengan benar. */
    private static final Object[][] SPRITE = {
            {"Rose", 16},
            {"Ice Cream Cone", 17},
            {"GG", 20},
            {"Cake Slice", 24},
            {"Thumbs Up", 22},
            {"Doughnut", 2},
            {"Finger Heart", 36},
            {"Love you", 3},
            {"Cap", 98},
            {"Little Crown", 97},
            {"Paper Crane", 96},
            {"Groove Guitar", 104},
            {"Sunglasses", 128},
            {"Spinning Soccer", 26},
            {"Rosa", 65},
            {"Tiny Diny", 66},
            {"Cat", 35},
            {"Live Up Earth", 19},
            {"Corgi", 146}};

    public static int size() { return NAMES.length; }

    /** Gambar gift (id ikon) untuk sebuah nama, atau kotak gift umum bila belum dikenali. */
    public static int iconFor(String name) {
        String n = GameSettings.norm(name);
        for (Object[] s : SPRITE) if (GameSettings.norm((String) s[0]).equals(n)) return SPRITE_BASE + (Integer) s[1];
        return GENERIC_ICON;
    }

    public static int indexOf(String name) {
        String n = GameSettings.norm(name);
        for (int i = 0; i < NAMES.length; i++) if (GameSettings.norm(NAMES[i]).equals(n)) return i;
        return -1;
    }

    public static int coinsOf(String name) {
        int i = indexOf(name);
        return i < 0 ? 0 : COINS[i];
    }
}
