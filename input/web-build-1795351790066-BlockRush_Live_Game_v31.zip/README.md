# BlockRush Live Game v30 — AndroidForge Source

Game Minecraft 2D untuk live TikTok: penonton kirim gift / follow / like, dan game langsung bereaksi (TNT, petir, tornado, robot, meteor, monster, dll).

## Hubungkan ke TikTok Live

**Mode LANGSUNG (tanpa Node.js):** menu **TIKTOK LIVE** → isi **Username** (yang sedang LIVE) dan **API KEY** → **MULAI TERHUBUNG**. Game membuka WebSocket sendiri ke `wss://ws.eulerstream.com`.
> Server Euler **menolak koneksi tanpa key** (error `4400 Must provide either 'apiKey' or 'jwtKey'`). Key gratis: tombol **AMBIL API KEY GRATIS** membuka eulerstream.com → daftar → API Keys → salin → ketuk baris **API KEY** di game → tempel. Tanpa key, game kini langsung menampilkan pesan yang jelas.
> Mode ini belum bisa dites dari sini (butuh internet + akun live). Teks status koneksi hanya tampil di menu TIKTOK, tidak lagi di layar game.

**Mode NODE.JS BRIDGE:** tetap tersedia (tombol NODE.JS BRIDGE). Di bridge TIKTOMC: `MINECRAFT_OUTBOUND_ENABLED=false`, `WS_PORT=25601`; di game isi host/port. Mode ini sudah diuji dengan `TMine.js` asli.

**HUBUNG OTOMATIS** = langsung tersambung saat game dibuka. **TES** = kirim follow + gift palsu.

## Hadiah & Event

- **HADIAH** (24 slot): satu slot = satu gift TikTok → **tepat** satu efek yang kamu atur (mis. Mawar = 1 TNT → hanya 1 TNT). Atur nama gift (pilih dari ±750 gift Indonesia / cari / ketik), gambar, efek, jumlah, teks, ON/OFF, TAMPIL/SEMBUNYI (maks 16 tampil; yang disembunyikan tetap memicu efek) dan **SUARA** sendiri (ketuk baris SUARA → pilih file audio dari HP; X = hapus, kembali ke suara bawaan) dan tombol **TES** per baris. Mengetuk gambar gift di atas layar juga memicu efeknya.
- Notifikasi: "asep mengirim 1x mawar". Nama pengirim juga tampil di atas robot, tornado, dan monster yang ia panggil.
- **Gambar gift** diambil otomatis dari streamtoearn.io (daftar gift Indonesia) dan dari gambar yang ikut terkirim saat live; disimpan di cache HP, jadi cukup online sekali. Tanpa internet dipakai gambar bawaan / kotak hadiah. Ketuk gambar di baris gift untuk memilih gambar lain (AUTO = dari web).
- Setiap gift di atas layar punya lencana kecil gambar efeknya (petir, tornado, dll).
- **EVENT**: follow, share, masuk, like, komentar, subscribe, gift lain → efek + jumlah + TES + **mata** (tampil sebagai tile di atas layar seperti gift, ketuk untuk memicu) + **SUARA** sendiri. Tile gift + event bersama maks 16 (2 baris).
- **Efek**: BLOK (blok langsung muncul di arena, lapisan paling bawah dulu, mis. 1 mawar = 5 blok), TNT, HUJAN TNT, KOSONG (tidak melakukan apa-apa, notifikasi tetap muncul), NYAWA (nyawa tambahan), PERISAI, PETIR (menembus dalam), TORNADO (muncul di atas lalu jatuh, berjalan ke samping; blok yang menghalangi ikut terabas, dan tiap ±0,5 detik ia **menarik 1 blok acak dari 5 baris di bawahnya**), ROBOT (tiap robot punya kolom sendiri, terbang ke atas & hilang bila selesai), METEOR, MONSTER.

## Aturan

- Blok per **lapisan**: 10 blok ke samping = 1 lapisan, HUD menampilkan `N/40`. 40 lapisan penuh → hitung mundur → menang.
- Hitung mundur **batal** kalau ada blok hancur. Mulai hitungan, kecepatan, dan target menang bisa diatur.
- Pemain bisa mati (PENGATURAN > GAME). Saat mati tidak ada menu: pemain hilang beberapa detik (**HIDUP LAGI** bisa diatur) lalu hidup lagi otomatis dengan perlindungan 3 detik.
- Blok hanya bisa dipasang bila menempel tanah/blok; lalu jatuh sampai bertumpu (**BLOK JATUH** bisa dimatikan di PENGATURAN > GAME). Tombol **DEPAN** (atau F) memasang blok di depan player seperti Minecraft Bedrock.
- Saat player berdiri di tengah garis antara dua kolom, blok dipasang bergantian kiri-kanan. Semua jalur pemasangan (di bawah player, DEPAN, ketuk) memakai gravitasi.
- **MAP & KARAKTER** hanya dari menu utama: 2 map (PADANG RUMPUT, NETHER MALAM — tampilan beda: langit gua, dinding bata nether, lava) dan 2 karakter (STEVE, PINKY).
- Suara: langkah (3 variasi jalan + 3 lari), suara & animasi menaruh blok baru.

## Pengaturan

- **UMUM**: tombol layar, **ATUR POSISI & UKURAN TOMBOL** (seret tombol ke tempat nyaman, atur ukuran per tombol atau semua sekaligus, tersimpan), notif TikTok, blok tak terbatas, **HUD transparan** (arena terlihat di belakang HUD; matikan untuk latar biru), kecepatan pasang, HUD turun.
- **GAME**: bisa mati, tampilkan nyawa, hidup lagi (detik), blok jatuh, target menang, hitungan mundur, gift tampil.
- **EFEK**: durasi tornado / robot / monster / perisai, dan saklar **NAMA DI TORNADO / ROBOT / MONSTER** (nama pengirim di atas tiap efek bisa dimatikan sendiri-sendiri).
- **SUARA**: efek suara on/off + volume, musik latar on/off + volume, suara klik tombol.

## Mod

Menu utama → **MOD** (atau tombol M). Folder mod ada di `Android/data/com.mcpakel.blockarea/files/mods/` (satu folder = satu mod; sebagian file manager butuh akses khusus ke Android/data). Saat pertama dibuka dibuat folder `contoh_mod` berisi `mod.json` dan `README.txt` contoh.

- **Ganti texture / suara**: taruh file dengan path yang SAMA seperti di `assets` (mis. `ui/fx_tnt.png`, `blocks/block_00.png`, `sounds/sfx_place.wav`, `music/bgm.wav`, `menu/background.jpg`) di dalam folder mod.
- **Tambah fitur**: `mod.json`:
```json
{ "name": "Mod Saya", "version": "1.0", "author": "aku",
  "gifts":  [ { "name": "Lion", "label": "BADAI", "icon": "gift/lion.png",
                "actions": [ {"effect": "TNT", "amount": 3}, {"effect": "METEOR", "amount": 1} ] } ],
  "events": { "share": [ {"effect": "PETIR", "amount": 1} ] } }
```
  effect: BLOK, TNT, HUJAN TNT, KOSONG, NYAWA, PERISAI, PETIR, TORNADO, ROBOT, METEOR, MONSTER. Gift yang kamu atur sendiri di menu HADIAH tetap diutamakan; aksi event mod berjalan tambahan.
- Aktif/nonaktifkan tiap mod di menu MOD; setelah mengubah file tekan **MUAT ULANG**.

## Kontrol

| Aksi | Sentuh | Keyboard | Mouse |
|---|---|---|---|
| Jalan | ◀ ▶ | A / D | – |
| Lompat | ⬆ | W / Spasi | – |
| Lari | tombol lari | Shift | – |
| Blok di bawah | tombol blok | E / Enter | – |
| Blok di depan | DEPAN | F | – |
| Pasang / gali | ketuk / mode beliung | X / Z, S | klik kiri / kanan |
| Hadiah (uji) | ketuk ikon | 1–8 | klik ikon |
| Jeda | tombol jeda, Back | Esc / P | – |
| Menu | – | O / G / T / L / M | – |

## Build

Ekstrak ke workspace AndroidForge, build modul `app` dengan JDK 17, Android SDK 35. Application ID `com.mcpakel.blockarea` — Versi 2.4 (versionCode 24). Izin INTERNET sudah ada.

Diuji dengan API Android tiruan (logika, input, tampilan). APK asli / TikTok live asli belum dites di perangkat.


## Update aplikasi & rekam suara game (v25)

- **Update tanpa uninstall:** project memakai satu kunci tetap `app/blockrush.keystore` (debug & release) dan `versionCode 25`. APK v25 dan seterusnya bisa dipasang menimpa yang lama. **Sekali saja** v25 harus dipasang setelah meng-uninstall versi lama (v24 dan sebelumnya ditandatangani kunci lain; Android menolak menimpa). Jaga file keystore tetap ada; kalau AndroidForge memakai kunci sendiri, aktifkan opsi memakai signingConfig project.
- **Suara game ikut terekam / live:** manifest memakai `allowAudioPlaybackCapture="true"` (aplikasi targetSdk 28 secara bawaan tidak bisa direkam) dan semua suara memakai AudioAttributes USAGE_GAME dengan izin capture. Perekam layar / live yang merekam *audio internal* akan menangkap suara game walau mikrofon dimute. Perlu Android 10+ dan perekam yang memakai "suara dari perangkat/internal".


## Perubahan v26

- **HUD:** kamera sekarang bisa turun lebih jauh saat pemain di baris paling atas, jadi pemain tidak tertutup HUD / tile. **Bar nyawa (HP)** pindah ke kiri bawah (di atas tombol), notifikasi naik di atasnya. Judul **MATI** + hitung mundur hidup lagi tampil di tengah layar.
- **Event seperti gift:** FOLLOW / SHARE / MASUK / LIKE / KOMEN / SUB memakai gambar badge buatanmu sebagai tile di atas layar (aktifkan ikon mata di menu EVENT).
- **Pilih efek:** ketuk chip efek di HADIAH / EVENT → muncul grid semua efek (gambar + keterangan), pilih dengan satu ketukan.
- **Gambar gift:** hanya dari website (streamtoearn.io / gambar dari event live), tidak lagi memakai sheet bawaan. Saat gambar belum terunduh / offline tampil kotak hadiah polos. Pemilih gambar: AUTO (website) atau gambar efek.
- **Tornado:** lihat bagian Efek di atas.


## Perubahan v27

Tiga efek baru (pilih lewat grid PILIH EFEK di HADIAH / EVENT, atau nama `rudal`, `pelempar`, `bos` di mod):

- **RUDAL** — rudal terbang dari samping layar, meledak saat kena blok pertama (atau pemain): lubang besar + terowongan pendek. Nama pengirim tampil di atas rudal.
- **PELEMPAR TNT** — karakter lain (kebalikan karakter yang kamu pakai) berjalan di atas arena dengan papan melayang dan melempar TNT berbentuk busur ke blok. **Nama pengirim di atas kepala.** Lama berdiri diatur di PENGATURAN > EFEK (default 10 dtk).
- **BOS** — naga raksasa muncul di atas, mengisi napas, lalu menyemburkan api yang menyapu kiri-kanan, melelehkan 3 kolom blok sekaligus dan melukai pemain yang kena semburan. Nama pengirim tampil di atas bos. Durasi diatur di PENGATURAN > EFEK (default 10 dtk).
- PENGATURAN > EFEK: tambah DURASI BOS API, DURASI PELEMPAR TNT, dan saklar nama untuk PELEMPAR / BOS / RUDAL.
- **Suara TNT baru:** ledakan berlapis (retakan, dentuman dalam, gemuruh, serpihan) dengan 2 variasi acak, desis sumbu baru berpercikan. Suara baru: lemparan, rudal, napas api, raungan bos. File suara memakai nama baru (`sfx_boom1/2`, `sfx_boom_big`, `sfx_fuse2`, `sfx_throw`, `sfx_missile`, `sfx_flame`, `sfx_boss`) supaya terbaca setelah update; `sfx_explode*` lama sudah tidak dipakai.


## Perubahan v28

- **HUD / lompat:** kamera memberi ruang setinggi satu lompatan penuh di bawah baris gift, jadi pemain tidak tertutup gift saat lompat di lapisan atas.
- **TNT vs HUJAN TNT:** efek **TNT** sekarang muncul langsung di pemain (kolom pemain, lalu kiri/kanan bergantian). **HUJAN TNT** tetap jatuh dari langit.
- **Nama pemain:** nama TikTok (`@username`) tampil di atas karakter. Saklar: PENGATURAN > UMUM > NAMA PEMAIN.
- **Zoom otomatis:** saat monster, naga, rudal, atau bor aktif, peta mengecil (zoom out) lalu kembali normal. Saklar: PENGATURAN > UMUM > ZOOM OTOMATIS.
- **Area tidak reset:** keluar ke menu lalu masuk lagi melanjutkan area yang sama (tombol jadi LANJUT). Reset manual: tombol **ULANG AREA** di menu (atau ULANG di layar jeda).
- **Gambar baru:** pelempar TNT (anak lelaki, animasi lempar), naga (tampak samping, api dari mulut), **RUDAL = rudal nuklir besar** jatuh dari langit dengan ledakan jamur, dan efek baru **BOR** (mesin bor turun, mengebor 3 kolom ke bawah, lalu pergi; nama `bor`/`drill` di mod). PENGATURAN > EFEK: saklar NAMA DI BOR.
- **Notifikasi** semua berformat `nama > teks` (mis. `asep > itu gimana bang`); komentar panjang dipotong dengan "…" bukan dikecilkan. Toast efek juga diawali nama pengirim.
- **Tombol DEPAN dihapus** dari layar (tombol E / F keyboard tetap).
- **Bahasa:** PENGATURAN > UMUM > BAHASA / LANGUAGE (Indonesia default, English).
- **YouTube & TikTok** di menu utama bisa diklik (`GameSettings.LINK_YT` / `LINK_TT` untuk mengubah tautan).
- **Semua efek suara dibuat ulang** lebih realistis (langkah, blok, ledakan berlapis dengan gema, nuklir, petir, tornado, naga, bor, notifikasi, dll). Cache suara memakai nama baru (`snd28_*`) agar terbaca setelah update.


## Perubahan v31
- **Hak cipta:** tulisan "Hak Cipta © 2026 MCPAKEL. Semua hak dilindungi." tampil di layar MEMUAT dan menu utama (ikut berganti ke English), semua file `.java` diberi header hak cipta, dan ada file `COPYRIGHT.md`.

## Perubahan v30
- Interaksi sekarang menargetkan kolom yang ada block-nya (petir, meteor, rudal, BOR, hujan TNT, monster, lemparan pelempar, arah tornado). Sebagian tetap acak; makin sedikit block, makin sering menargetkan block. Kalau tidak ada block, acak biasa.
- Komentar: kalau teks kosong tidak ditampilkan lagi ("anonymous > komentar"), pembacaan nama/teks dari bridge lebih lengkap, dan notifikasi memakai ikon event (komentar, follow, dll) bukan ikon efek.

## Perubahan v29

- **Pelempar TNT** sekarang berjalan di atas blok (atau di tanah kalau belum ada blok), tidak terbang. Dia melempar **searah hadapnya** (ke depan, tidak ke belakang), lebih pelan (jeda ±1–2 dtk, animasi lempar lebih panjang). **Jumlah lemparan bisa diatur**: PENGATURAN > EFEK > JUMLAH LEMPARAN PELEMPAR (default 8, 1–999); setelah habis dia pergi.
- **Naga** acak: kadang **mendarat** di atas blok/tanah dan menyembur dari sana, kadang **terbang melayang**. Semburan api dipendekkan (tidak lagi dari atas arena sampai dasar) dan hanya melelehkan blok yang kena api.
- **Tornado:** blok yang tersedot sekarang ikut **berputar dan berputar-putar (berotasi)** mengelilingi pusaran sambil naik, lalu terlempar keluar dan pecah saat jatuh.
- **Hujan TNT** selalu turun dari langit di atas arena, juga ketika blok sudah penuh sampai atas. (Efek **TNT** tetap muncul di pemain.)
- **Zoom out:** blok bagian bawah tidak lagi hilang saat peta mengecil (perbaikan culling).
- **Rudal nuklir:** awan jamur sekarang keluar dari tengah kawah ledakan, tidak lagi terlihat mengambang di atas.
- **Tanpa batas spawn:** jumlah per gift/event bisa sampai 9999 (minimal 5 untuk semua efek), antrian tidak dipotong 100 lagi, LIKE tidak dibatasi (mis. 5000 like = ribuan aksi; "aksi tiap N like" sampai 9999). Antrian panjang dijalankan lebih cepat (beberapa sekaligus). Slot TNT diperbesar (80), rudal 6, bor 6, pelempar 3.
