# Hak Cipta / Copyright

**Block Rush Live Game** (`com.mcpakel.blockarea`)
Hak Cipta © 2026 MCPAKEL. Semua hak dilindungi.
Copyright © 2026 MCPAKEL. All rights reserved.

Dilarang menyalin, menjual ulang, mendistribusikan ulang, atau mengubah game ini
(termasuk kode, gambar, dan suara) tanpa izin tertulis dari MCPAKEL.
Copying, reselling, redistributing, or modifying this game (code, images, and sounds)
without written permission from MCPAKEL is not allowed.

Nama TikTok, YouTube, dan Minecraft adalah milik pemiliknya masing-masing;
game ini tidak berafiliasi dengan mereka.
TikTok, YouTube, and Minecraft are trademarks of their respective owners;
this game is not affiliated with them.
