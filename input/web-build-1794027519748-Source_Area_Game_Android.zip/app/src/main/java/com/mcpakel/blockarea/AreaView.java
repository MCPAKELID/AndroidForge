package com.mcpakel.blockarea;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.LinearGradient;
import android.graphics.Paint;
import android.graphics.RadialGradient;
import android.graphics.Shader;
import android.view.View;

/**
 * Area-only scene. The dark cells are deliberately empty and are reserved
 * for the future block placement system.
 */
public class AreaView extends View {
    private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
    private static final float DESIGN_W = 864f;
    private static final float DESIGN_H = 1536f;

    // Proportions are based on the supplied 9:16 area reference.
    private static final float LEFT = 88f;
    private static final float RIGHT = 776f;
    private static final float TOP = 74f;
    private static final float BOTTOM = 1482f;
    private static final float CELL = 36f;

    public AreaView(Context context) {
        super(context);
        setLayerType(View.LAYER_TYPE_SOFTWARE, null);
    }

    private void fill(Canvas c, float l, float t, float r, float b, int color) {
        p.setShader(null);
        p.setColor(color);
        c.drawRect(l, t, r, b, p);
    }

    private void gradient(Canvas c, float l, float t, float r, float b,
                          int topColor, int bottomColor) {
        p.setShader(new LinearGradient(l, t, l, b, topColor, bottomColor,
                Shader.TileMode.CLAMP));
        c.drawRect(l, t, r, b, p);
        p.setShader(null);
    }

    @Override
    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        // Fit the 9:16 design without stretching the grid.
        float scale = Math.min(getWidth() / DESIGN_W, getHeight() / DESIGN_H);
        float dx = (getWidth() - DESIGN_W * scale) / 2f;
        float dy = (getHeight() - DESIGN_H * scale) / 2f;
        canvas.save();
        canvas.translate(dx, dy);
        canvas.scale(scale, scale);

        drawSky(canvas);
        drawDistantForest(canvas);
        drawOuterEarth(canvas);
        drawVines(canvas);
        drawStoneFrame(canvas);
        drawEmptyGrid(canvas);
        drawLantern(canvas, 65f, 177f);
        drawLantern(canvas, 765f, 177f);
        drawFrameShadows(canvas);

        canvas.restore();
    }

    private void drawSky(Canvas c) {
        gradient(c, 0, 0, DESIGN_W, DESIGN_H, Color.rgb(62, 173, 239),
                Color.rgb(107, 194, 244));
        // Soft blocky clouds
        cloud(c, 0, 430, 1.0f);
        cloud(c, 700, 520, .78f);
        cloud(c, 0, 820, .72f);
        cloud(c, 710, 900, .82f);
    }

    private void cloud(Canvas c, float x, float y, float s) {
        int a = Color.rgb(218, 242, 255);
        int b = Color.rgb(241, 250, 255);
        fill(c, x + 8*s, y + 14*s, x + 90*s, y + 35*s, a);
        fill(c, x + 28*s, y, x + 72*s, y + 22*s, b);
        fill(c, x, y + 25*s, x + 105*s, y + 42*s, a);
    }

    private void drawDistantForest(Canvas c) {
        for (int side = 0; side < 2; side++) {
            for (int i = 0; i < 9; i++) {
                float x = side == 0 ? -18 + i*9 : 790 + i*9;
                float y = 760 + (i % 3)*34;
                fill(c, x+12, y+24, x+34, DESIGN_H, Color.rgb(91, 57, 34));
                fill(c, x-5, y-30, x+48, y+35, Color.rgb(20, 99, 43));
                fill(c, x+1, y-48, x+43, y+3, Color.rgb(34, 133, 48));
                fill(c, x+9, y-60, x+34, y-22, Color.rgb(54, 164, 52));
                fill(c, x-3, y+10, x+42, y+20, Color.rgb(69, 151, 39));
            }
        }
    }

    private void drawOuterEarth(Canvas c) {
        // Top grassy cap
        fill(c, 0, 0, DESIGN_W, 23, Color.rgb(50, 115, 31));
        fill(c, 0, 0, DESIGN_W, 9, Color.rgb(83, 174, 35));
        for (int x = 0; x < DESIGN_W; x += 19) {
            fill(c, x, 3 + (x % 3), x+8, 13, Color.rgb(105, 202, 39));
            fill(c, x+8, 11, x+15, 22, Color.rgb(38, 101, 31));
        }
        // Lower outer ground
        fill(c, 0, 1480, DESIGN_W, DESIGN_H, Color.rgb(105, 67, 37));
        fill(c, 0, 1480, DESIGN_W, 1492, Color.rgb(57, 127, 34));
        fill(c, 0, 1492, DESIGN_W, 1501, Color.rgb(87, 151, 38));
        for (int x=0; x<DESIGN_W; x+=24) {
            fill(c, x+3, 1504, x+17, 1512, Color.rgb(119, 75, 39));
            fill(c, x+11, 1517, x+20, 1527, Color.rgb(77, 51, 32));
        }
    }

    private void drawVines(Canvas c) {
        for (int side=0; side<2; side++) {
            float base = side == 0 ? 0 : 837;
            for (int i=0; i<11; i++) {
                float x = base + (i%3)*7;
                float y = i*35;
                fill(c, x, y, x+5, y+43, Color.rgb(29, 100, 35));
                fill(c, x+(i%2==0?4:-5), y+12, x+15, y+20,
                        Color.rgb(55, 151, 39));
                fill(c, x-2, y+27, x+7, y+34, Color.rgb(75, 179, 43));
            }
        }
    }

    private void stoneTile(Canvas c, float x, float y, float w, float h) {
        fill(c, x, y, x+w, y+h, Color.rgb(62, 68, 77));
        fill(c, x+2, y+2, x+w-2, y+h-2, Color.rgb(119, 127, 138));
        fill(c, x+4, y+4, x+w-4, y+7, Color.rgb(166, 173, 181));
        fill(c, x+4, y+8, x+7, y+h-5, Color.rgb(143, 151, 160));
        fill(c, x+5, y+h-7, x+w-5, y+h-4, Color.rgb(67, 73, 82));
        fill(c, x+w-7, y+5, x+w-4, y+h-6, Color.rgb(76, 83, 93));
        fill(c, x+w*.35f, y+h*.38f, x+w*.35f+4, y+h*.38f+2,
                Color.rgb(98, 106, 116));
    }

    private void drawStoneFrame(Canvas c) {
        // Deep shadow behind the masonry border
        fill(c, 49, 48, 815, 1515, Color.rgb(25, 29, 34));
        float size = 32;
        for (float x=54; x<814; x+=size) {
            stoneTile(c, x, 50, size, 32);
            stoneTile(c, x, 1480, size, 32);
        }
        for (float y=82; y<1480; y+=size) {
            stoneTile(c, 54, y, 32, size);
            stoneTile(c, 778, y, 32, size);
        }
        // Inner dark bevel
        fill(c, 86, 82, 91, 1480, Color.rgb(43, 48, 56));
        fill(c, 773, 82, 778, 1480, Color.rgb(43, 48, 56));
        fill(c, 86, 82, 778, 87, Color.rgb(43, 48, 56));
        fill(c, 86, 1475, 778, 1480, Color.rgb(43, 48, 56));
    }

    private void drawEmptyGrid(Canvas c) {
        int cols = (int)Math.ceil((RIGHT-LEFT)/CELL);
        int rows = (int)Math.ceil((BOTTOM-TOP)/CELL);
        for (int row=0; row<rows; row++) {
            for (int col=0; col<cols; col++) {
                float x=LEFT+col*CELL, y=TOP+row*CELL;
                float w=Math.min(CELL, RIGHT-x), h=Math.min(CELL, BOTTOM-y);
                int base=((row+col)&1)==0 ? Color.rgb(29,31,36) : Color.rgb(27,29,34);
                fill(c,x,y,x+w,y+h,base);
                fill(c,x+2,y+2,x+w-2,y+h-2,Color.rgb(31,33,39));
                fill(c,x+3,y+3,x+w-3,y+5,Color.rgb(39,42,49));
                fill(c,x+3,y+3,x+5,y+h-3,Color.rgb(38,41,48));
                fill(c,x+3,y+h-5,x+w-3,y+h-3,Color.rgb(20,22,27));
                fill(c,x+w-5,y+3,x+w-3,y+h-3,Color.rgb(19,21,26));
            }
        }
    }

    private void drawLantern(Canvas c, float x, float y) {
        // Hanging chain
        for (int i=0; i<6; i++) {
            fill(c,x+12,y+i*10,x+17,y+i*10+8,Color.rgb(181,193,207));
            fill(c,x+18,y+i*10,x+22,y+i*10+8,Color.rgb(75,86,101));
        }
        // Glow halo
        p.setShader(new RadialGradient(x+17,y+75,64,
                new int[]{0x55ffb34a,0x18ff9f24,0x00ff9f24}, null,
                Shader.TileMode.CLAMP));
        c.drawCircle(x+17,y+75,64,p);
        p.setShader(null);
        fill(c,x+1,y+53,x+34,y+59,Color.rgb(49,54,61));
        fill(c,x,y+59,x+36,y+101,Color.rgb(91,61,27));
        fill(c,x+4,y+63,x+32,y+94,Color.rgb(255,151,22));
        fill(c,x+8,y+66,x+28,y+91,Color.rgb(255,211,92));
        fill(c,x+12,y+70,x+24,y+87,Color.rgb(255,244,184));
        fill(c,x+4,y+98,x+32,y+103,Color.rgb(46,39,30));
    }

    private void drawFrameShadows(Canvas c) {
        p.setShader(new LinearGradient(88,0,122,0,
                0x77000000,0x00000000,Shader.TileMode.CLAMP));
        c.drawRect(88,86,122,1475,p);
        p.setShader(new LinearGradient(742,0,778,0,
                0x00000000,0x77000000,Shader.TileMode.CLAMP));
        c.drawRect(742,86,778,1475,p);
        p.setShader(null);
    }
}
