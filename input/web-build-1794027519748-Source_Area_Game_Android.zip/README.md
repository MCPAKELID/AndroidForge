# Minecraft Block Area (Android Native)

Proyek ini hanya membuat area permainan kosong sesuai referensi gambar.

## Isi saat ini
- Android Native Java, tanpa WebView.
- Area grid gelap kosong sebagai slot blok untuk fitur berikutnya.
- Bingkai stone-brick, latar langit/hutan, rumput/tanah, dan dua lentera.
- Orientasi portrait dan tampilan fullscreen.
- Tidak ada player, inventory, HUD, tombol, HP, atau blok gameplay.

## Build
Buka folder `MinecraftBlockArea` sebagai proyek Gradle Android di AndroidForge.
Gunakan JDK 17 dan Android SDK Platform 35 (atau sesuaikan compileSdk dengan SDK yang tersedia).
Module aplikasi: `app`
Application ID: `com.mcpakel.blockarea`

Tidak ada dependency eksternal.
