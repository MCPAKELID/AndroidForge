package com.mcpakel.blockarea;

import android.content.Context;
import android.graphics.*;
import android.view.MotionEvent;
import android.view.View;
import java.io.IOException;

/**
 * Minecraft block game stage:
 * - Arena artwork is a separate asset.
 * - HUD is drawn as independent Canvas components.
 * - Character uses 15 transparent animation frames.
 * - Run button is a toggle: tap once to enable sprint, tap again to disable.
 * - No vertical red side meter and no block-placement logic yet.
 */
public class AreaView extends View {
    private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Bitmap[][] frames = new Bitmap[3][5]; // walk, run, jump
    private Bitmap arenaBitmap;

    private static final float W = 864f, H = 1920f;
    private static final RectF ARENA = new RectF(72, 340, 792, 1620);
    private static final float PLAYER_GROUND = 1510f;

    private float playerX = 432f;
    private float playerY = PLAYER_GROUND;
    private float velocityY = 0f;
    private boolean leftPressed, rightPressed, jumpPressed;
    private boolean sprintMode = false;
    private boolean facingRight = true;
    private boolean onGround = true;
    private long lastTime = 0L;
    private float animationClock = 0f;
    private int action = 0; // 0 walk/idle, 1 run, 2 jump
    private int walkFrame = 0, runFrame = 0, jumpFrame = 0;
    private final RectF target = new RectF();

    private final RectF leftButton  = new RectF(52, 1660, 168, 1776);
    private final RectF rightButton = new RectF(184, 1660, 300, 1776);
    private final RectF runButton   = new RectF(340, 1660, 530, 1776);
    private final RectF jumpButton  = new RectF(674, 1650, 812, 1786);

    public AreaView(Context context) {
        super(context);
        setLayerType(View.LAYER_TYPE_SOFTWARE, null);
        loadAssets(context);
    }

    private void loadAssets(Context context) {
        try {
            arenaBitmap = BitmapFactory.decodeStream(
                    context.getAssets().open("area/arena_reference.jpg"));
        } catch (IOException ignored) { }
        String[] actions = {"walk", "run", "jump"};
        for (int a = 0; a < actions.length; a++) {
            for (int i = 0; i < 5; i++) {
                try {
                    frames[a][i] = BitmapFactory.decodeStream(context.getAssets().open(
                            "character/" + actions[a] + "_" + i + ".png"));
                } catch (IOException ignored) { }
            }
        }
    }

    @Override protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        float scale = Math.min(getWidth() / W, getHeight() / H);
        float ox = (getWidth() - W * scale) / 2f;
        float oy = (getHeight() - H * scale) / 2f;
        canvas.save();
        canvas.translate(ox, oy);
        canvas.scale(scale, scale);

        drawScreenBackground(canvas);
        drawHud(canvas);
        drawArena(canvas);
        drawPlayer(canvas);
        drawControlDeck(canvas);

        canvas.restore();
        updatePlayer();
        postInvalidateDelayed(16);
    }

    private void drawScreenBackground(Canvas c) {
        p.setShader(new LinearGradient(0,0,0,H,0xff18232e,0xff443b31,Shader.TileMode.CLAMP));
        c.drawRect(0,0,W,H,p);
        p.setShader(null);
    }

    // ---------- HUD: all components are independent of the arena ----------
    private void panel(Canvas c, RectF r) {
        p.setShader(new LinearGradient(r.left,r.top,r.left,r.bottom,
                0xff727b8b,0xff242a34,Shader.TileMode.CLAMP));
        c.drawRoundRect(r,16,16,p);
        p.setShader(null);
        p.setStyle(Paint.Style.STROKE);
        p.setStrokeWidth(5);
        p.setColor(0xff080b11);
        c.drawRoundRect(r,16,16,p);
        p.setStrokeWidth(2);
        p.setColor(0xffb8c1ce);
        c.drawRoundRect(r.left+4,r.top+4,r.right-4,r.bottom-4,12,12,p);
        p.setStyle(Paint.Style.FILL);
        // small metallic highlight
        p.setColor(0xffd2d9e2);
        c.drawRect(r.left+16,r.top+6,r.right-16,r.top+9,p);
    }

    private void drawHud(Canvas c) {
        // Top row: player identity, trophy progress and block percentage.
        RectF profile = new RectF(18,16,292,112);
        RectF trophy = new RectF(306,16,570,112);
        RectF percent = new RectF(584,16,846,112);
        panel(c,profile); panel(c,trophy); panel(c,percent);

        // Avatar portrait tile
        RectF avatar = new RectF(29,26,99,102);
        p.setColor(0xff11151b); c.drawRoundRect(avatar,9,9,p);
        p.setColor(0xffcbd2dc); p.setStyle(Paint.Style.STROKE); p.setStrokeWidth(3);
        c.drawRoundRect(avatar,9,9,p); p.setStyle(Paint.Style.FILL);
        p.setColor(0xff8b5839); c.drawRect(43,44,85,88,p);
        p.setColor(0xff3b2419); c.drawRect(43,39,85,53,p);
        p.setColor(0xffe7b28c); c.drawRect(48,53,80,82,p);
        p.setColor(Color.WHITE); c.drawRect(52,59,59,65,p); c.drawRect(69,59,76,65,p);
        p.setColor(0xff263b83); c.drawRect(49,82,79,88,p);

        text(c,"AlexPakel",108,55,27,Color.WHITE,Paint.Align.LEFT,true);
        // Level plate
        p.setColor(0xff89531f); c.drawRoundRect(108,66,278,101,7,7,p);
        p.setColor(0xffffc75b); p.setStyle(Paint.Style.STROKE); p.setStrokeWidth(2);
        c.drawRoundRect(108,66,278,101,7,7,p); p.setStyle(Paint.Style.FILL);
        text(c,"Lv.1",193,92,23,0xffffe08a,Paint.Align.CENTER,true);

        drawTrophy(c,330,39,54);
        text(c,"4 / 10",470,78,39,Color.WHITE,Paint.Align.CENTER,true);
        drawGrassBlock(c,606,35,62);
        text(c,"26%",775,78,37,Color.WHITE,Paint.Align.CENTER,true);

        // Progress row
        RectF progressPanel = new RectF(18,126,846,202);
        panel(c,progressPanel);
        drawDirtBlock(c,34,143,43);
        text(c,"10 / 40",125,177,30,Color.WHITE,Paint.Align.CENTER,true);
        // Progress track
        RectF track = new RectF(207,143,831,185);
        p.setColor(0xff080a0e); c.drawRoundRect(track,9,9,p);
        p.setStyle(Paint.Style.STROKE); p.setStrokeWidth(3);
        p.setColor(0xff68717e); c.drawRoundRect(track,9,9,p); p.setStyle(Paint.Style.FILL);
        RectF fill = new RectF(212,148,212+(track.width()-10)*.25f,180);
        p.setShader(new LinearGradient(fill.left,fill.top,fill.left,fill.bottom,
                0xffa5ff31,0xff28b900,Shader.TileMode.CLAMP));
        c.drawRoundRect(fill,5,5,p); p.setShader(null);
        // Segment lines in the bar
        p.setColor(0xff15220e);
        for(float x=260;x<830;x+=39) c.drawRect(x,149,x+3,179,p);

        // Seven empty inventory slots. No item icons are placed yet.
        float slotY=214, slotW=111, gap=8;
        for(int i=0;i<7;i++) {
            float x=18+i*(slotW+gap);
            RectF slot=new RectF(x,slotY,x+slotW,slotY+112);
            panel(c,slot);
            int accent;
            switch(i) {
                case 0: accent=0xffffd72f; break;
                case 1: accent=0xffff9827; break;
                case 2: accent=0xffffd72f; break;
                case 3: accent=0xfff34b4b; break;
                case 4: accent=0xffffd72f; break;
                case 5: accent=0xffc64be8; break;
                default: accent=0xffffa52b; break;
            }
            p.setColor(accent);
            c.drawRect(x+13,slotY+7,x+slotW-13,slotY+12,p);
            p.setColor(0xff15181d);
            c.drawRoundRect(x+10,slotY+17,x+slotW-10,slotY+101,7,7,p);
        }
    }

    private void text(Canvas c,String value,float x,float y,float size,int color,
                      Paint.Align align,boolean bold) {
        p.setShader(null); p.setColor(color); p.setTextSize(size);
        p.setTextAlign(align);
        p.setTypeface(Typeface.create("sans-serif",bold?Typeface.BOLD:Typeface.NORMAL));
        c.drawText(value,x,y,p);
    }

    private void drawTrophy(Canvas c,float x,float y,float s) {
        p.setColor(0xffffc51b);
        c.drawRect(x+s*.25f,y+s*.08f,x+s*.75f,y+s*.62f,p);
        c.drawRect(x+s*.16f,y+s*.12f,x+s*.28f,y+s*.42f,p);
        c.drawRect(x+s*.72f,y+s*.12f,x+s*.84f,y+s*.42f,p);
        c.drawRect(x+s*.38f,y+s*.60f,x+s*.62f,y+s*.80f,p);
        c.drawRect(x+s*.24f,y+s*.80f,x+s*.76f,y+s*.92f,p);
        p.setColor(0xffffe46b);
        c.drawRect(x+s*.32f,y+s*.15f,x+s*.43f,y+s*.22f,p);
    }

    private void drawGrassBlock(Canvas c,float x,float y,float s) {
        p.setColor(0xff79502e); c.drawRect(x,y+s*.28f,x+s,y+s,p);
        p.setColor(0xff4a9b2c); c.drawRect(x,y+s*.18f,x+s,y+s*.40f,p);
        p.setColor(0xff83d83c); c.drawRect(x,y+s*.18f,x+s,y+s*.29f,p);
        p.setColor(0xff5a3b26);
        for(int i=0;i<4;i++) c.drawRect(x+i*15+4,y+s*.47f,x+i*15+9,y+s*.55f,p);
    }

    private void drawDirtBlock(Canvas c,float x,float y,float s) {
        p.setColor(0xffc1b18d); c.drawRect(x,y,x+s,y+s*.30f,p);
        p.setColor(0xff8b6541); c.drawRect(x,y+s*.30f,x+s,y+s,p);
        p.setColor(0xffd9c9a4); c.drawRect(x+5,y+5,x+s-5,y+s*.25f,p);
        p.setColor(0xff63452e); c.drawRect(x+8,y+s*.55f,x+14,y+s*.65f,p);
    }

    // ---------- Arena and player ----------
    private void drawArena(Canvas c) {
        if(arenaBitmap!=null) {
            p.setAlpha(255); p.setFilterBitmap(false);
            c.drawBitmap(arenaBitmap,null,ARENA,p);
        } else {
            p.setColor(0xff1c2026); c.drawRect(ARENA,p);
        }
    }

    private void drawPlayer(Canvas c) {
        Bitmap sprite;
        if(action==2) sprite=frames[2][jumpFrame];
        else if(action==1) sprite=frames[1][runFrame];
        else sprite=frames[0][walkFrame];
        if(sprite==null) return;

        float height=104f;
        float width=height*sprite.getWidth()/sprite.getHeight();
        float x=playerX-width/2f, y=playerY-height;
        target.set(x,y,x+width,y+height);
        c.save();
        if(!facingRight) c.scale(-1f,1f,playerX,0f);
        p.setAlpha(255); p.setFilterBitmap(false);
        c.drawBitmap(sprite,null,target,p);
        c.restore();
    }

    // ---------- Separate lower movement deck ----------
    private void drawControlDeck(Canvas c) {
        p.setShader(new LinearGradient(0,1620,0,H,
                0xff7b512f,0xff4d301f,Shader.TileMode.CLAMP));
        c.drawRect(0,1620,W,H,p); p.setShader(null);
        // Grass/dirt pixel trim at the top of the control deck
        p.setColor(0xff438b2d); c.drawRect(0,1620,W,1631,p);
        p.setColor(0xff78c33a); c.drawRect(0,1620,W,1625,p);
        for(int x=0;x<W;x+=24) {
            p.setColor(0xff684126); c.drawRect(x+4,1581,x+15,1592,p);
            p.setColor(0xff9b6338); c.drawRect(x+14,1600,x+21,1608,p);
        }

        drawControlButton(c,leftButton,"‹",leftPressed,false);
        drawControlButton(c,rightButton,"›",rightPressed,false);
        drawControlButton(c,runButton,"RUN",false,sprintMode);
        drawControlButton(c,jumpButton,"↑",jumpPressed,false);
        drawHearts(c,300,1840,5);
        text(c,"MOVE",176,1800,16,0xffffe8c8,Paint.Align.CENTER,true);
        text(c,"SPRINT",435,1800,16,0xffffe8c8,Paint.Align.CENTER,true);
        text(c,"JUMP",743,1800,16,0xffffe8c8,Paint.Align.CENTER,true);
    }

    private void drawControlButton(Canvas c,RectF r,String label,boolean pressed,boolean toggled) {
        int top=(pressed||toggled)?0xff526779:0xff303946;
        int bottom=(pressed||toggled)?0xff172b3b:0xff171c24;
        p.setShader(new LinearGradient(r.left,r.top,r.left,r.bottom,top,bottom,Shader.TileMode.CLAMP));
        c.drawRoundRect(r,17,17,p); p.setShader(null);
        p.setStyle(Paint.Style.STROKE); p.setStrokeWidth(5);
        p.setColor((pressed||toggled)?0xff31d7ef:0xff080b10);
        c.drawRoundRect(r,17,17,p);
        p.setStyle(Paint.Style.FILL);
        p.setColor(0xffb8c3d0); p.setStrokeWidth(2);
        p.setStyle(Paint.Style.STROKE); c.drawRoundRect(r.left+5,r.top+5,r.right-5,r.bottom-5,13,13,p);
        p.setStyle(Paint.Style.FILL);
        text(c,label,r.centerX(),r.centerY()+12,label.equals("RUN")?28:67,Color.WHITE,Paint.Align.CENTER,true);
        if(label.equals("RUN")) {
            p.setColor(toggled?0xff62ff37:0xff66717d);
            c.drawCircle(r.right-20,r.top+19,8,p);
        }
    }

    private void drawHearts(Canvas c,float startX,float y,int count) {
        for(int i=0;i<count;i++) {
            float x=startX+i*48;
            Path heart=new Path();
            heart.moveTo(x+17,y+36);
            heart.cubicTo(x-20,y+12,x+1,y-7,x+17,y+9);
            heart.cubicTo(x+34,y-7,x+54,y+12,x+17,y+36);
            p.setColor(0xff13090b); c.drawPath(heart,p);
            c.save(); c.translate(0,-3);
            p.setColor(0xffef1825); c.drawPath(heart,p);
            p.setColor(0xffff6a70);
            c.drawCircle(x+10,y+11,4,p);
            c.restore();
        }
    }

    // ---------- Movement and animation ----------
    private void updatePlayer() {
        long now=System.nanoTime();
        if(lastTime==0L) lastTime=now;
        float dt=Math.min((now-lastTime)/1_000_000_000f,.04f);
        lastTime=now;

        float speed=sprintMode?270f:165f;
        if(leftPressed) { playerX-=speed*dt; facingRight=false; }
        if(rightPressed) { playerX+=speed*dt; facingRight=true; }
        playerX=Math.max(160f,Math.min(704f,playerX));

        if(jumpPressed&&onGround) {
            velocityY=-500f; onGround=false; jumpFrame=0; animationClock=0f;
        }
        if(!onGround) {
            velocityY+=1120f*dt; playerY+=velocityY*dt;
            if(playerY>=PLAYER_GROUND) {
                playerY=PLAYER_GROUND; velocityY=0f; onGround=true;
            }
        }

        animationClock+=dt;
        if(!onGround) {
            action=2;
            if(animationClock>=.11f) { jumpFrame=(jumpFrame+1)%5; animationClock=0f; }
        } else if(leftPressed||rightPressed) {
            action=sprintMode?1:0;
            float delay=sprintMode?.075f:.13f;
            if(animationClock>=delay) {
                if(action==1) runFrame=(runFrame+1)%5;
                else walkFrame=(walkFrame+1)%5;
                animationClock=0f;
            }
        } else {
            action=0; walkFrame=0; animationClock=0f;
        }
    }

    private float[] toDesign(float screenX,float screenY) {
        float scale=Math.min(getWidth()/W,getHeight()/H);
        float ox=(getWidth()-W*scale)/2f, oy=(getHeight()-H*scale)/2f;
        return new float[]{(screenX-ox)/scale,(screenY-oy)/scale};
    }

    @Override public boolean onTouchEvent(MotionEvent event) {
        int a=event.getActionMasked();
        int index=event.getActionIndex();

        if(a==MotionEvent.ACTION_DOWN || a==MotionEvent.ACTION_POINTER_DOWN) {
            float[] pos=toDesign(event.getX(index),event.getY(index));
            if(runButton.contains(pos[0],pos[1])) {
                sprintMode=!sprintMode; // tap once ON, tap again OFF
            }
        }

        if(a==MotionEvent.ACTION_UP || a==MotionEvent.ACTION_CANCEL) {
            leftPressed=rightPressed=jumpPressed=false;
            return true;
        }

        // Re-evaluate all currently held fingers; RUN is a toggle, not a hold button.
        leftPressed=rightPressed=jumpPressed=false;
        for(int i=0;i<event.getPointerCount();i++) {
            if((a==MotionEvent.ACTION_POINTER_UP)&&i==index) continue;
            float[] pos=toDesign(event.getX(i),event.getY(i));
            if(leftButton.contains(pos[0],pos[1])) leftPressed=true;
            if(rightButton.contains(pos[0],pos[1])) rightPressed=true;
            if(jumpButton.contains(pos[0],pos[1])) jumpPressed=true;
        }
        return true;
    }
}
