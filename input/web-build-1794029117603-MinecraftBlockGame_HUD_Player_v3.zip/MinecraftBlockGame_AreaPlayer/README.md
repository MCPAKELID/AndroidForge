# Minecraft Block Game - HUD + Area + Player

Android Native Java project for AndroidForge.

## Features in this build
- Arena artwork remains a separate asset and is displayed below the HUD.
- Top HUD: profile/level panel, trophy counter, grass percentage, block count, progress bar and seven empty inventory slots.
- No vertical red side meter is included.
- Five heart icons are shown in the lower control deck.
- Character animations: 5 walk frames, 5 run frames and 5 jump frames.
- Left/right movement and jump are hold controls.
- RUN is a toggle: tap once to enable sprint, tap again to return to normal walking.
- Grid remains empty; no block placement or inventory logic yet.

## Build
Open this project in AndroidForge. Use JDK 17 and Android SDK Platform 35.
Application ID: `com.mcpakel.blockarea`
No WebView and no external dependencies.
