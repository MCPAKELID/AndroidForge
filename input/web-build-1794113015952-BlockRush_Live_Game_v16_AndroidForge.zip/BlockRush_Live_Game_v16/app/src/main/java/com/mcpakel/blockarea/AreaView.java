package com.mcpakel.blockarea;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Rect;
import android.graphics.RectF;
import android.graphics.Typeface;
import android.util.SparseArray;
import android.view.MotionEvent;
import android.view.View;

import java.io.IOException;

public class AreaView extends View {
    private static final float WORLD_W = 512f;
    private static final float BOARD_H = 1935f;
    private static final float MAX_CONTROL_H = 384f;
    private static final float MIN_CONTROL_H = 140f;
    private static final int COLS = 10, ROWS = 40, BLOCK_TYPES = 48;
    private static final int BUILD_LIMIT_ROW = 0;
    private static final int MATERIAL_LAYERS = 5;
    private static final float GRID_X = 41f, GRID_Y = 132f, CELL = 43f;
    private static final float PLAYER_H = 112f;
    private static final float GRAVITY = 1850f, JUMP_SPEED = 720f;
    private static final float HUD_HEIGHT = 70f;
    private static final float PLAYER_SCREEN_RATIO = 0.72f;

    private static final int ROLE_NONE=0, ROLE_LEFT=1, ROLE_RIGHT=2, ROLE_JUMP=3,
            ROLE_RUN=4, ROLE_PICK=5, ROLE_BUILD=6, ROLE_GRID=7;

    private static final class TouchPoint {
        int role;
        float x,y;
        TouchPoint(int role,float x,float y){this.role=role;this.x=x;this.y=y;}
    }

    private final Paint paint = new Paint();
    private final int[][] blocks = new int[ROWS][COLS];
    private final Bitmap[] blockTextures = new Bitmap[BLOCK_TYPES];
    private final Bitmap[][] characterFrames = new Bitmap[3][5];
    private final SparseArray<TouchPoint> touches = new SparseArray<>();

    private Bitmap arena, hud, fontAtlas, placementFrame;
    private Bitmap leftImage,rightImage,runImage,pickImage,blockImage,jumpImage;

    // Visible control images and larger touch hitboxes.
    private final RectF[] hit = new RectF[6];
    private final RectF[] icon = new RectF[6];

    private float playerX, playerFeet, velocityY;
    private float cameraY, cameraTarget;
    private final float spawnFeet=GRID_Y+ROWS*CELL;
    private float animationClock;
    private long lastFrameNanos;
    private boolean grounded=true, sprint=false, facingRight=true;
    private boolean leftHeld=false,rightHeld=false,jumpHeld=false,jumpRequested=false;
    private boolean buildMode=false,breakMode=false;
    private int walkFrame=0,runFrame=0,jumpFrame=0;
    private int targetCol=-1,targetRow=-1,previewBlock=0;
    private int maxStackReached=0,brokenCount=0,totalPlaced=0;

    public AreaView(Context context) {
        super(context);
        setLayerType(View.LAYER_TYPE_SOFTWARE,null);
        arena=load("area/arena_reference.png");
        hud=load("ui/hud_top.png");
        fontAtlas=load("font/pixel_font.png");
        placementFrame=load("blocks/placement_frame.png");
        leftImage=load("ui/control_left.png");
        rightImage=load("ui/control_right.png");
        runImage=load("ui/control_run.png");
        pickImage=load("ui/control_pickaxe.png");
        blockImage=load("ui/control_block.png");
        jumpImage=load("ui/control_jump.png");

        for(int i=0;i<BLOCK_TYPES;i++){
            blockTextures[i]=load(String.format(java.util.Locale.US,"blocks/block_%02d.png",i));
        }
        String[] actions={"walk","run","jump"};
        for(int a=0;a<3;a++){
            for(int f=0;f<5;f++){
                characterFrames[a][f]=load("character/"+actions[a]+"_"+f+".png");
            }
        }
        for(int r=0;r<ROWS;r++) for(int c=0;c<COLS;c++) blocks[r][c]=-1;

        playerX=GRID_X+(COLS*CELL)/2f;
        playerFeet=GRID_Y+ROWS*CELL;
        for(int i=0;i<6;i++){hit[i]=new RectF();icon[i]=new RectF();}
        paint.setFilterBitmap(false);
        paint.setAntiAlias(false);
    }

    private Bitmap load(String path){
        try{return BitmapFactory.decodeStream(getContext().getAssets().open(path));}
        catch(IOException e){return null;}
    }

    private float scale(){return getWidth()/WORLD_W;}
    private float logicalHeight(){return getHeight()/Math.max(0.001f,scale());}
    private float controlHeight(){return Math.min(MAX_CONTROL_H,Math.max(MIN_CONTROL_H,logicalHeight()-BOARD_H));}
    private float controlTop(){return logicalHeight()-controlHeight();}
    private float areaTop(){return Math.min(HUD_HEIGHT,Math.max(0f,controlTop()-360f));}
    private float boardViewportHeight(){return Math.max(360f,controlTop()-areaTop());}
    private float worldToScreenY(float y){return areaTop()+y-cameraY;}
    private int clamp(int value,int min,int max){return Math.max(min,Math.min(max,value));}
    private int playerColumn(){return clamp((int)((playerX-GRID_X)/CELL),0,COLS-1);}

    private int topBlockRow(int col){
        for(int r=BUILD_LIMIT_ROW;r<ROWS;r++) if(blocks[r][col]>=0)return r;
        return ROWS;
    }
    private float supportY(int col){return GRID_Y+topBlockRow(col)*CELL;}
    // Count only the continuous stack connected to the arena floor.
    private int stackHeight(int col){
        int n=0;
        for(int row=ROWS-1;row>=BUILD_LIMIT_ROW;row--){
            if(blocks[row][col]<0)break;
            n++;
        }
        return n;
    }
    private int maxStack(){
        int m=0;for(int c=0;c<COLS;c++)m=Math.max(m,stackHeight(c));
        return m;
    }
    private int blockCount(){
        int n=0;for(int[] row:blocks)for(int v:row)if(v>=0)n++;
        return n;
    }
    // One completed horizontal layer contains all ten cells in a row.
    private int completedRows(){
        int full=0;
        for(int row=0;row<ROWS;row++){
            int count=0;
            for(int col=0;col<COLS;col++)if(blocks[row][col]>=0)count++;
            if(count==COLS)full++;
        }
        return full;
    }
    // Percentage is based on all 400 playable cells.
    private int areaPercent(){
        return Math.min(100,Math.round(blockCount()*100f/(COLS*ROWS)));
    }
    // Five vertical layers use one fixed material before advancing to the next.
    private int materialForRow(int row){
        int layerFromFloor=(ROWS-1)-row;
        return Math.min(BLOCK_TYPES-1,layerFromFloor/MATERIAL_LAYERS);
    }

    private void layoutControls(){
        float y=controlTop()+(controlHeight()-84f)/2f;
        float[] xs={2,86,170,268,352,436};
        for(int i=0;i<6;i++){
            hit[i].set(xs[i]-4,y-4,xs[i]+78,y+82);
            icon[i].set(xs[i]+2,y+2,xs[i]+76,y+80);
        }
    }

    private void drawBitmap(Canvas canvas,Bitmap bitmap,RectF dst){
        if(bitmap==null)return;
        paint.setAlpha(255);paint.setFilterBitmap(false);paint.clearShadowLayer();
        canvas.drawBitmap(bitmap,null,dst,paint);
    }

    @Override protected void onDraw(Canvas canvas){
        super.onDraw(canvas);
        if(getWidth()<=0)return;
        float sc=scale(),boardH=boardViewportHeight();
        layoutControls();
        if(lastFrameNanos==0){
            cameraY=clampFloat(spawnFeet-boardViewportHeight()*PLAYER_SCREEN_RATIO,
                    0f,Math.max(0f,BOARD_H-boardViewportHeight()));
        }

        canvas.save();
        canvas.scale(sc,sc);
        canvas.drawColor(0xff38a6fd);

        // Arena camera scrolls vertically in a viewport reserved below the fixed HUD.
        canvas.save();
        canvas.clipRect(0,areaTop(),WORLD_W,controlTop());
        if(arena!=null){
            drawBitmap(canvas,arena,new RectF(0,areaTop()-cameraY,
                    WORLD_W,areaTop()+BOARD_H-cameraY));
        }else{
            paint.setColor(0xff20232a);
            canvas.drawRect(0,areaTop(),WORLD_W,controlTop(),paint);
        }
        drawPlacedBlocks(canvas);
        drawPlacementTarget(canvas);
        drawPlayer(canvas);
        canvas.restore();

        drawHud(canvas);
        drawControls(canvas);
        canvas.restore();

        updatePhysics();
        postInvalidateDelayed(16);
    }

    private void drawPlacedBlocks(Canvas canvas){
        for(int row=BUILD_LIMIT_ROW;row<ROWS;row++){
            float y=worldToScreenY(GRID_Y+row*CELL);
            if(y>controlTop()||y+CELL<areaTop())continue;
            for(int col=0;col<COLS;col++){
                if(blocks[row][col]<0)continue;
                int type=materialForRow(row);
                float x=GRID_X+col*CELL;
                float inset=2.0f;
                drawBitmap(canvas,blockTextures[type],
                        new RectF(x+inset,y+inset,x+CELL-inset,y+CELL-inset));
            }
        }
    }

    private void drawPlacementTarget(Canvas canvas){
        if(targetCol<0||targetRow<BUILD_LIMIT_ROW||targetRow>=ROWS)return;
        float x=GRID_X+targetCol*CELL;
        float y=worldToScreenY(GRID_Y+targetRow*CELL);
        float inset=2.0f;
        RectF cell=new RectF(x+inset,y+inset,x+CELL-inset,y+CELL-inset);
        int ghostType=materialForRow(targetRow);
        if(!breakMode&&blocks[targetRow][targetCol]<0&&blockTextures[ghostType]!=null){
            paint.setAlpha(115);paint.setFilterBitmap(false);
            canvas.drawBitmap(blockTextures[ghostType],null,cell,paint);
            paint.setAlpha(255);
        }
        if(placementFrame!=null)drawBitmap(canvas,placementFrame,cell);
        paint.setStyle(Paint.Style.STROKE);
        paint.setStrokeWidth(2.5f);
        paint.setColor(breakMode?0xffff5555:0xff42ef69);
        canvas.drawRect(cell,paint);
        paint.setStyle(Paint.Style.FILL);
    }

    private void drawPlayer(Canvas canvas){
        int action=!grounded?2:((leftHeld||rightHeld)?(sprint?1:0):0);
        int frame=action==2?jumpFrame:(action==1?runFrame:walkFrame);
        Bitmap sprite=characterFrames[action][frame];
        if(sprite==null)return;
        float h=PLAYER_H,w=h*sprite.getWidth()/Math.max(1f,sprite.getHeight());
        float feet=worldToScreenY(playerFeet);
        RectF dst=new RectF(playerX-w/2,feet-h,playerX+w/2,feet);
        canvas.save();
        if(!facingRight)canvas.scale(-1,1,playerX,0);
        drawBitmap(canvas,sprite,dst);
        canvas.restore();
    }

    private void drawHud(Canvas canvas){
        if(hud==null)return;
        float hudW=WORLD_W;
        float hudH=hudW*hud.getHeight()/Math.max(1f,hud.getWidth());
        drawBitmap(canvas,hud,new RectF(0,0,hudW,hudH));

        // Left: count complete horizontal rows out of 40.
        drawAtlasText(canvas,completedRows()+"/40",77f,25f,18f);
        // Right: percentage of the occupied 10 x 40 play area.
        drawAtlasText(canvas,areaPercent()+"%",470f,25f,18f);

        // Fill the provided segmented strip according to occupied cells.
        float barX=6f, barY=44f, barW=500f, barH=12f;
        final int segments=16;
        float segW=barW/segments;
        float filled=(areaPercent()/100f)*segments;
        paint.setColor(0xff39e64f);
        paint.setStyle(Paint.Style.FILL);
        for(int i=0;i<segments;i++){
            float part=Math.max(0f,Math.min(1f,filled-i));
            if(part<=0f)continue;
            float left=barX+i*segW+1.2f;
            float right=barX+i*segW+segW*part-1.2f;
            if(right>left){
                canvas.drawRoundRect(new RectF(left,barY,right,barY+barH),2.5f,2.5f,paint);
            }
        }
        // Trophy and heart remain visual assets only; WIN and HP are not active yet.
    }

    private Rect fontSource(char ch){
        switch(ch){
            case '0': return new Rect(254,529,369,649);
            case '1': return new Rect(395,529,484,649);
            case '2': return new Rect(499,529,613,649);
            case '3': return new Rect(627,529,739,649);
            case '4': return new Rect(751,529,872,649);
            case '5': return new Rect(890,529,1005,649);
            case '6': return new Rect(1022,529,1139,649);
            case '7': return new Rect(1155,529,1266,649);
            case '8': return new Rect(1285,529,1399,649);
            case '9': return new Rect(1416,529,1533,649);
            case '/': return new Rect(1432,655,1520,765);
            case '%': return new Rect(643,763,758,873);
            default: return null;
        }
    }

    private void drawAtlasText(Canvas canvas,String text,float centerX,float centerY,float targetHeight){
        if(fontAtlas==null||text==null||text.length()==0)return;
        float total=0f;
        for(int i=0;i<text.length();i++){
            Rect r=fontSource(text.charAt(i));
            if(r!=null)total+=targetHeight*(r.width()/(float)r.height())+2f;
        }
        if(total>0f)total-=2f;
        float x=centerX-total/2f;
        for(int i=0;i<text.length();i++){
            Rect src=fontSource(text.charAt(i));
            if(src==null)continue;
            float w=targetHeight*src.width()/(float)src.height();
            RectF dst=new RectF(x,centerY-targetHeight/2f,x+w,centerY+targetHeight/2f);
            paint.setAlpha(255);
            paint.setFilterBitmap(false);
            canvas.drawBitmap(fontAtlas,src,dst,paint);
            x+=w+2f;
        }
    }

    private void drawControls(Canvas canvas){
        // Keep the controls floating over the same sky-blue scene background.
        Bitmap[] images={leftImage,rightImage,runImage,pickImage,blockImage,jumpImage};
        for(int i=0;i<6;i++){
            boolean active=(i==2&&sprint)||(i==3&&breakMode);
            if(active){
                paint.setColor(i==3?0x5537cfff:0x55ffc928);
                paint.setShadowLayer(10,0,0,i==3?0xff37cfff:0xffffc928);
                canvas.drawRoundRect(icon[i],18,18,paint);
                paint.clearShadowLayer();
            }
            drawBitmap(canvas,images[i],icon[i]);
        }
    }

    private boolean withinRange(int col,int row){
        float playerRow=(playerFeet-GRID_Y)/CELL;
        float dx=col-playerColumn(),dy=row-playerRow;
        return Math.sqrt(dx*dx+dy*dy)<=10.0;
    }

    private boolean supportedCell(int row,int col){
        // No floating blocks: every placed block must sit on the floor or directly on another block.
        return row==ROWS-1||blocks[row+1][col]>=0;
    }

    private boolean placeAtCell(int col,int row,boolean liftPlayer){
        if(col<0||col>=COLS||row<BUILD_LIMIT_ROW||row>=ROWS)return false;
        if(blocks[row][col]>=0||!withinRange(col,row))return false;

        // Simulate gravity for a newly placed block: it drops to the lowest
        // available cell in this column, then joins the stack from the bottom up.
        int landingRow=row;
        while(landingRow<ROWS-1&&blocks[landingRow+1][col]<0)landingRow++;
        if(blocks[landingRow][col]>=0||!supportedCell(landingRow,col))return false;
        row=landingRow;

        float top=GRID_Y+row*CELL;
        float bottom=top+CELL;
        int playerCol=playerColumn();
        boolean sameColumn=(col==playerCol);
        boolean underPlayer=sameColumn&&Math.abs(bottom-playerFeet)<CELL*0.35f;
        float playerTop=playerFeet-PLAYER_H;
        boolean overlapsPlayer=sameColumn&&bottom>playerTop+1f&&top<playerFeet-1f;

        // Do not place a tile through the player's body. A tile directly under
        // the feet is allowed and raises the player onto the new stack layer.
        if(overlapsPlayer&&!underPlayer)return false;

        // If the block lands under the player, move the player up by one cell.
        if(underPlayer){
            float newFeet=top;
            float newTop=newFeet-PLAYER_H;
            if(intersectsBlocks(col,newTop,newFeet))return false;
            if(!liftPlayer)return false;
        }

        blocks[row][col]=materialForRow(row);
        totalPlaced++;
        maxStackReached=Math.max(maxStackReached,maxStack());

        if(underPlayer&&liftPlayer){
            playerFeet=top;
            velocityY=0f;
            grounded=true;
        }
        return true;
    }

    // Main Block button: place one solid tile directly beneath the player, then step onto it.
    private void placeUnderPlayer(){
        int col=playerColumn();
        int surfaceRow=topBlockRow(col);
        float surfaceY=GRID_Y+surfaceRow*CELL;

        // Accept a small contact tolerance, then snap feet to the real surface.
        // If the center column is empty, do not let adjacent blocks hold the player up.
        if(Math.abs(playerFeet-surfaceY)>CELL*0.22f)return;
        playerFeet=surfaceY;
        velocityY=0f;
        grounded=true;

        int row=surfaceRow-1;
        if(row<BUILD_LIMIT_ROW)return;
        placeAtCell(col,row,true);
    }

    private void breakBlock(){
        int col=targetCol,row=targetRow;
        if(col<0||row<BUILD_LIMIT_ROW||row>=ROWS)return;
        if(blocks[row][col]<0||!withinRange(col,row))return;
        blocks[row][col]=-1;
        brokenCount++;
        maxStackReached=maxStack();

        // If the removed tile was the player's floor, release support and let gravity take over.
        if(grounded&&!hasSurfaceAtFeet(playerX,playerFeet)){
            grounded=false;
            velocityY=0f;
        }
    }

    private boolean intersectsBlocks(int col,float top,float feet){
        for(int row=BUILD_LIMIT_ROW;row<ROWS;row++){
            if(blocks[row][col]<0)continue;
            float blockTop=GRID_Y+row*CELL;
            float blockBottom=blockTop+CELL;
            if(feet>blockTop+1f&&top<blockBottom-1f)return true;
        }
        return false;
    }

    private boolean hasSurfaceAtFeet(float x,float feet){
        float floor=GRID_Y+ROWS*CELL;
        if(Math.abs(feet-floor)<2f)return true;

        int col=(int)((x-GRID_X)/CELL);
        if(col<0||col>=COLS)return false;
        for(int row=BUILD_LIMIT_ROW;row<ROWS;row++){
            if(blocks[row][col]<0)continue;
            float top=GRID_Y+row*CELL;
            if(Math.abs(feet-top)<2f)return true;
        }
        return false;
    }

    private float landingSurface(float x,float oldFeet,float newFeet){
        float best=Float.POSITIVE_INFINITY;
        float floor=GRID_Y+ROWS*CELL;
        if(oldFeet<=floor&&newFeet>=floor)best=floor;

        // Only the center of the feet can land on a block. Blocks beside a gap
        // must not act like an invisible bridge under the player's wide sprite.
        int col=(int)((x-GRID_X)/CELL);
        if(col<0||col>=COLS)return best;
        for(int row=BUILD_LIMIT_ROW;row<ROWS;row++){
            if(blocks[row][col]<0)continue;
            float top=GRID_Y+row*CELL;
            if(oldFeet<=top+1f&&newFeet>=top-1f&&top<best)best=top;
        }
        return best;
    }

    private float ceilingSurface(float x,float oldTop,float newTop){
        float best=Float.NEGATIVE_INFINITY;
        float half=PLAYER_H*0.22f;
        float left=x-half,right=x+half;
        int first=clamp((int)((left-GRID_X)/CELL),0,COLS-1);
        int last=clamp((int)((right-GRID_X)/CELL),0,COLS-1);
        // On upward motion, collide with the underside only if the player's head crosses it.
        for(int col=first;col<=last;col++){
            for(int row=BUILD_LIMIT_ROW;row<ROWS;row++){
                if(blocks[row][col]<0)continue;
                float bottom=GRID_Y+(row+1)*CELL;
                if(oldTop>=bottom-1f&&newTop<=bottom+1f&&bottom>best)best=bottom;
            }
        }
        return best;
    }

    private boolean blockedAt(float x,float top,float feet){
        float half=PLAYER_H*0.22f;
        float left=x-half,right=x+half;
        int first=clamp((int)((left-GRID_X)/CELL),0,COLS-1);
        int last=clamp((int)((right-GRID_X)/CELL),0,COLS-1);
        for(int col=first;col<=last;col++){
            for(int row=BUILD_LIMIT_ROW;row<ROWS;row++){
                if(blocks[row][col]<0)continue;
                float l=GRID_X+col*CELL,r=l+CELL;
                float t=GRID_Y+row*CELL,b=t+CELL;
                if(right>l+1f&&left<r-1f&&feet>t+1f&&top<b-1f)return true;
            }
        }
        return false;
    }

    private void updatePhysics(){
        long now=System.nanoTime();
        if(lastFrameNanos==0)lastFrameNanos=now;
        float dt=Math.min(0.032f,(now-lastFrameNanos)/1_000_000_000f);
        lastFrameNanos=now;

        float speed=sprint?245f:145f;
        float dx=0f;
        if(leftHeld&&!rightHeld){dx=-speed*dt;facingRight=false;}
        if(rightHeld&&!leftHeld){dx=speed*dt;facingRight=true;}

        // Horizontal collision uses the complete player body, not a guessed column support.
        float candidateX=clampFloat(playerX+dx,GRID_X+CELL*.5f,GRID_X+(COLS-.5f)*CELL);
        if(!blockedAt(candidateX,playerFeet-PLAYER_H,playerFeet)){
            playerX=candidateX;
        }

        if(grounded&&!hasSurfaceAtFeet(playerX,playerFeet)){
            grounded=false;
        }

        if(jumpRequested&&grounded){
            velocityY=-JUMP_SPEED;
            grounded=false;
        }
        jumpRequested=false;

        if(!grounded){
            float oldFeet=playerFeet;
            float oldTop=oldFeet-PLAYER_H;
            velocityY+=GRAVITY*dt;
            float nextFeet=oldFeet+velocityY*dt;
            float nextTop=nextFeet-PLAYER_H;

            if(velocityY<0f){
                float ceiling=ceilingSurface(playerX,oldTop,nextTop);
                if(ceiling!=Float.NEGATIVE_INFINITY){
                    nextFeet=ceiling+PLAYER_H;
                    velocityY=0f;
                }
            }else{
                float landing=landingSurface(playerX,oldFeet,nextFeet);
                if(landing!=Float.POSITIVE_INFINITY){
                    nextFeet=landing;
                    velocityY=0f;
                    grounded=true;
                }
            }
            playerFeet=nextFeet;
        }else{
            velocityY=0f;
        }

        // Camera follows the player vertically: climbing moves the arena down on screen.
        // HUD stays fixed above the arena and the bottom controls remain fixed below it.
        float desiredCamera=playerFeet-boardViewportHeight()*PLAYER_SCREEN_RATIO;
        cameraTarget=clampFloat(desiredCamera,0f,Math.max(0f,BOARD_H-boardViewportHeight()));
        cameraY+=(cameraTarget-cameraY)*Math.min(1f,dt*7f);

        animationClock+=dt;
        if(!grounded){
            if(animationClock>0.11f){jumpFrame=(jumpFrame+1)%5;animationClock=0f;}
        }else if(leftHeld||rightHeld){
            float delay=sprint?0.075f:0.13f;
            if(animationClock>delay){
                if(sprint)runFrame=(runFrame+1)%5;
                else walkFrame=(walkFrame+1)%5;
                animationClock=0f;
            }
        }else{
            walkFrame=0;animationClock=0f;
        }
    }

    private float clampFloat(float v,float min,float max){return Math.max(min,Math.min(max,v));}
    private float toLogicalX(float px){return px/Math.max(0.001f,scale());}
    private float toLogicalY(float py){return py/Math.max(0.001f,scale());}

    private int roleAt(float x,float y){
        // Image order is left, right, run, pickaxe, block, jump;
        // role IDs keep jump separate so it can be held together with movement.
        final int[] roles={ROLE_LEFT,ROLE_RIGHT,ROLE_RUN,ROLE_PICK,ROLE_BUILD,ROLE_JUMP};
        for(int i=0;i<6;i++)if(hit[i].contains(x,y))return roles[i];
        if(y>=areaTop()&&y<controlTop()&&x>=GRID_X&&x<GRID_X+COLS*CELL)return ROLE_GRID;
        return ROLE_NONE;
    }

    private void addPointer(MotionEvent e,int index){
        int id=e.getPointerId(index);
        float x=toLogicalX(e.getX(index)),y=toLogicalY(e.getY(index));
        int role=roleAt(x,y);
        TouchPoint t=new TouchPoint(role,x,y);
        touches.put(id,t);
        if(role==ROLE_RUN)sprint=!sprint;
        else if(role==ROLE_PICK){breakMode=!breakMode;buildMode=false;}
        else if(role==ROLE_BUILD){buildMode=false;breakMode=false;placeUnderPlayer();}
        else if(role==ROLE_JUMP)jumpRequested=true;
        if(role==ROLE_GRID)updateTarget(x,y);
        refreshHeldButtons();
    }

    private void updatePointers(MotionEvent e){
        for(int i=0;i<e.getPointerCount();i++){
            int id=e.getPointerId(i);
            TouchPoint t=touches.get(id);
            if(t==null)continue;
            t.x=toLogicalX(e.getX(i));
            t.y=toLogicalY(e.getY(i));
            if(t.role==ROLE_GRID)updateTarget(t.x,t.y);
        }
        refreshHeldButtons();
    }

    private void releasePointer(MotionEvent e,int index){
        int id=e.getPointerId(index);
        TouchPoint t=touches.get(id);
        if(t!=null&&t.role==ROLE_GRID){
            float x=toLogicalX(e.getX(index)),y=toLogicalY(e.getY(index));
            updateTarget(x,y);
            if(breakMode)breakBlock();
            else placeAtCell(targetCol,targetRow,true);
        }
        touches.remove(id);
        refreshHeldButtons();
    }

    private void refreshHeldButtons(){
        leftHeld=rightHeld=jumpHeld=false;
        for(int i=0;i<touches.size();i++){
            int role=touches.valueAt(i).role;
            if(role==ROLE_LEFT)leftHeld=true;
            if(role==ROLE_RIGHT)rightHeld=true;
            if(role==ROLE_JUMP)jumpHeld=true;
        }
    }

    private void updateTarget(float x,float y){
        int col=(int)((x-GRID_X)/CELL);
        int row=(int)((y-areaTop()+cameraY-GRID_Y)/CELL);
        targetCol=(col>=0&&col<COLS)?col:-1;
        targetRow=(row>=0&&row<ROWS)?row:-1;
    }

    @Override public boolean onTouchEvent(MotionEvent event){
        int action=event.getActionMasked();
        int index=event.getActionIndex();

        if(action==MotionEvent.ACTION_DOWN||action==MotionEvent.ACTION_POINTER_DOWN){
            addPointer(event,index);
            invalidate();
            return true;
        }
        if(action==MotionEvent.ACTION_MOVE){
            updatePointers(event);
            invalidate();
            return true;
        }
        if(action==MotionEvent.ACTION_POINTER_UP){
            releasePointer(event,index);
            invalidate();
            return true;
        }
        if(action==MotionEvent.ACTION_UP){
            releasePointer(event,index);
            touches.clear();
            refreshHeldButtons();
            invalidate();
            return true;
        }
        if(action==MotionEvent.ACTION_CANCEL){
            touches.clear();
            refreshHeldButtons();
            jumpRequested=false;
            invalidate();
            return true;
        }
        return true;
    }
}
