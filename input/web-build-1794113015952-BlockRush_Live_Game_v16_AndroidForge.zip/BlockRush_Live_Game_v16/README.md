# BlockRush Live Game v16 — AndroidForge Source

## Fixes in v16

### Block texture alignment
- Re-extracted all 48 block textures from the original supplied atlas using the correct per-sprite origins.
- Removed neighboring atlas bleed and preserved square pixel textures.
- Draws placed blocks inside each 43 x 43 cell with a 2-unit inset, keeping the map grid gutters visible.
- Placement preview uses the same cell inset as placed blocks.

### Player physics and gaps
- Ground support and landing now use the center of the player's feet, not the full sprite width.
- A block on the left and another on the right no longer form an invisible bridge across an empty middle cell.
- The player falls through a genuinely empty center column.

### Block placement and gravity
- Newly placed blocks fall down their selected column to the lowest supported empty cell.
- Stacks build from the bottom upward.
- The Block button finds the current column's top surface and places the next block above it.
- The player is snapped to the actual support surface before placing, preventing small physics offsets from blocking placement.
- Blocks cannot be placed through the player's body; a block directly beneath the feet is allowed and raises the player onto it.

### HUD and controls background
- Removed the opaque white panel behind the bottom controls.
- Replaced the white canvas background with the arena's sky-blue color, so transparent HUD and control artwork shows the scene background.
- Both top HUD and bottom controls now sit on the same sky-blue background.

### Font alignment
- Replaced guessed fixed-width font source positions with exact digit glyph rectangles from the supplied font atlas.
- Corrected slash and percent glyph crops.
- Repositioned and resized `0/40` and percentage counters to fit their HUD capsules.

### Retained from v15
- 10 columns x 40 rows (400 cells).
- Left counter counts fully filled rows.
- Right counter shows occupied cell percentage.
- Segmented progress bar follows occupied cells.
- Trophy and heart remain visual only; WIN and HP systems are not active.
- New arena, app icon, 48 block atlas, and supplied font atlas.

## Build
1. Extract `BlockRush_Live_Game_v16_AndroidForge.zip`.
2. Open `BlockRush_Live_Game_v16` in AndroidForge.
3. Build the `app` module.
4. Use JDK 17 and Android SDK Platform 35.
5. Application ID: `com.mcpakel.blockarea`.

Version: 1.6 (versionCode 16)

The Java source is syntax-checked against lightweight Android API stubs. A full AndroidForge APK build and on-device test have not been run in this environment.
