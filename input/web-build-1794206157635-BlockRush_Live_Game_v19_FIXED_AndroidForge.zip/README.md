# BlockRush Live Game v19 — AndroidForge Source

## v19 changes

- Enlarged the top HUD counters and adjusted their placement so the values fit inside the transparent panels.
- Added a win counter beside the trophy (`0/10` through `10/10`).
- The green placement preview now follows the player's current column and marks the exact cell where the next block will land.
- The Block button drops a tile smoothly from above the preview position; it stacks on the current column instead of falling to the bottom of an unrelated gap.
- The player is raised onto the new block only when standing on that column when the tile lands. Placement remains available while moving or jumping.
- Left/right touch pads can be dragged between directions without lifting the finger; separate simultaneous touches remain supported.
- Mining mode highlights the selected cell in red. Tapping the arena no longer places a block accidentally.
- When all 400 cells are filled, a center countdown runs from 15 to 4, then holds 3, 2, and 1 longer before clearing the area and incrementing the win counter.
- Gameplay controls are locked during the round countdown; pause remains available.
- Block material changes every three vertical layers, preserving the supplied texture sequence.

## Build

Import this ZIP with its contents extracted directly into the AndroidForge project workspace. The ZIP root contains `settings.gradle` and `build.gradle`. Build the `app` module with JDK 17 and Android SDK Platform 35.

Application ID: `com.mcpakel.blockarea`  
Version: 1.9 (versionCode 19)

The project structure and ZIP integrity were checked. A full Android APK build and on-device gameplay test could not be run in this environment because the Android SDK/Gradle build environment is not available here. Please run the build in AndroidForge and share the new build log if it reports an error.
