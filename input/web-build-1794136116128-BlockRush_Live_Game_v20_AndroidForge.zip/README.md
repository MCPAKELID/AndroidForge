# BlockRush Live Game v20 — AndroidForge Source

## v20 fixes

- Fixed arena rendering to preserve the exact authored 512x1935 map dimensions. The map no longer stretches vertically while the camera moves, so the 10x40 grid and block physics stay aligned.
- Repositioned and resized the HUD counters so 0/40, 0/10, and 0% fit their transparent panels more cleanly; the green fill stays inside the segmented bar.
- The green placement marker now shows the actual cell where the block will land. Pressing the block button drops a block smoothly from above into that marked cell.
- The placement target recalculates from nearby supported columns, keeping block placement predictable while the player climbs.
- Expanded the left/right touch zone into a drag joystick. Slide a held finger to change direction; movement and jump still support multi-touch.
- Expanded the camera's upper travel limit so the arena continues moving down as the player climbs instead of stopping too early.
- Kept transparent HUD/control artwork and the 15-to-1 plus slower 3-2-1 full-area countdown, board reset, and +1/10 win progression.

## Build
Import this ZIP as a project with its contents extracted directly into the AndroidForge workspace. The ZIP root contains `settings.gradle`, `build.gradle`, `gradle.properties`, and `app/`.

Build the `app` module with JDK 17 and Android SDK Platform 35.

Application ID: `com.mcpakel.blockarea`  
Version: 2.0 (versionCode 20)

Java source syntax was checked with Android API stubs. A full AndroidForge APK build and on-device gameplay test have not been run in this environment.
