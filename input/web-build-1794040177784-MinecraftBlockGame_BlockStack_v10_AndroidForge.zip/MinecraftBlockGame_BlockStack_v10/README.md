# Minecraft Block Game — Block Stacking v10

Android Native Java project for AndroidForge.

## What is implemented

### Arena
- Uses the latest supplied 864x1536 arena image as the background.
- Uses its matching 14-column x 28-row grid.
- The arena ends above the separate white control deck.
- Grid cell coordinates are aligned to the square cells in the supplied arena image.

### Block textures
- Uses all 28 block textures cropped from the supplied block sheet:
  - Grass, dirt, stone, cobblestone, diorite, sand, planks, granite, iron ore
  - Gold, redstone, lapis, diamond, emerald, quartz, obsidian, magma, TNT
  - Target, birch planks, bone, wood, bricks, stone bricks, mossy stone bricks, glass, ice, bedrock
- The top row of slot-frame graphics from the block sheet is not used.
- Only the white frame from that top row is used as the placement preview.
- The selected block appears as a translucent ghost inside the white placement frame.

### Gameplay
- Left / right: move the player.
- RUN: tap once to toggle sprint; tap again to return to walking.
- JUMP: jump and land on the top of placed blocks.
- BLOCK: place the selected block in the lowest empty cell of the player's column; blocks stack upward.
- PICKAXE: break the highest block in the player's current column.
- Tap one of the 8 hotbar slots to select a block.
- Swipe left/right over the hotbar to browse all 28 block textures (4 pages).

### Level and HUD
- Player label: PLAYER.
- Level increases every 3 layers of stack height.
- Layer progress is displayed toward the next level.
- Trophy counter tracks total blocks placed.
- Block percentage shows the percentage of arena cells currently occupied.
- No WIN indicator or win screen is included.

### Build
1. Extract this ZIP.
2. Open the `MinecraftBlockGame_BlockStack_v10` folder in AndroidForge.
3. Build the `app` module.
4. Project settings: JDK 17, Android SDK Platform 35, Android Gradle Plugin 8.6.1.

Package: `com.mcpakel.blockarea`

Note: Java source was syntax-checked against Android API stubs. A full Android/AndroidForge APK build was not available in this environment, so the final APK build still needs to be run in AndroidForge.
