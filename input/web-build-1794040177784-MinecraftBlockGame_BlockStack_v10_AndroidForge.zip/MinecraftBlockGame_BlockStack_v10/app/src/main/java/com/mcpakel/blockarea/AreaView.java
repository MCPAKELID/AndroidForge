package com.mcpakel.blockarea;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.RectF;
import android.graphics.Typeface;
import android.view.MotionEvent;
import android.view.View;
import java.io.IOException;

/**
 * Minecraft-style block stacking scene.
 * Grid, block tiles, placement ghost, inventory, level progression and touch controls
 * are rendered directly from the supplied pixel-art assets.
 */
public class AreaView extends View {
    private static final float DESIGN_W = 864f;
    private static final float CONTROL_H = 285f;
    private static final int COLS = 14;
    private static final int ROWS = 28;
    private static final int BLOCK_TYPES = 28;
    private static final int HOTBAR_SLOTS = 8;
    private static final int LAYERS_PER_LEVEL = 3;

    private final Paint paint = new Paint();
    private Bitmap arena, hudHeader, hudHotbar, placementFrame;
    private Bitmap leftImage, rightImage, runImage, pickaxeImage, blockImage, jumpImage;
    private final Bitmap[] blockTextures = new Bitmap[BLOCK_TYPES];
    private final Bitmap[][] sprites = new Bitmap[3][5];
    private final int[][] placedBlocks = new int[ROWS][COLS];

    private final RectF leftButton = new RectF();
    private final RectF rightButton = new RectF();
    private final RectF runButton = new RectF();
    private final RectF pickaxeButton = new RectF();
    private final RectF blockButton = new RectF();
    private final RectF jumpButton = new RectF();

    private float designHeight = 1536f;
    private float arenaBottom;
    private float gridLeft = 97f;
    private float gridTop;
    private float cellW = 48f;
    private float cellH;
    private float gridBottom;
    private float playerX;
    private float playerY;
    private float velocityY;
    private float animationClock;
    private long lastTime;

    private boolean leftDown, rightDown, jumpDown;
    private boolean leftVisual, rightVisual, runVisual, pickVisual, blockVisual, jumpVisual;
    private boolean sprintMode;
    private boolean facingRight = true;
    private boolean grounded = true;

    private int walkFrame, runFrame, jumpFrame;
    private int selectedBlock = 0;
    private int inventoryPage = 0;
    private int totalPlaced = 0;
    private int totalBroken = 0;
    private int maxLayersReached = 0;

    private float downX, downY;

    public AreaView(Context context) {
        super(context);
        setLayerType(View.LAYER_TYPE_SOFTWARE, null);

        arena = load(context, "area/arena_reference.jpg");
        hudHeader = load(context, "ui/hud_header.png");
        hudHotbar = load(context, "ui/hud_hotbar.png");
        placementFrame = load(context, "blocks/placement_frame.png");

        leftImage = load(context, "ui/control_left.png");
        rightImage = load(context, "ui/control_right.png");
        runImage = load(context, "ui/control_run.png");
        pickaxeImage = load(context, "ui/control_pickaxe.png");
        blockImage = load(context, "ui/control_block.png");
        jumpImage = load(context, "ui/control_jump.png");

        for (int i = 0; i < BLOCK_TYPES; i++) {
            blockTextures[i] = load(context, String.format(java.util.Locale.US,
                    "blocks/block_%02d.png", i));
        }

        String[] actions = {"walk", "run", "jump"};
        for (int a = 0; a < actions.length; a++) {
            for (int i = 0; i < 5; i++) {
                sprites[a][i] = load(context,
                        "character/" + actions[a] + "_" + i + ".png");
            }
        }

        for (int r = 0; r < ROWS; r++) {
            for (int c = 0; c < COLS; c++) placedBlocks[r][c] = -1;
        }
        playerX = gridLeft + (COLS / 2f) * cellW + cellW / 2f;
    }

    private Bitmap load(Context context, String path) {
        try {
            return BitmapFactory.decodeStream(context.getAssets().open(path));
        } catch (IOException ignored) {
            return null;
        }
    }

    private void setRect(RectF rect, float left, float top, float width, float height) {
        rect.set(left, top, left + width, top + height);
    }

    private void updateLayout() {
        if (getWidth() <= 0 || getHeight() <= 0) return;

        designHeight = getHeight() * DESIGN_W / getWidth();
        float controlHeight = Math.min(CONTROL_H, designHeight * 0.24f);
        arenaBottom = designHeight - controlHeight;

        // The background is scaled to the available arena height, excluding controls.
        float yScale = arenaBottom / 1536f;
        gridTop = 87f * yScale;
        cellH = 48f * yScale;
        gridBottom = gridTop + ROWS * cellH;

        if (playerX == 0f) playerX = gridLeft + (COLS / 2f) * cellW + cellW / 2f;
        if (grounded) playerY = supportYForColumn(playerColumn());

        float buttonSize = Math.min(120f, controlHeight * 0.46f);
        float buttonY = arenaBottom + (controlHeight - buttonSize) * 0.40f;
        setRect(leftButton, 8, buttonY, buttonSize, buttonSize);
        setRect(rightButton, 140, buttonY, buttonSize, buttonSize);
        setRect(runButton, 272, buttonY, buttonSize, buttonSize);
        setRect(pickaxeButton, 480, buttonY, buttonSize, buttonSize);
        setRect(blockButton, 612, buttonY, buttonSize, buttonSize);
        setRect(jumpButton, 744, buttonY, buttonSize, buttonSize);
    }

    private void drawBitmap(Canvas canvas, Bitmap bitmap, RectF destination) {
        if (bitmap == null) return;
        paint.clearShadowLayer();
        paint.setStyle(Paint.Style.FILL);
        paint.setAlpha(255);
        paint.setFilterBitmap(false);
        canvas.drawBitmap(bitmap, null, destination, paint);
    }

    private void drawBitmapAlpha(Canvas canvas, Bitmap bitmap, RectF destination, int alpha) {
        if (bitmap == null) return;
        paint.clearShadowLayer();
        paint.setStyle(Paint.Style.FILL);
        paint.setAlpha(alpha);
        paint.setFilterBitmap(false);
        canvas.drawBitmap(bitmap, null, destination, paint);
        paint.setAlpha(255);
    }

    @Override
    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        updateLayout();

        float scale = getWidth() / DESIGN_W;
        canvas.save();
        canvas.scale(scale, scale);
        canvas.drawColor(Color.WHITE);

        // Exact uploaded arena texture; the white control deck remains separate.
        if (arena != null) {
            drawBitmap(canvas, arena, new RectF(0, 0, DESIGN_W, arenaBottom));
        } else {
            paint.setColor(0xff1b1e24);
            canvas.drawRect(0, 0, DESIGN_W, arenaBottom, paint);
        }

        drawPlacedBlocks(canvas);
        drawPlacementPreview(canvas);
        drawPlayer(canvas);
        drawHud(canvas);
        drawControlDeck(canvas);

        canvas.restore();
        updatePlayer();
        postInvalidateDelayed(16);
    }

    private void drawPlacedBlocks(Canvas canvas) {
        for (int row = 0; row < ROWS; row++) {
            for (int col = 0; col < COLS; col++) {
                int id = placedBlocks[row][col];
                if (id < 0 || id >= BLOCK_TYPES) continue;
                Bitmap tile = blockTextures[id];
                if (tile == null) continue;

                float x = gridLeft + col * cellW;
                float y = gridTop + row * cellH;
                RectF dst = new RectF(x + 1.5f, y + 1.5f,
                        x + cellW - 1.5f, y + cellH - 1.5f);
                drawBitmap(canvas, tile, dst);
            }
        }
    }

    private int playerColumn() {
        int col = (int) ((playerX - gridLeft) / cellW);
        return Math.max(0, Math.min(COLS - 1, col));
    }

    // Returns the surface on which the player stands in the current column.
    private float supportYForColumn(int col) {
        for (int row = 0; row < ROWS; row++) {
            if (placedBlocks[row][col] >= 0) {
                return gridTop + row * cellH;
            }
        }
        return gridBottom;
    }

    // Find the lowest empty cell in this column, so new blocks stack upward.
    private int placementRow(int col) {
        for (int row = ROWS - 1; row >= 0; row--) {
            if (placedBlocks[row][col] < 0) return row;
        }
        return -1;
    }

    private void drawPlacementPreview(Canvas canvas) {
        int col = playerColumn();
        int row = placementRow(col);
        if (row < 0) return;

        float x = gridLeft + col * cellW;
        float y = gridTop + row * cellH;
        RectF cell = new RectF(x, y, x + cellW, y + cellH);

        Bitmap selected = blockTextures[selectedBlock];
        drawBitmapAlpha(canvas, selected, new RectF(
                x + 2f, y + 2f, x + cellW - 2f, y + cellH - 2f), 105);
        // Only the white frame from the top row of the supplied sheet is used as ghost.
        drawBitmap(canvas, placementFrame, cell);
    }

    private void drawPlayer(Canvas canvas) {
        int action = !grounded ? 2 :
                ((leftDown || rightDown) ? (sprintMode ? 1 : 0) : 0);
        int frame = action == 2 ? jumpFrame : (action == 1 ? runFrame : walkFrame);
        Bitmap sprite = sprites[action][frame];
        if (sprite == null) return;

        float height = 112f;
        float width = height * sprite.getWidth() / sprite.getHeight();
        RectF dst = new RectF(playerX - width / 2f, playerY - height,
                playerX + width / 2f, playerY);
        canvas.save();
        if (!facingRight) canvas.scale(-1f, 1f, playerX, 0f);
        drawBitmap(canvas, sprite, dst);
        canvas.restore();
    }

    private void drawHud(Canvas canvas) {
        float headerHeight = 0f;
        if (hudHeader != null) {
            headerHeight = DESIGN_W * hudHeader.getHeight() / hudHeader.getWidth();
            drawBitmap(canvas, hudHeader, new RectF(0, 0, DESIGN_W, headerHeight));
        }

        float hotbarTop = headerHeight + 5f;
        float hotbarHeight = 0f;
        if (hudHotbar != null) {
            hotbarHeight = DESIGN_W * hudHotbar.getHeight() / hudHotbar.getWidth();
            drawBitmap(canvas, hudHotbar,
                    new RectF(0, hotbarTop, DESIGN_W, hotbarTop + hotbarHeight));
            drawInventoryIcons(canvas, hotbarTop, hotbarHeight);
        }

        // Dynamic level and counters are drawn over the blank/zero fields in the HUD.
        paint.setTypeface(Typeface.create("sans-serif", Typeface.BOLD));
        paint.setTextAlign(Paint.Align.CENTER);
        paint.setTextSize(15f);
        paint.setColor(Color.WHITE);
        paint.setShadowLayer(3f, 1f, 2f, Color.BLACK);

        int level = 1 + (maxLayersReached / LAYERS_PER_LEVEL);
        int progress = maxLayersReached % LAYERS_PER_LEVEL;
        canvas.drawText("PLAYER", 222f, 48f, paint);
        paint.setTextSize(21f);
        canvas.drawText("LEVEL " + level, 222f, 75f, paint);
        paint.setTextSize(10f);
        canvas.drawText(progress + "/" + LAYERS_PER_LEVEL + " LAYERS",
                222f, 91f, paint);

        paint.setTextSize(23f);
        canvas.drawText(String.valueOf(totalPlaced), 466f, 83f, paint);
        int fillPercent = Math.round(countBlocksOnMap() * 100f / (COLS * ROWS));
        canvas.drawText(fillPercent + "%", 694f, 83f, paint);
        paint.clearShadowLayer();

        if (hotbarHeight > 0f) {
            paint.setTextSize(11f);
            paint.setTextAlign(Paint.Align.RIGHT);
            paint.setColor(Color.WHITE);
            paint.setShadowLayer(2f, 1f, 1f, Color.BLACK);
            canvas.drawText((inventoryPage + 1) + "/4", 850f,
                    hotbarTop + hotbarHeight - 3f, paint);
            paint.clearShadowLayer();
        }
    }

    private void drawInventoryIcons(Canvas canvas, float top, float height) {
        float[] centers = {55.5f, 159.2f, 262.5f, 366f, 469.5f, 573f, 676.5f, 780f};
        float iconSize = Math.min(51f, height * 0.40f);
        int selectedSlot = selectedBlock % HOTBAR_SLOTS;
        float selectedX = centers[selectedSlot];
        float slotCenterY = top + height * 0.50f;

        // Highlight follows the selected inventory slot.
        paint.setStyle(Paint.Style.STROKE);
        paint.setStrokeWidth(3f);
        paint.setColor(0xffffd84b);
        canvas.drawRoundRect(new RectF(selectedX - 38f, slotCenterY - 53f,
                selectedX + 38f, slotCenterY + 53f), 9f, 9f, paint);
        paint.setStyle(Paint.Style.FILL);

        for (int slot = 0; slot < HOTBAR_SLOTS; slot++) {
            int blockId = inventoryPage * HOTBAR_SLOTS + slot;
            if (blockId >= BLOCK_TYPES) continue;
            Bitmap tile = blockTextures[blockId];
            float cx = centers[slot];
            RectF dst = new RectF(cx - iconSize / 2f, slotCenterY - iconSize / 2f,
                    cx + iconSize / 2f, slotCenterY + iconSize / 2f);
            drawBitmap(canvas, tile, dst);
        }
    }

    private void drawControlDeck(Canvas canvas) {
        paint.setColor(Color.WHITE);
        canvas.drawRect(0, arenaBottom, DESIGN_W, designHeight, paint);
        drawActionButton(canvas, leftImage, leftButton, leftVisual);
        drawActionButton(canvas, rightImage, rightButton, rightVisual);
        drawActionButton(canvas, runImage, runButton, runVisual || sprintMode);
        drawActionButton(canvas, pickaxeImage, pickaxeButton, pickVisual);
        drawActionButton(canvas, blockImage, blockButton, blockVisual);
        drawActionButton(canvas, jumpImage, jumpButton, jumpVisual);
    }

    private void drawActionButton(Canvas canvas, Bitmap bitmap, RectF rect, boolean pressed) {
        if (bitmap == null) return;
        float factor = pressed ? 0.91f : 1f;
        float w = rect.width() * factor;
        float h = rect.height() * factor;
        float cx = rect.centerX();
        float cy = rect.centerY();
        RectF dst = new RectF(cx - w / 2f, cy - h / 2f,
                cx + w / 2f, cy + h / 2f);

        if (pressed) {
            paint.setStyle(Paint.Style.FILL);
            paint.setColor(0x5536cfff);
            paint.setShadowLayer(12f, 0f, 0f, 0xff20cfff);
            canvas.drawRoundRect(dst, 24f, 24f, paint);
            paint.clearShadowLayer();
        }
        drawBitmap(canvas, bitmap, dst);
    }

    private void placeBlock() {
        int col = playerColumn();
        int row = placementRow(col);
        if (row < 0) return;
        placedBlocks[row][col] = selectedBlock;
        totalPlaced++;
        updateMaxLayers();
        playerY = supportYForColumn(col);
        grounded = true;
        velocityY = 0f;
    }

    private void breakBlock() {
        int col = playerColumn();
        for (int row = 0; row < ROWS; row++) {
            if (placedBlocks[row][col] >= 0) {
                placedBlocks[row][col] = -1;
                totalBroken++;
                updateMaxLayers();
                playerY = supportYForColumn(col);
                grounded = true;
                velocityY = 0f;
                return;
            }
        }
    }

    private void updateMaxLayers() {
        int max = 0;
        for (int col = 0; col < COLS; col++) {
            int height = 0;
            for (int row = 0; row < ROWS; row++) {
                if (placedBlocks[row][col] >= 0) height++;
            }
            if (height > max) max = height;
        }
        maxLayersReached = Math.max(maxLayersReached, max);
    }

    private int countBlocksOnMap() {
        int count = 0;
        for (int row = 0; row < ROWS; row++) {
            for (int col = 0; col < COLS; col++) {
                if (placedBlocks[row][col] >= 0) count++;
            }
        }
        return count;
    }

    private void updatePlayer() {
        long now = System.nanoTime();
        if (lastTime == 0L) lastTime = now;
        float dt = Math.min((now - lastTime) / 1_000_000_000f, 0.04f);
        lastTime = now;

        float speed = sprintMode ? 270f : 155f;
        if (leftDown && !rightDown) {
            playerX -= speed * dt;
            facingRight = false;
        } else if (rightDown && !leftDown) {
            playerX += speed * dt;
            facingRight = true;
        }

        playerX = Math.max(gridLeft + 10f,
                Math.min(gridLeft + COLS * cellW - 10f, playerX));

        float supportY = supportYForColumn(playerColumn());
        if (grounded) playerY = supportY;

        if (jumpDown && grounded) {
            velocityY = -490f;
            grounded = false;
            jumpFrame = 0;
            animationClock = 0f;
        }

        if (!grounded) {
            velocityY += 1120f * dt;
            playerY += velocityY * dt;
            if (velocityY > 0f && playerY >= supportY) {
                playerY = supportY;
                velocityY = 0f;
                grounded = true;
            }
        }

        animationClock += dt;
        if (!grounded) {
            if (animationClock >= 0.12f) {
                jumpFrame = (jumpFrame + 1) % 5;
                animationClock = 0f;
            }
        } else if (leftDown || rightDown) {
            float delay = sprintMode ? 0.075f : 0.13f;
            if (animationClock >= delay) {
                if (sprintMode) runFrame = (runFrame + 1) % 5;
                else walkFrame = (walkFrame + 1) % 5;
                animationClock = 0f;
            }
        } else {
            walkFrame = 0;
            animationClock = 0f;
        }
    }

    private float touchX(float x) {
        return x * DESIGN_W / Math.max(1f, getWidth());
    }

    private float touchY(float y) {
        return y * DESIGN_W / Math.max(1f, getWidth());
    }

    @Override
    public boolean onTouchEvent(MotionEvent event) {
        int action = event.getActionMasked();
        int index = event.getActionIndex();

        if (action == MotionEvent.ACTION_DOWN) {
            downX = touchX(event.getX(index));
            downY = touchY(event.getY(index));
        }

        if (action == MotionEvent.ACTION_DOWN || action == MotionEvent.ACTION_POINTER_DOWN) {
            float x = touchX(event.getX(index));
            float y = touchY(event.getY(index));

            if (runButton.contains(x, y)) {
                sprintMode = !sprintMode;
                runVisual = true;
            } else if (pickaxeButton.contains(x, y)) {
                pickVisual = true;
                breakBlock();
            } else if (blockButton.contains(x, y)) {
                blockVisual = true;
                placeBlock();
            }
        }

        if (action == MotionEvent.ACTION_UP || action == MotionEvent.ACTION_CANCEL) {
            float upX = touchX(event.getX(index));
            float upY = touchY(event.getY(index));
            float deltaX = upX - downX;

            // Swipe across the hotbar to browse all 28 block textures in pages of 8.
            float hotbarTop = (hudHeader == null ? 0f :
                    DESIGN_W * hudHeader.getHeight() / hudHeader.getWidth()) + 5f;
            float hotbarBottom = hotbarTop + (hudHotbar == null ? 0f :
                    DESIGN_W * hudHotbar.getHeight() / hudHotbar.getWidth());
            if (Math.abs(deltaX) > 42f && downY >= hotbarTop && downY <= hotbarBottom) {
                int pages = (BLOCK_TYPES + HOTBAR_SLOTS - 1) / HOTBAR_SLOTS;
                inventoryPage = Math.max(0, Math.min(pages - 1,
                        inventoryPage + (deltaX < 0f ? 1 : -1)));
                selectedBlock = inventoryPage * HOTBAR_SLOTS;
            } else if (downY >= hotbarTop && downY <= hotbarBottom) {
                float[] centers = {55.5f, 159.2f, 262.5f, 366f, 469.5f, 573f, 676.5f, 780f};
                int slot = 0;
                float best = Float.MAX_VALUE;
                for (int i = 0; i < centers.length; i++) {
                    float d = Math.abs(upX - centers[i]);
                    if (d < best) { best = d; slot = i; }
                }
                int id = inventoryPage * HOTBAR_SLOTS + slot;
                if (id < BLOCK_TYPES) selectedBlock = id;
            }

            leftDown = rightDown = jumpDown = false;
            leftVisual = rightVisual = runVisual = false;
            pickVisual = blockVisual = jumpVisual = false;
            return true;
        }

        leftDown = rightDown = jumpDown = false;
        leftVisual = rightVisual = jumpVisual = false;

        for (int i = 0; i < event.getPointerCount(); i++) {
            if (action == MotionEvent.ACTION_POINTER_UP && i == index) continue;
            float x = touchX(event.getX(i));
            float y = touchY(event.getY(i));
            if (leftButton.contains(x, y)) leftDown = leftVisual = true;
            if (rightButton.contains(x, y)) rightDown = rightVisual = true;
            if (jumpButton.contains(x, y)) jumpDown = jumpVisual = true;
        }
        return true;
    }
}
