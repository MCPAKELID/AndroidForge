# Minecraft Block Game - Fullscreen Area + Player + HUD Base

Android Native Java project for AndroidForge.

## Changes in this version
- Uses the supplied 864 x 1536 arena image as the full-screen background.
- Logical canvas is now 864 x 1536 to match the arena artwork and remove the previous unused blank strip.
- The arena is drawn full-screen; the HUD overlays the upper area.
- Player starts with feet aligned to the lower edge of the empty grid (ground Y = 1474 in the 864 x 1536 design).
- Grid geometry is aligned to the supplied image: 19 columns x 36 rows.
- Lower movement controls are drawn as a translucent overlay at the bottom of the screen.
- Top HUD frames remain, but username, level text, block percentage and win/count values are intentionally blank for now.
- Seven empty inventory slot frames are shown; no block icons are populated yet.
- Five heart icons remain. No vertical red side meter.
- Character uses the supplied 15 transparent sprite frames (walk/run/jump).
- RUN remains a toggle: tap once to sprint, tap again to return to walking.
- Existing block placement foundation and block sound assets remain in the project, but no HUD score/win information is displayed.

## Build in AndroidForge
1. Extract this ZIP.
2. Open the `MinecraftBlockGame_AreaPlayer` folder as an Android Gradle project.
3. Use JDK 17 and Android SDK Platform 35.
4. Build the `app` module.

Application ID: `com.mcpakel.blockarea`
No WebView and no external libraries.
