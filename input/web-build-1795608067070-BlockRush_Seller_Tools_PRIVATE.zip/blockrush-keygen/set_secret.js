#!/usr/bin/env node
/*
 * Mengganti rahasia premium di game DAN di secret.txt sekaligus.
 * Pakai: node set_secret.js RAHASIA-BARU /jalur/ke/app/src/main/java/com/mcpakel/blockarea/Premium.java
 * Rahasia minimal 16 karakter (huruf/angka). Setelah diganti, build ulang APK-nya.
 * Kunci yang dibuat dengan rahasia lama tidak berlaku lagi.
 */
'use strict';
const fs = require('fs');
const path = require('path');
const [secret, file] = process.argv.slice(2);
if (!secret || !file || secret.length < 16 || !/^[A-Za-z0-9]+$/.test(secret)) {
  console.error('Pakai: node set_secret.js RAHASIA-BARU(min 16 huruf/angka) /jalur/Premium.java');
  process.exit(1);
}
const src = fs.readFileSync(file, 'utf8');
const arr = [...secret].map((c, i) => c.charCodeAt(0) ^ 0x5A ^ ((i * 7) & 255));
const re = /(\/\/ SECRET-BEGIN\s*\n\s*private static final int\[\] S = \{)[^}]*(\};\s*\n\s*\/\/ SECRET-END)/;
if (!re.test(src)) { console.error('Penanda SECRET-BEGIN/END tidak ketemu di ' + file); process.exit(1); }
fs.writeFileSync(file, src.replace(re, '$1' + arr.join(', ') + '$2'));
fs.writeFileSync(path.join(__dirname, 'secret.txt'), secret + '\n');
console.log('Rahasia diganti di Premium.java dan secret.txt. Build ulang APK sekarang.');
