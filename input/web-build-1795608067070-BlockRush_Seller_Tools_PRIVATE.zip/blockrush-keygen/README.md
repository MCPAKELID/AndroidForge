# Alat penjual Block Rush (PRIBADI)

Jangan masukkan folder ini ke zip yang dikirim ke pembeli. `secret.txt` adalah rahasia pembuat kunci.

## Membuat kunci premium untuk pembeli
1. Pembeli buka game -> tombol **PREMIUM** di menu -> **KIRIM ID** (atau **SALIN ID**) dan mengirim ID-nya ke kamu.
2. Kamu jalankan: `node keygen.js 3F2A-91CC-07DE "Budi - WA 0812"`
3. Kirim kunci `XXXX-XXXX-XXXX-XXXX` ke pembeli. Di game: PREMIUM -> **MASUKKAN KUNCI**.
Kunci hanya berlaku di HP pemilik ID itu. Setiap kunci yang dibuat dicatat di `log_kunci.csv`.

## Ganti rahasia sebelum jualan (wajib)
`node set_secret.js RAHASIABARUKAMU123 /jalur/ke/src/app/src/main/java/com/mcpakel/blockarea/Premium.java`
lalu build ulang APK. Jangan pernah membagikan secret.txt. Kalau rahasia bocor, ganti lagi dan buat kunci baru.

## Notif update
1. Taruh file JSON seperti `update.json.contoh` di tempat yang bisa dibuka lewat internet (GitHub raw, Gist, hosting sendiri).
2. Isi alamatnya di `AppConfig.UPDATE_URL` pada kode game, lalu build.
3. Setiap kali kamu merilis versi baru: naikkan `versionCode` di JSON (harus lebih besar dari versionCode APK terpasang), isi `url` ke file APK baru dan `notes`. HP yang membuka game akan menampilkan banner UPDATE di menu.
4. `"force": true` membuat banner tidak bisa ditutup.

## Catatan jujur
Kunci ini cukup untuk jualan skala kecil. Siapa pun yang membongkar APK dengan alat khusus bisa mengakalinya (itu berlaku untuk semua pengecekan di dalam aplikasi tanpa server). Untuk perlindungan lebih kuat perlu cek ke server, dan itu butuh hosting.
