#!/usr/bin/env node
/*
 * Block Rush Live - pembuat kunci premium (PRIBADI, jangan dibagikan ke pembeli).
 * Hak Cipta (c) 2026 MCPAKEL.
 *
 * Pakai:  node keygen.js ID-PERANGKAT [catatan]
 * Contoh: node keygen.js 3F2A-91CC-07DE "Budi - WA 0812..."
 * Rahasia dibaca dari secret.txt (harus sama dengan yang ada di game, lihat set_secret.js).
 */
'use strict';
const crypto = require('crypto');
const fs = require('fs');
const path = require('path');

const B32 = '0123456789ABCDEFGHJKMNPQRSTVWXYZ';
function secret() {
  if (process.env.BR_SECRET) return process.env.BR_SECRET.trim();
  return fs.readFileSync(path.join(__dirname, 'secret.txt'), 'utf8').trim();
}
function keyFor(deviceId) {
  const raw = String(deviceId).toUpperCase().replace(/[^0-9A-Z]/g, '');
  const d = crypto.createHmac('sha256', secret()).update('BR1|' + raw).digest();
  let out = '', buf = 0, bits = 0;
  for (let i = 0; i < 10; i++) {
    buf = (buf << 8) | d[i]; bits += 8;
    while (bits >= 5) { out += B32[(buf >> (bits - 5)) & 31]; bits -= 5; buf &= (1 << bits) - 1; }
  }
  return out.match(/.{4}/g).join('-');
}
module.exports = { keyFor };

if (require.main === module) {
  const id = process.argv[2];
  if (!id || !/^[0-9A-Fa-f]{4}-?[0-9A-Fa-f]{4}-?[0-9A-Fa-f]{4}$/.test(id)) {
    console.error('Pakai: node keygen.js ID-PERANGKAT [catatan]\nID dari layar PREMIUM di game, bentuknya XXXX-XXXX-XXXX.');
    process.exit(1);
  }
  const key = keyFor(id);
  console.log('\nID perangkat : ' + id.toUpperCase());
  console.log('Kunci premium: ' + key + '\n');
  const line = [new Date().toISOString(), id.toUpperCase(), key, (process.argv[3] || '').replace(/[",\n]/g, ' ')].join(',') + '\n';
  fs.appendFileSync(path.join(__dirname, 'log_kunci.csv'), line);
}
