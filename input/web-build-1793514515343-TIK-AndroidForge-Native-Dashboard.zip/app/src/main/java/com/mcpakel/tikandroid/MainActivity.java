package com.mcpakel.tikandroid;
import android.app.*;
import android.os.*;
import android.graphics.Color;
import android.view.*;
import android.widget.*;
import android.content.*;
import android.content.SharedPreferences;
import android.text.InputType;
import org.json.JSONObject;
import java.net.*;
import java.io.*;
import java.util.concurrent.*;
import javax.net.ssl.*;\nimport org.java_websocket.client.WebSocketClient;\nimport org.java_websocket.handshake.ServerHandshake;
import java.util.*;

public class MainActivity extends Activity {
  LinearLayout root, content; TextView wsStatus, apiStatus, logView;
  EditText wsInput, apiInput, userInput;
  SharedPreferences prefs; ExecutorService executor=Executors.newSingleThreadExecutor();
  SocketClient socket;
  int bg=Color.rgb(11,16,32), card=Color.rgb(18,26,48), fg=Color.rgb(237,242,255), muted=Color.rgb(155,169,196), blue=Color.rgb(52,120,246);
  public void onCreate(Bundle b){super.onCreate(b);prefs=getSharedPreferences("tik",0);buildUI();}
  TextView text(String s,int size,boolean bold){TextView t=new TextView(this);t.setText(s);t.setTextColor(fg);t.setTextSize(size);if(bold)t.setTypeface(null,1);return t;}
  GradientDrawable shape(int color){GradientDrawable d=new GradientDrawable();d.setColor(color);d.setCornerRadius(24);return d;}
  void buildUI(){
    ScrollView scroll=new ScrollView(this);root=new LinearLayout(this);root.setOrientation(1);root.setPadding(22,24,22,30);root.setBackgroundColor(bg);scroll.addView(root);setContentView(scroll);
    TextView title=text("TIK MCPAKEL",25,true);root.addView(title);TextView sub=text("TikTok LIVE • Minecraft WebSocket",13,false);sub.setTextColor(muted);root.addView(sub);
    addCard("STATUS KONEKSI"); wsStatus=text("● WebSocket: belum terhubung",15,true);root.addView(wsStatus);apiStatus=text("● API: belum diperiksa",15,true);root.addView(apiStatus);
    addCard("KONEKSI MINECRAFT");
    wsInput=field("Alamat WebSocket (ws:// atau wss://)",prefs.getString("ws",""));root.addView(wsInput);
    userInput=field("Username TikTok",prefs.getString("user",""));root.addView(userInput);
    Button save=button("SIMPAN PENGATURAN",blue);root.addView(save);save.setOnClickListener(v->{prefs.edit().putString("ws",wsInput.getText().toString()).putString("user",userInput.getText().toString()).apply();log("Pengaturan disimpan");});
    Button connect=button("HUBUNGKAN WEBSOCKET",blue);root.addView(connect);connect.setOnClickListener(v->connectWS());
    addCard("DASHBOARD LIVE");TextView note=text("Statistik LIVE dan event akan tampil setelah backend TikTok terintegrasi dan mengirim data ke aplikasi.",13,false);note.setTextColor(muted);root.addView(note);
    addCard("LOG AKTIVITAS");logView=text("Aplikasi siap. Isi alamat WebSocket Minecraft.",12,false);root.addView(logView);
  }
  void addCard(String label){TextView h=text(label,13,true);h.setTextColor(0xff9fb8e8);h.setPadding(0,26,0,10);root.addView(h);}
  EditText field(String hint,String value){EditText e=new EditText(this);e.setSingleLine(true);e.setText(value);e.setHint(hint);e.setHintTextColor(muted);e.setTextColor(fg);e.setPadding(14,10,14,10);e.setBackground(shape(card));LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-1,-2);lp.bottomMargin=10;e.setLayoutParams(lp);return e;}
  Button button(String s,int c){Button b=new Button(this);b.setText(s);b.setTextColor(Color.WHITE);b.setBackground(shape(c));return b;}
  void log(String s){runOnUiThread(()->{logView.setText(new java.text.SimpleDateFormat("HH:mm:ss",Locale.getDefault()).format(new Date())+"  "+s+"\n"+logView.getText());});}
  void connectWS(){String u=wsInput.getText().toString().trim();if(u.isEmpty()){log("Isi alamat WebSocket dahulu");return;}try{if(socket!=null)socket.close();socket=new SocketClient(new URI(u));socket.connect();}catch(Exception e){log("Alamat WebSocket tidak valid: "+e.getMessage());}}
  class WebSocketClient extends WebSocket {
    WebSocketClient(URI u){super(u);}
    public void onOpen(ServerHandshake h){runOnUiThread(()->wsStatus.setText("● WebSocket: terhubung"));log("WebSocket terhubung");}
    public void onMessage(String m){log("Pesan: "+m);}
    public void onClose(int c,String r,boolean remote){runOnUiThread(()->wsStatus.setText("● WebSocket: terputus"));log("WebSocket terputus");}
    public void onError(Exception e){log("WebSocket error: "+e.getMessage());}
  }
}
