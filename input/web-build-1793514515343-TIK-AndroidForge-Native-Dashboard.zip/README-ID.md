# TIK MCPAKEL Android — paket AndroidForge

## Perubahan sesuai permintaan
- WhatsApp bot dihapus: tidak ada `whatsapp.js`, Baileys, QR WhatsApp, atau sesi WhatsApp.
- Dashboard HTML/WebView dihapus.
- Dashboard aplikasi dibuat native Android menggunakan Java Views.
- Ada kolom username TikTok, endpoint WebSocket, tombol simpan dan hubungkan, status, serta log.
- Source Node.js TikTok LIVE + Minecraft tetap disertakan di `backend-reference/` sebagai sumber integrasi.

## Build
Proyek ini menggunakan Android Gradle Plugin 8.7.3, compileSdk 35, dan Java-WebSocket 1.5.6.
Unggah ZIP ini ke AndroidForge, pilih build Android/Debug, lalu unduh APK dari artifact build.

## Batasan fungsi saat ini — baca sebelum build
Ini adalah **native dashboard + WebSocket client**, bukan port penuh runtime Node.js ke Android. Dashboard tidak memakai HTML. Namun koneksi TikTok LIVE belum dijalankan langsung oleh APK; source Node.js masih berupa backend reference dan belum di-embed sebagai runtime Android. WebSocket client dapat tersambung ke endpoint yang kompatibel, tetapi belum mengubah event TikTok menjadi perintah Minecraft dari dalam APK.

Agar TikTok LIVE benar-benar berjalan lokal di Android, tahap terpisah masih diperlukan: integrasi runtime Node.js Android versi >=20 atau implementasi ulang konektor, lifecycle foreground service, penyimpanan konfigurasi/event, dan pengujian ARM64. Jangan menganggap semua fitur telah aktif hanya karena APK berhasil dibangun.

## Keamanan
Tidak ada file `.env`, token, atau sesi WhatsApp yang sengaja disertakan. Jangan menambahkan kredensial ke repository publik.
