TIK-FIX40-GIFT-COUNT-DEDUPE

Based on FIX37's proven event deduplication and reconnect behavior.
Count parsing is conservative: canonical repeatCount wins; generic count/amount
cannot inflate a gift when canonical count is present. comboCount/streakCount
are only used to recover a final combo total when repeatEnd=true and the normal
count is 1 or missing. Gift event deduplication logic remains unchanged from FIX37.

Validation: node --check main.js passed. TikTok Live runtime test not performed.
