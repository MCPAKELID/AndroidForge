Historical FIX37 notes; see README-FIX40.txt for this package's actual changes.
