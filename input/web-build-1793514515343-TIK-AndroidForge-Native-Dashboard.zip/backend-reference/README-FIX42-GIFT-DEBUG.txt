TIK-FIX42-GIFT-DEBUG-RAW

Debug diagnostik untuk gift count. Berdasarkan TIK-FIX41; mekanisme deduplikasi dan penghantaran event dikekalkan, hanya ditambah log diagnostik.

Aktifkan environment variable TIKTOMC_DEBUG=true pada panel hosting, lalu restart Node.js.

Cari log:
- [Gift Raw] : payload mentah dan meta hasil parser sebelum filter combo/dedupe.
- [Gift Skipped] : alasan event tidak diteruskan (combo-not-final, event-id-duplicate, group-id-duplicate, fingerprint-duplicate).
- [Gift Accepted] : jumlah yang diteruskan ke Minecraft.
- [GIFT] ... xN : jumlah yang diproses pada bridge WebSocket.

Kirim satu combo 3 gift dan salin baris Gift Raw, Gift Skipped, Gift Accepted, dan [GIFT]. Sensor token/API key jika muncul. Payload dibatasi 6000 karakter per baris.


FIX42A: DEBUG SEKARANG AKTIF OTOMATIS. Tidak perlu menambahkan TIKTOMC_DEBUG di panel. Saat startup harus muncul [DEBUG] TIKTOMC gift debug AKTIF otomatis. Event gift akan mencetak [Gift Raw], [Gift Skipped], dan [Gift Accepted].
