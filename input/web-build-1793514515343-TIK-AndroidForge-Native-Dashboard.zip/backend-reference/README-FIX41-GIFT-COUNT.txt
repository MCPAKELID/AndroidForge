TIK-FIX41-GIFT-COUNT-COMBO

Perbaikan:
- Mempertahankan deduplikasi FIX40 berdasarkan source event ID dan gift group ID.
- Membaca field repeatCount/repeat_count serta comboCount/streakCount yang berada di payload bertingkat atau JSON-string.
- Jika connector tidak mengirim repeatEnd untuk gift combo, update dengan groupId dikoaleskan selama 350 ms dan hanya nilai kumulatif tertinggi yang diteruskan sekali.
- Event combo yang memiliki repeatEnd tetap hanya diproses pada event final.
- Payload yang diteruskan ke CubicCraft tetap mengisi count, repeatCount, rawRepeatCount, dan totalCoin secara konsisten.

Debug:
Set TIKTOMC_DEBUG=true untuk melihat log [Gift Accepted] termasuk count, group, dan event ID.

Catatan:
Pengujian yang dilakukan: node --check main.js. Pengujian langsung TikTok Live belum dilakukan.
