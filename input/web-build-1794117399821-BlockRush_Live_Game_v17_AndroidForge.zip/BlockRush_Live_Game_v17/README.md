# BlockRush Live Game v17 — AndroidForge Source

## v17 updates

### Player movement and collision
- Player visual and collision height is now exactly two grid blocks.
- Player collision width is independent from sprite height.
- Horizontal movement uses a short binary-search collision slide to stop at block faces instead of sticking inside them.
- Added overlap recovery for tiny edge collisions and blocks placed very close to the player.
- Block placement checks the real player width, including adjacent columns.

### Blocks and textures
- Replaced all 48 block PNGs with the exact supplied `custom_block_textures_48.zip` assets.
- All 48 block textures are retained in `app/src/main/assets/blocks/`.
- Uses a different texture for each vertical layer, rather than repeating only eight textures.
- Placed blocks render edge-to-edge with no artificial inset/gutters.
- Newly placed blocks have a short scale/pop placement animation.
- Blocks continue to fall to the lowest supported cell in their column; floating placement is not allowed.

### Camera and arena
- Arena viewport starts slightly lower to leave a dedicated pause control below the top HUD.
- Camera can scroll a little above the arena's top boundary, keeping the player's head visible during high jumps.

### Main menu and pause
- Added the supplied full-screen pixel-art background.
- Added the supplied MAIN, PENGATURAN, PAUS, LANJUT, ULANGI, MENU, KELUAR, and KEMBALI button artwork.
- Added a working main menu, settings screen, in-game pause control, pause overlay, resume, restart, return-to-menu, and exit actions.
- Settings screen has sound/music toggle states. Audio playback is not yet implemented.

### HUD
- Slightly reduced counter glyph size and adjusted alignment in the top HUD.

## Build
1. Extract `BlockRush_Live_Game_v17_AndroidForge.zip`.
2. Open `BlockRush_Live_Game_v17` in AndroidForge.
3. Build the `app` module.
4. Use JDK 17 and Android SDK Platform 35.
5. Application ID: `com.mcpakel.blockarea`.

Version: 1.7 (versionCode 17)

Java source checks and ZIP integrity checks are performed before delivery. A full AndroidForge APK build and on-device test have not been run in this environment.
