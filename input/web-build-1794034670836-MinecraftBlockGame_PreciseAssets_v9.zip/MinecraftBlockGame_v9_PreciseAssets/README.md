# Minecraft Block Game - Precise Assets v9

This version fixes the sprite-sheet cropping from v8.

## Asset corrections
- Re-cropped the supplied 1774x887 source image using the actual bounds of each individual graphic.
- Removed only the connected black outer background, preserving dark pixels inside the pixel-art frames/icons.
- Header HUD, hotbar, and all six control buttons are separate tightly cropped transparent PNGs.
- No adjacent icon fragments or large unused black margins are included in each button image.
- Original supplied artwork is preserved; no redrawn or AI-substituted icons.

## Controls
- Six enlarged controls: left, right, run, pickaxe, block, jump.
- Press animation: 90% scale while pressed plus cyan glow.
- Run is tap-to-toggle sprint.
- Pickaxe and block buttons are visual placeholders for the later block interaction stage.

## Scene
- Arena remains above a separate white control deck.
- Character feet align to the bottom inner floor.
- No hearts, red side meter, or generated name/level/progress/win labels.

Build the project in AndroidForge using JDK 17 and Android SDK 35.
