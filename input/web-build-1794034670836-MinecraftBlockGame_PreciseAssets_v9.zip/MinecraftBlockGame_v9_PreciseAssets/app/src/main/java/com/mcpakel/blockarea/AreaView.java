package com.mcpakel.blockarea;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.RectF;
import android.view.MotionEvent;
import android.view.View;
import java.io.IOException;

/** Responsive arena with the user's latest HUD/buttons and tactile press animation. */
public class AreaView extends View {
    private static final float DESIGN_W = 864f;
    private static final float CONTROL_H = 285f;

    private final Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private Bitmap arena, hudHeader, hudHotbar;
    private Bitmap leftImage, rightImage, runImage, pickaxeImage, blockImage, jumpImage;
    private final Bitmap[][] sprites = new Bitmap[3][5];

    private final RectF leftButton = new RectF();
    private final RectF rightButton = new RectF();
    private final RectF runButton = new RectF();
    private final RectF pickaxeButton = new RectF();
    private final RectF blockButton = new RectF();
    private final RectF jumpButton = new RectF();

    private float designHeight = 1536f;
    private float arenaBottom = 1251f;
    private float floorY = 1200f;
    private float playerX = 432f, playerY = floorY, velocityY;
    private boolean leftDown, rightDown, jumpDown;
    private boolean runHeld, pickHeld, blockHeld, leftVisual, rightVisual, jumpVisual;
    private boolean sprintMode, facingRight = true, grounded = true;
    private int walkFrame, runFrame, jumpFrame;
    private float animationClock;
    private long lastTime;

    public AreaView(Context context) {
        super(context);
        setLayerType(View.LAYER_TYPE_SOFTWARE, null);
        arena = load(context, "area/arena_reference.jpg");
        hudHeader = load(context, "ui/hud_header.png");
        hudHotbar = load(context, "ui/hud_hotbar.png");
        leftImage = load(context, "ui/control_left.png");
        rightImage = load(context, "ui/control_right.png");
        runImage = load(context, "ui/control_run.png");
        pickaxeImage = load(context, "ui/control_pickaxe.png");
        blockImage = load(context, "ui/control_block.png");
        jumpImage = load(context, "ui/control_jump.png");

        String[] actions = {"walk", "run", "jump"};
        for (int a = 0; a < actions.length; a++) {
            for (int i = 0; i < 5; i++) {
                sprites[a][i] = load(context,
                        "character/" + actions[a] + "_" + i + ".png");
            }
        }
    }

    private Bitmap load(Context context, String path) {
        try {
            return BitmapFactory.decodeStream(context.getAssets().open(path));
        } catch (IOException ignored) {
            return null;
        }
    }

    private void setRect(RectF r, float l, float t, float w, float h) {
        r.set(l, t, l + w, t + h);
    }

    private void updateLayout() {
        if (getWidth() <= 0 || getHeight() <= 0) return;
        designHeight = getHeight() * DESIGN_W / getWidth();
        float controlHeight = Math.min(CONTROL_H, designHeight * 0.24f);
        arenaBottom = designHeight - controlHeight;

        // The character's feet sit on the inner top edge of the bottom stone frame.
        floorY = arenaBottom * (1474f / 1536f);
        if (grounded) playerY = floorY;

        float buttonSize = Math.min(120f, controlHeight * 0.46f);
        float buttonY = arenaBottom + (controlHeight - buttonSize) * 0.40f;
        setRect(leftButton, 8, buttonY, buttonSize, buttonSize);
        setRect(rightButton, 140, buttonY, buttonSize, buttonSize);
        setRect(runButton, 272, buttonY, buttonSize, buttonSize);
        setRect(pickaxeButton, 480, buttonY, buttonSize, buttonSize);
        setRect(blockButton, 612, buttonY, buttonSize, buttonSize);
        setRect(jumpButton, 744, buttonY, buttonSize, buttonSize);
    }

    private void drawImage(Canvas c, Bitmap bitmap, RectF rect) {
        if (bitmap == null) return;
        paint.clearShadowLayer();
        paint.setAlpha(255);
        paint.setFilterBitmap(false);
        c.drawBitmap(bitmap, null, rect, paint);
    }

    @Override
    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        updateLayout();
        float scale = getWidth() / DESIGN_W;
        canvas.save();
        canvas.scale(scale, scale);

        // Arena ends at the control deck; no arena artwork under the buttons.
        canvas.drawColor(Color.WHITE);
        if (arena != null) {
            drawImage(canvas, arena, new RectF(0, 0, DESIGN_W, arenaBottom));
        } else {
            paint.setColor(0xff1b1e24);
            canvas.drawRect(0, 0, DESIGN_W, arenaBottom, paint);
        }

        drawPlayer(canvas);

        // Latest HUD artwork supplied by the user; no substitute text or hearts.
        if (hudHeader != null) {
            float h = DESIGN_W * hudHeader.getHeight() / hudHeader.getWidth();
            drawImage(canvas, hudHeader, new RectF(0, 0, DESIGN_W, h));
        }
        if (hudHotbar != null) {
            float h = DESIGN_W * hudHotbar.getHeight() / hudHotbar.getWidth();
            float top = hudHeader == null ? 0 :
                    DESIGN_W * hudHeader.getHeight() / hudHeader.getWidth() + 5f;
            drawImage(canvas, hudHotbar, new RectF(0, top, DESIGN_W, top + h));
        }

        // Plain white control area, with larger icons and press feedback.
        paint.setColor(Color.WHITE);
        canvas.drawRect(0, arenaBottom, DESIGN_W, designHeight, paint);
        drawActionButton(canvas, leftImage, leftButton, leftVisual);
        drawActionButton(canvas, rightImage, rightButton, rightVisual);
        drawActionButton(canvas, runImage, runButton, runHeld || sprintMode);
        drawActionButton(canvas, pickaxeImage, pickaxeButton, pickHeld);
        drawActionButton(canvas, blockImage, blockButton, blockHeld);
        drawActionButton(canvas, jumpImage, jumpButton, jumpVisual);

        canvas.restore();
        updatePlayer();
        postInvalidateDelayed(16);
    }

    private void drawActionButton(Canvas canvas, Bitmap bitmap, RectF rect, boolean pressed) {
        if (bitmap == null) return;
        float scale = pressed ? 0.90f : 1.0f;
        float cx = rect.centerX(), cy = rect.centerY();
        float w = rect.width() * scale, h = rect.height() * scale;
        RectF dst = new RectF(cx - w / 2f, cy - h / 2f, cx + w / 2f, cy + h / 2f);

        if (pressed) {
            paint.setColor(0x5536cfff);
            paint.setShadowLayer(13f, 0f, 0f, 0xff20cfff);
            canvas.drawRoundRect(dst, 28f, 28f, paint);
            paint.clearShadowLayer();
        }
        drawImage(canvas, bitmap, dst);
    }

    private void drawPlayer(Canvas canvas) {
        int action = !grounded ? 2 : ((leftDown || rightDown) ? (sprintMode ? 1 : 0) : 0);
        int frame = action == 2 ? jumpFrame : (action == 1 ? runFrame : walkFrame);
        Bitmap sprite = sprites[action][frame];
        if (sprite == null) return;

        float h = Math.min(112f, (arenaBottom - 250f) * 0.11f);
        float w = h * sprite.getWidth() / sprite.getHeight();
        RectF dst = new RectF(playerX - w / 2f, playerY - h, playerX + w / 2f, playerY);
        canvas.save();
        if (!facingRight) canvas.scale(-1f, 1f, playerX, 0f);
        drawImage(canvas, sprite, dst);
        canvas.restore();
    }

    private void updatePlayer() {
        long now = System.nanoTime();
        if (lastTime == 0L) lastTime = now;
        float dt = Math.min((now - lastTime) / 1_000_000_000f, 0.04f);
        lastTime = now;

        float speed = sprintMode ? 270f : 155f;
        if (leftDown && !rightDown) {
            playerX -= speed * dt;
            facingRight = false;
        } else if (rightDown && !leftDown) {
            playerX += speed * dt;
            facingRight = true;
        }
        playerX = Math.max(112f, Math.min(752f, playerX));

        if (jumpDown && grounded) {
            velocityY = -490f;
            grounded = false;
            jumpFrame = 0;
            animationClock = 0f;
        }
        if (!grounded) {
            velocityY += 1120f * dt;
            playerY += velocityY * dt;
            if (playerY >= floorY) {
                playerY = floorY;
                velocityY = 0f;
                grounded = true;
            }
        }

        animationClock += dt;
        if (!grounded) {
            if (animationClock >= 0.12f) {
                jumpFrame = (jumpFrame + 1) % 5;
                animationClock = 0f;
            }
        } else if (leftDown || rightDown) {
            float delay = sprintMode ? 0.075f : 0.13f;
            if (animationClock >= delay) {
                if (sprintMode) runFrame = (runFrame + 1) % 5;
                else walkFrame = (walkFrame + 1) % 5;
                animationClock = 0f;
            }
        } else {
            walkFrame = 0;
            animationClock = 0f;
        }
    }

    private float px(float x) { return x * DESIGN_W / Math.max(1f, getWidth()); }
    private float py(float y) { return y * DESIGN_W / Math.max(1f, getWidth()); }

    @Override
    public boolean onTouchEvent(MotionEvent e) {
        int action = e.getActionMasked();
        int index = e.getActionIndex();

        if (action == MotionEvent.ACTION_DOWN || action == MotionEvent.ACTION_POINTER_DOWN) {
            float x = px(e.getX(index)), y = py(e.getY(index));
            if (runButton.contains(x, y)) {
                sprintMode = !sprintMode;
                runHeld = true;
            }
        }

        if (action == MotionEvent.ACTION_UP || action == MotionEvent.ACTION_CANCEL) {
            leftDown = rightDown = jumpDown = false;
            leftVisual = rightVisual = jumpVisual = false;
            runHeld = pickHeld = blockHeld = false;
            return true;
        }

        leftDown = rightDown = jumpDown = false;
        leftVisual = rightVisual = jumpVisual = false;
        pickHeld = blockHeld = false;

        for (int i = 0; i < e.getPointerCount(); i++) {
            if (action == MotionEvent.ACTION_POINTER_UP && i == index) continue;
            float x = px(e.getX(i)), y = py(e.getY(i));
            if (leftButton.contains(x, y)) leftDown = leftVisual = true;
            if (rightButton.contains(x, y)) rightDown = rightVisual = true;
            if (jumpButton.contains(x, y)) jumpDown = jumpVisual = true;
            if (pickaxeButton.contains(x, y)) pickHeld = true;
            if (blockButton.contains(x, y)) blockHeld = true;
            if (runButton.contains(x, y)) runHeld = true;
        }
        return true;
    }
}
