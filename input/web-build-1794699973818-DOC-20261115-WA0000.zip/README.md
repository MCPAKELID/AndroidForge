# BlockRush Live Game v21 — AndroidForge Source

## Cara main (gaya Minecraft 2D)

- **Tombol Blok**: blok langsung dipasang di kotak **tepat di bawah kaki player**, lalu player otomatis naik ke atasnya (pillar jump). Bisa juga saat melompat. Tahan tombol = bangun menara cepat.
- **Ketuk / klik layar**: ketuk kotak kosong mana pun di arena untuk memasang blok di situ. Geser jari = pasang beruntun.
- Blok **tidak punya gravitasi**: kalau blok bawah dihancurkan, blok di atasnya tetap diam.
- Player setinggi 1,8 kotak, jadi **celah 2 blok bisa dilewati** (jalan di bawahnya atau sambil lompat).
- Awal permainan: player berdiri di rumput, tanah ada di bawah dan di belakang tombol; area arena baru terlihat makin ke atas.

## Kontrol

| Aksi | Sentuh | Keyboard | Mouse |
|---|---|---|---|
| Jalan kiri / kanan | tombol ◀ ▶ | A / D atau panah | – |
| Lompat (tahan = lompat terus) | tombol ⬆ | W / Spasi / panah atas | – |
| Lari | tombol lari | tahan Shift | – |
| Blok di bawah player (tahan = beruntun) | tombol blok | E / Enter | – |
| Pasang blok di kotak mana pun | ketuk kotak | F = blok di depan | klik kiri |
| Gali blok | mode beliung lalu ketuk | X / Z / Ctrl (depan), S / panah bawah (bawah) | klik kanan |
| Mode beliung | tombol beliung | Q | – |
| Jatuhkan TNT | ketuk panel TNT | T | klik panel TNT |
| Hadiah (urut sesuai yang tampil) | ketuk ikon hadiah | tombol 1–8 | klik ikon |
| Jeda / lanjut | tombol jeda di HUD, Back | Esc / P | klik tombol jeda |

Gamepad: D-pad / stik kiri jalan, A lompat, X blok, B gali, Y beliung, L1 TNT, R1 lari, Start jeda.

## Pengaturan

Menu utama: MAIN, HADIAH LIVE, PENGATURAN (juga dari menu jeda).

- Suara on/off, tombol di layar tampil/sembunyi (untuk keyboard + mouse), blok tak terbatas, kecepatan pasang (NORMAL / CEPAT / SUPER).
- **Hadiah live** (8 slot, tiap slot sendiri-sendiri): tampil/sembunyi, ganti ikon, efek (BLOK, TNT, HUJAN TNT, TURBO, NYAWA, PERISAI), jumlah (+/− atau ketik), dan teks di bawah ikon (kosong = otomatis). Hanya hadiah yang aktif yang tampil di baris atas. Semua tersimpan.

## Perubahan v21

- Pasang blok di bawah player + player naik otomatis, pasang lewat ketuk/klik layar, tanpa blok jatuh.
- Tanah/rumput di dasar arena, menutup bagian di belakang tombol.
- HUD atas dibuat ulang dengan sprite baru (kubus rumput, piala, bar bersegmen 15, bar nyawa) dan angka rapi.
- Menu utama, jeda, pengaturan, dan pengaturan hadiah dibuat ulang; tombol yang tidak berguna dihapus.
- Pemasangan blok cepat (tahan tombol, geser jari, atau 3 tingkat kecepatan).

## Build

Import ZIP ini dengan isi diekstrak langsung ke workspace proyek AndroidForge (root berisi `settings.gradle` dan `build.gradle`). Build modul `app` dengan JDK 17 dan Android SDK Platform 35.

Application ID: `com.mcpakel.blockarea`  
Versi: 2.1 (versionCode 21)

Kode diuji dengan API Android tiruan (menggambar ke Java2D) untuk logika, input, dan tampilan. APK asli belum dibuild/dites di perangkat karena Android SDK tidak tersedia di sini. Jika build error, kirim lognya.
