package com.mcpakel.blockarea;

import android.content.Context;
import android.content.SharedPreferences;

/** Persistent settings: sound, on-screen buttons, build speed and the configurable gift row. */
public final class GameSettings {
    public static final int GIFTS = 8;
    public static final int ICONS = 8;
    public static final int E_BLOCK = 0, E_TNT = 1, E_RAIN = 2, E_TURBO = 3, E_HEAL = 4, E_SHIELD = 5;
    public static final int EFFECTS = 6;
    public static final String[] EFFECT_NAMES = {"BLOK", "TNT", "HUJAN TNT", "TURBO", "NYAWA", "PERISAI"};
    public static final int[] EFFECT_MAX = {100, 99, 30, 60, 100, 60};
    public static final int[] EFFECT_COLOR = {0xff47d16a, 0xffe0a030, 0xff4fc3d9, 0xffe6c83a, 0xff7ae07a, 0xff9a7ae0};
    public static final String[] SPEED_NAMES = {"NORMAL", "CEPAT", "SUPER"};
    public static final float[] SPEED_INTERVAL = {0.12f, 0.065f, 0.03f};

    /** One entry of the gift row shown above the arena. */
    public static final class Gift {
        public boolean on;
        public int icon, effect, amount;
        public String label = "";

        public String autoLabel() {
            switch (effect) {
                case E_BLOCK: return "+" + amount;
                case E_TNT:
                case E_RAIN: return "x" + amount;
                case E_HEAL: return amount + "%";
                default: return amount + "s";
            }
        }

        /** Custom text when set, otherwise generated from the amount. */
        public String shownLabel() {
            String t = label == null ? "" : label.trim();
            return t.length() > 0 ? t : autoLabel();
        }

        public String toast() {
            switch (effect) {
                case E_BLOCK: return "+" + amount + " BLOK";
                case E_TNT: return "+" + amount + " TNT";
                case E_RAIN: return "HUJAN TNT x" + amount;
                case E_TURBO: return "TURBO " + amount + " DETIK";
                case E_HEAL: return "NYAWA +" + amount + "%";
                default: return "PERISAI " + amount + " DETIK";
            }
        }

        public void clampAmount() {
            amount = Math.max(1, Math.min(EFFECT_MAX[effect], amount));
        }
    }

    // icon, effect, amount, on
    private static final int[][] DEFAULTS = {
            {0, E_BLOCK, 60, 1}, {1, E_TNT, 20, 1}, {2, E_TNT, 45, 1}, {3, E_RAIN, 6, 0},
            {4, E_TURBO, 10, 0}, {5, E_HEAL, 100, 0}, {6, E_SHIELD, 10, 0}, {7, E_TNT, 5, 0}};

    public boolean sound = true;
    public boolean showButtons = true;
    public boolean unlimited = false;
    public int speed = 1;
    public final Gift[] gifts = new Gift[GIFTS];
    private final SharedPreferences prefs;

    public GameSettings(Context context) {
        SharedPreferences p = null;
        try { p = context.getSharedPreferences("blockrush_settings", Context.MODE_PRIVATE); } catch (Throwable ignored) { }
        prefs = p;
        for (int i = 0; i < GIFTS; i++) gifts[i] = new Gift();
        resetDefaults();
        load();
    }

    public void resetDefaults() {
        sound = true; showButtons = true; unlimited = false; speed = 1;
        for (int i = 0; i < GIFTS; i++) {
            Gift g = gifts[i];
            g.icon = DEFAULTS[i][0]; g.effect = DEFAULTS[i][1]; g.amount = DEFAULTS[i][2];
            g.on = DEFAULTS[i][3] == 1; g.label = "";
        }
    }

    public void resetGifts() {
        boolean s = sound, b = showButtons, u = unlimited;
        int sp = speed;
        resetDefaults();
        sound = s; showButtons = b; unlimited = u; speed = sp;
    }

    public int enabledGifts() {
        int n = 0;
        for (Gift g : gifts) if (g.on) n++;
        return n;
    }

    public float placeInterval() { return SPEED_INTERVAL[Math.max(0, Math.min(SPEED_INTERVAL.length - 1, speed))]; }

    private void load() {
        if (prefs == null) return;
        try {
            sound = prefs.getBoolean("sound", sound);
            showButtons = prefs.getBoolean("buttons", showButtons);
            unlimited = prefs.getBoolean("unlimited", unlimited);
            speed = Math.max(0, Math.min(SPEED_NAMES.length - 1, prefs.getInt("speed", speed)));
            for (int i = 0; i < GIFTS; i++) {
                Gift g = gifts[i];
                String k = "g" + i + "_";
                g.on = prefs.getBoolean(k + "on", g.on);
                g.icon = Math.max(0, Math.min(ICONS - 1, prefs.getInt(k + "icon", g.icon)));
                g.effect = Math.max(0, Math.min(EFFECTS - 1, prefs.getInt(k + "effect", g.effect)));
                g.amount = prefs.getInt(k + "amount", g.amount);
                g.label = prefs.getString(k + "label", g.label);
                g.clampAmount();
            }
        } catch (Throwable ignored) { }
    }

    public void save() {
        if (prefs == null) return;
        try {
            SharedPreferences.Editor e = prefs.edit();
            e.putBoolean("sound", sound);
            e.putBoolean("buttons", showButtons);
            e.putBoolean("unlimited", unlimited);
            e.putInt("speed", speed);
            for (int i = 0; i < GIFTS; i++) {
                Gift g = gifts[i];
                String k = "g" + i + "_";
                e.putBoolean(k + "on", g.on);
                e.putInt(k + "icon", g.icon);
                e.putInt(k + "effect", g.effect);
                e.putInt(k + "amount", g.amount);
                e.putString(k + "label", g.label == null ? "" : g.label);
            }
            e.apply();
        } catch (Throwable ignored) { }
    }
}
