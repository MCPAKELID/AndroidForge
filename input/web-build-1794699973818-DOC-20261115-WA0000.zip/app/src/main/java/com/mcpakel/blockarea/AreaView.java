package com.mcpakel.blockarea;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Rect;
import android.graphics.RectF;
import android.graphics.Typeface;
import android.media.AudioAttributes;
import android.media.SoundPool;
import android.os.Build;
import android.text.InputType;
import android.util.SparseArray;
import android.view.InputDevice;
import android.view.KeyEvent;
import android.view.MotionEvent;
import android.view.View;
import android.widget.EditText;

import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.util.Locale;
import java.util.Random;

/**
 * Block Rush (2D Minecraft style): place blocks under yourself and climb, mine, blow things up
 * with TNT. Input: touch, keyboard and mouse (Bluetooth / OTG / built-in) and simple gamepads.
 * Everything is drawn on one Canvas in a 512-unit wide world.
 */
public class AreaView extends View {
    // ---- world / layout -------------------------------------------------------------
    private static final float WORLD_W = 512f;
    private static final float BOARD_H = 1935f;
    private static final float MIN_LOGICAL_H = 700f;
    private static final float MAX_CONTROL_H = 384f;
    private static final float MIN_CONTROL_H = 140f;
    private static final int COLS = 10, ROWS = 40, BLOCK_TYPES = 48, TNT_TYPE = 28;
    private static final int BUILD_LIMIT_ROW = 0;
    private static final float GRID_X = 41f, GRID_Y = 132f, CELL = 43f;
    private static final float FLOOR_Y = GRID_Y + ROWS * CELL;
    private static final float PLAYER_H = CELL * 1.8f;          // fits through a 2-cell gap
    private static final float PLAYER_HALF_W = CELL * 0.30f;
    private static final float GRAVITY = 1850f, JUMP_SPEED = 720f;
    private static final float AREA_TOP = 160f;
    private static final float PLAYER_SCREEN_RATIO = 0.72f;
    private static final int SKY = 0xff38a6fd;

    private static final int MAX_INVENTORY = 100, MAX_TNT = 24;
    private static final int MAX_PARTICLES = 220, MAX_FX = 8;
    private static final int[] LADDER = {1, 2, 3, 4, 5, 33, 6, 10, 11};
    private static final int[] ORES = {12, 13, 14, 15, 16, 17, 18};

    // Inner compartments of hud_bar.png (source pixels): start,end pairs.
    private static final int[] BAR_SEG = {42, 145, 156, 265, 276, 396, 407, 527, 539, 660,
            672, 797, 808, 933, 945, 1067, 1078, 1200, 1211, 1336, 1347, 1471, 1483, 1607,
            1618, 1741, 1753, 1859, 1870, 1974};

    private static final int ROLE_NONE = 0, ROLE_LEFT = 1, ROLE_RIGHT = 2, ROLE_JUMP = 3,
            ROLE_RUN = 4, ROLE_PICK = 5, ROLE_BUILD = 6, ROLE_GRID = 7, ROLE_PAUSE = 8,
            ROLE_GIFT = 9, ROLE_TNT = 10;
    private static final int SCREEN_MENU = 0, SCREEN_GAME = 1, SCREEN_PAUSE = 2,
            SCREEN_SETTINGS = 3, SCREEN_GIFTS = 4;

    // UI button ids
    private static final int B_PLAY = 1, B_GIFTS = 2, B_SETTINGS = 3, B_RESUME = 4, B_RETRY = 5,
            B_MENU = 6, B_SOUND = 10, B_BUTTONS = 11, B_UNLIMITED = 12, B_SPEED = 13,
            B_RESET = 15, B_BACK = 16, B_RESET_GIFTS = 18,
            B_G_ON = 100, B_G_ICON = 120, B_G_EFFECT = 140, B_G_MINUS = 160, B_G_AMOUNT = 180,
            B_G_PLUS = 200, B_G_LABEL = 220;

    private interface TextResult { void done(String text); }

    private static final class TouchPoint {
        int role, arg;
        boolean mouse;
        float x, y;
        TouchPoint(int role, float x, float y) { this.role = role; this.x = x; this.y = y; }
    }

    private final Paint paint = new Paint();
    private final RectF tmp = new RectF();
    private final Random rnd = new Random();
    private final GameSettings cfg;
    private final int[][] blocks = new int[ROWS][COLS];
    private final long[][] blockPlacedAt = new long[ROWS][COLS];
    private final RectF[] giftRects = new RectF[GameSettings.GIFTS];
    private final int[] giftIdx = new int[GameSettings.GIFTS];
    private int giftCount = 0;
    private final RectF tntRect = new RectF();
    private final RectF pauseRect = new RectF(460f, 4f, 504f, 48f);
    private final Bitmap[] blockTextures = new Bitmap[BLOCK_TYPES];
    private final int[] blockColor = new int[BLOCK_TYPES];
    private final Bitmap[] giftIcons = new Bitmap[GameSettings.ICONS];
    private final Bitmap[][] characterFrames = new Bitmap[3][5];
    private final float[][] characterBottom = new float[3][5];
    private final SparseArray<TouchPoint> touches = new SparseArray<>();

    // UI hit boxes recorded while drawing a menu screen.
    private final RectF[] uiRects = new RectF[64];
    private final int[] uiIds = new int[64];
    private int uiCount = 0;

    private Bitmap arena, fontAtlas, placementFrame, menuBackground, pauseIcon;
    private Bitmap hudBar, hudCube, hudTrophy, hudHp;
    private Bitmap leftImage, rightImage, runImage, pickImage, blockImage, jumpImage;

    private final RectF[] hit = new RectF[6];
    private final RectF[] icon = new RectF[6];

    // ---- player ---------------------------------------------------------------------
    private float playerX, playerFeet, velocityY;
    private float cameraY, cameraTarget;
    private float animationClock, stepClock, impactVy;
    private long lastFrameNanos;
    private boolean grounded = true, wasGrounded = true, facingRight = true;
    private boolean jumpRequested = false;
    private int walkFrame = 0, runFrame = 0, jumpFrame = 0;

    // ---- input state ----------------------------------------------------------------
    private boolean touchLeft, touchRight, touchJump, touchBuild;
    private boolean keyLeft, keyRight, keyJump, keyBuild, keyShift, keyMineFront, keyMineDown;
    private boolean padLeft, padRight;
    private boolean sprintToggle = false;
    private boolean leftHeld, rightHeld, jumpHeld, buildHeld;
    private boolean breakMode = false;
    private boolean mouseActive = false;
    private boolean gridHeld = false, gridMine = false;
    private int hoverCol = -1, hoverRow = -1;
    private int targetCol = -1, targetRow = -1;
    private int hitArg = -1;
    private float buildCooldown = 0f, gridCooldown = 0f, mineCooldown = 0f;

    // ---- game state -----------------------------------------------------------------
    private int screen = SCREEN_MENU;
    private int settingsBack = SCREEN_MENU, giftsBack = SCREEN_MENU;
    private int inventory = MAX_INVENTORY, tntStock = 15, winCount = 0;
    private float hp = 100f;
    private float gameClock = 0f, regenClock = 0f, lastPlaceSound = -1f;
    private float turboUntil = -1f, shieldUntil = -1f;
    private String toastText = "";
    private float toastUntil = -1f;
    private final float[] giftFlash = new float[GameSettings.GIFTS];
    private int rainLeft = 0;
    private float rainClock = 0f;
    private long playerPlaceUntilNanos = 0L;
    private float pressCenterX = -1000f, pressCenterY = -1000f;
    private long pressUntilNanos = 0L;
    private int countdownValue = -1;
    private long countdownNextNanos = 0L;
    private float shake = 0f;

    // TNT entities.
    private final boolean[] tntOn = new boolean[MAX_TNT];
    private final float[] tntY = new float[MAX_TNT], tntVy = new float[MAX_TNT], tntFuse = new float[MAX_TNT];
    private final int[] tntCol = new int[MAX_TNT];

    // Particles and explosion rings.
    private final float[] px = new float[MAX_PARTICLES], py = new float[MAX_PARTICLES];
    private final float[] pvx = new float[MAX_PARTICLES], pvy = new float[MAX_PARTICLES];
    private final float[] plife = new float[MAX_PARTICLES];
    private final int[] pcol = new int[MAX_PARTICLES];
    private final float[] fxX = new float[MAX_FX], fxY = new float[MAX_FX], fxT = new float[MAX_FX];

    // Sound.
    private SoundPool pool;
    private int sJump, sLand, sStep, sRun;

    public AreaView(Context context) {
        super(context);
        cfg = new GameSettings(context);
        arena = load("area/arena_reference.png");
        fontAtlas = load("font/pixel_font.png");
        placementFrame = load("blocks/placement_frame.png");
        hudBar = load("ui/hud_bar.png");
        hudCube = load("ui/hud_cube.png");
        hudTrophy = load("ui/hud_trophy.png");
        hudHp = load("ui/hud_hp.png");
        leftImage = load("ui/control_left.png");
        rightImage = load("ui/control_right.png");
        runImage = load("ui/control_run.png");
        pickImage = load("ui/control_pickaxe.png");
        blockImage = load("ui/control_block.png");
        jumpImage = load("ui/control_jump.png");
        menuBackground = load("menu/background.jpg");
        pauseIcon = load("menu/icon_pause.png");

        for (int i = 0; i < uiRects.length; i++) uiRects[i] = new RectF();
        for (int i = 0; i < BLOCK_TYPES; i++) {
            blockTextures[i] = load(String.format(Locale.US, "blocks/block_%02d.png", i));
            blockColor[i] = averageColor(blockTextures[i]);
        }
        String[] actions = {"walk", "run", "jump"};
        for (int a = 0; a < 3; a++) {
            for (int f = 0; f < 5; f++) {
                characterFrames[a][f] = load("character/" + actions[a] + "_" + f + ".png");
                characterBottom[a][f] = bottomPadding(characterFrames[a][f]);
            }
        }
        for (int i = 0; i < GameSettings.ICONS; i++) giftIcons[i] = load("ui/gift_icon_" + i + ".png");
        for (int i = 0; i < GameSettings.GIFTS; i++) giftRects[i] = new RectF();
        for (int r = 0; r < ROWS; r++) for (int c = 0; c < COLS; c++) blocks[r][c] = -1;
        for (int i = 0; i < 6; i++) { hit[i] = new RectF(); icon[i] = new RectF(); }
        for (int i = 0; i < MAX_FX; i++) fxT[i] = -1f;

        playerX = GRID_X + (COLS * CELL) / 2f;
        playerFeet = FLOOR_Y;
        paint.setFilterBitmap(false);
        paint.setAntiAlias(false);

        initSound();
        setFocusable(true);
        setFocusableInTouchMode(true);
        if (Build.VERSION.SDK_INT >= 26) setDefaultFocusHighlightEnabled(false);
        requestFocus();
    }

    // ================================================================================
    // Resources
    // ================================================================================
    private Bitmap load(String path) {
        InputStream in = null;
        try {
            in = getContext().getAssets().open(path);
            return BitmapFactory.decodeStream(in);
        } catch (Exception e) {
            return null;
        } finally {
            try { if (in != null) in.close(); } catch (Exception ignored) { }
        }
    }

    private int averageColor(Bitmap b) {
        if (b == null || b.getWidth() < 4 || b.getHeight() < 4) return 0xff8a8a8a;
        long r = 0, g = 0, bl = 0;
        int n = 0;
        for (int yy = 0; yy < 4; yy++) {
            for (int xx = 0; xx < 4; xx++) {
                int p = b.getPixel((xx * 2 + 1) * b.getWidth() / 8, (yy * 2 + 1) * b.getHeight() / 8);
                r += (p >> 16) & 255; g += (p >> 8) & 255; bl += p & 255; n++;
            }
        }
        return 0xff000000 | ((int) (r / n) << 16) | ((int) (g / n) << 8) | (int) (bl / n);
    }

    /** Fraction of the bitmap height that is transparent at the bottom (so feet sit on the floor). */
    private float bottomPadding(Bitmap b) {
        if (b == null) return 0f;
        int w = b.getWidth(), h = b.getHeight();
        for (int y = h - 1; y >= 0; y--) {
            for (int x = 0; x < w; x += 2) {
                if (((b.getPixel(x, y) >> 24) & 255) > 40) return (h - 1 - y) / (float) h;
            }
        }
        return 0f;
    }

    private void initSound() {
        try {
            AudioAttributes attrs = new AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_GAME)
                    .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION).build();
            pool = new SoundPool.Builder().setMaxStreams(6).setAudioAttributes(attrs).build();
            sJump = loadSound("jump");
            sLand = loadSound("land");
            sStep = loadSound("footstep");
            sRun = loadSound("run_step");
        } catch (Throwable t) {
            pool = null;
        }
    }

    private int loadSound(String name) {
        try {
            File f = new File(getContext().getCacheDir(), "snd_" + name + ".wav");
            if (!f.exists() || f.length() == 0) {
                InputStream in = getContext().getAssets().open("sounds/" + name + ".wav");
                FileOutputStream out = new FileOutputStream(f);
                byte[] buf = new byte[4096];
                int n;
                while ((n = in.read(buf)) > 0) out.write(buf, 0, n);
                out.close();
                in.close();
            }
            return pool.load(f.getAbsolutePath(), 1);
        } catch (Throwable t) {
            return 0;
        }
    }

    private void play(int id, float volume, float rate) {
        if (pool == null || !cfg.sound || id == 0) return;
        try { pool.play(id, volume, volume, 1, 0, rate); } catch (Throwable ignored) { }
    }

    /** Called by the activity when it is destroyed. */
    public void release() {
        if (pool != null) {
            try { pool.release(); } catch (Throwable ignored) { }
            pool = null;
        }
    }

    protected long now() { return System.nanoTime(); }

    // ================================================================================
    // Layout helpers
    // ================================================================================
    private float scale() { return Math.min(getWidth() / WORLD_W, getHeight() / MIN_LOGICAL_H); }
    private float offsetX() { return (getWidth() - WORLD_W * scale()) * 0.5f; }
    private float logicalHeight() { return getHeight() / Math.max(0.001f, scale()); }
    private float controlHeight() {
        if (!cfg.showButtons) return 0f;
        return Math.min(MAX_CONTROL_H, Math.max(MIN_CONTROL_H, logicalHeight() - BOARD_H));
    }
    private float controlTop() { return logicalHeight() - controlHeight(); }
    private float areaTop() { return Math.min(AREA_TOP, Math.max(0f, controlTop() - 360f)); }
    private float boardViewportHeight() { return Math.max(360f, controlTop() - areaTop()); }
    private float worldToScreenY(float y) { return areaTop() + y - cameraY; }
    private int clamp(int value, int min, int max) { return Math.max(min, Math.min(max, value)); }
    private float clampFloat(float v, float min, float max) { return Math.max(min, Math.min(max, v)); }
    private int playerColumn() { return clamp((int) ((playerX - GRID_X) / CELL), 0, COLS - 1); }
    private float toLogicalX(float pxv) { return (pxv - offsetX()) / Math.max(0.001f, scale()); }
    private float toLogicalY(float pyv) { return pyv / Math.max(0.001f, scale()); }
    private float minCamera() { return -PLAYER_H * 1.2f; }
    private float maxCamera() { return Math.max(minCamera(), FLOOR_Y + 260f - boardViewportHeight()); }

    /** Row of the cell the player's feet are in (the cell a block under the player will fill). */
    private int feetRow() {
        return (int) Math.floor((playerFeet - 1f - GRID_Y) / CELL);
    }

    // ================================================================================
    // Board queries
    // ================================================================================
    private int topBlockRow(int col) {
        for (int r = BUILD_LIMIT_ROW; r < ROWS; r++) if (blocks[r][col] >= 0) return r;
        return ROWS;
    }

    private int blockCount() {
        int n = 0;
        for (int[] row : blocks) for (int v : row) if (v >= 0) n++;
        return n;
    }

    private int areaPercent() {
        return Math.min(100, Math.round(blockCount() * 100f / (COLS * ROWS)));
    }

    // Floor row = dirt, then every material lasts two rows.
    private int materialForRow(int row) {
        int layer = (ROWS - 1) - row;
        int idx = layer == 0 ? 0 : 1 + (layer - 1) / 2;
        return LADDER[idx % LADDER.length];
    }

    private int pickType(int row) {
        int base = materialForRow(row);
        if (base == 2 && rnd.nextInt(100) < 12) return ORES[rnd.nextInt(ORES.length)];
        return base;
    }

    private boolean isSprint() { return sprintToggle || keyShift; }
    private boolean turboOn() { return gameClock < turboUntil; }
    private boolean shieldOn() { return gameClock < shieldUntil; }

    private void layoutControls() {
        float y = controlTop() + (controlHeight() - 84f) / 2f;
        float[] xs = {2, 86, 170, 268, 352, 436};
        for (int i = 0; i < 6; i++) {
            hit[i].set(xs[i] - 4, y - 4, xs[i] + 78, y + 82);
            icon[i].set(xs[i] + 2, y + 2, xs[i] + 76, y + 80);
        }
    }

    /** Only enabled gifts are shown, centered and sized to fit. */
    private void layoutGifts() {
        giftCount = 0;
        for (int i = 0; i < GameSettings.GIFTS; i++) if (cfg.gifts[i].on) giftIdx[giftCount++] = i;
        if (giftCount == 0) return;
        float gap = 6f;
        float tw = Math.min(60f, (478f - (giftCount - 1) * gap) / giftCount);
        float th = tw * 129f / 162f + 17f;
        float total = giftCount * tw + (giftCount - 1) * gap;
        float x = (WORLD_W - total) / 2f, y = 93f;
        for (int k = 0; k < giftCount; k++) {
            giftRects[k].set(x, y, x + tw, y + th);
            x += tw + gap;
        }
    }

    // ================================================================================
    // Drawing primitives
    // ================================================================================
    private void drawBitmap(Canvas canvas, Bitmap bitmap, RectF dst) {
        if (bitmap == null) return;
        paint.setAlpha(255); paint.setFilterBitmap(false); paint.clearShadowLayer();
        canvas.drawBitmap(bitmap, null, dst, paint);
    }

    private void blit(Canvas c, Bitmap b, float l, float t, float r, float bt, boolean smooth) {
        if (b == null) return;
        tmp.set(l, t, r, bt);
        paint.setAlpha(255); paint.setFilterBitmap(smooth);
        c.drawBitmap(b, null, tmp, paint);
        paint.setFilterBitmap(false);
    }

    private void fill(Canvas c, float l, float t, float r, float b, int color) {
        paint.setStyle(Paint.Style.FILL);
        paint.setColor(color);
        c.drawRect(l, t, r, b, paint);
    }

    private void roundRect(Canvas c, float l, float t, float r, float b, float rad, int color) {
        tmp.set(l, t, r, b);
        paint.setStyle(Paint.Style.FILL);
        paint.setColor(color);
        c.drawRoundRect(tmp, rad, rad, paint);
    }

    /** Dark plate with a gold frame, matching the HUD sprite sheet. */
    private void drawPlate(Canvas c, float l, float t, float r, float b, int fillColor) {
        roundRect(c, l, t, r, b, 8f, 0xff0b0c10);
        roundRect(c, l + 1.5f, t + 1.5f, r - 1.5f, b - 1.5f, 7f, 0xffe9b61a);
        roundRect(c, l + 3.5f, t + 3.5f, r - 3.5f, b - 3.5f, 5f, 0xff7a5a0a);
        roundRect(c, l + 4.5f, t + 4.5f, r - 4.5f, b - 4.5f, 4f, fillColor);
    }

    private void textRaw(Canvas c, String text, float cx, float cy, float size, int color, float stroke) {
        paint.setTypeface(Typeface.create("sans-serif-black", Typeface.BOLD));
        paint.setTextAlign(Paint.Align.CENTER);
        paint.setTextSize(size);
        float y = cy + size * 0.36f;
        if (stroke > 0f) {
            paint.setStrokeWidth(stroke);
            paint.setStyle(Paint.Style.STROKE);
            paint.setColor(0xff111318);
            c.drawText(text, cx, y, paint);
        }
        paint.setStyle(Paint.Style.FILL);
        paint.setColor(color);
        c.drawText(text, cx, y, paint);
    }

    /** Text shrunk to fit maxW. */
    private void text(Canvas c, String s, float cx, float cy, float size, int color, float stroke, float maxW) {
        paint.setTypeface(Typeface.create("sans-serif-black", Typeface.BOLD));
        paint.setTextSize(size);
        float w = paint.measureText(s);
        if (w > maxW && w > 0f) size = size * maxW / w;
        textRaw(c, s, cx, cy, size, color, stroke);
    }

    private boolean pressedAt(RectF r) {
        return now() < pressUntilNanos && pressCenterX >= r.left && pressCenterX <= r.right
                && pressCenterY >= r.top && pressCenterY <= r.bottom;
    }

    private void addHit(RectF r, int id) {
        if (uiCount >= uiRects.length) return;
        uiRects[uiCount].set(r);
        uiIds[uiCount] = id;
        uiCount++;
    }

    private int uiAt(float x, float y) {
        for (int i = uiCount - 1; i >= 0; i--) if (uiRects[i].contains(x, y)) return uiIds[i];
        return -1;
    }

    /** style: 0 normal, 1 primary (green), 2 danger (red), 3 on (green), 4 off (grey). */
    private void drawButton(Canvas c, float l, float t, float r, float b, String label, int style, int id, float size) {
        RectF rect = new RectF(l, t, r, b);
        addHit(rect, id);
        boolean pr = pressedAt(rect);
        float off = pr ? 2f : 0f;
        int fillC;
        switch (style) {
            case 1: fillC = 0xff2f9a42; break;
            case 2: fillC = 0xff9a3030; break;
            case 3: fillC = 0xff2f9a42; break;
            case 4: fillC = 0xff4b505e; break;
            default: fillC = 0xff2b3040; break;
        }
        roundRect(c, l, t + 4f, r, b + 4f, 9f, 0x88000000);
        drawPlate(c, l, t + off, r, b + off, fillC);
        roundRect(c, l + 6f, t + off + 6f, r - 6f, t + off + 6f + (b - t) * 0.22f, 3f, 0x26ffffff);
        text(c, label, (l + r) / 2f, (t + b) / 2f + off, size, 0xffffffff, 4f, (r - l) - 20f);
    }

    private void drawChip(Canvas c, float l, float t, float r, float b, String label, int style, int id, float size) {
        RectF rect = new RectF(l, t, r, b);
        if (id >= 0) addHit(rect, id);
        boolean pr = id >= 0 && pressedAt(rect);
        int fillC;
        switch (style) {
            case 3: fillC = 0xff2f9a42; break;
            case 4: fillC = 0xff4b505e; break;
            case 5: fillC = 0xff1a1d27; break;
            default: fillC = 0xff353b4f; break;
        }
        roundRect(c, l, t, r, b, 6f, 0xff0b0c10);
        roundRect(c, l + 1.5f, t + 1.5f, r - 1.5f, b - 1.5f, 5f, pr ? 0xffffe27a : 0xffb98a10);
        roundRect(c, l + 3f, t + 3f, r - 3f, b - 3f, 4f, fillC);
        text(c, label, (l + r) / 2f, (t + b) / 2f, size, 0xffffffff, 3f, (r - l) - 8f);
    }

    private void drawMenuBackground(Canvas canvas, int dim) {
        float h = logicalHeight();
        fill(canvas, 0, 0, WORLD_W, h, 0xff12151f);
        if (menuBackground != null) {
            float bgW = h * menuBackground.getWidth() / Math.max(1f, menuBackground.getHeight());
            if (bgW < WORLD_W) bgW = WORLD_W;
            float left = (WORLD_W - bgW) * 0.5f;
            tmp.set(left, 0, left + bgW, h);
            paint.setAlpha(255); paint.setFilterBitmap(true);
            canvas.drawBitmap(menuBackground, null, tmp, paint);
            paint.setFilterBitmap(false);
        }
        fill(canvas, 0, 0, WORLD_W, h, dim);
    }

    // ================================================================================
    // Main draw loop
    // ================================================================================
    @Override protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        if (getWidth() <= 0 || getHeight() <= 0) return;
        float sc = scale();
        canvas.drawColor(0xff0b0d14);
        canvas.save();
        canvas.translate(offsetX(), 0f);
        canvas.scale(sc, sc);
        canvas.clipRect(0f, 0f, WORLD_W, logicalHeight());
        uiCount = 0;

        if (screen == SCREEN_MENU) {
            drawMenuScreen(canvas);
        } else if (screen == SCREEN_SETTINGS) {
            drawSettingsScreen(canvas);
        } else if (screen == SCREEN_GIFTS) {
            drawGiftsScreen(canvas);
        } else {
            drawGame(canvas);
            if (screen == SCREEN_PAUSE) drawPauseScreen(canvas);
        }
        canvas.restore();

        if (screen == SCREEN_GAME) updatePhysics();
        postInvalidateOnAnimation();
    }

    private void drawGame(Canvas canvas) {
        layoutControls();
        layoutGifts();
        if (lastFrameNanos == 0) {
            cameraY = clampFloat(playerFeet - boardViewportHeight() * PLAYER_SCREEN_RATIO,
                    minCamera(), maxCamera());
        }
        float top = areaTop();
        canvas.drawColor(SKY);
        if (arena != null) {
            tmp.set(0, top - cameraY, WORLD_W, top + BOARD_H - cameraY);
            drawBitmap(canvas, arena, tmp);
        }

        canvas.save();
        canvas.clipRect(0, top, WORLD_W, logicalHeight());
        if (shake > 0.01f) {
            canvas.translate((rnd.nextFloat() - 0.5f) * shake * 7f, (rnd.nextFloat() - 0.5f) * shake * 7f);
        }
        drawSideFill(canvas);
        drawGround(canvas);
        drawPlacedBlocks(canvas);
        drawTnt(canvas);
        drawPlacementTarget(canvas);
        drawPlayer(canvas);
        drawEffects(canvas);
        canvas.restore();

        drawHud(canvas);
        drawGiftRow(canvas);
        drawMinimap(canvas);
        drawHpPanel(canvas);
        if (cfg.showButtons) drawControls(canvas);
        if (toastUntil > gameClock) drawToast(canvas);
        if (countdownValue >= 0) drawRoundCountdown(canvas);
    }

    /** The reference arena image has raised ground outside the walls; hide it so the floor is consistent. */
    private void drawSideFill(Canvas canvas) {
        float y0 = worldToScreenY(FLOOR_Y - 90f), y1 = worldToScreenY(FLOOR_Y);
        fill(canvas, 0, y0, 19f, y1, 0xff5bbafd);
        fill(canvas, 493f, y0, WORLD_W, y1, 0xff5bbafd);
    }

    /** Grass on top, dirt, then stone: the soil continues behind the on-screen buttons. */
    private void drawGround(Canvas canvas) {
        float fy = worldToScreenY(FLOOR_Y);
        float bottom = logicalHeight();
        if (fy >= bottom) return;
        for (int r = 0; ; r++) {
            float y = fy + r * CELL;
            if (y >= bottom) break;
            if (y + CELL < areaTop()) continue;
            int type = r == 0 ? 0 : (r <= 4 ? 1 : 2);
            Bitmap tex = blockTextures[type];
            for (int c = -1; c <= COLS + 1; c++) {
                float x = GRID_X + c * CELL;
                blit(canvas, tex, x, y, x + CELL, y + CELL, false);
            }
            if (r >= 1) {
                int a = Math.min(120, 14 + r * 14);
                fill(canvas, 0, y, WORLD_W, y + CELL, a << 24);
            }
        }
    }

    // ---- menu screens ---------------------------------------------------------------
    private void drawMenuScreen(Canvas canvas) {
        drawMenuBackground(canvas, 0x80000000);
        float h = logicalHeight();
        float cx = WORLD_W / 2f;
        float titleY = h * 0.2f;
        textRaw(canvas, "BLOCK RUSH", cx, titleY, 50f, 0xffffd34a, 8f);
        textRaw(canvas, "MINECRAFT 2D  -  LIVE GAME", cx, titleY + 40f, 14f, 0xffffffff, 4f);

        float w = 330f, l = cx - w / 2f, r = cx + w / 2f;
        float y = h * 0.36f;
        drawButton(canvas, l, y, r, y + 66f, "MAIN", 1, B_PLAY, 30f);
        y += 66f + 16f;
        drawButton(canvas, l, y, r, y + 54f, "HADIAH LIVE  (" + cfg.enabledGifts() + " aktif)", 0, B_GIFTS, 19f);
        y += 54f + 12f;
        drawButton(canvas, l, y, r, y + 54f, "PENGATURAN", 0, B_SETTINGS, 20f);

        float hy = h - 70f;
        textRaw(canvas, "KEYBOARD: A/D jalan  W/Spasi lompat  E blok  F blok depan  X gali  T TNT  1-8 hadiah",
                cx, hy, 10.5f, 0xffffffff, 3.5f);
        textRaw(canvas, "MOUSE: klik kiri pasang blok  klik kanan gali  |  SENTUH: ketuk kotak untuk pasang",
                cx, hy + 17f, 10.5f, 0xffffffff, 3.5f);
        textRaw(canvas, "Esc = jeda", cx, hy + 34f, 10.5f, 0xffffffff, 3.5f);
    }

    private void drawPauseScreen(Canvas canvas) {
        float h = logicalHeight();
        fill(canvas, 0, 0, WORLD_W, h, 0xc0000000);
        float cx = WORLD_W / 2f;
        float pw = 340f, ph = 392f;
        float pl = cx - pw / 2f, pt = (h - ph) / 2f;
        drawPlate(canvas, pl, pt, pl + pw, pt + ph, 0xee161922);
        textRaw(canvas, "JEDA", cx, pt + 36f, 32f, 0xffffd34a, 6f);
        float l = pl + 26f, r = pl + pw - 26f;
        float y = pt + 72f;
        drawButton(canvas, l, y, r, y + 52f, "LANJUT", 1, B_RESUME, 22f);
        y += 52f + 10f;
        drawButton(canvas, l, y, r, y + 46f, "HADIAH", 0, B_GIFTS, 18f);
        y += 46f + 10f;
        drawButton(canvas, l, y, r, y + 46f, "PENGATURAN", 0, B_SETTINGS, 18f);
        y += 46f + 10f;
        drawButton(canvas, l, y, r, y + 46f, "ULANG", 0, B_RETRY, 18f);
        y += 46f + 10f;
        drawButton(canvas, l, y, r, y + 46f, "MENU UTAMA", 2, B_MENU, 18f);
    }

    private void drawSettingsScreen(Canvas canvas) {
        drawMenuBackground(canvas, 0xb0000000);
        float h = logicalHeight();
        float cx = WORLD_W / 2f;
        textRaw(canvas, "PENGATURAN", cx, h * 0.14f, 34f, 0xffffd34a, 7f);
        float w = 440f, l = cx - w / 2f, r = cx + w / 2f;
        float y = h * 0.14f + 44f;
        float rowH = 50f, gap = 10f;

        drawSettingRow(canvas, l, r, y, rowH, "SUARA", cfg.sound ? "ON" : "OFF", cfg.sound, B_SOUND);
        y += rowH + gap;
        drawSettingRow(canvas, l, r, y, rowH, "TOMBOL DI LAYAR", cfg.showButtons ? "TAMPIL" : "SEMBUNYI",
                cfg.showButtons, B_BUTTONS);
        y += rowH + gap;
        drawSettingRow(canvas, l, r, y, rowH, "BLOK TAK TERBATAS", cfg.unlimited ? "ON" : "OFF", cfg.unlimited, B_UNLIMITED);
        y += rowH + gap;
        drawSettingRow(canvas, l, r, y, rowH, "KECEPATAN PASANG", GameSettings.SPEED_NAMES[cfg.speed], true, B_SPEED);
        y += rowH + gap;
        drawButton(canvas, l, y, r, y + rowH, "PENGATURAN HADIAH  >", 0, B_GIFTS, 18f);
        y += rowH + gap + 10f;
        textRaw(canvas, "Matikan tombol layar jika bermain dengan keyboard + mouse.", cx, y, 10.5f, 0xffdddddd, 3f);
        y += 30f;
        drawButton(canvas, l, y, cx - 6f, y + 48f, "RESET", 2, B_RESET, 17f);
        drawButton(canvas, cx + 6f, y, r, y + 48f, "KEMBALI", 1, B_BACK, 17f);
    }

    private void drawSettingRow(Canvas c, float l, float r, float y, float h, String label, String value,
                                boolean on, int id) {
        RectF rect = new RectF(l, y, r, y + h);
        addHit(rect, id);
        drawPlate(c, l, y, r, y + h, pressedAt(rect) ? 0xff2d3345 : 0xff1b1f2b);
        text(c, label, l + 18f + 110f, y + h / 2f, 17f, 0xffffffff, 4f, 220f);
        drawChip(c, r - 128f, y + 8f, r - 12f, y + h - 8f, value, on ? 3 : 4, -1, 15f);
    }

    private void drawGiftsScreen(Canvas canvas) {
        drawMenuBackground(canvas, 0xc0000000);
        float h = logicalHeight();
        float cx = WORLD_W / 2f;
        textRaw(canvas, "HADIAH LIVE", cx, 34f, 30f, 0xffffd34a, 6f);
        textRaw(canvas, "Tampil " + cfg.enabledGifts() + "/" + GameSettings.GIFTS
                + "  -  ketuk ikon/efek untuk ganti, angka & teks untuk edit", cx, 62f, 10.5f, 0xffffffff, 3f);
        float y = 80f;
        float rowH = Math.min(58f, (h - 80f - 76f) / GameSettings.GIFTS - 4f);
        for (int i = 0; i < GameSettings.GIFTS; i++) {
            drawGiftSettingRow(canvas, i, y, rowH);
            y += rowH + 4f;
        }
        y += 8f;
        drawButton(canvas, 14f, y, cx - 6f, y + 48f, "RESET HADIAH", 2, B_RESET_GIFTS, 16f);
        drawButton(canvas, cx + 6f, y, WORLD_W - 14f, y + 48f, "KEMBALI", 1, B_BACK, 16f);
    }

    private void drawGiftSettingRow(Canvas c, int i, float y, float h) {
        GameSettings.Gift g = cfg.gifts[i];
        float l = 8f, r = WORLD_W - 8f, pad = 4f;
        drawPlate(c, l, y, r, y + h, g.on ? 0xff1b2230 : 0xff15171e);
        float cy = y + h / 2f, ch = h - 14f;
        float x = l + 8f;
        drawChip(c, x, cy - ch / 2f, x + 42f, cy + ch / 2f, g.on ? "ON" : "OFF", g.on ? 3 : 4, B_G_ON + i, 14f);
        x += 42f + pad;
        float iw = ch * 162f / 129f;
        RectF ir = new RectF(x, cy - ch / 2f, x + iw, cy + ch / 2f);
        addHit(ir, B_G_ICON + i);
        roundRect(c, ir.left - 1f, ir.top - 1f, ir.right + 1f, ir.bottom + 1f, 4f, 0xff0b0c10);
        blit(c, giftIcons[g.icon], ir.left, ir.top, ir.right, ir.bottom, true);
        x += iw + pad + 2f;
        drawChip(c, x, cy - ch / 2f, x + 92f, cy + ch / 2f, GameSettings.EFFECT_NAMES[g.effect], 0, B_G_EFFECT + i, 12f);
        x += 92f + pad;
        drawChip(c, x, cy - ch / 2f, x + 24f, cy + ch / 2f, "-", 0, B_G_MINUS + i, 17f);
        x += 24f;
        drawChip(c, x, cy - ch / 2f, x + 40f, cy + ch / 2f, String.valueOf(g.amount), 5, B_G_AMOUNT + i, 15f);
        x += 40f;
        drawChip(c, x, cy - ch / 2f, x + 24f, cy + ch / 2f, "+", 0, B_G_PLUS + i, 17f);
        x += 24f + pad + 2f;
        boolean custom = g.label != null && g.label.trim().length() > 0;
        drawChip(c, x, cy - ch / 2f, r - 8f, cy + ch / 2f, custom ? g.label.trim() : g.autoLabel() + " (auto)",
                custom ? 0 : 5, B_G_LABEL + i, 13f);
    }

    // ---- world objects ------------------------------------------------------------
    private void drawPlacedBlocks(Canvas canvas) {
        long t = now();
        for (int row = BUILD_LIMIT_ROW; row < ROWS; row++) {
            float y = worldToScreenY(GRID_Y + row * CELL);
            if (y > logicalHeight() || y + CELL < areaTop()) continue;
            for (int col = 0; col < COLS; col++) {
                int type = blocks[row][col];
                if (type < 0) continue;
                float x = GRID_X + col * CELL;
                blit(canvas, blockTextures[type], x, y, x + CELL, y + CELL, false);
                long placed = blockPlacedAt[row][col];
                if (placed > 0L) {
                    float age = (t - placed) / 1_000_000_000f;
                    if (age >= 0f && age < 0.6f) {
                        int a = (int) (200 * (1f - age / 0.6f));
                        fill(canvas, x, y, x + CELL, y + CELL, (a << 24) | 0x00ffffff);
                    }
                }
            }
        }
    }

    private void drawPlacementTarget(Canvas canvas) {
        int col, row;
        boolean valid;
        if (breakMode) {
            if (mouseActive && hoverCol >= 0) { col = hoverCol; row = hoverRow; }
            else { col = targetCol; row = targetRow; }
            valid = col >= 0 && row >= 0 && blocks[row][col] >= 0;
        } else if (mouseActive && hoverCol >= 0 && hoverRow >= 0) {
            col = hoverCol; row = hoverRow;
            valid = blocks[row][col] < 0;
        } else {
            col = playerColumn(); row = feetRow();
            valid = row >= BUILD_LIMIT_ROW && blocks[row][col] < 0;
        }
        if (col < 0 || col >= COLS || row < BUILD_LIMIT_ROW || row >= ROWS) return;
        float x = GRID_X + col * CELL;
        float y = worldToScreenY(GRID_Y + row * CELL);
        RectF cell = new RectF(x + 1.5f, y + 1.5f, x + CELL - 1.5f, y + CELL - 1.5f);
        if (!breakMode && valid && blockTextures[materialForRow(row)] != null) {
            paint.setAlpha(90);
            canvas.drawBitmap(blockTextures[materialForRow(row)], null, cell, paint);
            paint.setAlpha(255);
        }
        if (placementFrame != null) drawBitmap(canvas, placementFrame, cell);
        paint.setStyle(Paint.Style.STROKE);
        paint.setStrokeWidth(3f);
        paint.setColor(breakMode ? 0xffff5555 : (valid ? 0xff42ef69 : 0xffffa030));
        canvas.drawRect(cell, paint);
        paint.setStyle(Paint.Style.FILL);
    }

    private void drawTnt(Canvas canvas) {
        for (int i = 0; i < MAX_TNT; i++) {
            if (!tntOn[i]) continue;
            float x = GRID_X + tntCol[i] * CELL;
            float y = worldToScreenY(tntY[i]);
            float grow = tntFuse[i] >= 0f && tntFuse[i] < 0.4f ? (0.4f - tntFuse[i]) * 5f : 0f;
            blit(canvas, blockTextures[TNT_TYPE], x - grow, y - grow, x + CELL + grow, y + CELL + grow, false);
            if (tntFuse[i] >= 0f && ((int) (tntFuse[i] * 6f)) % 2 == 0) {
                fill(canvas, x, y, x + CELL, y + CELL, 0x99ffffff);
            }
        }
    }

    private void drawPlayer(Canvas canvas) {
        boolean spr = isSprint();
        int action = !grounded ? 2 : ((leftHeld || rightHeld) ? (spr ? 1 : 0) : 0);
        int frame = action == 2 ? jumpFrame : (action == 1 ? runFrame : walkFrame);
        Bitmap sprite = characterFrames[action][frame];
        if (sprite == null) return;
        float unit = PLAYER_H / (233f * 0.93f);
        float w = sprite.getWidth() * unit, h = sprite.getHeight() * unit;
        float feet = worldToScreenY(playerFeet) + characterBottom[action][frame] * h;
        tmp.set(playerX - w / 2, feet - h, playerX + w / 2, feet);
        long t = now();
        boolean placing = t < playerPlaceUntilNanos;
        if (placing) {
            float k = (playerPlaceUntilNanos - t) / 220000000f;
            float pulse = (float) Math.sin((1f - k) * Math.PI);
            tmp.offset(facingRight ? pulse * 4f : -pulse * 4f, 0f);
        }
        canvas.save();
        if (!facingRight) canvas.scale(-1, 1, playerX, 0);
        drawBitmap(canvas, sprite, tmp);
        canvas.restore();
        if (shieldOn()) {
            paint.setStyle(Paint.Style.STROKE);
            paint.setStrokeWidth(2.5f);
            paint.setColor(0xaa5ad8ff);
            canvas.drawCircle(playerX, worldToScreenY(playerFeet) - PLAYER_H * 0.5f, PLAYER_H * 0.62f, paint);
            paint.setStyle(Paint.Style.FILL);
        }
    }

    private void drawEffects(Canvas canvas) {
        for (int i = 0; i < MAX_FX; i++) {
            if (fxT[i] < 0f) continue;
            float k = fxT[i] / 0.38f;
            float r = CELL * (0.6f + 2.0f * k);
            int a = (int) (200 * (1f - k));
            float cx = fxX[i], cy = worldToScreenY(fxY[i]);
            paint.setStyle(Paint.Style.FILL);
            paint.setColor((a << 24) | 0x00ff9a1e);
            canvas.drawCircle(cx, cy, r, paint);
            paint.setColor((a << 24) | 0x00fff3b0);
            canvas.drawCircle(cx, cy, r * 0.55f, paint);
        }
        for (int i = 0; i < MAX_PARTICLES; i++) {
            if (plife[i] <= 0f) continue;
            float a = Math.min(1f, plife[i] * 2.5f);
            int c = ((int) (255 * a) << 24) | (pcol[i] & 0x00ffffff);
            float sy = worldToScreenY(py[i]);
            fill(canvas, px[i] - 2.5f, sy - 2.5f, px[i] + 2.5f, sy + 2.5f, c);
        }
    }

    // ---- HUD ----------------------------------------------------------------------
    private void drawHud(Canvas canvas) {
        float top = areaTop();
        // Solid panel behind the HUD so the arena never shows through the sprites.
        fill(canvas, 0, 0, WORLD_W, top, 0xff12141c);
        fill(canvas, 0, 0, WORLD_W, 3f, 0xff1d212e);
        fill(canvas, 0, top - 3f, WORLD_W, top, 0xffe9b61a);
        fill(canvas, 0, top - 5f, WORLD_W, top - 3f, 0xff0b0c10);

        // Row 1: blocks | trophies | area %, pause.
        drawPlate(canvas, 6f, 8f, 150f, 44f, 0xff191c26);
        blit(canvas, hudCube, 12f, 5f, 12f + 38f * 131f / 151f, 43f, true);
        drawAtlasTextFit(canvas, inventory + "/" + MAX_INVENTORY, 100f, 26f, 18f, 90f);

        float tw = 196f, th = tw * 162f / 791f, tl = (WORLD_W - tw) / 2f - 14f, tt = 5f;
        blit(canvas, hudTrophy, tl, tt, tl + tw, tt + th, true);
        drawAtlasTextFit(canvas, winCount + "/10", tl + tw * 0.5f, tt + th * 0.5f, 15f, tw * 0.34f);

        drawPlate(canvas, 366f, 8f, 454f, 44f, 0xff191c26);
        drawAtlasTextFit(canvas, areaPercent() + "%", 410f, 26f, 18f, 70f);
        drawPauseControl(canvas);

        // Row 2: segmented progress bar (15 compartments) = filled area.
        float bx = 7f, by = 50f, bw = 498f, bh = bw * 151f / 2016f;
        blit(canvas, hudBar, bx, by, bx + bw, by + bh, true);
        float k = bw / 2016f;
        float fillSegs = areaPercent() / 100f * (BAR_SEG.length / 2);
        for (int i = 0; i < BAR_SEG.length / 2; i++) {
            float part = Math.max(0f, Math.min(1f, fillSegs - i));
            if (part <= 0f) continue;
            float l = bx + BAR_SEG[i * 2] * k;
            float r = l + (BAR_SEG[i * 2 + 1] - BAR_SEG[i * 2]) * k * part;
            float t = by + 38f * k, b = by + 100f * k;
            fill(canvas, l, t, r, b, 0xff2fd24a);
            fill(canvas, l, t, r, t + (b - t) * 0.35f, 0xff7cf08a);
        }
    }

    private void drawPauseControl(Canvas canvas) {
        boolean pr = pressedAt(pauseRect);
        drawPlate(canvas, pauseRect.left, pauseRect.top + 2f, pauseRect.right, pauseRect.bottom - 2f,
                pr ? 0xff3a4058 : 0xff191c26);
        float cx = pauseRect.centerX(), cy = pauseRect.centerY();
        fill(canvas, cx - 7f, cy - 8f, cx - 2.5f, cy + 8f, 0xffffffff);
        fill(canvas, cx + 2.5f, cy - 8f, cx + 7f, cy + 8f, 0xffffffff);
    }

    private void drawGiftRow(Canvas canvas) {
        for (int k = 0; k < giftCount; k++) {
            GameSettings.Gift g = cfg.gifts[giftIdx[k]];
            RectF r = giftRects[k];
            boolean active = (g.effect == GameSettings.E_TURBO && turboOn())
                    || (g.effect == GameSettings.E_SHIELD && shieldOn());
            boolean flash = giftFlash[giftIdx[k]] > 0f;
            drawPlate(canvas, r.left, r.top, r.right, r.bottom, 0xff1a1d28);
            float iw = r.width() - 10f, ih = iw * 129f / 162f;
            blit(canvas, giftIcons[g.icon], r.left + 5f, r.top + 5f, r.left + 5f + iw, r.top + 5f + ih, true);
            text(canvas, g.shownLabel(), r.centerX(), r.bottom - 11f, 12f, 0xffffffff, 4f, r.width() - 6f);
            if (flash || active) {
                paint.setStyle(Paint.Style.STROKE);
                paint.setStrokeWidth(2.5f);
                paint.setColor(active ? 0xff5ad8ff : 0xffffe14a);
                canvas.drawRoundRect(r, 8f, 8f, paint);
                paint.setStyle(Paint.Style.FILL);
            }
        }
    }

    private void drawMinimap(Canvas canvas) {
        float x0 = 495.5f, x1 = 508f;
        float top = areaTop() + 6f, bottom = controlTop() - 8f, h = bottom - top;
        if (h < 40f) return;
        float gridH = ROWS * CELL;
        fill(canvas, x0 - 1.5f, top - 3f, x1 + 1.5f, bottom + 1.5f, 0xff0a0d18);
        fill(canvas, x0, top, x1, bottom, 0xff1c2340);
        fill(canvas, x0, top - 2f, x1, top + 1f, 0xffffc928);
        float rowH = h / ROWS;
        for (int r = 0; r < ROWS; r++) {
            int type = -1;
            for (int c = 0; c < COLS && type < 0; c++) type = blocks[r][c];
            if (type < 0) continue;
            float y = top + r * rowH;
            fill(canvas, x0 + 1f, y + 0.4f, x1 - 1f, y + rowH, blockColor[type]);
        }
        float vTop = top + clampFloat((cameraY - GRID_Y) / gridH, 0f, 1f) * h;
        float vBot = top + clampFloat((cameraY + boardViewportHeight() - GRID_Y) / gridH, 0f, 1f) * h;
        paint.setStyle(Paint.Style.STROKE);
        paint.setStrokeWidth(1.2f);
        paint.setColor(0xccffffff);
        canvas.drawRect(x0 - 1f, vTop, x1 + 1f, Math.max(vTop + 4f, vBot), paint);
        float py2 = top + clampFloat((playerFeet - PLAYER_H * 0.5f - GRID_Y) / gridH, 0f, 1f) * h;
        paint.setStyle(Paint.Style.FILL);
        paint.setColor(0xffff9a3c);
        canvas.drawCircle(x0 - 3.5f, py2, 2.4f, paint);
    }

    private void drawHpPanel(Canvas canvas) {
        float w = 176f, h = w * 134f / 641f;
        float x = GRID_X + COLS * CELL - w - 4f, y = controlTop() - h - 8f;
        float k = w / 641f;
        // Fill behind the sprite's dark window, then the sprite on top is transparent-free, so draw after.
        blit(canvas, hudHp, x, y, x + w, y + h, true);
        float ix0 = x + 130f * k, ix1 = x + 596f * k, iy0 = y + 46f * k, iy1 = y + 92f * k;
        float f = clampFloat(hp / 100f, 0f, 1f);
        if (f > 0f) {
            int c1 = shieldOn() ? 0xff4ad0ff : 0xffe02a2a, c2 = shieldOn() ? 0xff9ae8ff : 0xffff6a6a;
            fill(canvas, ix0, iy0, ix0 + (ix1 - ix0) * f, iy1, c1);
            fill(canvas, ix0, iy0, ix0 + (ix1 - ix0) * f, iy0 + (iy1 - iy0) * 0.35f, c2);
        }
        // TNT counter (tap to drop TNT).
        float tl = GRID_X + 4f, tr = tl + 84f;
        tntRect.set(tl, y - 2f, tr, y + h + 2f);
        drawPlate(canvas, tl, y - 2f, tr, y + h + 2f, 0xff191c26);
        blit(canvas, blockTextures[TNT_TYPE], tl + 8f, y + h / 2f - 11f, tl + 30f, y + h / 2f + 11f, false);
        drawAtlasTextFit(canvas, String.valueOf(tntStock), tl + 56f, y + h / 2f, 15f, 36f);
    }

    private void drawToast(Canvas canvas) {
        float k = Math.min(1f, (toastUntil - gameClock) * 3f);
        if (k <= 0f) return;
        text(canvas, toastText, WORLD_W / 2f, areaTop() + 52f, 22f, 0xffffffff, 6f, 440f);
    }

    private void drawRoundCountdown(Canvas canvas) {
        float cx = WORLD_W * 0.5f;
        float cy = areaTop() + boardViewportHeight() * 0.46f;
        roundRect(canvas, cx - 88f, cy - 70f, cx + 88f, cy + 70f, 18f, 0xb9000000);
        paint.setStyle(Paint.Style.STROKE);
        paint.setStrokeWidth(4f);
        paint.setColor(0xffffc928);
        tmp.set(cx - 88f, cy - 70f, cx + 88f, cy + 70f);
        canvas.drawRoundRect(tmp, 18f, 18f, paint);
        paint.setStyle(Paint.Style.FILL);
        drawAtlasText(canvas, String.valueOf(countdownValue), cx, cy, 76f);
    }

    private Rect fontSource(char ch) {
        switch (ch) {
            case '0': return new Rect(254, 529, 369, 649);
            case '1': return new Rect(395, 529, 484, 649);
            case '2': return new Rect(499, 529, 613, 649);
            case '3': return new Rect(627, 529, 739, 649);
            case '4': return new Rect(751, 529, 872, 649);
            case '5': return new Rect(890, 529, 1005, 649);
            case '6': return new Rect(1022, 529, 1139, 649);
            case '7': return new Rect(1155, 529, 1266, 649);
            case '8': return new Rect(1285, 529, 1399, 649);
            case '9': return new Rect(1416, 529, 1533, 649);
            case '/': return new Rect(1432, 655, 1520, 765);
            case '%': return new Rect(643, 763, 758, 873);
            default: return null;
        }
    }

    private float atlasWidth(String text, float targetHeight) {
        float total = 0f;
        for (int i = 0; i < text.length(); i++) {
            Rect r = fontSource(text.charAt(i));
            if (r != null) total += targetHeight * (r.width() / (float) r.height()) + 2f;
        }
        return total > 0f ? total - 2f : 0f;
    }

    private void drawAtlasTextFit(Canvas canvas, String text, float cx, float cy, float h, float maxW) {
        float w = atlasWidth(text, h);
        if (w > maxW && w > 0f) h = h * maxW / w;
        drawAtlasText(canvas, text, cx, cy, h);
    }

    private void drawAtlasText(Canvas canvas, String text, float centerX, float centerY, float targetHeight) {
        if (fontAtlas == null || text == null || text.length() == 0) return;
        float x = centerX - atlasWidth(text, targetHeight) / 2f;
        for (int i = 0; i < text.length(); i++) {
            Rect src = fontSource(text.charAt(i));
            if (src == null) continue;
            float w = targetHeight * src.width() / (float) src.height();
            tmp.set(x, centerY - targetHeight / 2f, x + w, centerY + targetHeight / 2f);
            paint.setAlpha(255);
            paint.setFilterBitmap(false);
            canvas.drawBitmap(fontAtlas, src, tmp, paint);
            x += w + 2f;
        }
    }

    private void drawControls(Canvas canvas) {
        Bitmap[] images = {leftImage, rightImage, runImage, pickImage, blockImage, jumpImage};
        final int[] roles = {ROLE_LEFT, ROLE_RIGHT, ROLE_RUN, ROLE_PICK, ROLE_BUILD, ROLE_JUMP};
        for (int i = 0; i < 6; i++) {
            boolean held = false;
            for (int p = 0; p < touches.size(); p++) {
                if (touches.valueAt(p).role == roles[i]) { held = true; break; }
            }
            if (i == 0 && keyLeft) held = true;
            if (i == 1 && keyRight) held = true;
            if (i == 4 && keyBuild) held = true;
            if (i == 5 && keyJump) held = true;
            boolean active = (i == 2 && isSprint()) || (i == 3 && breakMode);
            if (active) {
                paint.setStyle(Paint.Style.FILL);
                paint.setColor(i == 3 ? 0x5537cfff : 0x55ffc928);
                canvas.drawRoundRect(icon[i], 18, 18, paint);
            }
            tmp.set(icon[i]);
            if (held) {
                float cx = tmp.centerX(), cy = tmp.centerY();
                tmp.inset(tmp.width() * 0.055f, tmp.height() * 0.055f);
                tmp.offset(cx - tmp.centerX(), cy - tmp.centerY());
            }
            drawBitmap(canvas, images[i], tmp);
        }
    }

    // ================================================================================
    // Game rules
    // ================================================================================
    private void startGame() {
        resetGame();
        screen = SCREEN_GAME;
    }

    private void resetGame() {
        for (int r = 0; r < ROWS; r++) {
            for (int c = 0; c < COLS; c++) { blocks[r][c] = -1; blockPlacedAt[r][c] = 0L; }
        }
        playerX = GRID_X + (COLS * CELL) / 2f;
        playerFeet = FLOOR_Y;
        velocityY = 0f;
        cameraY = 0f; cameraTarget = 0f;
        grounded = true; wasGrounded = true;
        facingRight = true;
        targetCol = -1; targetRow = -1;
        countdownValue = -1; countdownNextNanos = 0L; winCount = 0;
        inventory = MAX_INVENTORY; tntStock = 15; hp = 100f;
        turboUntil = -1f; shieldUntil = -1f; toastUntil = -1f;
        rainLeft = 0; shake = 0f; gameClock = 0f;
        buildCooldown = 0f; gridCooldown = 0f;
        breakMode = false;
        clearEffects();
        releaseAllInput();
        lastFrameNanos = 0L;
    }

    private void clearEffects() {
        for (int i = 0; i < MAX_TNT; i++) tntOn[i] = false;
        for (int i = 0; i < MAX_PARTICLES; i++) plife[i] = 0f;
        for (int i = 0; i < MAX_FX; i++) fxT[i] = -1f;
        for (int i = 0; i < GameSettings.GIFTS; i++) giftFlash[i] = 0f;
    }

    private void resetBoardAfterWin() {
        for (int r = 0; r < ROWS; r++) for (int c = 0; c < COLS; c++) {
            blocks[r][c] = -1;
            blockPlacedAt[r][c] = 0L;
        }
        playerX = GRID_X + (COLS * CELL) / 2f;
        playerFeet = FLOOR_Y;
        velocityY = 0f;
        grounded = true;
        cameraY = 0f; cameraTarget = 0f;
        facingRight = true;
        targetCol = -1; targetRow = -1;
        hp = 100f;
        clearEffects();
        lastFrameNanos = now();
    }

    private void toast(String text) {
        toastText = text;
        toastUntil = gameClock + 1.6f;
    }

    private boolean withinRange(int col, int row) {
        float playerRow = (playerFeet - GRID_Y) / CELL;
        float dx = col - playerColumn(), dy = row - playerRow;
        return Math.sqrt(dx * dx + dy * dy) <= 10.0;
    }

    private boolean cellOverlapsPlayer(int col, int row) {
        float l = GRID_X + col * CELL, t = GRID_Y + row * CELL;
        return playerX + PLAYER_HALF_W > l + 1f && playerX - PLAYER_HALF_W < l + CELL - 1f
                && t + CELL > playerFeet - PLAYER_H + 1f && t < playerFeet - 1f;
    }

    private boolean canSpend() { return cfg.unlimited || inventory > 0; }

    private void spend() {
        if (!cfg.unlimited && inventory > 0) inventory--;
    }

    private void afterPlace(int col, int row) {
        blockPlacedAt[row][col] = now();
        spawnBurst(GRID_X + col * CELL + CELL / 2f, GRID_Y + row * CELL + CELL / 2f,
                blockColor[blocks[row][col]], 3, 90f);
        if (gameClock - lastPlaceSound > 0.06f) {
            lastPlaceSound = gameClock;
            play(sLand, 0.45f, 1.5f);
        }
        playerPlaceUntilNanos = now() + 200000000L;
        if (blockCount() >= COLS * ROWS && countdownValue < 0) {
            countdownValue = 15;
            countdownNextNanos = now() + 620000000L;
        }
    }

    /**
     * Minecraft pillar placement: a block appears in the cell under the player's feet and the
     * player is moved straight on top of it. Works on the ground and in mid-air.
     */
    private boolean placeUnderPlayer() {
        if (screen != SCREEN_GAME || countdownValue >= 0) return false;
        int col = playerColumn();
        int row = feetRow();
        if (row < BUILD_LIMIT_ROW) { toast("SUDAH PALING ATAS"); return false; }
        if (row >= ROWS || blocks[row][col] >= 0) return false;
        if (!canSpend()) { toast("BLOK HABIS"); return false; }
        float newFeet = GRID_Y + row * CELL;
        if (blockedAt(playerX, newFeet - PLAYER_H, newFeet)) { toast("ATAP TERHALANG"); return false; }
        blocks[row][col] = pickType(row);
        spend();
        playerFeet = newFeet;
        velocityY = 0f;
        grounded = true;
        afterPlace(col, row);
        return true;
    }

    /** Places a block into an empty cell (tap / mouse click). The cell under the player lifts the player. */
    private boolean placeAt(int col, int row) {
        if (screen != SCREEN_GAME || countdownValue >= 0) return false;
        if (col < 0 || col >= COLS || row < BUILD_LIMIT_ROW || row >= ROWS) return false;
        if (blocks[row][col] >= 0) return false;
        if (cellOverlapsPlayer(col, row)) {
            if (col == playerColumn() && row == feetRow()) return placeUnderPlayer();
            toast("ADA PLAYER");
            return false;
        }
        if (!withinRange(col, row)) { toast("TERLALU JAUH"); return false; }
        if (!canSpend()) { toast("BLOK HABIS"); return false; }
        blocks[row][col] = pickType(row);
        spend();
        afterPlace(col, row);
        return true;
    }

    /** Places a block in front of the player at feet level (or on top when that cell is taken). */
    private boolean placeFront() {
        int col = playerColumn() + (facingRight ? 1 : -1);
        if (col < 0 || col >= COLS) return false;
        int row = feetRow();
        if (row >= 0 && row < ROWS && blocks[row][col] >= 0) row--;
        return placeAt(col, row);
    }

    private boolean breakBlockAt(int col, int row) {
        if (col < 0 || col >= COLS || row < BUILD_LIMIT_ROW || row >= ROWS) return false;
        if (blocks[row][col] < 0 || !withinRange(col, row)) return false;
        spawnBurst(GRID_X + col * CELL + CELL / 2f, GRID_Y + row * CELL + CELL / 2f,
                blockColor[blocks[row][col]], 7, 150f);
        blocks[row][col] = -1;
        blockPlacedAt[row][col] = 0L;
        if (inventory < MAX_INVENTORY) inventory++;
        play(sStep, 0.8f, 1.6f);
        // Blocks above never fall. Only the player can lose its footing.
        if (grounded && !hasSurfaceAtFeet(playerX, playerFeet)) {
            grounded = false;
            velocityY = 0f;
        }
        return true;
    }

    private void mineFront() {
        int col = playerColumn() + (facingRight ? 1 : -1);
        if (col < 0 || col >= COLS) return;
        int feetRow = (int) Math.floor((playerFeet - 2f - GRID_Y) / CELL);
        int[] order = {feetRow, feetRow + 1, feetRow - 1};
        for (int r : order) {
            if (breakBlockAt(col, r)) { targetCol = col; targetRow = r; return; }
        }
    }

    private void mineDown() {
        int col = playerColumn();
        int row = (int) Math.floor((playerFeet + 2f - GRID_Y) / CELL);
        if (breakBlockAt(col, row)) { targetCol = col; targetRow = row; }
    }

    // ---- TNT / gifts ----------------------------------------------------------------
    private void spawnTnt(int col, float fuse) {
        if (col < 0 || col >= COLS) return;
        int slot = -1;
        for (int i = 0; i < MAX_TNT; i++) if (!tntOn[i]) { slot = i; break; }
        if (slot < 0) return;
        float surface = GRID_Y + topBlockRow(col) * CELL;
        float y = Math.max(GRID_Y - CELL, cameraY - CELL);
        y = Math.min(y, surface - CELL);
        tntOn[slot] = true;
        tntCol[slot] = col;
        tntY[slot] = y;
        tntVy[slot] = 0f;
        tntFuse[slot] = fuse;
    }

    private void dropTnt() {
        if (screen != SCREEN_GAME || countdownValue >= 0) return;
        if (tntStock <= 0) { toast("TNT HABIS"); return; }
        int dir = facingRight ? 1 : -1;
        int pc = playerColumn();
        int col = pc + 2 * dir;
        if (col < 0 || col >= COLS) col = pc - 2 * dir;
        if (col < 0 || col >= COLS) col = pc + dir;
        col = clamp(col, 0, COLS - 1);
        tntStock--;
        spawnTnt(col, -1f);
    }

    /** slot = index into the list of gifts that are currently shown. */
    private void triggerShownGift(int slot) {
        layoutGifts();
        if (slot < 0 || slot >= giftCount) return;
        triggerGift(giftIdx[slot]);
    }

    private void triggerGift(int i) {
        if (screen != SCREEN_GAME || countdownValue >= 0 || i < 0 || i >= GameSettings.GIFTS) return;
        GameSettings.Gift g = cfg.gifts[i];
        giftFlash[i] = 0.4f;
        switch (g.effect) {
            case GameSettings.E_BLOCK: inventory = Math.min(MAX_INVENTORY, inventory + g.amount); break;
            case GameSettings.E_TNT: tntStock = Math.min(99, tntStock + g.amount); break;
            case GameSettings.E_RAIN: rainLeft += g.amount; rainClock = 0f; break;
            case GameSettings.E_TURBO: turboUntil = gameClock + g.amount; break;
            case GameSettings.E_HEAL: hp = Math.min(100f, hp + g.amount); break;
            default: shieldUntil = gameClock + g.amount; break;
        }
        toast(g.toast());
    }

    private void explode(int i) {
        int col = tntCol[i];
        int row = Math.round((tntY[i] - GRID_Y) / CELL);
        float cx = GRID_X + col * CELL + CELL / 2f, cy = tntY[i] + CELL / 2f;
        tntOn[i] = false;
        for (int dr = -2; dr <= 2; dr++) {
            for (int dc = -2; dc <= 2; dc++) {
                if (dr * dr + dc * dc > 5) continue;
                int r = row + dr, c = col + dc;
                if (r < BUILD_LIMIT_ROW || r >= ROWS || c < 0 || c >= COLS || blocks[r][c] < 0) continue;
                spawnBurst(GRID_X + c * CELL + CELL / 2f, GRID_Y + r * CELL + CELL / 2f,
                        blockColor[blocks[r][c]], 4, 260f);
                blocks[r][c] = -1;
                blockPlacedAt[r][c] = 0L;
            }
        }
        for (int j = 0; j < MAX_TNT; j++) {   // chain reaction
            if (!tntOn[j]) continue;
            float dx = GRID_X + tntCol[j] * CELL + CELL / 2f - cx, dy = tntY[j] + CELL / 2f - cy;
            if (Math.sqrt(dx * dx + dy * dy) < CELL * 2.6f && (tntFuse[j] < 0f || tntFuse[j] > 0.12f)) {
                tntFuse[j] = 0.12f;
            }
        }
        for (int k = 0; k < MAX_FX; k++) {
            if (fxT[k] < 0f) { fxT[k] = 0f; fxX[k] = cx; fxY[k] = cy; break; }
        }
        spawnBurst(cx, cy, 0xffff9a1e, 14, 320f);
        spawnBurst(cx, cy, 0xff555555, 10, 220f);
        shake = 1f;
        play(sLand, 1f, 0.5f);

        float pdx = playerX - cx, pdy = (playerFeet - PLAYER_H * 0.5f) - cy;
        float dist = (float) Math.sqrt(pdx * pdx + pdy * pdy);
        if (dist < CELL * 2.4f) {
            if (!shieldOn()) hp -= 12f + 38f * (1f - dist / (CELL * 2.4f));
            velocityY = -520f;
            grounded = false;
            if (hp <= 0f) respawnPlayer();
        }
        if (grounded && !hasSurfaceAtFeet(playerX, playerFeet)) grounded = false;
    }

    private void respawnPlayer() {
        hp = 100f;
        int col = COLS / 2;
        playerX = GRID_X + col * CELL + CELL / 2f;
        playerFeet = GRID_Y + topBlockRow(col) * CELL;
        velocityY = 0f;
        grounded = true;
        toast("KAMU KEMBALI!");
    }

    private void spawnBurst(float x, float y, int color, int n, float speed) {
        for (int k = 0; k < n; k++) {
            int slot = -1;
            for (int i = 0; i < MAX_PARTICLES; i++) if (plife[i] <= 0f) { slot = i; break; }
            if (slot < 0) return;
            double ang = rnd.nextDouble() * Math.PI * 2.0;
            float sp = speed * (0.35f + rnd.nextFloat() * 0.65f);
            px[slot] = x; py[slot] = y;
            pvx[slot] = (float) Math.cos(ang) * sp;
            pvy[slot] = (float) Math.sin(ang) * sp - 90f;
            plife[slot] = 0.5f + rnd.nextFloat() * 0.5f;
            pcol[slot] = color;
        }
    }

    // ================================================================================
    // Physics
    // ================================================================================
    private boolean hasSurfaceAtFeet(float x, float feet) {
        if (Math.abs(feet - FLOOR_Y) < 2f) return true;
        int col = (int) ((x - GRID_X) / CELL);
        if (col < 0 || col >= COLS) return false;
        for (int row = BUILD_LIMIT_ROW; row < ROWS; row++) {
            if (blocks[row][col] < 0) continue;
            float top = GRID_Y + row * CELL;
            if (Math.abs(feet - top) < 2f) return true;
        }
        return false;
    }

    private float landingSurface(float x, float oldFeet, float newFeet) {
        float best = Float.POSITIVE_INFINITY;
        if (oldFeet <= FLOOR_Y && newFeet >= FLOOR_Y) best = FLOOR_Y;
        int col = (int) ((x - GRID_X) / CELL);
        if (col < 0 || col >= COLS) return best;
        for (int row = BUILD_LIMIT_ROW; row < ROWS; row++) {
            if (blocks[row][col] < 0) continue;
            float top = GRID_Y + row * CELL;
            if (oldFeet <= top + 1f && newFeet >= top - 1f && top < best) best = top;
        }
        return best;
    }

    private float ceilingSurface(float x, float oldTop, float newTop) {
        float best = Float.NEGATIVE_INFINITY;
        float left = x - PLAYER_HALF_W, right = x + PLAYER_HALF_W;
        int first = clamp((int) ((left - GRID_X) / CELL), 0, COLS - 1);
        int last = clamp((int) ((right - GRID_X) / CELL), 0, COLS - 1);
        for (int col = first; col <= last; col++) {
            for (int row = BUILD_LIMIT_ROW; row < ROWS; row++) {
                if (blocks[row][col] < 0) continue;
                float bottom = GRID_Y + (row + 1) * CELL;
                if (oldTop >= bottom - 1f && newTop <= bottom + 1f && bottom > best) best = bottom;
            }
        }
        return best;
    }

    private boolean blockedAt(float x, float top, float feet) {
        float left = x - PLAYER_HALF_W, right = x + PLAYER_HALF_W;
        int first = clamp((int) ((left - GRID_X) / CELL), 0, COLS - 1);
        int last = clamp((int) ((right - GRID_X) / CELL), 0, COLS - 1);
        for (int col = first; col <= last; col++) {
            for (int row = BUILD_LIMIT_ROW; row < ROWS; row++) {
                if (blocks[row][col] < 0) continue;
                float l = GRID_X + col * CELL, r = l + CELL;
                float t = GRID_Y + row * CELL, b = t + CELL;
                if (right > l + 1f && left < r - 1f && feet > t + 1f && top < b - 1f) return true;
            }
        }
        return false;
    }

    private void resolvePlayerOverlap() {
        float top = playerFeet - PLAYER_H;
        if (!blockedAt(playerX, top, playerFeet)) return;
        for (float d = 2f; d <= CELL * 2f; d += 2f) {
            float left = clampFloat(playerX - d, GRID_X + PLAYER_HALF_W, GRID_X + COLS * CELL - PLAYER_HALF_W);
            if (!blockedAt(left, top, playerFeet)) { playerX = left; return; }
            float right = clampFloat(playerX + d, GRID_X + PLAYER_HALF_W, GRID_X + COLS * CELL - PLAYER_HALF_W);
            if (!blockedAt(right, top, playerFeet)) { playerX = right; return; }
        }
        for (float lift = 2f; lift <= PLAYER_H; lift += 2f) {
            if (!blockedAt(playerX, top - lift, playerFeet - lift)) {
                playerFeet -= lift;
                velocityY = 0f;
                grounded = hasSurfaceAtFeet(playerX, playerFeet);
                return;
            }
        }
    }

    private void updatePhysics() {
        long t = now();
        if (lastFrameNanos == 0) lastFrameNanos = t;
        float dt = Math.min(0.032f, (t - lastFrameNanos) / 1_000_000_000f);
        lastFrameNanos = t;
        if (dt <= 0f) return;
        gameClock += dt;

        updateEffects(dt);

        if (countdownValue >= 0) {
            if (t >= countdownNextNanos) {
                if (countdownValue == 1) {
                    winCount = Math.min(10, winCount + 1);
                    countdownValue = -1;
                    resetBoardAfterWin();
                    return;
                }
                countdownValue--;
                long delay = countdownValue <= 3 ? 1350000000L : 620000000L;
                countdownNextNanos = t + delay;
            }
            return;
        }

        updateTnt(dt);

        regenClock += dt;
        if (regenClock >= 0.25f) {
            regenClock = 0f;
            if (inventory < MAX_INVENTORY) inventory++;
        }

        // Held actions repeat at the configured build speed.
        buildCooldown -= dt;
        gridCooldown -= dt;
        mineCooldown -= dt;
        if (buildHeld && buildCooldown <= 0f) {
            placeUnderPlayer();
            buildCooldown = cfg.placeInterval();
        }
        if (gridHeld && targetCol >= 0 && targetRow >= 0 && gridCooldown <= 0f) {
            if (gridMine || breakMode) breakBlockAt(targetCol, targetRow);
            else placeAt(targetCol, targetRow);
            gridCooldown = (gridMine || breakMode) ? Math.max(0.08f, cfg.placeInterval()) : cfg.placeInterval();
        }
        if (keyMineFront && mineCooldown <= 0f) { mineFront(); mineCooldown = 0.15f; }
        if (keyMineDown && mineCooldown <= 0f) { mineDown(); mineCooldown = 0.15f; }

        updatePlayer(dt);

        if (blockCount() >= COLS * ROWS && countdownValue < 0) {
            countdownValue = 15;
            countdownNextNanos = t + 620000000L;
        }
    }

    private void updateEffects(float dt) {
        for (int i = 0; i < GameSettings.GIFTS; i++) if (giftFlash[i] > 0f) giftFlash[i] -= dt;
        shake = Math.max(0f, shake - dt * 3f);
        for (int i = 0; i < MAX_FX; i++) {
            if (fxT[i] < 0f) continue;
            fxT[i] += dt;
            if (fxT[i] > 0.38f) fxT[i] = -1f;
        }
        for (int i = 0; i < MAX_PARTICLES; i++) {
            if (plife[i] <= 0f) continue;
            plife[i] -= dt;
            pvy[i] += 700f * dt;
            px[i] += pvx[i] * dt;
            py[i] += pvy[i] * dt;
        }
    }

    private void updateTnt(float dt) {
        if (rainLeft > 0) {
            rainClock -= dt;
            if (rainClock <= 0f) {
                rainClock = 0.28f;
                rainLeft--;
                spawnTnt(rnd.nextInt(COLS), -1f);
            }
        }
        for (int i = 0; i < MAX_TNT; i++) {
            if (!tntOn[i]) continue;
            float surface = GRID_Y + topBlockRow(tntCol[i]) * CELL;
            boolean supported = tntY[i] + CELL >= surface - 0.5f;
            if (!supported) {
                tntVy[i] = Math.min(1100f, tntVy[i] + 1600f * dt);
                tntY[i] += tntVy[i] * dt;
                if (tntY[i] + CELL >= surface) {
                    tntY[i] = surface - CELL;
                    tntVy[i] = 0f;
                    if (tntFuse[i] < 0f) tntFuse[i] = 1.4f;
                }
            } else {
                tntY[i] = surface - CELL;
                tntVy[i] = 0f;
                if (tntFuse[i] < 0f) tntFuse[i] = 1.4f;
            }
            if (tntFuse[i] >= 0f) {
                tntFuse[i] -= dt;
                if (tntFuse[i] <= 0f) explode(i);
            }
        }
    }

    private void updatePlayer(float dt) {
        boolean spr = isSprint();
        float speed = (spr ? 245f : 145f) * (turboOn() ? 1.5f : 1f);
        float dx = 0f;
        if (leftHeld && !rightHeld) { dx = -speed * dt; facingRight = false; }
        if (rightHeld && !leftHeld) { dx = speed * dt; facingRight = true; }

        resolvePlayerOverlap();

        float candidateX = clampFloat(playerX + dx, GRID_X + PLAYER_HALF_W, GRID_X + COLS * CELL - PLAYER_HALF_W);
        if (Math.abs(dx) > 0.001f) {
            if (!blockedAt(candidateX, playerFeet - PLAYER_H, playerFeet)) {
                playerX = candidateX;
            } else {
                float low = 0f, high = 1f;
                for (int i = 0; i < 12; i++) {
                    float mid = (low + high) * 0.5f;
                    float test = playerX + (candidateX - playerX) * mid;
                    if (blockedAt(test, playerFeet - PLAYER_H, playerFeet)) high = mid;
                    else low = mid;
                }
                playerX = playerX + (candidateX - playerX) * low;
            }
        }

        if (grounded && !hasSurfaceAtFeet(playerX, playerFeet)) grounded = false;

        if ((jumpRequested || jumpHeld) && grounded) {
            velocityY = -JUMP_SPEED * (turboOn() ? 1.08f : 1f);
            grounded = false;
            play(sJump, 0.7f, 1f);
        }
        jumpRequested = false;

        wasGrounded = grounded;
        if (!grounded) {
            float oldFeet = playerFeet;
            float oldTop = oldFeet - PLAYER_H;
            velocityY += GRAVITY * dt;
            float nextFeet = oldFeet + velocityY * dt;
            float nextTop = nextFeet - PLAYER_H;

            if (velocityY < 0f) {
                float ceiling = ceilingSurface(playerX, oldTop, nextTop);
                if (ceiling != Float.NEGATIVE_INFINITY) {
                    nextFeet = ceiling + PLAYER_H;
                    velocityY = 0f;
                }
            } else {
                float landing = landingSurface(playerX, oldFeet, nextFeet);
                if (landing != Float.POSITIVE_INFINITY) {
                    nextFeet = landing;
                    impactVy = velocityY;
                    velocityY = 0f;
                    grounded = true;
                }
            }
            playerFeet = nextFeet;
            if (grounded && !wasGrounded && impactVy > 380f) play(sLand, 0.6f, 1f);
        } else {
            velocityY = 0f;
        }

        // Camera follows the player vertically.
        float desiredCamera = playerFeet - boardViewportHeight() * PLAYER_SCREEN_RATIO;
        cameraTarget = clampFloat(desiredCamera, minCamera(), maxCamera());
        cameraY += (cameraTarget - cameraY) * Math.min(1f, dt * 8f);

        animationClock += dt;
        if (!grounded) {
            if (animationClock > 0.11f) { jumpFrame = (jumpFrame + 1) % 5; animationClock = 0f; }
        } else if (leftHeld != rightHeld) {
            float delay = spr ? 0.075f : 0.13f;
            if (animationClock > delay) {
                if (spr) runFrame = (runFrame + 1) % 5;
                else walkFrame = (walkFrame + 1) % 5;
                animationClock = 0f;
            }
            stepClock += dt;
            float iv = spr ? 0.17f : 0.30f;
            if (stepClock >= iv) { stepClock = 0f; play(spr ? sRun : sStep, 0.5f, 1f); }
        } else {
            walkFrame = 0; animationClock = 0f; stepClock = 0.1f;
        }
    }

    // ================================================================================
    // Input: touch + mouse
    // ================================================================================
    private int roleAt(float x, float y) {
        hitArg = -1;
        layoutGifts();
        if (x >= pauseRect.left - 6f && x <= pauseRect.right + 6f
                && y >= pauseRect.top - 4f && y <= pauseRect.bottom + 6f) return ROLE_PAUSE;
        if (countdownValue >= 0) return ROLE_NONE;
        if (cfg.showButtons) {
            layoutControls();
            final int[] roles = {ROLE_LEFT, ROLE_RIGHT, ROLE_RUN, ROLE_PICK, ROLE_BUILD, ROLE_JUMP};
            for (int i = 0; i < 6; i++) if (hit[i].contains(x, y)) return roles[i];
        }
        for (int k = 0; k < giftCount; k++) {
            if (giftRects[k].contains(x, y)) { hitArg = k; return ROLE_GIFT; }
        }
        if (tntRect.contains(x, y)) return ROLE_TNT;
        if (y >= areaTop() && y < controlTop() && x >= GRID_X && x < GRID_X + COLS * CELL) return ROLE_GRID;
        return ROLE_NONE;
    }

    private void updateTarget(float x, float y) {
        int col = (int) Math.floor((x - GRID_X) / CELL);
        int row = (int) Math.floor((y - areaTop() + cameraY - GRID_Y) / CELL);
        targetCol = (col >= 0 && col < COLS) ? col : -1;
        targetRow = (row >= 0 && row < ROWS) ? row : -1;
    }

    private void updateHover(float x, float y) {
        int col = (int) Math.floor((x - GRID_X) / CELL);
        int row = (int) Math.floor((y - areaTop() + cameraY - GRID_Y) / CELL);
        boolean inside = y >= areaTop() && y < controlTop() && col >= 0 && col < COLS;
        hoverCol = inside ? col : -1;
        hoverRow = (inside && row >= 0 && row < ROWS) ? row : -1;
    }

    private void addPointer(MotionEvent e, int index) {
        int id = e.getPointerId(index);
        float x = toLogicalX(e.getX(index)), y = toLogicalY(e.getY(index));
        boolean mouse = e.getToolType(index) == MotionEvent.TOOL_TYPE_MOUSE;
        int role = roleAt(x, y);
        TouchPoint t = new TouchPoint(role, x, y);
        t.arg = hitArg;
        t.mouse = mouse;
        touches.put(id, t);

        mouseActive = mouse;
        if (mouse) updateHover(x, y);

        if (role == ROLE_PAUSE) {
            pressCenterX = x; pressCenterY = y;
            pressUntilNanos = now() + 220000000L;
        } else if (role == ROLE_RUN) {
            sprintToggle = !sprintToggle;
        } else if (role == ROLE_PICK) {
            breakMode = !breakMode;
        } else if (role == ROLE_BUILD) {
            breakMode = false;
            placeUnderPlayer();
            buildCooldown = cfg.placeInterval() * 2f;
        } else if (role == ROLE_JUMP) {
            jumpRequested = true;
        } else if (role == ROLE_GIFT) {
            triggerShownGift(t.arg);
        } else if (role == ROLE_TNT) {
            dropTnt();
        } else if (role == ROLE_GRID) {
            updateTarget(x, y);
            boolean right = mouse && (e.getButtonState() & MotionEvent.BUTTON_SECONDARY) != 0;
            gridMine = right;
            gridHeld = true;
            if (right || breakMode) breakBlockAt(targetCol, targetRow);
            else placeAt(targetCol, targetRow);
            gridCooldown = cfg.placeInterval() * 2f;
        }
        refreshHeldButtons();
    }

    private void updatePointers(MotionEvent e) {
        for (int i = 0; i < e.getPointerCount(); i++) {
            int id = e.getPointerId(i);
            TouchPoint t = touches.get(id);
            if (t == null) continue;
            t.x = toLogicalX(e.getX(i));
            t.y = toLogicalY(e.getY(i));
            if ((t.role == ROLE_LEFT || t.role == ROLE_RIGHT) && t.y >= controlTop() && t.x >= 0f && t.x < 164f) {
                t.role = t.x < 83f ? ROLE_LEFT : ROLE_RIGHT;
            }
            if (t.role == ROLE_GRID) {
                int oc = targetCol, orow = targetRow;
                updateTarget(t.x, t.y);
                if (t.mouse) updateHover(t.x, t.y);
                // Dragging onto a new cell acts right away (no waiting for the repeat timer).
                if (gridHeld && (targetCol != oc || targetRow != orow) && targetCol >= 0 && targetRow >= 0) {
                    if (gridMine || breakMode) breakBlockAt(targetCol, targetRow);
                    else placeAt(targetCol, targetRow);
                    gridCooldown = cfg.placeInterval();
                }
            }
        }
        refreshHeldButtons();
    }

    private void releasePointer(MotionEvent e, int index) {
        int id = e.getPointerId(index);
        TouchPoint t = touches.get(id);
        if (t != null && t.role == ROLE_GRID) {
            gridHeld = false;
            gridMine = false;
        } else if (t != null && t.role == ROLE_PAUSE) {
            pauseGame();
            pressUntilNanos = now() + 140000000L;
        }
        touches.remove(id);
        refreshHeldButtons();
    }

    private void refreshHeldButtons() {
        touchLeft = touchRight = touchJump = touchBuild = false;
        for (int i = 0; i < touches.size(); i++) {
            int role = touches.valueAt(i).role;
            if (role == ROLE_LEFT) touchLeft = true;
            if (role == ROLE_RIGHT) touchRight = true;
            if (role == ROLE_JUMP) touchJump = true;
            if (role == ROLE_BUILD) touchBuild = true;
        }
        leftHeld = touchLeft || keyLeft || padLeft;
        rightHeld = touchRight || keyRight || padRight;
        jumpHeld = touchJump || keyJump;
        buildHeld = touchBuild || keyBuild;
    }

    private void releaseAllInput() {
        touches.clear();
        keyLeft = keyRight = keyJump = keyBuild = keyShift = keyMineFront = keyMineDown = false;
        padLeft = padRight = false;
        gridHeld = false; gridMine = false;
        jumpRequested = false;
        refreshHeldButtons();
    }

    @Override public boolean onTouchEvent(MotionEvent event) {
        int action = event.getActionMasked();
        int index = event.getActionIndex();

        if (screen != SCREEN_GAME) {
            if (action == MotionEvent.ACTION_DOWN) {
                pressCenterX = toLogicalX(event.getX(index));
                pressCenterY = toLogicalY(event.getY(index));
                pressUntilNanos = now() + 220000000L;
            } else if (action == MotionEvent.ACTION_UP) {
                int id = uiAt(toLogicalX(event.getX(index)), toLogicalY(event.getY(index)));
                pressUntilNanos = now() + 140000000L;
                if (id >= 0) onUi(id);
            }
            invalidate();
            return true;
        }

        switch (action) {
            case MotionEvent.ACTION_DOWN:
            case MotionEvent.ACTION_POINTER_DOWN:
                addPointer(event, index);
                break;
            case MotionEvent.ACTION_MOVE:
                updatePointers(event);
                break;
            case MotionEvent.ACTION_POINTER_UP:
                releasePointer(event, index);
                break;
            case MotionEvent.ACTION_UP:
                releasePointer(event, index);
                touches.clear();
                gridHeld = false;
                gridMine = false;
                refreshHeldButtons();
                break;
            case MotionEvent.ACTION_CANCEL:
                touches.clear();
                gridHeld = false;
                gridMine = false;
                jumpRequested = false;
                refreshHeldButtons();
                break;
            default:
                break;
        }
        invalidate();
        return true;
    }

    /** Mouse hover and gamepad sticks arrive as generic motion events. */
    @Override public boolean onGenericMotionEvent(MotionEvent e) {
        int src = e.getSource();
        int action = e.getActionMasked();
        if ((src & InputDevice.SOURCE_JOYSTICK) == InputDevice.SOURCE_JOYSTICK
                && action == MotionEvent.ACTION_MOVE) {
            float ax = e.getAxisValue(MotionEvent.AXIS_X);
            float hat = e.getAxisValue(MotionEvent.AXIS_HAT_X);
            padLeft = ax < -0.45f || hat < -0.5f;
            padRight = ax > 0.45f || hat > 0.5f;
            refreshHeldButtons();
            return true;
        }
        if (action == MotionEvent.ACTION_HOVER_MOVE || action == MotionEvent.ACTION_HOVER_ENTER) {
            mouseActive = true;
            updateHover(toLogicalX(e.getX()), toLogicalY(e.getY()));
            return true;
        }
        if (action == MotionEvent.ACTION_HOVER_EXIT) {
            hoverCol = -1; hoverRow = -1;
            return true;
        }
        return super.onGenericMotionEvent(e);
    }

    // ================================================================================
    // Menu actions
    // ================================================================================
    private void openSettings(int from) { settingsBack = from; screen = SCREEN_SETTINGS; }
    private void openGifts(int from) { giftsBack = from; screen = SCREEN_GIFTS; }

    private void leaveTo(int target) {
        screen = target;
        if (target == SCREEN_MENU) lastFrameNanos = 0L;
    }

    private void onUi(int id) {
        if (id >= B_G_ON && id < B_G_LABEL + GameSettings.GIFTS) { onGiftUi(id); return; }
        switch (id) {
            case B_PLAY: startGame(); break;
            case B_GIFTS: openGifts(screen); break;
            case B_SETTINGS: openSettings(screen); break;
            case B_RESUME: resumeGame(); break;
            case B_RETRY: startGame(); break;
            case B_MENU: leaveTo(SCREEN_MENU); break;
            case B_SOUND: cfg.sound = !cfg.sound; cfg.save(); break;
            case B_BUTTONS: cfg.showButtons = !cfg.showButtons; cfg.save(); break;
            case B_UNLIMITED: cfg.unlimited = !cfg.unlimited; cfg.save(); break;
            case B_SPEED: cfg.speed = (cfg.speed + 1) % GameSettings.SPEED_NAMES.length; cfg.save(); break;
            case B_RESET: cfg.resetDefaults(); cfg.save(); break;
            case B_RESET_GIFTS: cfg.resetGifts(); cfg.save(); break;
            case B_BACK:
                if (screen == SCREEN_GIFTS) leaveTo(giftsBack);
                else if (screen == SCREEN_SETTINGS) leaveTo(settingsBack);
                break;
            default: break;
        }
    }

    private void onGiftUi(int id) {
        int base, i;
        if (id >= B_G_LABEL) { base = B_G_LABEL; }
        else if (id >= B_G_PLUS) { base = B_G_PLUS; }
        else if (id >= B_G_AMOUNT) { base = B_G_AMOUNT; }
        else if (id >= B_G_MINUS) { base = B_G_MINUS; }
        else if (id >= B_G_EFFECT) { base = B_G_EFFECT; }
        else if (id >= B_G_ICON) { base = B_G_ICON; }
        else { base = B_G_ON; }
        i = id - base;
        if (i < 0 || i >= GameSettings.GIFTS) return;
        final GameSettings.Gift g = cfg.gifts[i];
        switch (base) {
            case B_G_ON: g.on = !g.on; break;
            case B_G_ICON: g.icon = (g.icon + 1) % GameSettings.ICONS; break;
            case B_G_EFFECT:
                g.effect = (g.effect + 1) % GameSettings.EFFECTS;
                g.clampAmount();
                break;
            case B_G_MINUS: g.amount -= giftStep(g); g.clampAmount(); break;
            case B_G_PLUS: g.amount += giftStep(g); g.clampAmount(); break;
            case B_G_AMOUNT:
                askText("Jumlah (1-" + GameSettings.EFFECT_MAX[g.effect] + ")", String.valueOf(g.amount), true, 3,
                        new TextResult() {
                            @Override public void done(String s) {
                                try { g.amount = Integer.parseInt(s.trim()); } catch (Exception ignored) { return; }
                                g.clampAmount();
                                cfg.save();
                            }
                        });
                return;
            case B_G_LABEL:
                askText("Teks hadiah (kosong = otomatis)", g.label == null ? "" : g.label, false, 9,
                        new TextResult() {
                            @Override public void done(String s) {
                                g.label = s.trim();
                                cfg.save();
                            }
                        });
                return;
            default: return;
        }
        cfg.save();
    }

    private int giftStep(GameSettings.Gift g) {
        return (g.effect == GameSettings.E_BLOCK || g.effect == GameSettings.E_TNT
                || g.effect == GameSettings.E_HEAL) ? 5 : 1;
    }

    /** Simple text / number prompt (works with the on-screen and a hardware keyboard). */
    private void askText(String title, String initial, boolean numeric, final int maxLen, final TextResult cb) {
        try {
            final EditText input = new EditText(getContext());
            input.setText(initial);
            input.setSingleLine(true);
            input.setInputType(numeric ? InputType.TYPE_CLASS_NUMBER : InputType.TYPE_CLASS_TEXT);
            input.setSelectAllOnFocus(true);
            new AlertDialog.Builder(getContext())
                    .setTitle(title)
                    .setView(input)
                    .setPositiveButton("OK", new DialogInterface.OnClickListener() {
                        @Override public void onClick(DialogInterface d, int which) {
                            String s = input.getText().toString();
                            if (s.length() > maxLen) s = s.substring(0, maxLen);
                            cb.done(s);
                        }
                    })
                    .setNegativeButton("Batal", null)
                    .show();
        } catch (Throwable ignored) { }
    }

    // ================================================================================
    // Input: keyboard / gamepad buttons / activity hooks
    // ================================================================================
    public void pauseGame() {
        if (screen != SCREEN_GAME) return;
        screen = SCREEN_PAUSE;
        releaseAllInput();
    }

    private void resumeGame() {
        screen = SCREEN_GAME;
        lastFrameNanos = now();
    }

    /** Called from Activity.onPause. */
    public void onHostPause() {
        pauseGame();
        releaseAllInput();
    }

    /** Back button. Returns true when the game consumed it. */
    public boolean handleBack() {
        if (screen == SCREEN_GAME) { pauseGame(); return true; }
        if (screen == SCREEN_PAUSE) { resumeGame(); return true; }
        if (screen == SCREEN_SETTINGS) { leaveTo(settingsBack); return true; }
        if (screen == SCREEN_GIFTS) { leaveTo(giftsBack); return true; }
        return false;
    }

    @Override public void onWindowFocusChanged(boolean hasWindowFocus) {
        super.onWindowFocusChanged(hasWindowFocus);
        if (!hasWindowFocus) {
            if (screen == SCREEN_GAME) pauseGame();
            releaseAllInput();
        }
    }

    @Override protected void onDetachedFromWindow() {
        release();
        super.onDetachedFromWindow();
    }

    @Override public boolean onKeyDown(int keyCode, KeyEvent event) {
        return handleKeyEvent(event) || super.onKeyDown(keyCode, event);
    }

    @Override public boolean onKeyUp(int keyCode, KeyEvent event) {
        return handleKeyEvent(event) || super.onKeyUp(keyCode, event);
    }

    /**
     * Keyboard / gamepad handling. The activity forwards every key event here, so
     * input works even when the view does not hold focus (Bluetooth / OTG keyboards).
     */
    public boolean handleKeyEvent(KeyEvent e) {
        int code = e.getKeyCode();
        boolean down = e.getAction() == KeyEvent.ACTION_DOWN;
        boolean up = e.getAction() == KeyEvent.ACTION_UP;
        if (!down && !up) return false;
        boolean fresh = down && e.getRepeatCount() == 0;
        if (code == KeyEvent.KEYCODE_BACK) return false;   // handled by Activity.onBackPressed

        if (screen == SCREEN_MENU) {
            if (fresh && isConfirmKey(code)) { startGame(); return true; }
            if (fresh && code == KeyEvent.KEYCODE_O) { openSettings(SCREEN_MENU); return true; }
            if (fresh && code == KeyEvent.KEYCODE_G) { openGifts(SCREEN_MENU); return true; }
            return code == KeyEvent.KEYCODE_ESCAPE;
        }
        if (screen == SCREEN_SETTINGS) {
            if (fresh && (isConfirmKey(code) || code == KeyEvent.KEYCODE_ESCAPE)) { leaveTo(settingsBack); return true; }
            if (fresh && code == KeyEvent.KEYCODE_S) { onUi(B_SOUND); return true; }
            if (fresh && code == KeyEvent.KEYCODE_B) { onUi(B_BUTTONS); return true; }
            if (fresh && code == KeyEvent.KEYCODE_U) { onUi(B_UNLIMITED); return true; }
            if (fresh && code == KeyEvent.KEYCODE_V) { onUi(B_SPEED); return true; }
            if (fresh && code == KeyEvent.KEYCODE_G) { openGifts(SCREEN_SETTINGS); return true; }
            return false;
        }
        if (screen == SCREEN_GIFTS) {
            if (fresh && (isConfirmKey(code) || code == KeyEvent.KEYCODE_ESCAPE)) { leaveTo(giftsBack); return true; }
            if (fresh && code >= KeyEvent.KEYCODE_1 && code <= KeyEvent.KEYCODE_8) {
                onUi(B_G_ON + (code - KeyEvent.KEYCODE_1));
                return true;
            }
            return false;
        }
        if (screen == SCREEN_PAUSE) {
            if (fresh && (isConfirmKey(code) || code == KeyEvent.KEYCODE_ESCAPE || code == KeyEvent.KEYCODE_P
                    || code == KeyEvent.KEYCODE_BUTTON_START)) { resumeGame(); return true; }
            if (fresh && code == KeyEvent.KEYCODE_R) { startGame(); return true; }
            if (fresh && code == KeyEvent.KEYCODE_M) { leaveTo(SCREEN_MENU); return true; }
            if (fresh && code == KeyEvent.KEYCODE_O) { openSettings(SCREEN_PAUSE); return true; }
            if (fresh && code == KeyEvent.KEYCODE_G) { openGifts(SCREEN_PAUSE); return true; }
            return false;
        }

        // ---- in game ----
        switch (code) {
            case KeyEvent.KEYCODE_A:
            case KeyEvent.KEYCODE_DPAD_LEFT:
                keyLeft = down; break;
            case KeyEvent.KEYCODE_D:
            case KeyEvent.KEYCODE_DPAD_RIGHT:
                keyRight = down; break;
            case KeyEvent.KEYCODE_W:
            case KeyEvent.KEYCODE_DPAD_UP:
            case KeyEvent.KEYCODE_SPACE:
            case KeyEvent.KEYCODE_BUTTON_A:
                if (fresh) jumpRequested = true;
                keyJump = down; break;
            case KeyEvent.KEYCODE_SHIFT_LEFT:
            case KeyEvent.KEYCODE_SHIFT_RIGHT:
            case KeyEvent.KEYCODE_BUTTON_R1:
                keyShift = down; break;
            case KeyEvent.KEYCODE_E:
            case KeyEvent.KEYCODE_ENTER:
            case KeyEvent.KEYCODE_NUMPAD_ENTER:
            case KeyEvent.KEYCODE_BUTTON_X:
            case KeyEvent.KEYCODE_BUTTON_R2:
                if (fresh) {
                    breakMode = false;
                    placeUnderPlayer();
                    buildCooldown = cfg.placeInterval() * 2f;
                }
                keyBuild = down; break;
            case KeyEvent.KEYCODE_F:
                if (fresh) placeFront();
                break;
            case KeyEvent.KEYCODE_S:
            case KeyEvent.KEYCODE_DPAD_DOWN:
                keyMineDown = down; if (down) mineCooldown = Math.min(mineCooldown, 0f); break;
            case KeyEvent.KEYCODE_X:
            case KeyEvent.KEYCODE_Z:
            case KeyEvent.KEYCODE_CTRL_LEFT:
            case KeyEvent.KEYCODE_CTRL_RIGHT:
            case KeyEvent.KEYCODE_BUTTON_B:
                keyMineFront = down; if (down) mineCooldown = Math.min(mineCooldown, 0f); break;
            case KeyEvent.KEYCODE_Q:
            case KeyEvent.KEYCODE_BUTTON_Y:
                if (fresh) { breakMode = !breakMode; toast(breakMode ? "MODE BELIUNG" : "MODE BLOK"); }
                break;
            case KeyEvent.KEYCODE_T:
            case KeyEvent.KEYCODE_BUTTON_L1:
                if (fresh) dropTnt();
                break;
            case KeyEvent.KEYCODE_P:
            case KeyEvent.KEYCODE_ESCAPE:
            case KeyEvent.KEYCODE_BUTTON_START:
            case KeyEvent.KEYCODE_MENU:
                if (fresh) pauseGame();
                break;
            default:
                if (code >= KeyEvent.KEYCODE_1 && code <= KeyEvent.KEYCODE_8) {
                    if (fresh) triggerShownGift(code - KeyEvent.KEYCODE_1);
                } else if (code >= KeyEvent.KEYCODE_NUMPAD_1 && code <= KeyEvent.KEYCODE_NUMPAD_8) {
                    if (fresh) triggerShownGift(code - KeyEvent.KEYCODE_NUMPAD_1);
                } else {
                    return false;
                }
        }
        refreshHeldButtons();
        return true;
    }

    private boolean isConfirmKey(int code) {
        return code == KeyEvent.KEYCODE_ENTER || code == KeyEvent.KEYCODE_NUMPAD_ENTER
                || code == KeyEvent.KEYCODE_SPACE || code == KeyEvent.KEYCODE_DPAD_CENTER
                || code == KeyEvent.KEYCODE_BUTTON_A || code == KeyEvent.KEYCODE_BUTTON_START;
    }
}
