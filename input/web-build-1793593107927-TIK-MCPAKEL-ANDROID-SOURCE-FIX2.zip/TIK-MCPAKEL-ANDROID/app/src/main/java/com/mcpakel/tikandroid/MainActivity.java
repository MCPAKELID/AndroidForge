package com.mcpakel.tikandroid;

import android.app.*;
import android.os.*;
import android.content.*;
import android.graphics.Color;
import android.view.*;
import android.widget.*;

public class MainActivity extends Activity {
    LinearLayout root; TextView status,logs; EditText username,port;
    @Override public void onCreate(Bundle b){super.onCreate(b); buildUi();}
    private TextView text(String s,int size,int color){TextView t=new TextView(this);t.setText(s);t.setTextSize(size);t.setTextColor(color);t.setPadding(4,8,4,8);return t;}
    private Button button(String s){Button b=new Button(this);b.setText(s);return b;}
    private void buildUi(){
        root=new LinearLayout(this);root.setOrientation(1);root.setPadding(24,24,24,24);root.setBackgroundColor(Color.rgb(13,18,26));
        TextView title=text("TIK MCPAKEL",26,Color.WHITE);title.setGravity(Gravity.CENTER);root.addView(title);
        ImageView banner=new ImageView(this);try{banner.setImageDrawable(android.graphics.drawable.Drawable.createFromStream(getAssets().open("mcpakel-social-banner.png"),null));}catch(Exception ignored){} banner.setAdjustViewBounds(true);banner.setScaleType(ImageView.ScaleType.FIT_CENTER);root.addView(banner);
        status=text("STATUS: STOPPED",18,0xffff6464);status.setGravity(Gravity.CENTER);root.addView(status);
        username=new EditText(this);username.setSingleLine(true);username.setHint("Username TikTok (tanpa @)");root.addView(username);
        port=new EditText(this);port.setSingleLine(true);port.setInputType(2);port.setText("3000");port.setHint("Port WebSocket");root.addView(port);
        LinearLayout row=new LinearLayout(this);
        Button start=button("START"),restart=button("RESTART"),stop=button("STOP");
        row.addView(start,new LinearLayout.LayoutParams(0,-2,1));row.addView(restart,new LinearLayout.LayoutParams(0,-2,1));row.addView(stop,new LinearLayout.LayoutParams(0,-2,1));root.addView(row);
        TextView config=text("PENGATURAN",16,Color.WHITE);root.addView(config);
        TextView note=text("Node.js 24 tertanam • TikTok LIVE 2.4.4 • Minecraft WebSocket",13,0xffb8c4d4);root.addView(note);
        logs=text("Console siap. Tekan START untuk menjalankan bridge.",12,0xff66e0b8);root.addView(logs);
        start.setOnClickListener(v->startServiceNow());
        restart.setOnClickListener(v->{stopServiceNow();new Handler().postDelayed(this::startServiceNow,500);});
        stop.setOnClickListener(v->stopServiceNow());
        setContentView(root);
    }
    private void startServiceNow(){
        if(Build.VERSION.SDK_INT>=33 && checkSelfPermission("android.permission.POST_NOTIFICATIONS")!=android.content.pm.PackageManager.PERMISSION_GRANTED){requestPermissions(new String[]{"android.permission.POST_NOTIFICATIONS"},90);}
        Intent i=new Intent(this,NodeService.class);i.setAction(NodeService.ACTION_START);
        if(Build.VERSION.SDK_INT>=26)startForegroundService(i);else startService(i);
        status.setText("STATUS: STARTING");status.setTextColor(0xffffc857);logs.setText("Memulai Node.js bridge...");
    }
    private void stopServiceNow(){Intent i=new Intent(this,NodeService.class);i.setAction(NodeService.ACTION_STOP);startService(i);status.setText("STATUS: STOPPED");status.setTextColor(0xffff6464);logs.setText("Server dihentikan.");}
}
