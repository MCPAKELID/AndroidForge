package com.mcpakel.tikandroid;

import android.app.*;
import android.content.*;
import android.os.*;
import java.io.*;
import java.util.concurrent.atomic.AtomicBoolean;

public class NodeService extends Service {
    public static final String ACTION_START="com.mcpakel.tikandroid.START";
    public static final String ACTION_STOP="com.mcpakel.tikandroid.STOP";
    private static final int NOTIFY_ID=701;
    private Thread nodeThread;
    private final AtomicBoolean running=new AtomicBoolean(false);
    @Override public void onCreate(){ super.onCreate(); createChannel(); }
    @Override public int onStartCommand(Intent intent,int flags,int startId){
        String action=intent==null?ACTION_START:intent.getAction();
        if(ACTION_STOP.equals(action)){ stopNode(); stopForeground(true); stopSelf(); return START_NOT_STICKY; }
        startForeground(NOTIFY_ID,notification("Node.js bridge berjalan"));
        startNode();
        return START_STICKY;
    }
    private void startNode(){
        if(!running.compareAndSet(false,true)) return;
        nodeThread=new Thread(()->{
            try {
                File root=new File(getFilesDir(),"nodejs-project");
                copyAssets("nodejs-project",root);
                File settings=new File(root,"settings.json");
                if(!settings.exists()) try(FileWriter w=new FileWriter(settings)){w.write("{\"username\":\"\",\"port\":3000}");}
                String[] args={"node",new File(root,"index.js").getAbsolutePath()};
                new NodeRunner().startNode(args);
            } catch(Exception e) { android.util.Log.e("TIK-MCPAKEL","Node start failed",e); }
            finally { running.set(false); }
        },"node-runtime");
        nodeThread.start();
    }
    private void stopNode(){ running.set(false); if(nodeThread!=null) nodeThread.interrupt(); }
    private void copyAssets(String path,File dest)throws IOException{
        String[] children=getAssets().list(path);
        if(children!=null && children.length>0){ if(!dest.exists())dest.mkdirs(); for(String child:children)copyAssets(path+"/"+child,new File(dest,child)); }
        else { if(dest.exists())return; File p=dest.getParentFile();if(p!=null)p.mkdirs();try(InputStream in=getAssets().open(path);OutputStream out=new FileOutputStream(dest)){byte[] b=new byte[8192];int n;while((n=in.read(b))>0)out.write(b,0,n);} }
    }
    private void createChannel(){ if(Build.VERSION.SDK_INT>=26){NotificationChannel c=new NotificationChannel("tik_bridge","TIK MCPAKEL",NotificationManager.IMPORTANCE_LOW);((NotificationManager)getSystemService(NOTIFICATION_SERVICE)).createNotificationChannel(c);} }
    private Notification notification(String text){
        Intent stop=new Intent(this,NodeService.class);stop.setAction(ACTION_STOP);
        PendingIntent pi=PendingIntent.getService(this,2,stop,PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);
        Notification.Builder b=Build.VERSION.SDK_INT>=26?new Notification.Builder(this,"tik_bridge"):new Notification.Builder(this);
        return b.setContentTitle("TIK MCPAKEL").setContentText(text).setSmallIcon(android.R.drawable.stat_notify_sync).addAction(new Notification.Action.Builder(null,"STOP",pi).build()).build();
    }
    @Override public void onDestroy(){stopNode();super.onDestroy();}
    @Override public android.os.IBinder onBind(Intent i){return null;}
}
