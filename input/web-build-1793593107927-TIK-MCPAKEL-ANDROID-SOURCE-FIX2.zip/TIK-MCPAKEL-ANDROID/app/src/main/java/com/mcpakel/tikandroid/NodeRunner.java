package com.mcpakel.tikandroid;
public final class NodeRunner {
    static { System.loadLibrary("node"); System.loadLibrary("native-lib"); }
    public native int startNode(String[] args);
}
