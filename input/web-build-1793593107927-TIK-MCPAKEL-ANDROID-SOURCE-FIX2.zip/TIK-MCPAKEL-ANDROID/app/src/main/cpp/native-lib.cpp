#include <jni.h>
#include <cstdlib>
#include <cstring>
#include <string>
#include "node.h"

extern "C" JNIEXPORT jint JNICALL
Java_com_mcpakel_tikandroid_NodeRunner_startNode(JNIEnv *env, jobject, jobjectArray arguments) {
    jsize count = env->GetArrayLength(arguments);
    if (count <= 0) return -1;
    char **argv = (char**) calloc((size_t)count + 1, sizeof(char*));
    if (!argv) return -2;
    for (jsize i = 0; i < count; i++) {
        jstring value = (jstring) env->GetObjectArrayElement(arguments, i);
        const char *utf = env->GetStringUTFChars(value, nullptr);
        argv[i] = strdup(utf ? utf : "");
        if (utf) env->ReleaseStringUTFChars(value, utf);
        env->DeleteLocalRef(value);
    }
    int result = node::Start(count, argv);
    for (jsize i = 0; i < count; i++) free(argv[i]);
    free(argv);
    return result;
}
