# Android backend notes
- WhatsApp/Baileys intentionally excluded.
- Interactive readline prompts are not supported in the Android panel; use settings.json.
- Node dependencies must be bundled into `node_modules` during CI/build.
- Node mobile runtime does not provide a normal child-process environment. Avoid spawning child processes.
