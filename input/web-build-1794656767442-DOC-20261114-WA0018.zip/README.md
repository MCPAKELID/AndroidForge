# BlockRush Live Game v20 — AndroidForge Source

## Kontrol

| Aksi | Sentuh | Keyboard | Mouse |
|---|---|---|---|
| Jalan kiri / kanan | tombol ◀ ▶ | A / D atau panah | – |
| Lompat (tahan = lompat terus) | tombol ⬆ | W / Spasi / panah atas | – |
| Lari | tombol lari | tahan Shift | – |
| Pasang blok (tahan = beruntun) | tombol blok | E / F / Enter | klik kiri di kolom mana pun |
| Gali blok | mode beliung lalu ketuk blok | X / Z / Ctrl (depan), S / panah bawah (bawah) | klik kanan |
| Mode beliung | tombol beliung | Q | – |
| Jatuhkan TNT | ketuk panel nyawa/TNT | T | klik panel nyawa/TNT |
| Hadiah 1–8 | ketuk ikon hadiah | tombol 1–8 | klik ikon hadiah |
| Jeda / lanjut | tombol jeda, Back | Esc / P | klik tombol jeda |

Gamepad: D-pad / stik kiri jalan, A lompat, X blok, B gali, Y beliung, L1 TNT, R1 lari, Start jeda.
Keyboard dan mouse (Bluetooth atau OTG) bisa dipasang/dicabut saat game berjalan tanpa me-restart game.

## Perubahan v20

- HUD seperti referensi: jumlah blok `n/100`, piala `x/10`, persen area, bar hijau bersegmen, baris 8 ikon hadiah, minimap vertikal di kanan (strip lapisan, kotak kamera, penanda pemain), panel nyawa + jumlah TNT.
- Inventori blok (maks 100): memasang blok memakai 1, menggali menambah 1, plus regen pelan.
- TNT: jatuh, berkedip, meledak (kawah 5x5 membulat), reaksi berantai, getar layar, partikel, melukai pemain; perisai 0% dan nyawa 100% dari hadiah.
- Blok yang melayang setelah digali/diledakkan jatuh ke bawah.
- Material ladder mengikuti referensi: dirt di dasar, lalu tiap material 2 baris (stone dengan bijih acak, cobble, stone brick, brick merah, papan, sandstone).
- Suara (lompat, langkah, lari, mendarat) sekarang benar-benar diputar dan mengikuti pengaturan SUARA.
- Layout otomatis di-letterbox pada layar lebar/tablet/Chromebook; manifest tidak butuh layar sentuh.
- Rendering memakai hardware acceleration dan sinkron vsync.

## Build

Import ZIP ini dengan isi diekstrak langsung ke workspace proyek AndroidForge (root berisi `settings.gradle` dan `build.gradle`). Build modul `app` dengan JDK 17 dan Android SDK Platform 35.

Application ID: `com.mcpakel.blockarea`  
Versi: 2.0 (versionCode 20)

Kode dikompilasi dan dijalankan di lingkungan uji dengan API Android tiruan (menggambar ke Java2D) untuk menguji logika, input keyboard/mouse/sentuh, dan tampilan. APK asli belum dibuild dan belum dites di perangkat Android karena Android SDK tidak tersedia di sini. Jika build melaporkan error, kirim lognya.
