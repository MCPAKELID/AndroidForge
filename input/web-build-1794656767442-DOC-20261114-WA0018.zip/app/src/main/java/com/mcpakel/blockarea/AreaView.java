package com.mcpakel.blockarea;

import android.app.Activity;
import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Rect;
import android.graphics.RectF;
import android.graphics.Typeface;
import android.media.AudioAttributes;
import android.media.SoundPool;
import android.os.Build;
import android.util.SparseArray;
import android.view.InputDevice;
import android.view.KeyEvent;
import android.view.MotionEvent;
import android.view.View;

import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.util.Locale;
import java.util.Random;

/**
 * Block Rush: stack blocks, climb, mine and blow things up with TNT.
 *
 * Input: touch (on-screen buttons), keyboard and mouse (Bluetooth / OTG / built-in)
 * and simple gamepads. Everything is drawn on one Canvas in a 512-unit wide world.
 */
public class AreaView extends View {
    // ---- world / layout -------------------------------------------------------------
    private static final float WORLD_W = 512f;
    private static final float BOARD_H = 1935f;
    private static final float MIN_LOGICAL_H = 700f;
    private static final float MAX_CONTROL_H = 384f;
    private static final float MIN_CONTROL_H = 140f;
    private static final int COLS = 10, ROWS = 40, BLOCK_TYPES = 48, TNT_TYPE = 28;
    private static final int BUILD_LIMIT_ROW = 0;
    private static final float GRID_X = 41f, GRID_Y = 132f, CELL = 43f;
    private static final float PLAYER_H = CELL * 2f;
    private static final float PLAYER_HALF_W = CELL * 0.32f;
    private static final float GRAVITY = 1850f, JUMP_SPEED = 720f;
    private static final float AREA_TOP = 152f;
    private static final float PLAYER_SCREEN_RATIO = 0.72f;

    private static final int GIFTS = 8, MAX_INVENTORY = 100, MAX_TNT = 24;
    private static final int MAX_PARTICLES = 220, MAX_FX = 8;
    // Material ladder from the floor up: dirt, then two rows per material.
    private static final int[] LADDER = {1, 2, 3, 4, 5, 33, 6, 10, 11};
    private static final int[] ORES = {12, 13, 14, 15, 16, 17, 18};
    private static final String[] GIFT_TOAST = {
            "+60 BLOK", "+20 TNT", "+45 TNT", "HUJAN TNT x6",
            "TURBO 10 DETIK", "NYAWA 100%", "PERISAI 0% DAMAGE", "+5 TNT"};

    private static final int ROLE_NONE = 0, ROLE_LEFT = 1, ROLE_RIGHT = 2, ROLE_JUMP = 3,
            ROLE_RUN = 4, ROLE_PICK = 5, ROLE_BUILD = 6, ROLE_GRID = 7, ROLE_PAUSE = 8,
            ROLE_GIFT = 9, ROLE_TNT = 10;
    private static final int SCREEN_MENU = 0, SCREEN_GAME = 1, SCREEN_PAUSE = 2, SCREEN_SETTINGS = 3;

    private static final class TouchPoint {
        int role, arg;
        boolean mouse;
        float x, y;
        TouchPoint(int role, float x, float y) { this.role = role; this.x = x; this.y = y; }
    }

    private final Paint paint = new Paint();
    private final RectF tmp = new RectF();
    private final Random rnd = new Random();
    private final int[][] blocks = new int[ROWS][COLS];
    private final long[][] blockPlacedAt = new long[ROWS][COLS];
    private final RectF[] menuHits = new RectF[4];
    private final RectF[] pauseHits = new RectF[4];
    private final RectF[] settingsHits = new RectF[3];
    private final RectF[] giftRects = new RectF[GIFTS];
    private final RectF tntRect = new RectF();
    private final RectF pauseRect = new RectF(424f, 158f, 466f, 200f);
    private final Bitmap[] blockTextures = new Bitmap[BLOCK_TYPES];
    private final int[] blockColor = new int[BLOCK_TYPES];
    private final Bitmap[] giftTiles = new Bitmap[GIFTS];
    private final Bitmap[][] characterFrames = new Bitmap[3][5];
    private final SparseArray<TouchPoint> touches = new SparseArray<>();

    private Bitmap arena, hud, fontAtlas, placementFrame;
    private Bitmap menuBackground, menuMainButton, menuPauseButton, menuSettingsButton, menuExitButton;
    private Bitmap pauseButton, continueButton, retryButton, menuButton, exitButton;
    private Bitmap soundOnButton, soundOffButton, musicButton, backButton;
    private Bitmap leftImage, rightImage, runImage, pickImage, blockImage, jumpImage;

    // Visible control images and larger touch hitboxes.
    private final RectF[] hit = new RectF[6];
    private final RectF[] icon = new RectF[6];

    // ---- player ---------------------------------------------------------------------
    private float playerX, playerFeet, velocityY;
    private float cameraY, cameraTarget;
    private float animationClock, stepClock, impactVy;
    private long lastFrameNanos;
    private boolean grounded = true, wasGrounded = true, facingRight = true;
    private boolean jumpRequested = false;
    private int walkFrame = 0, runFrame = 0, jumpFrame = 0;

    // ---- input state ----------------------------------------------------------------
    private boolean touchLeft, touchRight, touchJump, touchBuild;
    private boolean keyLeft, keyRight, keyJump, keyBuild, keyShift, keyMineFront, keyMineDown;
    private boolean padLeft, padRight;
    private boolean sprintToggle = false;
    private boolean leftHeld, rightHeld, jumpHeld, buildHeld;
    private boolean breakMode = false;
    private boolean mouseActive = false, mouseGridHold = false;
    private int mouseButton = 0;                 // 1 = primary, 2 = secondary
    private int hoverCol = -1, hoverRow = -1;
    private int targetCol = -1, targetRow = -1;
    private int hitArg = -1;
    private float breakCooldown = 0f, mineCooldown = 0f;

    // ---- game state -----------------------------------------------------------------
    private int screen = SCREEN_MENU;
    private boolean soundEnabled = true, musicEnabled = true;
    private int inventory = 30, tntStock = 15, winCount = 0;
    private float hp = 100f;
    private float gameClock = 0f, regenClock = 0f, settleClock = 0f;
    private float turboUntil = -1f, shieldUntil = -1f;
    private String toastText = "";
    private float toastUntil = -1f;
    private final float[] giftFlash = new float[GIFTS];
    private int rainLeft = 0;
    private float rainClock = 0f;
    private long playerPlaceUntilNanos = 0L;
    private float pressCenterX = -1000f, pressCenterY = -1000f;
    private long pressUntilNanos = 0L;
    private int countdownValue = -1;
    private long countdownNextNanos = 0L;
    private float shake = 0f;

    // A newly placed block falls from above to the green preview cell.
    private boolean fallingBlockActive = false, fallingLiftPlayer = false;
    private int fallingCol = -1, fallingRow = -1, fallingType = 0;
    private float fallingY, fallingStartY, fallingEndY, fallingElapsed, fallingDuration;

    // TNT entities.
    private final boolean[] tntOn = new boolean[MAX_TNT];
    private final float[] tntY = new float[MAX_TNT], tntVy = new float[MAX_TNT], tntFuse = new float[MAX_TNT];
    private final int[] tntCol = new int[MAX_TNT];

    // Particles and explosion rings.
    private final float[] px = new float[MAX_PARTICLES], py = new float[MAX_PARTICLES];
    private final float[] pvx = new float[MAX_PARTICLES], pvy = new float[MAX_PARTICLES];
    private final float[] plife = new float[MAX_PARTICLES];
    private final int[] pcol = new int[MAX_PARTICLES];
    private final float[] fxX = new float[MAX_FX], fxY = new float[MAX_FX], fxT = new float[MAX_FX];

    // Sound.
    private SoundPool pool;
    private int sJump, sLand, sStep, sRun;

    public AreaView(Context context) {
        super(context);
        arena = load("area/arena_reference.png");
        hud = load("ui/hud_top.png");
        fontAtlas = load("font/pixel_font.png");
        placementFrame = load("blocks/placement_frame.png");
        leftImage = load("ui/control_left.png");
        rightImage = load("ui/control_right.png");
        runImage = load("ui/control_run.png");
        pickImage = load("ui/control_pickaxe.png");
        blockImage = load("ui/control_block.png");
        jumpImage = load("ui/control_jump.png");
        menuBackground = load("menu/background.jpg");
        menuMainButton = load("menu/menu_main.png");
        menuPauseButton = load("menu/menu_pause.png");
        menuSettingsButton = load("menu/menu_settings.png");
        menuExitButton = load("menu/button_exit.png");
        pauseButton = load("menu/icon_pause.png");
        continueButton = load("menu/button_continue.png");
        retryButton = load("menu/button_retry.png");
        menuButton = load("menu/button_menu.png");
        exitButton = load("menu/button_exit.png");
        soundOnButton = load("menu/icon_volume.png");
        soundOffButton = load("menu/icon_mute.png");
        musicButton = load("menu/icon_music.png");
        backButton = load("menu/button_back.png");

        for (int i = 0; i < menuHits.length; i++) menuHits[i] = new RectF();
        for (int i = 0; i < pauseHits.length; i++) pauseHits[i] = new RectF();
        for (int i = 0; i < settingsHits.length; i++) settingsHits[i] = new RectF();

        for (int i = 0; i < BLOCK_TYPES; i++) {
            blockTextures[i] = load(String.format(Locale.US, "blocks/block_%02d.png", i));
            blockColor[i] = averageColor(blockTextures[i]);
        }
        String[] actions = {"walk", "run", "jump"};
        for (int a = 0; a < 3; a++) {
            for (int f = 0; f < 5; f++) {
                characterFrames[a][f] = load("character/" + actions[a] + "_" + f + ".png");
            }
        }
        float tileW = 49f, gap = 5.5f;
        float startX = (WORLD_W - (GIFTS * tileW + (GIFTS - 1) * gap)) / 2f;
        for (int i = 0; i < GIFTS; i++) {
            giftTiles[i] = load("ui/gift_" + i + ".png");
            giftRects[i] = new RectF(startX + i * (tileW + gap), 88f,
                    startX + i * (tileW + gap) + tileW, 88f + tileW * 67f / 56f);
        }
        for (int r = 0; r < ROWS; r++) for (int c = 0; c < COLS; c++) blocks[r][c] = -1;
        for (int i = 0; i < 6; i++) { hit[i] = new RectF(); icon[i] = new RectF(); }
        for (int i = 0; i < MAX_FX; i++) fxT[i] = -1f;

        playerX = GRID_X + (COLS * CELL) / 2f;
        playerFeet = GRID_Y + ROWS * CELL;
        paint.setFilterBitmap(false);
        paint.setAntiAlias(false);

        initSound();
        setFocusable(true);
        setFocusableInTouchMode(true);
        if (Build.VERSION.SDK_INT >= 26) setDefaultFocusHighlightEnabled(false);
        requestFocus();
    }

    // ================================================================================
    // Resources
    // ================================================================================
    private Bitmap load(String path) {
        InputStream in = null;
        try {
            in = getContext().getAssets().open(path);
            return BitmapFactory.decodeStream(in);
        } catch (Exception e) {
            return null;
        } finally {
            try { if (in != null) in.close(); } catch (Exception ignored) { }
        }
    }

    private int averageColor(Bitmap b) {
        if (b == null || b.getWidth() < 4 || b.getHeight() < 4) return 0xff8a8a8a;
        long r = 0, g = 0, bl = 0;
        int n = 0;
        for (int yy = 0; yy < 4; yy++) {
            for (int xx = 0; xx < 4; xx++) {
                int p = b.getPixel((xx * 2 + 1) * b.getWidth() / 8, (yy * 2 + 1) * b.getHeight() / 8);
                r += (p >> 16) & 255; g += (p >> 8) & 255; bl += p & 255; n++;
            }
        }
        return 0xff000000 | ((int) (r / n) << 16) | ((int) (g / n) << 8) | (int) (bl / n);
    }

    private void initSound() {
        try {
            AudioAttributes attrs = new AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_GAME)
                    .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION).build();
            pool = new SoundPool.Builder().setMaxStreams(6).setAudioAttributes(attrs).build();
            sJump = loadSound("jump");
            sLand = loadSound("land");
            sStep = loadSound("footstep");
            sRun = loadSound("run_step");
        } catch (Throwable t) {
            pool = null;
        }
    }

    private int loadSound(String name) {
        try {
            File f = new File(getContext().getCacheDir(), "snd_" + name + ".wav");
            if (!f.exists() || f.length() == 0) {
                InputStream in = getContext().getAssets().open("sounds/" + name + ".wav");
                FileOutputStream out = new FileOutputStream(f);
                byte[] buf = new byte[4096];
                int n;
                while ((n = in.read(buf)) > 0) out.write(buf, 0, n);
                out.close();
                in.close();
            }
            return pool.load(f.getAbsolutePath(), 1);
        } catch (Throwable t) {
            return 0;
        }
    }

    private void play(int id, float volume, float rate) {
        if (pool == null || !soundEnabled || id == 0) return;
        try { pool.play(id, volume, volume, 1, 0, rate); } catch (Throwable ignored) { }
    }

    /** Called by the activity when it is destroyed. */
    public void release() {
        if (pool != null) {
            try { pool.release(); } catch (Throwable ignored) { }
            pool = null;
        }
    }

    protected long now() { return System.nanoTime(); }

    // ================================================================================
    // Layout helpers
    // ================================================================================
    private float scale() { return Math.min(getWidth() / WORLD_W, getHeight() / MIN_LOGICAL_H); }
    private float offsetX() { return (getWidth() - WORLD_W * scale()) * 0.5f; }
    private float logicalHeight() { return getHeight() / Math.max(0.001f, scale()); }
    private float controlHeight() {
        return Math.min(MAX_CONTROL_H, Math.max(MIN_CONTROL_H, logicalHeight() - BOARD_H));
    }
    private float controlTop() { return logicalHeight() - controlHeight(); }
    private float areaTop() { return Math.min(AREA_TOP, Math.max(0f, controlTop() - 360f)); }
    private float boardViewportHeight() { return Math.max(360f, controlTop() - areaTop()); }
    private float worldToScreenY(float y) { return areaTop() + y - cameraY; }
    private int clamp(int value, int min, int max) { return Math.max(min, Math.min(max, value)); }
    private float clampFloat(float v, float min, float max) { return Math.max(min, Math.min(max, v)); }
    private int playerColumn() { return clamp((int) ((playerX - GRID_X) / CELL), 0, COLS - 1); }
    private float toLogicalX(float pxv) { return (pxv - offsetX()) / Math.max(0.001f, scale()); }
    private float toLogicalY(float pyv) { return pyv / Math.max(0.001f, scale()); }

    // ================================================================================
    // Board queries
    // ================================================================================
    private int topBlockRow(int col) {
        for (int r = BUILD_LIMIT_ROW; r < ROWS; r++) if (blocks[r][col] >= 0) return r;
        return ROWS;
    }

    private int blockCount() {
        int n = 0;
        for (int[] row : blocks) for (int v : row) if (v >= 0) n++;
        return n;
    }

    // Percentage is based on all 400 playable cells.
    private int areaPercent() {
        return Math.min(100, Math.round(blockCount() * 100f / (COLS * ROWS)));
    }

    // Floor row = dirt, then every material lasts two rows.
    private int materialForRow(int row) {
        int layer = (ROWS - 1) - row;
        int idx = layer == 0 ? 0 : 1 + (layer - 1) / 2;
        return LADDER[idx % LADDER.length];
    }

    private int pickType(int row) {
        int base = materialForRow(row);
        if (base == 2 && rnd.nextInt(100) < 12) return ORES[rnd.nextInt(ORES.length)];
        return base;
    }

    private boolean isSprint() { return sprintToggle || keyShift; }
    private boolean turboOn() { return gameClock < turboUntil; }
    private boolean shieldOn() { return gameClock < shieldUntil; }

    private void layoutControls() {
        float y = controlTop() + (controlHeight() - 84f) / 2f;
        float[] xs = {2, 86, 170, 268, 352, 436};
        for (int i = 0; i < 6; i++) {
            hit[i].set(xs[i] - 4, y - 4, xs[i] + 78, y + 82);
            icon[i].set(xs[i] + 2, y + 2, xs[i] + 76, y + 80);
        }
    }

    // ================================================================================
    // Drawing primitives
    // ================================================================================
    private void drawBitmap(Canvas canvas, Bitmap bitmap, RectF dst) {
        if (bitmap == null) return;
        paint.setAlpha(255); paint.setFilterBitmap(false); paint.clearShadowLayer();
        canvas.drawBitmap(bitmap, null, dst, paint);
    }

    private void blit(Canvas c, Bitmap b, float l, float t, float r, float bt, boolean smooth) {
        if (b == null) return;
        tmp.set(l, t, r, bt);
        paint.setAlpha(255); paint.setFilterBitmap(smooth);
        c.drawBitmap(b, null, tmp, paint);
        paint.setFilterBitmap(false);
    }

    private void fill(Canvas c, float l, float t, float r, float b, int color) {
        paint.setStyle(Paint.Style.FILL);
        paint.setColor(color);
        c.drawRect(l, t, r, b, paint);
    }

    private void drawOutlined(Canvas canvas, String text, float cx, float y, float size, float stroke) {
        paint.setTypeface(Typeface.create("sans-serif-black", Typeface.BOLD));
        paint.setTextAlign(Paint.Align.CENTER);
        paint.setTextSize(size);
        paint.setStrokeWidth(stroke);
        paint.setStyle(Paint.Style.STROKE);
        paint.setColor(0xff111318);
        canvas.drawText(text, cx, y, paint);
        paint.setStyle(Paint.Style.FILL);
        paint.setColor(0xffffffff);
        canvas.drawText(text, cx, y, paint);
    }

    private void drawMenuTitle(Canvas canvas, String text, float centerX, float y, float size) {
        drawOutlined(canvas, text, centerX, y, size, 6f);
    }

    private void drawBitmapMenu(Canvas canvas, Bitmap bitmap, RectF dst) {
        if (bitmap == null) return;
        paint.setAlpha(255);
        paint.setFilterBitmap(true);
        paint.clearShadowLayer();
        float cx = (dst.left + dst.right) * 0.5f, cy = (dst.top + dst.bottom) * 0.5f;
        boolean pressed = now() < pressUntilNanos
                && pressCenterX >= dst.left && pressCenterX <= dst.right
                && pressCenterY >= dst.top && pressCenterY <= dst.bottom;
        if (pressed) {
            float s = 0.94f;
            float w = dst.width() * s, h = dst.height() * s;
            tmp.set(cx - w / 2f, cy - h / 2f, cx + w / 2f, cy + h / 2f);
            canvas.drawBitmap(bitmap, null, tmp, paint);
        } else {
            canvas.drawBitmap(bitmap, null, dst, paint);
        }
        paint.setFilterBitmap(false);
    }

    // ================================================================================
    // Main draw loop
    // ================================================================================
    @Override protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        if (getWidth() <= 0 || getHeight() <= 0) return;
        float sc = scale();
        canvas.drawColor(0xff0b0d14);
        canvas.save();
        canvas.translate(offsetX(), 0f);
        canvas.scale(sc, sc);
        canvas.clipRect(0f, 0f, WORLD_W, logicalHeight());

        if (screen == SCREEN_MENU) {
            drawMenuScreen(canvas);
            canvas.restore();
            postInvalidateOnAnimation();
            return;
        }
        if (screen == SCREEN_SETTINGS) {
            drawSettingsScreen(canvas);
            canvas.restore();
            postInvalidateOnAnimation();
            return;
        }

        layoutControls();
        if (lastFrameNanos == 0) {
            float minCamera = -PLAYER_H * 1.2f;
            cameraY = clampFloat(playerFeet - boardViewportHeight() * PLAYER_SCREEN_RATIO,
                    minCamera, Math.max(minCamera, BOARD_H - boardViewportHeight()));
        }

        canvas.drawColor(0xff38a6fd);
        if (arena != null) {
            float arenaTop = areaTop() - cameraY;
            float arenaBottom = Math.max(logicalHeight(), areaTop() + BOARD_H - cameraY);
            tmp.set(0, arenaTop, WORLD_W, arenaBottom);
            drawBitmap(canvas, arena, tmp);
        }

        // Only the interactive world objects are clipped to the play viewport.
        canvas.save();
        canvas.clipRect(0, areaTop(), WORLD_W, controlTop());
        if (shake > 0.01f) {
            canvas.translate((rnd.nextFloat() - 0.5f) * shake * 7f, (rnd.nextFloat() - 0.5f) * shake * 7f);
        }
        if (arena == null) fill(canvas, 0, areaTop(), WORLD_W, controlTop(), 0xff20232a);
        drawPlacedBlocks(canvas);
        drawFallingBlock(canvas);
        drawTnt(canvas);
        drawPlacementTarget(canvas);
        drawPlayer(canvas);
        drawEffects(canvas);
        canvas.restore();

        drawHud(canvas);
        drawGiftRow(canvas);
        drawMinimap(canvas);
        drawHpPanel(canvas);
        drawPauseControl(canvas);
        drawControls(canvas);
        if (toastUntil > gameClock) drawToast(canvas);
        if (countdownValue >= 0) drawRoundCountdown(canvas);
        if (screen == SCREEN_PAUSE) drawPauseScreen(canvas);

        canvas.restore();

        if (screen == SCREEN_GAME) updatePhysics();
        postInvalidateOnAnimation();
    }

    private void drawMenuScreen(Canvas canvas) {
        float h = logicalHeight();
        if (menuBackground != null) {
            float bgW = h * menuBackground.getWidth() / Math.max(1f, menuBackground.getHeight());
            float left = (WORLD_W - bgW) * 0.5f;
            tmp.set(left, 0, left + bgW, h);
            drawBitmapMenu(canvas, menuBackground, new RectF(tmp));
        }
        float mainW = 460f, mainH = mainW * 246f / 529f;
        float settingsW = 470f, settingsH = settingsW * 241f / 654f;
        float exitW = 420f, exitH = exitW * 145f / 430f;
        float gap = 12f;
        float total = mainH + settingsH + exitH + gap * 2f;
        float top = (h - total) * 0.5f + 54f;
        float titleY = Math.max(105f, top - 45f);
        drawMenuTitle(canvas, "BLOCK RUSH", WORLD_W * 0.5f, titleY, 38f);

        RectF r0 = new RectF((WORLD_W - mainW) / 2f, top, (WORLD_W + mainW) / 2f, top + mainH);
        RectF r1 = new RectF((WORLD_W - settingsW) / 2f, r0.bottom + gap,
                (WORLD_W + settingsW) / 2f, r0.bottom + gap + settingsH);
        RectF r2 = new RectF((WORLD_W - exitW) / 2f, r1.bottom + gap,
                (WORLD_W + exitW) / 2f, r1.bottom + gap + exitH);
        menuHits[0].set(r0); menuHits[1].set(r1); menuHits[2].set(r2);
        drawBitmapMenu(canvas, menuMainButton, r0);
        drawBitmapMenu(canvas, menuSettingsButton, r1);
        drawBitmapMenu(canvas, menuExitButton, r2);
        drawKeyHints(canvas, h - 74f);
    }

    private void drawKeyHints(Canvas canvas, float y) {
        drawOutlined(canvas, "KEYBOARD: A/D atau panah = jalan  |  W/Spasi = lompat  |  Shift = lari",
                WORLD_W / 2f, y, 11f, 3.5f);
        drawOutlined(canvas, "E/Enter = pasang blok  |  Q = beliung  |  X/S = gali  |  T = TNT  |  1-8 = hadiah",
                WORLD_W / 2f, y + 17f, 11f, 3.5f);
        drawOutlined(canvas, "MOUSE: klik kiri = pasang blok  |  klik kanan = gali  |  Esc = jeda",
                WORLD_W / 2f, y + 34f, 11f, 3.5f);
    }

    private void drawSettingsScreen(Canvas canvas) {
        float h = logicalHeight();
        if (menuBackground != null) {
            float bgW = h * menuBackground.getWidth() / Math.max(1f, menuBackground.getHeight());
            float left = (WORLD_W - bgW) * 0.5f;
            drawBitmapMenu(canvas, menuBackground, new RectF(left, 0, left + bgW, h));
        }
        float titleW = 440f, titleH = titleW * 241f / 654f;
        drawBitmapMenu(canvas, menuSettingsButton, new RectF((WORLD_W - titleW) / 2f, h * 0.24f,
                (WORLD_W + titleW) / 2f, h * 0.24f + titleH));

        float iconSize = 104f, iconY = h * 0.48f;
        RectF soundRect = new RectF(105f, iconY, 105f + iconSize, iconY + iconSize);
        RectF musicRect = new RectF(303f, iconY, 303f + iconSize, iconY + iconSize);
        settingsHits[0].set(soundRect); settingsHits[1].set(musicRect);
        drawBitmapMenu(canvas, soundEnabled ? soundOnButton : soundOffButton, soundRect);
        drawBitmapMenu(canvas, musicButton, musicRect);
        drawMenuTitle(canvas, "SUARA: " + (soundEnabled ? "ON" : "OFF"), 157f, iconY + iconSize + 42f, 18f);
        drawMenuTitle(canvas, "MUSIK: " + (musicEnabled ? "ON" : "OFF"), 355f, iconY + iconSize + 42f, 18f);

        float backW = 350f, backH = backW * 152f / 608f, backY = h * 0.76f;
        RectF backRect = new RectF((WORLD_W - backW) / 2f, backY, (WORLD_W + backW) / 2f, backY + backH);
        settingsHits[2].set(backRect);
        drawBitmapMenu(canvas, backButton, backRect);
    }

    private void drawPauseControl(Canvas canvas) {
        drawBitmapMenu(canvas, pauseButton, pauseRect);
    }

    private void drawPauseScreen(Canvas canvas) {
        float h = logicalHeight();
        fill(canvas, 0, 0, WORLD_W, h, 0xb9000000);

        float titleW = 310f, titleH = titleW * 241f / 513f;
        float titleY = Math.max(80f, (h - 590f) / 2f - 95f);
        drawBitmapMenu(canvas, menuPauseButton, new RectF((WORLD_W - titleW) / 2f, titleY,
                (WORLD_W + titleW) / 2f, titleY + titleH));

        Bitmap[] images = {continueButton, retryButton, menuButton, exitButton};
        float[] widths = {410f, 390f, 410f, 410f};
        float[] ratios = {431f / 144f, 402f / 145f, 419f / 144f, 430f / 145f};
        float gap = 10f;
        float total = 0f;
        for (int i = 0; i < 4; i++) total += widths[i] / ratios[i];
        total += gap * 3f;
        float y = (h - total) * 0.5f + 85f;
        for (int i = 0; i < 4; i++) {
            float w = widths[i], hh = w / ratios[i];
            RectF r = new RectF((WORLD_W - w) / 2f, y, (WORLD_W + w) / 2f, y + hh);
            pauseHits[i].set(r);
            drawBitmapMenu(canvas, images[i], r);
            y += hh + gap;
        }
        drawOutlined(canvas, "Esc / P = lanjut  |  R = ulang", WORLD_W / 2f, h - 30f, 12f, 3.5f);
    }

    // ---- world objects ------------------------------------------------------------
    private void drawPlacedBlocks(Canvas canvas) {
        long t = now();
        for (int row = BUILD_LIMIT_ROW; row < ROWS; row++) {
            float y = worldToScreenY(GRID_Y + row * CELL);
            if (y > controlTop() || y + CELL < areaTop()) continue;
            for (int col = 0; col < COLS; col++) {
                int type = blocks[row][col];
                if (type < 0) continue;
                float x = GRID_X + col * CELL;
                blit(canvas, blockTextures[type], x, y, x + CELL, y + CELL, false);
                long placed = blockPlacedAt[row][col];
                if (placed > 0L) {
                    float age = (t - placed) / 1_000_000_000f;
                    if (age >= 0f && age < 0.8f) {
                        int a = (int) (255 * (1f - age / 0.8f));
                        int hsh = (row * 31 + col * 17) & 15;
                        float sx = x + 8f + (hsh % 4) * 7f, sy = y + 8f + (hsh / 4) * 7f;
                        int c = (a << 24) | 0x00fff2a0;
                        fill(canvas, sx - 1.5f, sy - 5f, sx + 1.5f, sy + 5f, c);
                        fill(canvas, sx - 5f, sy - 1.5f, sx + 5f, sy + 1.5f, c);
                    }
                }
            }
        }
    }

    private int previewCol() {
        if (mouseActive && hoverCol >= 0) return hoverCol;
        return playerColumn();
    }

    private void drawPlacementTarget(Canvas canvas) {
        if (fallingBlockActive && !breakMode) return;
        int col, row;
        if (breakMode) {
            if (mouseActive && hoverCol >= 0) { col = hoverCol; row = hoverRow; }
            else { col = targetCol; row = targetRow; }
        } else {
            col = previewCol();
            row = (col >= 0 && col < COLS) ? topBlockRow(col) - 1 : -1;
        }
        if (col < 0 || col >= COLS || row < BUILD_LIMIT_ROW || row >= ROWS) return;
        float x = GRID_X + col * CELL;
        float y = worldToScreenY(GRID_Y + row * CELL);
        RectF cell = new RectF(x + 1.5f, y + 1.5f, x + CELL - 1.5f, y + CELL - 1.5f);
        if (!breakMode && blockTextures[materialForRow(row)] != null) {
            paint.setAlpha(100);
            canvas.drawBitmap(blockTextures[materialForRow(row)], null, cell, paint);
            paint.setAlpha(255);
        }
        if (placementFrame != null) drawBitmap(canvas, placementFrame, cell);
        boolean far = !withinRange(col, row);
        paint.setStyle(Paint.Style.STROKE);
        paint.setStrokeWidth(3f);
        paint.setColor(breakMode ? 0xffff5555 : (far ? 0xffffa030 : 0xff42ef69));
        canvas.drawRect(cell, paint);
        paint.setStyle(Paint.Style.FILL);
    }

    private void drawFallingBlock(Canvas canvas) {
        if (!fallingBlockActive || fallingType < 0 || fallingType >= BLOCK_TYPES) return;
        float y = worldToScreenY(fallingY);
        float x = GRID_X + fallingCol * CELL;
        blit(canvas, blockTextures[fallingType], x, y, x + CELL, y + CELL, false);
    }

    private void drawTnt(Canvas canvas) {
        for (int i = 0; i < MAX_TNT; i++) {
            if (!tntOn[i]) continue;
            float x = GRID_X + tntCol[i] * CELL;
            float y = worldToScreenY(tntY[i]);
            float grow = tntFuse[i] >= 0f && tntFuse[i] < 0.4f ? (0.4f - tntFuse[i]) * 5f : 0f;
            blit(canvas, blockTextures[TNT_TYPE], x - grow, y - grow, x + CELL + grow, y + CELL + grow, false);
            if (tntFuse[i] >= 0f && ((int) (tntFuse[i] * 6f)) % 2 == 0) {
                fill(canvas, x, y, x + CELL, y + CELL, 0x99ffffff);
            }
        }
    }

    private void drawPlayer(Canvas canvas) {
        boolean spr = isSprint();
        int action = !grounded ? 2 : ((leftHeld || rightHeld) ? (spr ? 1 : 0) : 0);
        int frame = action == 2 ? jumpFrame : (action == 1 ? runFrame : walkFrame);
        Bitmap sprite = characterFrames[action][frame];
        if (sprite == null) return;
        float h = PLAYER_H, w = h * sprite.getWidth() / Math.max(1f, sprite.getHeight());
        float feet = worldToScreenY(playerFeet);
        tmp.set(playerX - w / 2, feet - h, playerX + w / 2, feet);
        long t = now();
        boolean placing = t < playerPlaceUntilNanos;
        if (placing) {
            float k = (playerPlaceUntilNanos - t) / 220000000f;
            float pulse = (float) Math.sin((1f - k) * Math.PI);
            tmp.offset(facingRight ? pulse * 5f : -pulse * 5f, -pulse * 3f);
        }
        canvas.save();
        if (placing) canvas.rotate(facingRight ? -7f : 7f, playerX, feet - h * 0.48f);
        if (!facingRight) canvas.scale(-1, 1, playerX, 0);
        drawBitmap(canvas, sprite, tmp);
        if (placing) {
            float pulse = (float) Math.sin((playerPlaceUntilNanos - t) / 220000000f * Math.PI);
            float handX = playerX + (facingRight ? 1f : -1f) * (w * 0.22f + pulse * 8f);
            float handY = feet - h * 0.42f + pulse * 4f;
            paint.setStyle(Paint.Style.FILL);
            paint.setColor(0xffffd2a0);
            canvas.drawCircle(handX, handY, 4.5f, paint);
        }
        canvas.restore();
        if (shieldOn()) {
            paint.setStyle(Paint.Style.STROKE);
            paint.setStrokeWidth(2.5f);
            paint.setColor(0xaa5ad8ff);
            canvas.drawCircle(playerX, feet - h * 0.5f, h * 0.62f, paint);
            paint.setStyle(Paint.Style.FILL);
        }
    }

    private void drawEffects(Canvas canvas) {
        for (int i = 0; i < MAX_FX; i++) {
            if (fxT[i] < 0f) continue;
            float k = fxT[i] / 0.38f;
            float r = CELL * (0.6f + 2.0f * k);
            int a = (int) (200 * (1f - k));
            float cx = fxX[i], cy = worldToScreenY(fxY[i]);
            paint.setStyle(Paint.Style.FILL);
            paint.setColor((a << 24) | 0x00ff9a1e);
            canvas.drawCircle(cx, cy, r, paint);
            paint.setColor((a << 24) | 0x00fff3b0);
            canvas.drawCircle(cx, cy, r * 0.55f, paint);
        }
        for (int i = 0; i < MAX_PARTICLES; i++) {
            if (plife[i] <= 0f) continue;
            float a = Math.min(1f, plife[i] * 2.5f);
            int c = ((int) (255 * a) << 24) | (pcol[i] & 0x00ffffff);
            float sy = worldToScreenY(py[i]);
            fill(canvas, px[i] - 2.5f, sy - 2.5f, px[i] + 2.5f, sy + 2.5f, c);
        }
    }

    // ---- HUD ----------------------------------------------------------------------
    private void drawHud(Canvas canvas) {
        if (hud == null) return;
        tmp.set(0, 0, WORLD_W, 82f);
        drawBitmap(canvas, hud, tmp);

        // Counters are centered in their own transparent HUD windows.
        drawAtlasTextFit(canvas, inventory + "/" + MAX_INVENTORY, 80f, 31f, 24f, 76f);
        drawAtlasTextFit(canvas, areaPercent() + "%", 468f, 31f, 24f, 74f);
        drawAtlasText(canvas, winCount + "/10", 319f, 31f, 18f);

        // The segmented green strip reports total filled-cell percentage.
        float barX = 7f, barY = 58f, barW = 498f, barH = 15f;
        final int segments = 16;
        float segW = barW / segments;
        float filled = (areaPercent() / 100f) * segments;
        paint.setColor(0xff39e64f);
        paint.setStyle(Paint.Style.FILL);
        for (int i = 0; i < segments; i++) {
            float part = Math.max(0f, Math.min(1f, filled - i));
            if (part <= 0f) continue;
            float left = barX + i * segW + 1.2f;
            float right = barX + i * segW + segW * part - 1.2f;
            if (right > left) {
                tmp.set(left, barY, right, barY + barH);
                canvas.drawRoundRect(tmp, 2.5f, 2.5f, paint);
            }
        }
    }

    private void drawGiftRow(Canvas canvas) {
        for (int i = 0; i < GIFTS; i++) {
            RectF r = giftRects[i];
            blit(canvas, giftTiles[i], r.left, r.top, r.right, r.bottom, true);
            boolean active = (i == 4 && turboOn()) || (i == 6 && shieldOn());
            if (giftFlash[i] > 0f || active) {
                paint.setStyle(Paint.Style.STROKE);
                paint.setStrokeWidth(2.2f);
                paint.setColor(active ? 0xff5ad8ff : 0xffffe14a);
                canvas.drawRect(r, paint);
                paint.setStyle(Paint.Style.FILL);
            }
        }
    }

    private void drawMinimap(Canvas canvas) {
        float x0 = 495.5f, x1 = 508f;
        float top = areaTop() + 6f, bottom = controlTop() - 8f, h = bottom - top;
        if (h < 40f) return;
        float gridH = ROWS * CELL;
        fill(canvas, x0 - 1.5f, top - 3f, x1 + 1.5f, bottom + 1.5f, 0xff0a0d18);
        fill(canvas, x0, top, x1, bottom, 0xff1c2340);
        fill(canvas, x0, top - 2f, x1, top + 1f, 0xffffc928);
        float rowH = h / ROWS;
        for (int r = 0; r < ROWS; r++) {
            int type = -1;
            for (int c = 0; c < COLS && type < 0; c++) type = blocks[r][c];
            if (type < 0) continue;
            float y = top + r * rowH;
            fill(canvas, x0 + 1f, y + 0.4f, x1 - 1f, y + rowH, blockColor[type]);
        }
        // Camera window.
        float vTop = top + clampFloat((cameraY - GRID_Y) / gridH, 0f, 1f) * h;
        float vBot = top + clampFloat((cameraY + boardViewportHeight() - GRID_Y) / gridH, 0f, 1f) * h;
        paint.setStyle(Paint.Style.STROKE);
        paint.setStrokeWidth(1.2f);
        paint.setColor(0xccffffff);
        canvas.drawRect(x0 - 1f, vTop, x1 + 1f, Math.max(vTop + 4f, vBot), paint);
        // Player marker.
        float py2 = top + clampFloat((playerFeet - PLAYER_H * 0.5f - GRID_Y) / gridH, 0f, 1f) * h;
        paint.setStyle(Paint.Style.FILL);
        paint.setColor(0xffff9a3c);
        canvas.drawCircle(x0 - 3.5f, py2, 2.4f, paint);
    }

    private static final String[] HEART = {
            ".XX.XX.", "XXXXXXX", "XXXXXXX", ".XXXXX.", "..XXX..", "...X..."};

    private void drawHpPanel(Canvas canvas) {
        float w = 176f, h = 32f;
        float x = GRID_X + COLS * CELL - w - 3f, y = controlTop() - h - 6f;
        tntRect.set(x, y, x + w, y + h);
        tmp.set(x, y, x + w, y + h);
        paint.setStyle(Paint.Style.FILL);
        paint.setColor(0xd00b0d14);
        canvas.drawRoundRect(tmp, 4f, 4f, paint);
        // Heart.
        float p = 2.6f, hx = x + 9f, hy = y + (h - 6 * p) / 2f;
        for (int r = 0; r < HEART.length; r++) {
            for (int c = 0; c < HEART[r].length(); c++) {
                if (HEART[r].charAt(c) != 'X') continue;
                int col = (r == 1 && c == 1) ? 0xffff8a8a : 0xffe8222a;
                fill(canvas, hx + c * p, hy + r * p, hx + (c + 1) * p, hy + (r + 1) * p, col);
            }
        }
        // HP bar.
        float bx = x + 34f, bw = w - 34f - 62f, by = y + h / 2f - 4f;
        fill(canvas, bx, by, bx + bw, by + 8f, 0xff2a0d10);
        fill(canvas, bx, by, bx + bw * clampFloat(hp / 100f, 0f, 1f), by + 8f, shieldOn() ? 0xff4ad0ff : 0xffe02a2a);
        // TNT stock.
        drawAtlasTextFit(canvas, String.valueOf(tntStock), x + w - 50f, y + h / 2f, 15f, 30f);
        blit(canvas, blockTextures[TNT_TYPE], x + w - 27f, y + 5f, x + w - 5f, y + 27f, false);
    }

    private void drawToast(Canvas canvas) {
        float k = Math.min(1f, (toastUntil - gameClock) * 3f);
        if (k <= 0f) return;
        drawOutlined(canvas, toastText, WORLD_W / 2f, areaTop() + 74f, 22f, 6f);
    }

    private void drawRoundCountdown(Canvas canvas) {
        float cx = WORLD_W * 0.5f;
        float cy = areaTop() + boardViewportHeight() * 0.46f;
        paint.setStyle(Paint.Style.FILL);
        paint.setColor(0xb9000000);
        tmp.set(cx - 88f, cy - 70f, cx + 88f, cy + 70f);
        canvas.drawRoundRect(tmp, 18f, 18f, paint);
        paint.setStyle(Paint.Style.STROKE);
        paint.setStrokeWidth(4f);
        paint.setColor(0xffffc928);
        canvas.drawRoundRect(tmp, 18f, 18f, paint);
        paint.setStyle(Paint.Style.FILL);
        drawAtlasText(canvas, String.valueOf(countdownValue), cx, cy, 76f);
    }

    private Rect fontSource(char ch) {
        switch (ch) {
            case '0': return new Rect(254, 529, 369, 649);
            case '1': return new Rect(395, 529, 484, 649);
            case '2': return new Rect(499, 529, 613, 649);
            case '3': return new Rect(627, 529, 739, 649);
            case '4': return new Rect(751, 529, 872, 649);
            case '5': return new Rect(890, 529, 1005, 649);
            case '6': return new Rect(1022, 529, 1139, 649);
            case '7': return new Rect(1155, 529, 1266, 649);
            case '8': return new Rect(1285, 529, 1399, 649);
            case '9': return new Rect(1416, 529, 1533, 649);
            case '/': return new Rect(1432, 655, 1520, 765);
            case '%': return new Rect(643, 763, 758, 873);
            default: return null;
        }
    }

    private float atlasWidth(String text, float targetHeight) {
        float total = 0f;
        for (int i = 0; i < text.length(); i++) {
            Rect r = fontSource(text.charAt(i));
            if (r != null) total += targetHeight * (r.width() / (float) r.height()) + 2f;
        }
        return total > 0f ? total - 2f : 0f;
    }

    private void drawAtlasTextFit(Canvas canvas, String text, float cx, float cy, float h, float maxW) {
        float w = atlasWidth(text, h);
        if (w > maxW && w > 0f) h = h * maxW / w;
        drawAtlasText(canvas, text, cx, cy, h);
    }

    private void drawAtlasText(Canvas canvas, String text, float centerX, float centerY, float targetHeight) {
        if (fontAtlas == null || text == null || text.length() == 0) return;
        float x = centerX - atlasWidth(text, targetHeight) / 2f;
        for (int i = 0; i < text.length(); i++) {
            Rect src = fontSource(text.charAt(i));
            if (src == null) continue;
            float w = targetHeight * src.width() / (float) src.height();
            tmp.set(x, centerY - targetHeight / 2f, x + w, centerY + targetHeight / 2f);
            paint.setAlpha(255);
            paint.setFilterBitmap(false);
            canvas.drawBitmap(fontAtlas, src, tmp, paint);
            x += w + 2f;
        }
    }

    private void drawControls(Canvas canvas) {
        // Transparent touch controls: the moving map remains visible behind them.
        Bitmap[] images = {leftImage, rightImage, runImage, pickImage, blockImage, jumpImage};
        final int[] roles = {ROLE_LEFT, ROLE_RIGHT, ROLE_RUN, ROLE_PICK, ROLE_BUILD, ROLE_JUMP};
        for (int i = 0; i < 6; i++) {
            boolean held = false;
            for (int p = 0; p < touches.size(); p++) {
                if (touches.valueAt(p).role == roles[i]) { held = true; break; }
            }
            if (i == 0 && keyLeft) held = true;
            if (i == 1 && keyRight) held = true;
            if (i == 4 && keyBuild) held = true;
            if (i == 5 && keyJump) held = true;
            boolean active = (i == 2 && isSprint()) || (i == 3 && breakMode);
            if (active) {
                paint.setStyle(Paint.Style.FILL);
                paint.setColor(i == 3 ? 0x5537cfff : 0x55ffc928);
                canvas.drawRoundRect(icon[i], 18, 18, paint);
            }
            tmp.set(icon[i]);
            if (held) {
                float cx = tmp.centerX(), cy = tmp.centerY();
                tmp.inset(tmp.width() * 0.055f, tmp.height() * 0.055f);
                tmp.offset(cx - tmp.centerX(), cy - tmp.centerY());
            }
            drawBitmap(canvas, images[i], tmp);
        }
    }

    // ================================================================================
    // Game rules
    // ================================================================================
    private void startGame() {
        resetGame();
        screen = SCREEN_GAME;
    }

    private void resetGame() {
        for (int r = 0; r < ROWS; r++) {
            for (int c = 0; c < COLS; c++) { blocks[r][c] = -1; blockPlacedAt[r][c] = 0L; }
        }
        playerX = GRID_X + (COLS * CELL) / 2f;
        playerFeet = GRID_Y + ROWS * CELL;
        velocityY = 0f;
        cameraY = 0f; cameraTarget = 0f;
        grounded = true; wasGrounded = true;
        facingRight = true;
        targetCol = -1; targetRow = -1;
        fallingBlockActive = false; fallingLiftPlayer = false;
        countdownValue = -1; countdownNextNanos = 0L; winCount = 0;
        inventory = 30; tntStock = 15; hp = 100f;
        turboUntil = -1f; shieldUntil = -1f; toastUntil = -1f;
        rainLeft = 0; shake = 0f; gameClock = 0f;
        breakMode = false;
        clearEffects();
        releaseAllInput();
        lastFrameNanos = 0L;
    }

    private void clearEffects() {
        for (int i = 0; i < MAX_TNT; i++) tntOn[i] = false;
        for (int i = 0; i < MAX_PARTICLES; i++) plife[i] = 0f;
        for (int i = 0; i < MAX_FX; i++) fxT[i] = -1f;
        for (int i = 0; i < GIFTS; i++) giftFlash[i] = 0f;
    }

    private void resetBoardAfterWin() {
        for (int r = 0; r < ROWS; r++) for (int c = 0; c < COLS; c++) {
            blocks[r][c] = -1;
            blockPlacedAt[r][c] = 0L;
        }
        playerX = GRID_X + (COLS * CELL) / 2f;
        playerFeet = GRID_Y + ROWS * CELL;
        velocityY = 0f;
        grounded = true;
        cameraY = 0f; cameraTarget = 0f;
        facingRight = true;
        targetCol = -1; targetRow = -1;
        fallingBlockActive = false;
        hp = 100f;
        clearEffects();
        lastFrameNanos = now();
    }

    private void toast(String text) {
        toastText = text;
        toastUntil = gameClock + 1.6f;
    }

    private boolean withinRange(int col, int row) {
        float playerRow = (playerFeet - GRID_Y) / CELL;
        float dx = col - playerColumn(), dy = row - playerRow;
        return Math.sqrt(dx * dx + dy * dy) <= 10.0;
    }

    private boolean cellOverlapsPlayer(int col, int row) {
        float l = GRID_X + col * CELL, t = GRID_Y + row * CELL;
        return playerX + PLAYER_HALF_W > l + 1f && playerX - PLAYER_HALF_W < l + CELL - 1f
                && t + CELL > playerFeet - PLAYER_H + 1f && t < playerFeet - 1f;
    }

    /** Drops a block into the given column. It lands on top of that column's stack. */
    private boolean launchBlock(int col) {
        if (fallingBlockActive || countdownValue >= 0) return false;
        if (col < 0 || col >= COLS) return false;
        int row = topBlockRow(col) - 1;
        if (row < BUILD_LIMIT_ROW) return false;
        if (inventory <= 0) { toast("BLOK HABIS"); return false; }
        if (!withinRange(col, row)) { toast("TERLALU JAUH"); return false; }

        float supportY = GRID_Y + (row + 1) * CELL;
        fallingLiftPlayer = col == playerColumn() && grounded && Math.abs(playerFeet - supportY) < CELL * 0.24f;
        fallingCol = col;
        fallingRow = row;
        fallingType = pickType(row);
        fallingEndY = GRID_Y + row * CELL;
        fallingStartY = Math.max(GRID_Y - CELL, fallingEndY - CELL * 4f);
        fallingY = fallingStartY;
        fallingElapsed = 0f;
        fallingDuration = Math.max(0.24f, Math.min(0.82f, 0.24f + (fallingEndY - fallingStartY) / 2100f));
        fallingBlockActive = true;
        inventory--;
        return true;
    }

    private void finishFallingBlock() {
        if (!fallingBlockActive) return;
        int col = fallingCol, row = fallingRow;
        if (col >= 0 && col < COLS && row >= BUILD_LIMIT_ROW && row < ROWS && blocks[row][col] < 0) {
            blocks[row][col] = fallingType;
            blockPlacedAt[row][col] = now();
            float supportY = GRID_Y + (row + 1) * CELL;
            if (fallingLiftPlayer && playerColumn() == col && grounded
                    && Math.abs(playerFeet - supportY) < CELL * 0.3f) {
                playerFeet = GRID_Y + row * CELL;
                velocityY = 0f;
                grounded = true;
            }
            play(sLand, 0.5f, 1.5f);
        } else if (inventory < MAX_INVENTORY) {
            inventory++;   // the cell was taken meanwhile: refund
        }
        fallingBlockActive = false;
        fallingLiftPlayer = false;
        playerPlaceUntilNanos = now() + 260000000L;
        if (blockCount() >= COLS * ROWS && countdownValue < 0) {
            countdownValue = 15;
            countdownNextNanos = now() + 620000000L;
        }
    }

    private boolean breakBlockAt(int col, int row) {
        if (col < 0 || col >= COLS || row < BUILD_LIMIT_ROW || row >= ROWS) return false;
        if (blocks[row][col] < 0 || !withinRange(col, row)) return false;
        spawnBurst(GRID_X + col * CELL + CELL / 2f, GRID_Y + row * CELL + CELL / 2f,
                blockColor[blocks[row][col]], 7, 150f);
        blocks[row][col] = -1;
        blockPlacedAt[row][col] = 0L;
        if (inventory < MAX_INVENTORY) inventory++;
        play(sStep, 0.8f, 1.6f);
        // If the removed tile was the player's floor, release support and let gravity take over.
        if (grounded && !hasSurfaceAtFeet(playerX, playerFeet)) {
            grounded = false;
            velocityY = 0f;
        }
        return true;
    }

    private void mineFront() {
        int col = playerColumn() + (facingRight ? 1 : -1);
        if (col < 0 || col >= COLS) return;
        int feetRow = (int) Math.floor((playerFeet - 2f - GRID_Y) / CELL);
        int[] order = {feetRow, feetRow + 1, feetRow - 1};
        for (int r : order) {
            if (breakBlockAt(col, r)) { targetCol = col; targetRow = r; return; }
        }
    }

    private void mineDown() {
        int col = playerColumn();
        int row = (int) Math.floor((playerFeet + 2f - GRID_Y) / CELL);
        if (breakBlockAt(col, row)) { targetCol = col; targetRow = row; }
    }

    /** Settles floating blocks one cell at a time (after mining or explosions). */
    private void settleBlocks() {
        for (int c = 0; c < COLS; c++) {
            for (int r = ROWS - 2; r >= BUILD_LIMIT_ROW; r--) {
                if (blocks[r][c] >= 0 && blocks[r + 1][c] < 0 && !cellOverlapsPlayer(c, r + 1)) {
                    blocks[r + 1][c] = blocks[r][c];
                    blockPlacedAt[r + 1][c] = blockPlacedAt[r][c];
                    blocks[r][c] = -1;
                    blockPlacedAt[r][c] = 0L;
                }
            }
        }
    }

    // ---- TNT / gifts ----------------------------------------------------------------
    private void spawnTnt(int col, float fuse) {
        if (col < 0 || col >= COLS) return;
        int slot = -1;
        for (int i = 0; i < MAX_TNT; i++) if (!tntOn[i]) { slot = i; break; }
        if (slot < 0) return;
        float surface = GRID_Y + topBlockRow(col) * CELL;
        float y = Math.max(GRID_Y - CELL, cameraY - CELL);
        y = Math.min(y, surface - CELL);
        tntOn[slot] = true;
        tntCol[slot] = col;
        tntY[slot] = y;
        tntVy[slot] = 0f;
        tntFuse[slot] = fuse;
    }

    private void dropTnt() {
        if (screen != SCREEN_GAME || countdownValue >= 0) return;
        if (tntStock <= 0) { toast("TNT HABIS"); return; }
        int dir = facingRight ? 1 : -1;
        int pc = playerColumn();
        int col = pc + 2 * dir;
        if (col < 0 || col >= COLS) col = pc - 2 * dir;
        if (col < 0 || col >= COLS) col = pc + dir;
        col = clamp(col, 0, COLS - 1);
        tntStock--;
        spawnTnt(col, -1f);
    }

    private void triggerGift(int i) {
        if (screen != SCREEN_GAME || countdownValue >= 0 || i < 0 || i >= GIFTS) return;
        giftFlash[i] = 0.4f;
        switch (i) {
            case 0: inventory = Math.min(MAX_INVENTORY, inventory + 60); break;
            case 1: tntStock = Math.min(99, tntStock + 20); break;
            case 2: tntStock = Math.min(99, tntStock + 45); break;
            case 3: rainLeft += 6; rainClock = 0f; break;
            case 4: turboUntil = gameClock + 10f; break;
            case 5: hp = 100f; break;
            case 6: shieldUntil = gameClock + 10f; break;
            default: tntStock = Math.min(99, tntStock + 5); break;
        }
        toast(GIFT_TOAST[i]);
    }

    private void explode(int i) {
        int col = tntCol[i];
        int row = Math.round((tntY[i] - GRID_Y) / CELL);
        float cx = GRID_X + col * CELL + CELL / 2f, cy = tntY[i] + CELL / 2f;
        tntOn[i] = false;
        for (int dr = -2; dr <= 2; dr++) {
            for (int dc = -2; dc <= 2; dc++) {
                if (dr * dr + dc * dc > 5) continue;
                int r = row + dr, c = col + dc;
                if (r < BUILD_LIMIT_ROW || r >= ROWS || c < 0 || c >= COLS || blocks[r][c] < 0) continue;
                spawnBurst(GRID_X + c * CELL + CELL / 2f, GRID_Y + r * CELL + CELL / 2f,
                        blockColor[blocks[r][c]], 4, 260f);
                blocks[r][c] = -1;
                blockPlacedAt[r][c] = 0L;
            }
        }
        for (int j = 0; j < MAX_TNT; j++) {   // chain reaction
            if (!tntOn[j]) continue;
            float dx = GRID_X + tntCol[j] * CELL + CELL / 2f - cx, dy = tntY[j] + CELL / 2f - cy;
            if (Math.sqrt(dx * dx + dy * dy) < CELL * 2.6f && (tntFuse[j] < 0f || tntFuse[j] > 0.12f)) {
                tntFuse[j] = 0.12f;
            }
        }
        for (int k = 0; k < MAX_FX; k++) {
            if (fxT[k] < 0f) { fxT[k] = 0f; fxX[k] = cx; fxY[k] = cy; break; }
        }
        spawnBurst(cx, cy, 0xffff9a1e, 14, 320f);
        spawnBurst(cx, cy, 0xff555555, 10, 220f);
        shake = 1f;
        play(sLand, 1f, 0.5f);

        float pdx = playerX - cx, pdy = (playerFeet - PLAYER_H * 0.5f) - cy;
        float dist = (float) Math.sqrt(pdx * pdx + pdy * pdy);
        if (dist < CELL * 2.4f) {
            if (!shieldOn()) hp -= 12f + 38f * (1f - dist / (CELL * 2.4f));
            velocityY = -520f;
            grounded = false;
            if (hp <= 0f) respawnPlayer();
        }
        if (grounded && !hasSurfaceAtFeet(playerX, playerFeet)) grounded = false;
    }

    private void respawnPlayer() {
        hp = 100f;
        int col = COLS / 2;
        playerX = GRID_X + col * CELL + CELL / 2f;
        playerFeet = GRID_Y + topBlockRow(col) * CELL;
        velocityY = 0f;
        grounded = true;
        toast("KAMU KEMBALI!");
    }

    private void spawnBurst(float x, float y, int color, int n, float speed) {
        for (int k = 0; k < n; k++) {
            int slot = -1;
            for (int i = 0; i < MAX_PARTICLES; i++) if (plife[i] <= 0f) { slot = i; break; }
            if (slot < 0) return;
            double ang = rnd.nextDouble() * Math.PI * 2.0;
            float sp = speed * (0.35f + rnd.nextFloat() * 0.65f);
            px[slot] = x; py[slot] = y;
            pvx[slot] = (float) Math.cos(ang) * sp;
            pvy[slot] = (float) Math.sin(ang) * sp - 90f;
            plife[slot] = 0.5f + rnd.nextFloat() * 0.5f;
            pcol[slot] = color;
        }
    }

    // ================================================================================
    // Physics
    // ================================================================================
    private boolean intersectsBlocks(int col, float top, float feet) {
        for (int row = BUILD_LIMIT_ROW; row < ROWS; row++) {
            if (blocks[row][col] < 0) continue;
            float blockTop = GRID_Y + row * CELL;
            float blockBottom = blockTop + CELL;
            if (feet > blockTop + 1f && top < blockBottom - 1f) return true;
        }
        return false;
    }

    private boolean hasSurfaceAtFeet(float x, float feet) {
        float floor = GRID_Y + ROWS * CELL;
        if (Math.abs(feet - floor) < 2f) return true;
        int col = (int) ((x - GRID_X) / CELL);
        if (col < 0 || col >= COLS) return false;
        for (int row = BUILD_LIMIT_ROW; row < ROWS; row++) {
            if (blocks[row][col] < 0) continue;
            float top = GRID_Y + row * CELL;
            if (Math.abs(feet - top) < 2f) return true;
        }
        return false;
    }

    private float landingSurface(float x, float oldFeet, float newFeet) {
        float best = Float.POSITIVE_INFINITY;
        float floor = GRID_Y + ROWS * CELL;
        if (oldFeet <= floor && newFeet >= floor) best = floor;
        // Only the center of the feet can land on a block.
        int col = (int) ((x - GRID_X) / CELL);
        if (col < 0 || col >= COLS) return best;
        for (int row = BUILD_LIMIT_ROW; row < ROWS; row++) {
            if (blocks[row][col] < 0) continue;
            float top = GRID_Y + row * CELL;
            if (oldFeet <= top + 1f && newFeet >= top - 1f && top < best) best = top;
        }
        return best;
    }

    private float ceilingSurface(float x, float oldTop, float newTop) {
        float best = Float.NEGATIVE_INFINITY;
        float left = x - PLAYER_HALF_W, right = x + PLAYER_HALF_W;
        int first = clamp((int) ((left - GRID_X) / CELL), 0, COLS - 1);
        int last = clamp((int) ((right - GRID_X) / CELL), 0, COLS - 1);
        for (int col = first; col <= last; col++) {
            for (int row = BUILD_LIMIT_ROW; row < ROWS; row++) {
                if (blocks[row][col] < 0) continue;
                float bottom = GRID_Y + (row + 1) * CELL;
                if (oldTop >= bottom - 1f && newTop <= bottom + 1f && bottom > best) best = bottom;
            }
        }
        return best;
    }

    private boolean blockedAt(float x, float top, float feet) {
        float left = x - PLAYER_HALF_W, right = x + PLAYER_HALF_W;
        int first = clamp((int) ((left - GRID_X) / CELL), 0, COLS - 1);
        int last = clamp((int) ((right - GRID_X) / CELL), 0, COLS - 1);
        for (int col = first; col <= last; col++) {
            for (int row = BUILD_LIMIT_ROW; row < ROWS; row++) {
                if (blocks[row][col] < 0) continue;
                float l = GRID_X + col * CELL, r = l + CELL;
                float t = GRID_Y + row * CELL, b = t + CELL;
                if (right > l + 1f && left < r - 1f && feet > t + 1f && top < b - 1f) return true;
            }
        }
        return false;
    }

    private void resolvePlayerOverlap() {
        float top = playerFeet - PLAYER_H;
        if (!blockedAt(playerX, top, playerFeet)) return;
        for (float d = 2f; d <= CELL * 2f; d += 2f) {
            float left = clampFloat(playerX - d, GRID_X + PLAYER_HALF_W, GRID_X + COLS * CELL - PLAYER_HALF_W);
            if (!blockedAt(left, top, playerFeet)) { playerX = left; return; }
            float right = clampFloat(playerX + d, GRID_X + PLAYER_HALF_W, GRID_X + COLS * CELL - PLAYER_HALF_W);
            if (!blockedAt(right, top, playerFeet)) { playerX = right; return; }
        }
        for (float lift = 2f; lift <= PLAYER_H; lift += 2f) {
            if (!blockedAt(playerX, top - lift, playerFeet - lift)) {
                playerFeet -= lift;
                velocityY = 0f;
                grounded = hasSurfaceAtFeet(playerX, playerFeet);
                return;
            }
        }
    }

    private void updatePhysics() {
        long t = now();
        if (lastFrameNanos == 0) lastFrameNanos = t;
        float dt = Math.min(0.032f, (t - lastFrameNanos) / 1_000_000_000f);
        lastFrameNanos = t;
        if (dt <= 0f) return;
        gameClock += dt;

        updateEffects(dt);

        if (fallingBlockActive) {
            fallingElapsed += dt;
            float k = Math.min(1f, fallingElapsed / Math.max(0.01f, fallingDuration));
            float eased = 1f - (1f - k) * (1f - k);
            fallingY = fallingStartY + (fallingEndY - fallingStartY) * eased;
            if (k >= 1f) finishFallingBlock();
        }

        if (countdownValue >= 0) {
            if (t >= countdownNextNanos) {
                if (countdownValue == 1) {
                    winCount = Math.min(10, winCount + 1);
                    countdownValue = -1;
                    resetBoardAfterWin();
                    return;
                }
                countdownValue--;
                long delay = countdownValue <= 3 ? 1350000000L : 620000000L;
                countdownNextNanos = t + delay;
            }
            return;
        }

        updateTnt(dt);

        settleClock += dt;
        if (settleClock >= 0.07f) { settleClock = 0f; settleBlocks(); }

        regenClock += dt;
        if (regenClock >= 1.2f) {
            regenClock = 0f;
            if (inventory < MAX_INVENTORY) inventory++;
        }

        // Held actions: keyboard / button / mouse repeat.
        if (buildHeld && !fallingBlockActive) launchBlock(previewCol());
        breakCooldown -= dt;
        mineCooldown -= dt;
        if (keyMineFront && mineCooldown <= 0f) { mineFront(); mineCooldown = 0.17f; }
        if (keyMineDown && mineCooldown <= 0f) { mineDown(); mineCooldown = 0.17f; }
        if (mouseGridHold && mouseActive && hoverCol >= 0) {
            if (mouseButton == 2 || breakMode) {
                if (breakCooldown <= 0f) { breakBlockAt(hoverCol, hoverRow); breakCooldown = 0.12f; }
            } else if (!fallingBlockActive) {
                launchBlock(hoverCol);
            }
        }

        updatePlayer(dt);

        if (!fallingBlockActive && blockCount() >= COLS * ROWS && countdownValue < 0) {
            countdownValue = 15;
            countdownNextNanos = t + 620000000L;
        }
    }

    private void updateEffects(float dt) {
        for (int i = 0; i < GIFTS; i++) if (giftFlash[i] > 0f) giftFlash[i] -= dt;
        shake = Math.max(0f, shake - dt * 3f);
        for (int i = 0; i < MAX_FX; i++) {
            if (fxT[i] < 0f) continue;
            fxT[i] += dt;
            if (fxT[i] > 0.38f) fxT[i] = -1f;
        }
        for (int i = 0; i < MAX_PARTICLES; i++) {
            if (plife[i] <= 0f) continue;
            plife[i] -= dt;
            pvy[i] += 700f * dt;
            px[i] += pvx[i] * dt;
            py[i] += pvy[i] * dt;
        }
    }

    private void updateTnt(float dt) {
        if (rainLeft > 0) {
            rainClock -= dt;
            if (rainClock <= 0f) {
                rainClock = 0.28f;
                rainLeft--;
                spawnTnt(rnd.nextInt(COLS), -1f);
            }
        }
        for (int i = 0; i < MAX_TNT; i++) {
            if (!tntOn[i]) continue;
            float surface = GRID_Y + topBlockRow(tntCol[i]) * CELL;
            boolean supported = tntY[i] + CELL >= surface - 0.5f;
            if (!supported) {
                tntVy[i] = Math.min(1100f, tntVy[i] + 1600f * dt);
                tntY[i] += tntVy[i] * dt;
                if (tntY[i] + CELL >= surface) {
                    tntY[i] = surface - CELL;
                    tntVy[i] = 0f;
                    if (tntFuse[i] < 0f) tntFuse[i] = 1.4f;
                }
            } else {
                tntY[i] = surface - CELL;
                tntVy[i] = 0f;
                if (tntFuse[i] < 0f) tntFuse[i] = 1.4f;
            }
            if (tntFuse[i] >= 0f) {
                tntFuse[i] -= dt;
                if (tntFuse[i] <= 0f) explode(i);
            }
        }
    }

    private void updatePlayer(float dt) {
        boolean spr = isSprint();
        float speed = (spr ? 245f : 145f) * (turboOn() ? 1.5f : 1f);
        float dx = 0f;
        if (leftHeld && !rightHeld) { dx = -speed * dt; facingRight = false; }
        if (rightHeld && !leftHeld) { dx = speed * dt; facingRight = true; }

        resolvePlayerOverlap();

        float candidateX = clampFloat(playerX + dx, GRID_X + PLAYER_HALF_W, GRID_X + COLS * CELL - PLAYER_HALF_W);
        if (Math.abs(dx) > 0.001f) {
            if (!blockedAt(candidateX, playerFeet - PLAYER_H, playerFeet)) {
                playerX = candidateX;
            } else {
                float low = 0f, high = 1f;
                for (int i = 0; i < 12; i++) {
                    float mid = (low + high) * 0.5f;
                    float test = playerX + (candidateX - playerX) * mid;
                    if (blockedAt(test, playerFeet - PLAYER_H, playerFeet)) high = mid;
                    else low = mid;
                }
                playerX = playerX + (candidateX - playerX) * low;
            }
        }

        if (grounded && !hasSurfaceAtFeet(playerX, playerFeet)) grounded = false;

        // Holding jump keeps hopping, like the stream character does.
        if ((jumpRequested || jumpHeld) && grounded) {
            velocityY = -JUMP_SPEED * (turboOn() ? 1.08f : 1f);
            grounded = false;
            play(sJump, 0.7f, 1f);
        }
        jumpRequested = false;

        wasGrounded = grounded;
        if (!grounded) {
            float oldFeet = playerFeet;
            float oldTop = oldFeet - PLAYER_H;
            velocityY += GRAVITY * dt;
            float nextFeet = oldFeet + velocityY * dt;
            float nextTop = nextFeet - PLAYER_H;

            if (velocityY < 0f) {
                float ceiling = ceilingSurface(playerX, oldTop, nextTop);
                if (ceiling != Float.NEGATIVE_INFINITY) {
                    nextFeet = ceiling + PLAYER_H;
                    velocityY = 0f;
                }
            } else {
                float landing = landingSurface(playerX, oldFeet, nextFeet);
                if (landing != Float.POSITIVE_INFINITY) {
                    nextFeet = landing;
                    impactVy = velocityY;
                    velocityY = 0f;
                    grounded = true;
                }
            }
            playerFeet = nextFeet;
            if (grounded && !wasGrounded && impactVy > 380f) play(sLand, 0.6f, 1f);
        } else {
            velocityY = 0f;
        }

        // Camera follows the player vertically.
        float desiredCamera = playerFeet - boardViewportHeight() * PLAYER_SCREEN_RATIO;
        float minCamera = -PLAYER_H * 1.2f;
        cameraTarget = clampFloat(desiredCamera, minCamera, Math.max(minCamera, BOARD_H - boardViewportHeight()));
        cameraY += (cameraTarget - cameraY) * Math.min(1f, dt * 7f);

        animationClock += dt;
        if (!grounded) {
            if (animationClock > 0.11f) { jumpFrame = (jumpFrame + 1) % 5; animationClock = 0f; }
        } else if (leftHeld != rightHeld) {
            float delay = spr ? 0.075f : 0.13f;
            if (animationClock > delay) {
                if (spr) runFrame = (runFrame + 1) % 5;
                else walkFrame = (walkFrame + 1) % 5;
                animationClock = 0f;
            }
            stepClock += dt;
            float iv = spr ? 0.17f : 0.30f;
            if (stepClock >= iv) { stepClock = 0f; play(spr ? sRun : sStep, 0.5f, 1f); }
        } else {
            walkFrame = 0; animationClock = 0f; stepClock = 0.1f;
        }
    }

    // ================================================================================
    // Input: touch + mouse
    // ================================================================================
    private int roleAt(float x, float y) {
        hitArg = -1;
        if (x >= pauseRect.left - 6f && x <= pauseRect.right + 6f
                && y >= pauseRect.top - 6f && y <= pauseRect.bottom + 6f) return ROLE_PAUSE;
        // Lock gameplay input during the end-of-round countdown; pause remains available.
        if (countdownValue >= 0) return ROLE_NONE;
        final int[] roles = {ROLE_LEFT, ROLE_RIGHT, ROLE_RUN, ROLE_PICK, ROLE_BUILD, ROLE_JUMP};
        for (int i = 0; i < 6; i++) if (hit[i].contains(x, y)) return roles[i];
        for (int i = 0; i < GIFTS; i++) {
            if (giftRects[i].contains(x, y)) { hitArg = i; return ROLE_GIFT; }
        }
        if (tntRect.contains(x, y)) return ROLE_TNT;
        if (y >= areaTop() && y < controlTop() && x >= GRID_X && x < GRID_X + COLS * CELL) return ROLE_GRID;
        return ROLE_NONE;
    }

    private void updateTarget(float x, float y) {
        int col = (int) Math.floor((x - GRID_X) / CELL);
        int row = (int) Math.floor((y - areaTop() + cameraY - GRID_Y) / CELL);
        targetCol = (col >= 0 && col < COLS) ? col : -1;
        targetRow = (row >= 0 && row < ROWS) ? row : -1;
    }

    private void updateHover(float x, float y) {
        int col = (int) Math.floor((x - GRID_X) / CELL);
        int row = (int) Math.floor((y - areaTop() + cameraY - GRID_Y) / CELL);
        boolean inside = y >= areaTop() && y < controlTop() && col >= 0 && col < COLS;
        hoverCol = inside ? col : -1;
        hoverRow = (inside && row >= 0 && row < ROWS) ? row : -1;
    }

    private void addPointer(MotionEvent e, int index) {
        int id = e.getPointerId(index);
        float x = toLogicalX(e.getX(index)), y = toLogicalY(e.getY(index));
        boolean mouse = e.getToolType(index) == MotionEvent.TOOL_TYPE_MOUSE;
        int role = roleAt(x, y);
        TouchPoint t = new TouchPoint(role, x, y);
        t.arg = hitArg;
        t.mouse = mouse;
        touches.put(id, t);

        mouseActive = mouse;
        if (mouse) updateHover(x, y);

        if (role == ROLE_PAUSE) {
            pressCenterX = x; pressCenterY = y;
            pressUntilNanos = now() + 220000000L;
        } else if (role == ROLE_RUN) {
            sprintToggle = !sprintToggle;
        } else if (role == ROLE_PICK) {
            breakMode = !breakMode;
        } else if (role == ROLE_BUILD) {
            breakMode = false;
            launchBlock(previewCol());
        } else if (role == ROLE_JUMP) {
            jumpRequested = true;
        } else if (role == ROLE_GIFT) {
            triggerGift(t.arg);
        } else if (role == ROLE_TNT) {
            dropTnt();
        } else if (role == ROLE_GRID) {
            updateTarget(x, y);
            if (mouse) {
                boolean right = (e.getButtonState() & MotionEvent.BUTTON_SECONDARY) != 0;
                mouseButton = right ? 2 : 1;
                mouseGridHold = true;
                if (right || breakMode) {
                    breakBlockAt(targetCol, targetRow);
                    breakCooldown = 0.18f;
                } else if (targetCol >= 0) {
                    launchBlock(targetCol);
                }
            }
        }
        refreshHeldButtons();
    }

    private void updatePointers(MotionEvent e) {
        for (int i = 0; i < e.getPointerCount(); i++) {
            int id = e.getPointerId(i);
            TouchPoint t = touches.get(id);
            if (t == null) continue;
            t.x = toLogicalX(e.getX(i));
            t.y = toLogicalY(e.getY(i));
            // A finger may slide between the two directional pads without lifting.
            if ((t.role == ROLE_LEFT || t.role == ROLE_RIGHT) && t.y >= controlTop() && t.x >= 0f && t.x < 164f) {
                t.role = t.x < 83f ? ROLE_LEFT : ROLE_RIGHT;
            }
            if (t.role == ROLE_GRID) {
                updateTarget(t.x, t.y);
                if (t.mouse) updateHover(t.x, t.y);
            }
        }
        refreshHeldButtons();
    }

    private void releasePointer(MotionEvent e, int index) {
        int id = e.getPointerId(index);
        TouchPoint t = touches.get(id);
        if (t != null && t.role == ROLE_GRID) {
            if (t.mouse) {
                mouseGridHold = false;
                mouseButton = 0;
            } else {
                updateTarget(toLogicalX(e.getX(index)), toLogicalY(e.getY(index)));
                if (breakMode) breakBlockAt(targetCol, targetRow);
            }
        } else if (t != null && t.role == ROLE_PAUSE) {
            pauseGame();
            pressUntilNanos = now() + 140000000L;
        }
        touches.remove(id);
        refreshHeldButtons();
    }

    private void refreshHeldButtons() {
        touchLeft = touchRight = touchJump = touchBuild = false;
        for (int i = 0; i < touches.size(); i++) {
            int role = touches.valueAt(i).role;
            if (role == ROLE_LEFT) touchLeft = true;
            if (role == ROLE_RIGHT) touchRight = true;
            if (role == ROLE_JUMP) touchJump = true;
            if (role == ROLE_BUILD) touchBuild = true;
        }
        leftHeld = touchLeft || keyLeft || padLeft;
        rightHeld = touchRight || keyRight || padRight;
        jumpHeld = touchJump || keyJump;
        buildHeld = touchBuild || keyBuild;
    }

    private void releaseAllInput() {
        touches.clear();
        keyLeft = keyRight = keyJump = keyBuild = keyShift = keyMineFront = keyMineDown = false;
        padLeft = padRight = false;
        mouseGridHold = false;
        mouseButton = 0;
        jumpRequested = false;
        refreshHeldButtons();
    }

    @Override public boolean onTouchEvent(MotionEvent event) {
        int action = event.getActionMasked();
        int index = event.getActionIndex();

        if (screen != SCREEN_GAME) {
            if (action == MotionEvent.ACTION_DOWN) {
                pressCenterX = toLogicalX(event.getX(index));
                pressCenterY = toLogicalY(event.getY(index));
                pressUntilNanos = now() + 220000000L;
            } else if (action == MotionEvent.ACTION_UP) {
                handleScreenTap(toLogicalX(event.getX(index)), toLogicalY(event.getY(index)));
                pressUntilNanos = now() + 140000000L;
            }
            invalidate();
            return true;
        }

        switch (action) {
            case MotionEvent.ACTION_DOWN:
            case MotionEvent.ACTION_POINTER_DOWN:
                addPointer(event, index);
                break;
            case MotionEvent.ACTION_MOVE:
                updatePointers(event);
                break;
            case MotionEvent.ACTION_POINTER_UP:
                releasePointer(event, index);
                break;
            case MotionEvent.ACTION_UP:
                releasePointer(event, index);
                touches.clear();
                mouseGridHold = false;
                refreshHeldButtons();
                break;
            case MotionEvent.ACTION_CANCEL:
                touches.clear();
                mouseGridHold = false;
                jumpRequested = false;
                refreshHeldButtons();
                break;
            default:
                break;
        }
        invalidate();
        return true;
    }

    /** Mouse hover and gamepad sticks arrive as generic motion events. */
    @Override public boolean onGenericMotionEvent(MotionEvent e) {
        int src = e.getSource();
        int action = e.getActionMasked();
        if ((src & InputDevice.SOURCE_JOYSTICK) == InputDevice.SOURCE_JOYSTICK
                && action == MotionEvent.ACTION_MOVE) {
            float ax = e.getAxisValue(MotionEvent.AXIS_X);
            float hat = e.getAxisValue(MotionEvent.AXIS_HAT_X);
            padLeft = ax < -0.45f || hat < -0.5f;
            padRight = ax > 0.45f || hat > 0.5f;
            refreshHeldButtons();
            return true;
        }
        if (action == MotionEvent.ACTION_HOVER_MOVE || action == MotionEvent.ACTION_HOVER_ENTER) {
            mouseActive = true;
            updateHover(toLogicalX(e.getX()), toLogicalY(e.getY()));
            return true;
        }
        if (action == MotionEvent.ACTION_HOVER_EXIT) {
            hoverCol = -1; hoverRow = -1;
            return true;
        }
        return super.onGenericMotionEvent(e);
    }

    private void handleScreenTap(float x, float y) {
        if (screen == SCREEN_MENU) {
            if (menuHits[0].contains(x, y)) {
                startGame();
            } else if (menuHits[1].contains(x, y)) {
                screen = SCREEN_SETTINGS;
            } else if (menuHits[2].contains(x, y)) {
                if (getContext() instanceof Activity) ((Activity) getContext()).finish();
            }
        } else if (screen == SCREEN_SETTINGS) {
            if (settingsHits[0].contains(x, y)) {
                soundEnabled = !soundEnabled;
            } else if (settingsHits[1].contains(x, y)) {
                musicEnabled = !musicEnabled;
            } else if (settingsHits[2].contains(x, y)) {
                screen = SCREEN_MENU;
            }
        } else if (screen == SCREEN_PAUSE) {
            if (pauseHits[0].contains(x, y)) {
                resumeGame();
            } else if (pauseHits[1].contains(x, y)) {
                startGame();
            } else if (pauseHits[2].contains(x, y)) {
                screen = SCREEN_MENU;
                lastFrameNanos = 0L;
            } else if (pauseHits[3].contains(x, y)) {
                if (getContext() instanceof Activity) ((Activity) getContext()).finish();
            }
        }
    }

    // ================================================================================
    // Input: keyboard / gamepad buttons / activity hooks
    // ================================================================================
    public void pauseGame() {
        if (screen != SCREEN_GAME) return;
        screen = SCREEN_PAUSE;
        releaseAllInput();
    }

    private void resumeGame() {
        screen = SCREEN_GAME;
        lastFrameNanos = now();
    }

    /** Called from Activity.onPause. */
    public void onHostPause() {
        pauseGame();
        releaseAllInput();
    }

    /** Back button. Returns true when the game consumed it. */
    public boolean handleBack() {
        if (screen == SCREEN_GAME) { pauseGame(); return true; }
        if (screen == SCREEN_PAUSE) { resumeGame(); return true; }
        if (screen == SCREEN_SETTINGS) { screen = SCREEN_MENU; return true; }
        return false;
    }

    @Override public void onWindowFocusChanged(boolean hasWindowFocus) {
        super.onWindowFocusChanged(hasWindowFocus);
        if (!hasWindowFocus) {
            if (screen == SCREEN_GAME) pauseGame();
            releaseAllInput();
        }
    }

    @Override protected void onDetachedFromWindow() {
        release();
        super.onDetachedFromWindow();
    }

    @Override public boolean onKeyDown(int keyCode, KeyEvent event) {
        return handleKeyEvent(event) || super.onKeyDown(keyCode, event);
    }

    @Override public boolean onKeyUp(int keyCode, KeyEvent event) {
        return handleKeyEvent(event) || super.onKeyUp(keyCode, event);
    }

    /**
     * Keyboard / gamepad handling. The activity forwards every key event here, so
     * input works even when the view does not hold focus (Bluetooth / OTG keyboards).
     */
    public boolean handleKeyEvent(KeyEvent e) {
        int code = e.getKeyCode();
        boolean down = e.getAction() == KeyEvent.ACTION_DOWN;
        boolean up = e.getAction() == KeyEvent.ACTION_UP;
        if (!down && !up) return false;
        boolean fresh = down && e.getRepeatCount() == 0;
        if (code == KeyEvent.KEYCODE_BACK) return false;   // handled by Activity.onBackPressed

        if (screen == SCREEN_MENU) {
            if (fresh && isConfirmKey(code)) { startGame(); return true; }
            if (fresh && code == KeyEvent.KEYCODE_O) { screen = SCREEN_SETTINGS; return true; }
            return code == KeyEvent.KEYCODE_ESCAPE;
        }
        if (screen == SCREEN_SETTINGS) {
            if (fresh && (isConfirmKey(code) || code == KeyEvent.KEYCODE_ESCAPE)) { screen = SCREEN_MENU; return true; }
            if (fresh && code == KeyEvent.KEYCODE_S) { soundEnabled = !soundEnabled; return true; }
            if (fresh && code == KeyEvent.KEYCODE_M) { musicEnabled = !musicEnabled; return true; }
            return false;
        }
        if (screen == SCREEN_PAUSE) {
            if (fresh && (isConfirmKey(code) || code == KeyEvent.KEYCODE_ESCAPE || code == KeyEvent.KEYCODE_P
                    || code == KeyEvent.KEYCODE_BUTTON_START)) { resumeGame(); return true; }
            if (fresh && code == KeyEvent.KEYCODE_R) { startGame(); return true; }
            if (fresh && code == KeyEvent.KEYCODE_M) { screen = SCREEN_MENU; lastFrameNanos = 0L; return true; }
            return false;
        }

        // ---- in game ----
        switch (code) {
            case KeyEvent.KEYCODE_A:
            case KeyEvent.KEYCODE_DPAD_LEFT:
                keyLeft = down; break;
            case KeyEvent.KEYCODE_D:
            case KeyEvent.KEYCODE_DPAD_RIGHT:
                keyRight = down; break;
            case KeyEvent.KEYCODE_W:
            case KeyEvent.KEYCODE_DPAD_UP:
            case KeyEvent.KEYCODE_SPACE:
            case KeyEvent.KEYCODE_BUTTON_A:
                if (fresh) jumpRequested = true;
                keyJump = down; break;
            case KeyEvent.KEYCODE_SHIFT_LEFT:
            case KeyEvent.KEYCODE_SHIFT_RIGHT:
            case KeyEvent.KEYCODE_BUTTON_R1:
                keyShift = down; break;
            case KeyEvent.KEYCODE_E:
            case KeyEvent.KEYCODE_F:
            case KeyEvent.KEYCODE_ENTER:
            case KeyEvent.KEYCODE_NUMPAD_ENTER:
            case KeyEvent.KEYCODE_BUTTON_X:
            case KeyEvent.KEYCODE_BUTTON_R2:
                if (fresh) { breakMode = false; if (countdownValue < 0) launchBlock(previewCol()); }
                keyBuild = down; break;
            case KeyEvent.KEYCODE_S:
            case KeyEvent.KEYCODE_DPAD_DOWN:
                keyMineDown = down; if (down) mineCooldown = Math.min(mineCooldown, 0f); break;
            case KeyEvent.KEYCODE_X:
            case KeyEvent.KEYCODE_Z:
            case KeyEvent.KEYCODE_CTRL_LEFT:
            case KeyEvent.KEYCODE_CTRL_RIGHT:
            case KeyEvent.KEYCODE_BUTTON_B:
                keyMineFront = down; if (down) mineCooldown = Math.min(mineCooldown, 0f); break;
            case KeyEvent.KEYCODE_Q:
            case KeyEvent.KEYCODE_BUTTON_Y:
                if (fresh) { breakMode = !breakMode; toast(breakMode ? "MODE BELIUNG" : "MODE BLOK"); }
                break;
            case KeyEvent.KEYCODE_T:
            case KeyEvent.KEYCODE_BUTTON_L1:
                if (fresh) dropTnt();
                break;
            case KeyEvent.KEYCODE_P:
            case KeyEvent.KEYCODE_ESCAPE:
            case KeyEvent.KEYCODE_BUTTON_START:
            case KeyEvent.KEYCODE_MENU:
                if (fresh) pauseGame();
                break;
            default:
                if (code >= KeyEvent.KEYCODE_1 && code <= KeyEvent.KEYCODE_8) {
                    if (fresh) triggerGift(code - KeyEvent.KEYCODE_1);
                } else if (code >= KeyEvent.KEYCODE_NUMPAD_1 && code <= KeyEvent.KEYCODE_NUMPAD_8) {
                    if (fresh) triggerGift(code - KeyEvent.KEYCODE_NUMPAD_1);
                } else {
                    return false;
                }
        }
        refreshHeldButtons();
        return true;
    }

    private boolean isConfirmKey(int code) {
        return code == KeyEvent.KEYCODE_ENTER || code == KeyEvent.KEYCODE_NUMPAD_ENTER
                || code == KeyEvent.KEYCODE_SPACE || code == KeyEvent.KEYCODE_DPAD_CENTER
                || code == KeyEvent.KEYCODE_BUTTON_A || code == KeyEvent.KEYCODE_BUTTON_START;
    }
}
