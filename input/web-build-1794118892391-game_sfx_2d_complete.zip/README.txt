24 original game sound effects. WAV mono PCM 16-bit 22050 Hz.
Button, menu, block placing/breaking, footsteps, running, jumping, landing, finish, damage, game over.
