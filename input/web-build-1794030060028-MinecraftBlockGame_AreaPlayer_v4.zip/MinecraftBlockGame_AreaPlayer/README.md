# Minecraft Block Game - Area, Player, HUD, Levels and Blocks

Android Native Java project for AndroidForge.

## Included
- Full-screen responsive Canvas: arena is drawn to the device's complete width and height.
- HUD overlays the arena; it shifts upward slightly as placed blocks rise.
- No fake player name, block percentage, or WIN display.
- Active Level 1-3 selection.
- Different block palettes for each level.
- Settings button opens level settings; each level has independent enabled/disabled block choices saved in SharedPreferences.
- Five sample block textures are drawn in code; tap a slot to select, then tap a grid cell to place/remove the selected block.
- Steve character: 5 walk, 5 run and 5 jump frames.
- Left/right movement, jump and RUN toggle (tap once ON, tap again OFF).
- Original generated sound effects: footsteps, sprint footsteps, jump and landing.
- WIN/goal logic is deliberately not implemented yet.

## Build in AndroidForge
Open the extracted project folder as a Gradle Android project.
Use JDK 17 and Android SDK Platform 35.
Application ID: `com.mcpakel.blockarea`
No WebView and no external dependencies.
