package com.mcpakel.blockarea;

import android.content.Context;
import android.content.SharedPreferences;
import android.graphics.*;
import android.media.AudioAttributes;
import android.media.SoundPool;
import android.view.MotionEvent;
import android.view.View;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

/**
 * Minecraft block-stacking game foundation.
 * Responsive full-screen canvas, level-specific block palettes, editable block
 * availability, basic cell placement, character animation and SoundPool SFX.
 */
public class AreaView extends View {
    private static final float W=864f, H=1920f, ARENA_BOTTOM=1620f;
    private static final int COLS=19, ROWS=37;
    private static final float GRID_X=90f, GRID_Y=92f, CELL_W=36f, CELL_H=38f;

    private final Paint p=new Paint();
    private final Bitmap[][] frames=new Bitmap[3][5];
    private Bitmap arenaBitmap;
    private final int[][] placed=new int[ROWS][COLS];
    private final boolean[][] enabled=new boolean[3][5];
    private final SharedPreferences prefs;
    private SoundPool soundPool;
    private int soundWalk, soundRun, soundJump, soundLand;
    private long lastStepSound=0;
    private boolean wasGrounded=true;

    // Block ids: 1 grass, 2 dirt, 3 stone, 4 oak, 5 brick,
    // 6 cobble, 7 iron, 8 glass, 9 netherrack, 10 basalt.
    private final String[] blockNames={"Grass","Dirt","Stone","Oak","Brick",
            "Cobble","Iron","Glass","Netherrack","Basalt"};
    private final int[][] levelBlocks={
            {1,2,3,4,5},
            {3,6,7,8,5},
            {2,3,6,9,10}
    };
    private int currentLevel=0;
    private int selectedBlock=1;
    private boolean settingsOpen=false;

    private float playerX=432f, playerY=1510f, velocityY=0f;
    private boolean leftPressed,rightPressed,jumpPressed,sprintMode=false;
    private boolean facingRight=true,onGround=true;
    private int action=0,walkFrame=0,runFrame=0,jumpFrame=0;
    private float animClock=0f;
    private long lastTime=0L;
    private final RectF spriteDst=new RectF();

    private final RectF leftBtn=new RectF(42,1662,150,1770);
    private final RectF rightBtn=new RectF(164,1662,272,1770);
    private final RectF runBtn=new RectF(292,1662,440,1770);
    private final RectF jumpBtn=new RectF(710,1650,824,1778);
    private final RectF settingsBtn=new RectF(780,24,842,92);
    private final RectF[] slots=new RectF[5];

    public AreaView(Context context) {
        super(context);
        setLayerType(View.LAYER_TYPE_SOFTWARE,null);
        prefs=context.getSharedPreferences("block_level_settings",Context.MODE_PRIVATE);
        loadSavedBlockSettings();
        for(int i=0;i<5;i++) slots[i]=new RectF(18+i*168,118,160+i*168,230);
        loadAssets(context);
        initSounds(context);
    }

    private void loadSavedBlockSettings() {
        for(int l=0;l<3;l++) for(int i=0;i<5;i++)
            enabled[l][i]=prefs.getBoolean("level_"+l+"_block_"+levelBlocks[l][i],true);
    }

    private void saveBlockSetting(int blockId,boolean value) {
        enabled[currentLevel][indexOfBlock(currentLevel,blockId)]=value;
        prefs.edit().putBoolean("level_"+currentLevel+"_block_"+blockId,value).apply();
        if(!isBlockEnabled(selectedBlock)) selectedBlock=firstEnabledBlock();
    }

    private int indexOfBlock(int level,int blockId) {
        for(int i=0;i<levelBlocks[level].length;i++) if(levelBlocks[level][i]==blockId) return i;
        return 0;
    }
    private boolean isBlockEnabled(int id) {
        int idx=indexOfBlock(currentLevel,id);
        return levelBlocks[currentLevel][idx]==id && enabled[currentLevel][idx];
    }
    private int firstEnabledBlock() {
        for(int id:levelBlocks[currentLevel]) if(isBlockEnabled(id)) return id;
        return 0;
    }

    private void loadAssets(Context c) {
        try { arenaBitmap=BitmapFactory.decodeStream(c.getAssets().open("area/arena_reference.jpg")); }
        catch(IOException ignored) {}
        String[] acts={"walk","run","jump"};
        for(int a=0;a<3;a++) for(int i=0;i<5;i++) {
            try { frames[a][i]=BitmapFactory.decodeStream(c.getAssets().open(
                    "character/"+acts[a]+"_"+i+".png")); }
            catch(IOException ignored) {}
        }
    }

    private void initSounds(Context c) {
        AudioAttributes attrs=new AudioAttributes.Builder()
                .setUsage(AudioAttributes.USAGE_GAME)
                .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION).build();
        soundPool=new SoundPool.Builder().setMaxStreams(4).setAudioAttributes(attrs).build();
        try {
            soundWalk=soundPool.load(c.getAssets().openFd("sounds/footstep.wav"),1);
            soundRun=soundPool.load(c.getAssets().openFd("sounds/run_step.wav"),1);
            soundJump=soundPool.load(c.getAssets().openFd("sounds/jump.wav"),1);
            soundLand=soundPool.load(c.getAssets().openFd("sounds/land.wav"),1);
        } catch(IOException ignored) {}
    }

    @Override protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        // Fill every phone pixel; no letterbox bars.
        float sx=getWidth()/W, sy=getHeight()/H;
        canvas.save();
        canvas.scale(sx,sy);
        drawBackground(canvas);
        drawArena(canvas);
        drawPlacedBlocks(canvas);
        drawPlayer(canvas);
        drawHud(canvas);
        drawControls(canvas);
        if(settingsOpen) drawSettings(canvas);
        canvas.restore();
        updatePlayer();
        postInvalidateDelayed(16);
    }

    private void drawBackground(Canvas c) {
        p.setShader(new LinearGradient(0,0,0,H,0xff2d9fdf,0xff4e3526,Shader.TileMode.CLAMP));
        c.drawRect(0,0,W,H,p); p.setShader(null);
        // Ground texture visible in the bottom control strip.
        p.setColor(0xff397f29); c.drawRect(0,1618,W,1632,p);
        p.setColor(0xff8c5a32); c.drawRect(0,1632,W,H,p);
        for(int x=0;x<W;x+=24) {
            p.setColor(0xff5c3c28); c.drawRect(x+4,1645,x+14,1653,p);
            p.setColor(0xffa06a3d); c.drawRect(x+13,1680,x+21,1688,p);
        }
    }

    private void drawArena(Canvas c) {
        if(arenaBitmap!=null) {
            p.setAlpha(255); p.setFilterBitmap(false);
            // Full-screen height adapts to the device; HUD is layered above it.
            c.drawBitmap(arenaBitmap,null,new RectF(0,0,W,ARENA_BOTTOM),p);
        } else {
            p.setColor(0xff1c2026); c.drawRect(0,0,W,ARENA_BOTTOM,p);
        }
    }

    private void drawPlacedBlocks(Canvas c) {
        for(int r=0;r<ROWS;r++) for(int col=0;col<COLS;col++) {
            int id=placed[r][col];
            if(id==0) continue;
            float x=GRID_X+col*CELL_W, y=GRID_Y+r*CELL_H;
            drawBlock(c,id,x,y,CELL_W,CELL_H);
        }
    }

    private void drawBlock(Canvas c,int id,float x,float y,float w,float h) {
        int top,side,shade;
        switch(id) {
            case 1: top=0xff63b82d; side=0xff80502f; shade=0xff573823; break;
            case 2: top=0xff98613a; side=0xff79502f; shade=0xff553923; break;
            case 3: top=0xffa0a5aa; side=0xff777e86; shade=0xff4b5058; break;
            case 4: top=0xffb8844c; side=0xff8a5a32; shade=0xff5e3d25; break;
            case 5: top=0xffb75a4b; side=0xff923e35; shade=0xff5b2927; break;
            case 6: top=0xff858b91; side=0xff686e76; shade=0xff444950; break;
            case 7: top=0xffd1d8dc; side=0xff9ea8b1; shade=0xff66717a; break;
            case 8: top=0xff9cdef2; side=0xff68a9c1; shade=0xff42788d; break;
            case 9: top=0xff9c443c; side=0xff79322e; shade=0xff4d2525; break;
            default: top=0xff555b62; side=0xff41474f; shade=0xff292e35; break;
        }
        p.setColor(shade); c.drawRect(x,y,x+w,y+h,p);
        p.setColor(side); c.drawRect(x+2,y+2,x+w-2,y+h-2,p);
        p.setColor(top); c.drawRect(x+3,y+3,x+w-3,y+Math.max(7,h*.25f),p);
        p.setColor(0x44ffffff); c.drawRect(x+3,y+3,x+w-3,y+5,p);
        p.setColor(0x33000000); c.drawRect(x+3,y+h-4,x+w-3,y+h-2,p);
        // small pixel texture details
        p.setColor(0x33402010);
        c.drawRect(x+w*.25f,y+h*.48f,x+w*.38f,y+h*.58f,p);
        c.drawRect(x+w*.66f,y+h*.68f,x+w*.78f,y+h*.76f,p);
    }

    private void drawPlayer(Canvas c) {
        Bitmap b=action==2?frames[2][jumpFrame]:(action==1?frames[1][runFrame]:frames[0][walkFrame]);
        if(b==null) return;
        float h=108f,w=h*b.getWidth()/b.getHeight();
        spriteDst.set(playerX-w/2,playerY-h,playerX+w/2,playerY);
        c.save();
        if(!facingRight) c.scale(-1,1,playerX,0);
        p.setAlpha(255); p.setFilterBitmap(false); c.drawBitmap(b,null,spriteDst,p);
        c.restore();
    }

    // ---------- HUD ----------
    private float hudShift() {
        int highest=ROWS;
        for(int r=0;r<ROWS;r++) {
            boolean found=false;
            for(int c=0;c<COLS;c++) if(placed[r][c]!=0) { found=true; break; }
            if(found) { highest=r; break; }
        }
        if(highest==ROWS) return 0;
        int rise=ROWS-highest;
        return -Math.min(90f,rise*2.4f);
    }

    private void panel(Canvas c,RectF r) {
        p.setShader(new LinearGradient(r.left,r.top,r.left,r.bottom,0xff7c8796,0xff202630,Shader.TileMode.CLAMP));
        c.drawRoundRect(r,14,14,p); p.setShader(null);
        p.setStyle(Paint.Style.STROKE); p.setStrokeWidth(5); p.setColor(0xff090c12);
        c.drawRoundRect(r,14,14,p);
        p.setStrokeWidth(2); p.setColor(0xffc4ccd5);
        c.drawRoundRect(r.left+4,r.top+4,r.right-4,r.bottom-4,10,10,p);
        p.setStyle(Paint.Style.FILL);
    }

    private void drawHud(Canvas c) {
        float shift=hudShift();
        c.save(); c.translate(0,shift);
        panel(c,new RectF(18,14,270,101));
        panel(c,new RectF(284,14,570,101));
        panel(c,new RectF(584,14,846,101));

        // Level is active, but no player name, block percentage or WIN indicator yet.
        drawTrophy(c,310,31,48);
        text(c,"LEVEL "+(currentLevel+1),445,70,30,Color.WHITE,Paint.Align.CENTER,true);
        drawGrassBlock(c,610,29,54);
        text(c,"BLOCK SET",758,68,24,Color.WHITE,Paint.Align.CENTER,true);
        drawSettingsIcon(c,settingsBtn);

        // Inventory selection: only blocks enabled for this level are displayed.
        int[] palette=levelBlocks[currentLevel];
        for(int i=0;i<5;i++) {
            RectF r=slots[i]; panel(c,r);
            int id=palette[i];
            boolean on=enabled[currentLevel][i];
            if(on) {
                drawBlock(c,id,r.left+34,r.top+23,44,52);
                if(selectedBlock==id) {
                    p.setStyle(Paint.Style.STROKE); p.setStrokeWidth(4);
                    p.setColor(0xffffdf4a); c.drawRoundRect(r,12,12,p); p.setStyle(Paint.Style.FILL);
                }
            } else {
                p.setColor(0xff14171d); c.drawRect(r.left+10,r.top+15,r.right-10,r.bottom-12,p);
                text(c,"OFF",r.centerX(),r.centerY()+8,21,0xff777f8a,Paint.Align.CENTER,true);
            }
        }
        c.restore();
    }

    private void drawTrophy(Canvas c,float x,float y,float s) {
        p.setColor(0xffffc51b);
        c.drawRect(x+s*.25f,y+s*.08f,x+s*.75f,y+s*.62f,p);
        c.drawRect(x+s*.13f,y+s*.14f,x+s*.28f,y+s*.43f,p);
        c.drawRect(x+s*.72f,y+s*.14f,x+s*.87f,y+s*.43f,p);
        c.drawRect(x+s*.38f,y+s*.60f,x+s*.62f,y+s*.80f,p);
        c.drawRect(x+s*.22f,y+s*.80f,x+s*.78f,y+s*.92f,p);
    }

    private void drawGrassBlock(Canvas c,float x,float y,float s) {
        p.setColor(0xff754a2c); c.drawRect(x,y+s*.28f,x+s,y+s,p);
        p.setColor(0xff4a9829); c.drawRect(x,y+s*.18f,x+s,y+s*.42f,p);
        p.setColor(0xff83d83a); c.drawRect(x,y+s*.18f,x+s,y+s*.29f,p);
        p.setColor(0xff5b3a25); c.drawRect(x+8,y+s*.53f,x+15,y+s*.65f,p);
    }

    private void drawSettingsIcon(Canvas c,RectF r) {
        p.setColor(0xff252c35); c.drawRoundRect(r,10,10,p);
        p.setStyle(Paint.Style.STROKE); p.setStrokeWidth(5); p.setColor(Color.WHITE);
        c.drawCircle(r.centerX(),r.centerY(),17,p);
        p.setStyle(Paint.Style.FILL); p.setColor(Color.WHITE);
        c.drawCircle(r.centerX(),r.centerY(),6,p);
    }

    private void text(Canvas c,String s,float x,float y,float size,int color,Paint.Align align,boolean bold) {
        p.setShader(null); p.setColor(color); p.setTextSize(size); p.setTextAlign(align);
        p.setTypeface(Typeface.create("sans-serif",bold?Typeface.BOLD:Typeface.NORMAL));
        c.drawText(s,x,y,p);
    }

    private void drawControls(Canvas c) {
        p.setShader(new LinearGradient(0,1620,0,H,0xff76502f,0xff3e291d,Shader.TileMode.CLAMP));
        c.drawRect(0,1620,W,H,p); p.setShader(null);
        p.setColor(0xff408b2a); c.drawRect(0,1620,W,1630,p);
        p.setColor(0xff75c33a); c.drawRect(0,1620,W,1625,p);

        controlButton(c,leftBtn,"‹",leftPressed,false);
        controlButton(c,rightBtn,"›",rightPressed,false);
        controlButton(c,runBtn,"RUN",false,sprintMode);
        controlButton(c,jumpBtn,"↑",jumpPressed,false);
        drawHearts(c,300,1815,5);
    }

    private void controlButton(Canvas c,RectF r,String label,boolean pressed,boolean toggle) {
        int a=(pressed||toggle)?0xff49677b:0xff303946;
        int b=(pressed||toggle)?0xff172c3c:0xff171c24;
        p.setShader(new LinearGradient(r.left,r.top,r.left,r.bottom,a,b,Shader.TileMode.CLAMP));
        c.drawRoundRect(r,17,17,p); p.setShader(null);
        p.setStyle(Paint.Style.STROKE); p.setStrokeWidth(5);
        p.setColor((pressed||toggle)?0xff31d7ef:0xff080b10);
        c.drawRoundRect(r,17,17,p); p.setStyle(Paint.Style.FILL);
        text(c,label,r.centerX(),r.centerY()+12,label.equals("RUN")?28:66,Color.WHITE,Paint.Align.CENTER,true);
        if(label.equals("RUN")) {
            p.setColor(toggle?0xff69ff38:0xff626d79);
            c.drawCircle(r.right-17,r.top+17,7,p);
        }
    }

    private void drawHearts(Canvas c,float x,float y,int n) {
        for(int i=0;i<n;i++) {
            float hx=x+i*47;
            Path path=new Path();
            path.moveTo(hx+16,y+31);
            path.cubicTo(hx-15,y+10,hx+1,y-7,hx+16,y+7);
            path.cubicTo(hx+32,y-7,hx+48,y+10,hx+16,y+31);
            p.setColor(0xff12080a); c.drawPath(path,p);
            c.save(); c.translate(0,-3);
            p.setColor(0xffed1725); c.drawPath(path,p);
            p.setColor(0xffff7378); c.drawCircle(hx+9,y+9,3,p);
            c.restore();
        }
    }

    // ---------- Level settings overlay ----------
    private void drawSettings(Canvas c) {
        p.setColor(0xb9000000); c.drawRect(0,0,W,H,p);
        RectF box=new RectF(90,430,774,1390);
        panel(c,box);
        text(c,"LEVEL SETTINGS",432,495,34,Color.WHITE,Paint.Align.CENTER,true);
        text(c,"PILIH LEVEL",432,550,21,0xffd5dce5,Paint.Align.CENTER,true);
        for(int l=0;l<3;l++) {
            RectF b=new RectF(135+l*205,575,320+l*205,650);
            panel(c,b);
            text(c,"LEVEL "+(l+1),b.centerX(),621,20,
                    currentLevel==l?0xffffdf4a:Color.WHITE,Paint.Align.CENTER,true);
        }
        text(c,"BLOK YANG DIIZINKAN",432,710,23,Color.WHITE,Paint.Align.CENTER,true);
        for(int i=0;i<5;i++) {
            int id=levelBlocks[currentLevel][i];
            float y=750+i*105;
            RectF row=new RectF(130,y,734,y+82);
            p.setColor(0xff171c24); c.drawRoundRect(row,10,10,p);
            drawBlock(c,id,150,y+12,50,58);
            text(c,blockNames[id-1],225,y+51,23,Color.WHITE,Paint.Align.LEFT,true);
            RectF toggle=new RectF(650,y+17,714,y+65);
            p.setColor(enabled[currentLevel][i]?0xff239e42:0xff555b64);
            c.drawRoundRect(toggle,22,22,p);
            p.setColor(Color.WHITE);
            float cx=enabled[currentLevel][i]?695:669;
            c.drawCircle(cx,y+41,17,p);
        }
        text(c,"KETUK BLOK UNTUK AKTIF / NONAKTIF",432,1320,17,0xffc9d1dc,Paint.Align.CENTER,false);
        text(c,"TUTUP",432,1365,23,0xffffdf4a,Paint.Align.CENTER,true);
    }

    private void updatePlayer() {
        long now=System.nanoTime();
        if(lastTime==0) lastTime=now;
        float dt=Math.min((now-lastTime)/1_000_000_000f,.04f);
        lastTime=now;
        float speed=sprintMode?270f:165f;
        boolean moving=leftPressed||rightPressed;
        if(leftPressed) { playerX-=speed*dt; facingRight=false; }
        if(rightPressed) { playerX+=speed*dt; facingRight=true; }
        playerX=Math.max(112,Math.min(752,playerX));

        if(jumpPressed&&onGround) {
            velocityY=-500; onGround=false; jumpFrame=0;
            play(soundJump,0.85f);
        }
        if(!onGround) {
            velocityY+=1120*dt; playerY+=velocityY*dt;
            if(playerY>=PLAYER_GROUND) {
                playerY=PLAYER_GROUND; velocityY=0; onGround=true;
                if(!wasGrounded) play(soundLand,0.8f);
            }
        }
        if(moving&&onGround) {
            long stepDelay=sprintMode?245:390;
            if(now-lastStepSound>stepDelay*1_000_000L) {
                play(sprintMode?soundRun:soundWalk,sprintMode?0.7f:0.55f);
                lastStepSound=now;
            }
        }

        animationClock+=dt;
        if(!onGround) {
            action=2;
            if(animationClock>=.11f) { jumpFrame=(jumpFrame+1)%5; animationClock=0; }
        } else if(moving) {
            action=sprintMode?1:0;
            float delay=sprintMode?.075f:.13f;
            if(animationClock>=delay) {
                if(action==1) runFrame=(runFrame+1)%5;
                else walkFrame=(walkFrame+1)%5;
                animationClock=0;
            }
        } else {
            action=0; walkFrame=0; animationClock=0;
        }
        wasGrounded=onGround;
    }

    private void play(int id,float volume) {
        if(soundPool!=null&&id!=0) soundPool.play(id,volume,volume,1,0,1f);
    }

    private float[] point(float x,float y) {
        return new float[]{x*W/getWidth(),y*H/getHeight()};
    }

    private void handleGridTap(float x,float y) {
        int col=(int)((x-GRID_X)/CELL_W), row=(int)((y-GRID_Y)/CELL_H);
        if(col<0||col>=COLS||row<0||row>=ROWS) return;
        if(selectedBlock==0) return;
        if(placed[row][col]==selectedBlock) placed[row][col]=0;
        else placed[row][col]=selectedBlock;
    }

    private void handleSettingsTap(float x,float y) {
        if(y>=575&&y<=650) {
            int l=(int)((x-135)/205);
            if(l>=0&&l<3) {
                currentLevel=l;
                selectedBlock=firstEnabledBlock();
            }
            return;
        }
        for(int i=0;i<5;i++) {
            float top=750+i*105;
            if(y>=top&&y<=top+82&&x>=130&&x<=734) {
                int id=levelBlocks[currentLevel][i];
                saveBlockSetting(id,!enabled[currentLevel][i]);
                return;
            }
        }
        if(y>=1325&&y<=1395) settingsOpen=false;
    }

    @Override public boolean onTouchEvent(MotionEvent e) {
        int a=e.getActionMasked(), idx=e.getActionIndex();
        if(a==MotionEvent.ACTION_DOWN||a==MotionEvent.ACTION_POINTER_DOWN) {
            float[] q=point(e.getX(idx),e.getY(idx));
            float x=q[0],y=q[1];
            if(settingsOpen) { handleSettingsTap(x,y); invalidate(); return true; }
            if(settingsBtn.contains(x,y)) { settingsOpen=true; invalidate(); return true; }
            float sh=hudShift();
            for(int i=0;i<5;i++) {
                RectF r=new RectF(slots[i]); r.offset(0,sh);
                if(r.contains(x,y)) {
                    int id=levelBlocks[currentLevel][i];
                    if(enabled[currentLevel][i]) selectedBlock=id;
                    invalidate(); return true;
                }
            }
            if(y>=GRID_Y&&y<ARENA_BOTTOM&&x>=GRID_X&&x<GRID_X+COLS*CELL_W) {
                handleGridTap(x,y); invalidate(); return true;
            }
            if(runBtn.contains(x,y)) {
                sprintMode=!sprintMode; invalidate(); return true;
            }
        }
        if(a==MotionEvent.ACTION_UP||a==MotionEvent.ACTION_CANCEL) {
            leftPressed=rightPressed=jumpPressed=false; return true;
        }
        leftPressed=rightPressed=jumpPressed=false;
        for(int i=0;i<e.getPointerCount();i++) {
            if(a==MotionEvent.ACTION_POINTER_UP&&i==idx) continue;
            float[] q=point(e.getX(i),e.getY(i));
            if(leftBtn.contains(q[0],q[1])) leftPressed=true;
            if(rightBtn.contains(q[0],q[1])) rightPressed=true;
            if(jumpBtn.contains(q[0],q[1])) jumpPressed=true;
        }
        return true;
    }

    @Override protected void onDetachedFromWindow() {
        super.onDetachedFromWindow();
        if(soundPool!=null) { soundPool.release(); soundPool=null; }
    }
}
