import { Ionicons } from "@expo/vector-icons";
import * as Clipboard from "expo-clipboard";
import * as DocumentPicker from "expo-document-picker";
import * as Linking from "expo-linking";
import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import {
  ActivityIndicator,
  Animated,
  Easing,
  KeyboardAvoidingView,
  Modal,
  Platform,
  Pressable,
  ScrollView,
  StyleSheet,
  Switch,
  Text,
  TextInput,
  View,
} from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import { api } from "@/src/api";
import { startForegroundService, stopForegroundService } from "@/src/foreground";
import { translations, type Language } from "@/src/i18n";
import type { CreateServerInput, JavaVersion, ServerConfig, ServerState, ServerSummary } from "@/src/types";

const colors = {
  bg: "#0F111A", card: "#181B26", raised: "#232733", text: "#F0F2F5", muted: "#94A3B8",
  green: "#10B981", success: "#22C55E", amber: "#F59E0B", red: "#EF4444",
  blue: "#3B82F6", purple: "#8B5CF6", pink: "#EC4899", border: "#2A2F3D",
};

type Tab = "dashboard" | "console" | "files" | "players" | "mcpakel" | "settings";

const formatUptime = (seconds: number) =>
  [Math.floor(seconds / 3600), Math.floor((seconds % 3600) / 60), seconds % 60]
    .map((part) => String(part).padStart(2, "0")).join(":");
const formatSize = (bytes: number) =>
  bytes > 1024 * 1024 ? `${(bytes / 1024 / 1024).toFixed(1)} MB` : `${Math.max(1, Math.round(bytes / 1024))} KB`;

function PrimaryButton({ label, icon, onPress, tone = "green", disabled = false, testID, flex }: {
  label: string; icon: keyof typeof Ionicons.glyphMap; onPress: () => void;
  tone?: "green" | "dark" | "red" | "blue"; disabled?: boolean; testID?: string; flex?: boolean;
}) {
  return (
    <Pressable
      testID={testID || label.toLowerCase().replace(/[^a-z0-9]+/g, "-")}
      accessibilityRole="button"
      disabled={disabled}
      onPress={onPress}
      style={({ pressed }) => [
        styles.button,
        tone === "dark" && styles.darkButton,
        tone === "red" && styles.redButton,
        tone === "blue" && styles.blueButton,
        flex && { flex: 1 },
        disabled && styles.disabled,
        pressed && styles.pressed,
      ]}
    >
      <Ionicons name={icon} size={17} color={tone === "green" ? colors.bg : colors.text} />
      <Text style={[styles.buttonText, tone !== "green" && { color: colors.text }]}>{label}</Text>
    </Pressable>
  );
}

function Metric({ icon, label, value, accent = colors.text }: {
  icon: keyof typeof Ionicons.glyphMap; label: string; value: string; accent?: string;
}) {
  return (
    <View style={styles.metric}>
      <Ionicons name={icon} size={18} color={accent} />
      <Text style={styles.metricLabel}>{label}</Text>
      <Text style={[styles.metricValue, { color: accent }]}>{value}</Text>
    </View>
  );
}

function Field({ label, value, onChangeText, keyboardType, testID, placeholder }: {
  label: string; value: string; onChangeText: (value: string) => void;
  keyboardType?: "number-pad"; testID?: string; placeholder?: string;
}) {
  return (
    <View style={styles.field}>
      <Text style={styles.fieldLabel}>{label}</Text>
      <TextInput
        testID={testID || `field-${label.toLowerCase().replace(/[^a-z0-9]+/g, "-")}`}
        value={value}
        onChangeText={onChangeText}
        keyboardType={keyboardType}
        placeholder={placeholder}
        placeholderTextColor={colors.muted}
        style={styles.fieldInput}
        autoCapitalize="none"
      />
    </View>
  );
}

function Segment<T extends string>({ options, value, onChange, testIDPrefix }: {
  options: { key: T; label: string }[]; value: T; onChange: (v: T) => void; testIDPrefix: string;
}) {
  return (
    <View style={styles.segment}>
      {options.map((option) => (
        <Pressable
          key={option.key}
          testID={`${testIDPrefix}-${option.key}`}
          onPress={() => onChange(option.key)}
          style={[styles.segmentItem, value === option.key && styles.segmentActive]}
        >
          <Text style={[styles.segmentText, value === option.key && styles.segmentTextActive]}>{option.label}</Text>
        </Pressable>
      ))}
    </View>
  );
}

export default function Index() {
  const insets = useSafeAreaInsets();
  const [lang, setLang] = useState<Language>("id");
  const [tab, setTab] = useState<Tab>("dashboard");
  const [state, setState] = useState<ServerState | null>(null);
  const [config, setConfig] = useState<ServerConfig | null>(null);
  const [servers, setServers] = useState<ServerSummary[]>([]);
  const [lines, setLines] = useState<string[]>([]);
  const [files, setFiles] = useState<{ name: string; path: string; directory: boolean; size: number }[]>([]);
  const [command, setCommand] = useState("");
  const [loading, setLoading] = useState(true);
  const [busy, setBusy] = useState(false);
  const [message, setMessage] = useState("");
  const [showCreate, setShowCreate] = useState(false);
  const [showServerList, setShowServerList] = useState(false);
  const [confirmDeleteId, setConfirmDeleteId] = useState<string | null>(null);
  const [drawerOpen, setDrawerOpen] = useState(false);
  const [newServer, setNewServer] = useState<CreateServerInput>({
    name: "", java_version: "auto", min_ram: 1024, max_ram: 4096, port: 25565,
  });
  const t = translations[lang];

  // Drawer animation
  const drawerAnim = useRef(new Animated.Value(0)).current;
  useEffect(() => {
    Animated.timing(drawerAnim, {
      toValue: drawerOpen ? 1 : 0,
      duration: 220,
      easing: Easing.out(Easing.cubic),
      useNativeDriver: true,
    }).start();
  }, [drawerOpen, drawerAnim]);

  const load = useCallback(async () => {
    try {
      const [nextState, nextServers, nextConfig, nextConsole, nextFiles] = await Promise.all([
        api.state(),
        api.listServers(),
        api.config().catch(() => null),
        api.console().catch(() => ({ lines: [] as string[] })),
        api.files().catch(() => ({ items: [] })),
      ]);
      setState(nextState);
      setServers(nextServers.servers);
      if (nextConfig) setConfig(nextConfig);
      setLines(nextConsole.lines);
      setFiles(nextFiles.items);
    } catch (error) {
      setMessage(error instanceof Error ? error.message : t.error);
    } finally {
      setLoading(false);
    }
  }, [t.error]);

  useEffect(() => {
    void load();
    const interval = setInterval(() => { void api.state().then(setState).catch(() => undefined); }, 3000);
    return () => clearInterval(interval);
  }, [load]);

  useEffect(() => {
    if (tab !== "console") return;
    const interval = setInterval(() => {
      void api.console().then((response) => setLines(response.lines)).catch(() => undefined);
    }, 1500);
    return () => clearInterval(interval);
  }, [tab]);

  const perform = async (action: () => Promise<ServerState>) => {
    setBusy(true); setMessage("");
    try { setState(await action()); }
    catch (error) { setMessage(error instanceof Error ? error.message : t.error); }
    finally { setBusy(false); }
  };

  const importJar = async () => {
    const result = await DocumentPicker.getDocumentAsync({ type: "application/java-archive", copyToCacheDirectory: true });
    if (result.canceled || !result.assets[0]) return;
    setBusy(true); setMessage("");
    try {
      await api.importJar(result.assets[0].uri, result.assets[0].name);
      await load();
      setMessage(`${result.assets[0].name} siap digunakan.`);
    } catch (error) { setMessage(error instanceof Error ? error.message : t.error); }
    finally { setBusy(false); }
  };

  const copyIp = async () => {
    if (!state) return;
    await Clipboard.setStringAsync(`${state.local_ip}:${state.port}`);
    setMessage(t.copied);
  };

  const saveConfig = async () => {
    if (!config) return;
    setBusy(true);
    try { await api.saveConfig(config); setMessage(t.saved); await load(); }
    catch (error) { setMessage(error instanceof Error ? error.message : t.error); }
    finally { setBusy(false); }
  };

  const sendCommand = async () => {
    if (!command.trim()) return;
    try {
      await api.command(command);
      setCommand("");
      const response = await api.console();
      setLines(response.lines);
    } catch (error) { setMessage(error instanceof Error ? error.message : t.error); }
  };

  const createServer = async () => {
    if (!newServer.name.trim()) { setMessage(lang === "id" ? "Nama server wajib diisi" : "Server name is required"); return; }
    if (newServer.max_ram < newServer.min_ram) { setMessage(lang === "id" ? "RAM maksimum harus lebih besar dari minimum" : "Max RAM must be greater than min RAM"); return; }
    setBusy(true);
    try {
      await api.createServer(newServer);
      setShowCreate(false);
      setNewServer({ name: "", java_version: "auto", min_ram: 1024, max_ram: 4096, port: 25565 });
      await load();
      setMessage(t.createdOk);
    } catch (error) { setMessage(error instanceof Error ? error.message : t.error); }
    finally { setBusy(false); }
  };

  const activateServer = async (id: string) => {
    setBusy(true);
    try {
      await api.activateServer(id);
      setShowServerList(false);
      await load();
      setMessage(t.switchedOk);
    } catch (error) { setMessage(error instanceof Error ? error.message : t.error); }
    finally { setBusy(false); }
  };

  const deleteServer = async (id: string) => {
    setBusy(true);
    try {
      await api.deleteServer(id);
      setConfirmDeleteId(null);
      await load();
      setMessage(t.deletedOk);
    } catch (error) { setMessage(error instanceof Error ? error.message : t.error); }
    finally { setBusy(false); }
  };

  const statusMeta = useMemo(() => (
    { OFFLINE: [t.offline, colors.muted], STARTING: [t.starting, colors.amber],
      ONLINE: [t.online, colors.success], STOPPING: [t.stopping, colors.amber] } as Record<string, [string, string]>
  )[state?.status || "OFFLINE"], [state?.status, t]);

  const activeServer = servers.find((server) => server.active) || null;
  const hasServers = servers.length > 0;

  if (loading) {
    return (
      <View style={styles.loading}>
        <ActivityIndicator size="large" color={colors.green} />
        <Text style={styles.mutedText}>Memeriksa server dan Java Runtime...</Text>
      </View>
    );
  }

  const tabsConfig: [Tab, keyof typeof Ionicons.glyphMap, string][] = [
    ["dashboard", "speedometer-outline", t.dashboard],
    ["console", "terminal-outline", t.console],
    ["files", "folder-outline", t.files],
    ["players", "people-outline", t.players],
    ["mcpakel", "star-outline", t.mcpakel],
    ["settings", "settings-outline", t.settings],
  ];
  const currentTabLabel = tabsConfig.find(([key]) => key === tab)?.[2] || "";

  const goto = (next: Tab) => { setTab(next); setDrawerOpen(false); };

  // -------------- TOP BAR --------------
  const renderTopBar = () => (
    <View style={[styles.topBar, { paddingTop: insets.top + 8 }]}>
      <Pressable testID="open-drawer" onPress={() => setDrawerOpen(true)} style={({ pressed }) => [styles.iconBtn, pressed && styles.pressed]}>
        <Ionicons name="menu" size={24} color={colors.text} />
      </Pressable>
      <View style={styles.topBarCenter}>
        <Text style={styles.topBarTitle} numberOfLines={1}>{currentTabLabel}</Text>
        {activeServer ? <Text style={styles.topBarSub} numberOfLines={1}>{activeServer.name}</Text> : null}
      </View>
      <View style={[styles.statusPill, { borderColor: statusMeta[1] }]}>
        <View style={[styles.dot, { backgroundColor: statusMeta[1] }]} />
        <Text style={[styles.statusText, { color: statusMeta[1] }]}>{statusMeta[0]}</Text>
      </View>
    </View>
  );

  // -------------- DRAWER --------------
  const renderDrawer = () => {
    const translateX = drawerAnim.interpolate({ inputRange: [0, 1], outputRange: [-320, 0] });
    const scrimOpacity = drawerAnim.interpolate({ inputRange: [0, 1], outputRange: [0, 0.6] });
    return (
      <Modal visible={drawerOpen} transparent animationType="none" onRequestClose={() => setDrawerOpen(false)}>
        <View style={StyleSheet.absoluteFill}>
          <Animated.View style={[StyleSheet.absoluteFill, { backgroundColor: "#000", opacity: scrimOpacity }]}>
            <Pressable testID="drawer-scrim" onPress={() => setDrawerOpen(false)} style={StyleSheet.absoluteFill} />
          </Animated.View>
          <Animated.View style={[styles.drawer, { paddingTop: insets.top + 20, paddingBottom: insets.bottom + 20, transform: [{ translateX }] }]}>
            <View style={styles.drawerHeader}>
              <View style={styles.drawerLogo}><Ionicons name="game-controller" size={22} color={colors.green} /></View>
              <View style={styles.flex}>
                <Text style={styles.drawerBrand}>MCPLAY</Text>
                <Text style={styles.drawerBrandSub}>SERVER</Text>
              </View>
              <Pressable testID="close-drawer" onPress={() => setDrawerOpen(false)} style={styles.iconBtn}>
                <Ionicons name="close" size={22} color={colors.text} />
              </Pressable>
            </View>

            {activeServer ? (
              <View style={styles.drawerActive}>
                <Text style={styles.eyebrow}>SERVER AKTIF</Text>
                <Text style={styles.drawerActiveName} numberOfLines={1}>{activeServer.name}</Text>
                <Text style={styles.mutedText} numberOfLines={1}>
                  {activeServer.jar_name || t.noJarYet}
                </Text>
              </View>
            ) : null}

            <ScrollView style={styles.flex} contentContainerStyle={{ paddingBottom: 20 }}>
              {tabsConfig.map(([key, icon, label]) => {
                const active = tab === key;
                return (
                  <Pressable
                    key={key}
                    testID={`drawer-${key}`}
                    onPress={() => goto(key)}
                    style={({ pressed }) => [styles.drawerItem, active && styles.drawerItemActive, pressed && styles.pressed]}
                  >
                    <Ionicons name={icon} size={20} color={active ? colors.green : colors.muted} />
                    <Text style={[styles.drawerItemLabel, active && styles.drawerItemLabelActive]}>{label}</Text>
                    {active ? <View style={styles.drawerActiveBar} /> : null}
                  </Pressable>
                );
              })}
            </ScrollView>

            <Text style={styles.drawerFoot}>v1.0.0 · MCPLAY SERVER</Text>
          </Animated.View>
        </View>
      </Modal>
    );
  };

  // -------------- FIRST RUN --------------
  const renderFirstRun = () => (
    <ScrollView contentContainerStyle={[styles.content, { paddingTop: 20, paddingBottom: insets.bottom + 40 }]}>
      <View style={styles.welcomeCard}>
        <View style={styles.iconOrb}><Ionicons name="server-outline" size={32} color={colors.green} /></View>
        <Text style={styles.heroTitle}>{t.welcome}</Text>
        <Text style={styles.heroCopy}>{t.subtitle}</Text>
        <Text style={styles.helper}>{t.firstRunHelper}</Text>
        <PrimaryButton testID="first-run-create" label={t.createServer} icon="add-circle-outline" onPress={() => setShowCreate(true)} />
      </View>
    </ScrollView>
  );

  // -------------- DASHBOARD --------------
  const renderDashboard = () => {
    if (!hasServers) return renderFirstRun();
    return (
      <ScrollView contentContainerStyle={[styles.content, { paddingTop: 20, paddingBottom: insets.bottom + 40 }]}>
        {/* Server switcher */}
        <Pressable testID="open-server-list" onPress={() => setShowServerList(true)} style={({ pressed }) => [styles.switcher, pressed && styles.pressed]}>
          <View style={styles.switcherLeft}>
            <Ionicons name="layers-outline" size={20} color={colors.green} />
            <View style={styles.flex}>
              <Text style={styles.switcherLabel}>{t.yourServers} ({servers.length})</Text>
              <Text style={styles.switcherValue} numberOfLines={1}>
                {activeServer ? activeServer.name : t.switch}
                {activeServer?.server_type && activeServer.server_type !== "custom" ? `  ·  ${activeServer.server_type.toUpperCase()}` : ""}
                {activeServer?.minecraft_version ? `  ${activeServer.minecraft_version}` : ""}
              </Text>
            </View>
          </View>
          <Ionicons name="chevron-forward" size={18} color={colors.muted} />
        </Pressable>

        <View style={styles.actionsRow}>
          <PrimaryButton testID="dashboard-create-server" label={t.createServer} icon="add-circle-outline" onPress={() => setShowCreate(true)} flex />
          <PrimaryButton testID="dashboard-import-jar" label={t.importJarShort} icon="folder-open-outline" tone="dark" onPress={() => void importJar()} disabled={busy} flex />
        </View>

        {message ? (
          <View style={styles.message}>
            <Ionicons name="checkmark-circle-outline" size={16} color={colors.green} />
            <Text style={styles.messageText}>{message}</Text>
          </View>
        ) : null}

        {state?.jar ? (
          <View style={styles.jarRow}>
            <View style={styles.jarIcon}><Ionicons name="document-text-outline" size={20} color={colors.green} /></View>
            <View style={styles.flex}>
              <Text style={styles.cardLabel} numberOfLines={1}>{state.jar.name}</Text>
              <Text style={styles.mutedText}>{state.jar.type}  ·  {formatSize(state.jar.size)}{state.jar.version ? `  ·  ${state.jar.version}` : ""}</Text>
            </View>
            <Text style={styles.activeChip}>{t.activeJar}</Text>
          </View>
        ) : (
          <View style={styles.jarRow}>
            <View style={styles.jarIcon}><Ionicons name="alert-circle-outline" size={20} color={colors.amber} /></View>
            <View style={styles.flex}>
              <Text style={styles.cardLabel}>{t.noJarYet}</Text>
              <Text style={styles.mutedText}>{lang === "id" ? "Tekan IMPORT JAR untuk memilih file." : "Tap IMPORT JAR to pick a file."}</Text>
            </View>
          </View>
        )}

        <View style={styles.metricsGrid}>
          <Metric icon="people-outline" label={t.playersOnline} value={`${state?.players_online || 0}/${state?.max_players || 0}`} accent={colors.green} />
          <Metric icon="hardware-chip-outline" label={t.cpu} value={`${state?.cpu_usage || 0}%`} />
          <Metric icon="speedometer-outline" label={t.ram} value={`${(state?.ram_used || 0).toFixed(1)} / ${(state?.ram_max || 0).toFixed(1)} GB`} accent={colors.amber} />
          <Metric icon="time-outline" label={t.uptime} value={formatUptime(state?.uptime || 0)} />
        </View>

        <View style={styles.infoCard}>
          <View style={styles.infoHeader}>
            <View style={{ flex: 1 }}>
              <Text style={styles.cardLabel}>{state?.server_name}</Text>
              <Text style={styles.mutedText}>{t.minecraft} {state?.minecraft_version || (lang === "id" ? "terdeteksi saat server berjalan" : "detected when server runs")}  ·  {state?.server_type}</Text>
            </View>
            <Ionicons name="game-controller-outline" size={23} color={colors.green} />
          </View>
          <View style={styles.infoLine}>
            <Text style={styles.mutedText}>{t.tps}</Text>
            <Text style={styles.infoValue}>{state?.tps === null || state?.tps === undefined ? (lang === "id" ? "— tersedia saat online" : "— when online") : state.tps.toFixed(1)}</Text>
          </View>
        </View>

        <Text style={styles.sectionTitle}>LIFECYCLE</Text>
        <View style={styles.actions}>
          <PrimaryButton testID="start-server" label={t.start} icon="play"
            onPress={() => void perform(async () => { await startForegroundService(); return api.start(); })}
            disabled={busy || state?.status !== "OFFLINE" || !state?.jar} />
          <PrimaryButton testID="stop-server" label={t.stop} icon="stop" tone="dark"
            onPress={() => void perform(async () => { await stopForegroundService(); return api.stop(); })}
            disabled={busy || state?.status === "OFFLINE"} />
          <PrimaryButton testID="restart-server" label={t.restart} icon="refresh" tone="dark"
            onPress={() => void perform(async () => { await stopForegroundService(); return api.restart(); })}
            disabled={busy || !state?.jar} />
          <PrimaryButton testID="open-console" label={t.consoleOpen} icon="terminal-outline" tone="dark" onPress={() => goto("console")} />
        </View>

        <View style={styles.networkCard}>
          <View style={styles.networkIcon}><Ionicons name="wifi-outline" size={22} color={colors.green} /></View>
          <View style={styles.flex}>
            <Text style={styles.cardLabel}>{t.network} · {config?.network_mode || "LAN"}</Text>
            <Text style={styles.ipText}>{state?.local_ip}:{state?.port}</Text>
            <Text style={styles.mutedText}>127.0.0.1:{state?.port}  ·  localhost:{state?.port}</Text>
          </View>
          <Pressable testID="copy-ip" onPress={() => void copyIp()} style={({ pressed }) => [styles.copyButton, pressed && styles.pressed]}>
            <Ionicons name="copy-outline" size={19} color={colors.green} />
            <Text style={styles.copyText}>{t.copyIp}</Text>
          </Pressable>
        </View>

        <View style={styles.runtimeRow}>
          <Ionicons name="logo-javascript" size={20} color={state?.java.available ? colors.success : colors.red} />
          <View style={styles.flex}>
            <Text style={styles.cardLabel}>{t.java}</Text>
            <Text style={styles.mutedText}>{state?.java.available ? `${state.java.version} · ${state.java.architecture}` : state?.java.message}</Text>
          </View>
          <Text style={{ color: state?.java.available ? colors.success : colors.red, fontSize: 11, fontWeight: "800" }}>
            {state?.java.available ? t.ready : t.unavailable}
          </Text>
        </View>
      </ScrollView>
    );
  };

  // -------------- CONSOLE --------------
  const renderConsole = () => (
    <KeyboardAvoidingView behavior={Platform.OS === "ios" ? "padding" : "height"} style={styles.flex}>
      <ScrollView contentContainerStyle={[styles.consoleWrap, { paddingTop: 18, paddingBottom: 20 }]}>
        <View style={styles.terminal}>
          {lines.length ? lines.map((line, index) => (
            <Text key={`${line}-${index}`} style={[
              styles.logLine,
              line.toLowerCase().includes("error") && styles.errorLine,
              line.toLowerCase().includes("warn") && styles.warnLine,
              line.startsWith(">") && styles.commandLine,
            ]}>{line}</Text>
          )) : (
            <View style={styles.emptyConsole}>
              <Ionicons name="terminal-outline" size={30} color={colors.muted} />
              <Text style={styles.mutedText}>{t.noConsole}</Text>
              <Text style={styles.helper}>{t.consoleHelper}</Text>
            </View>
          )}
        </View>
      </ScrollView>
      <View style={[styles.commandBar, { paddingBottom: Math.max(insets.bottom, 12) }]}>
        <TextInput
          testID="console-command-input"
          value={command}
          onChangeText={setCommand}
          onSubmitEditing={() => void sendCommand()}
          placeholder={t.command}
          placeholderTextColor={colors.muted}
          style={styles.commandInput}
          autoCapitalize="none"
        />
        <Pressable testID="console-command-send" onPress={() => void sendCommand()} style={styles.sendButton}>
          <Ionicons name="arrow-up" size={19} color={colors.bg} />
        </Pressable>
      </View>
    </KeyboardAvoidingView>
  );

  // -------------- FILES --------------
  const renderFiles = () => (
    <ScrollView contentContainerStyle={[styles.content, { paddingTop: 20, paddingBottom: insets.bottom + 40 }]}>
      <View style={styles.pathBar}>
        <Ionicons name="server-outline" size={17} color={colors.green} />
        <Text style={styles.mutedText}>MCPLAY_SERVER/{activeServer?.directory || ""}</Text>
      </View>
      {files.length ? files.map((file) => (
        <View key={file.path} style={styles.fileRow}>
          <Ionicons name={file.directory ? "folder-outline" : "document-text-outline"} size={22} color={file.directory ? colors.amber : colors.muted} />
          <View style={styles.flex}>
            <Text style={styles.cardLabel}>{file.name}</Text>
            <Text style={styles.mutedText}>{file.directory ? "Folder" : formatSize(file.size)}</Text>
          </View>
          <Ionicons name="chevron-forward" size={18} color={colors.muted} />
        </View>
      )) : (
        <View style={styles.emptyCard}>
          <Ionicons name="folder-open-outline" size={30} color={colors.muted} />
          <Text style={styles.cardLabel}>{t.noFiles}</Text>
          <Text style={styles.helper}>{t.filesHint}</Text>
        </View>
      )}
    </ScrollView>
  );

  // -------------- PLAYERS --------------
  const renderPlayers = () => (
    <ScrollView contentContainerStyle={[styles.content, { paddingTop: 20, paddingBottom: insets.bottom + 40 }]}>
      <View style={styles.emptyCard}>
        <Ionicons name="people-outline" size={34} color={colors.green} />
        <Text style={styles.heroTitle}>{state?.players_online || 0} {t.playersEmpty}</Text>
        <Text style={styles.helper}>{t.playersHelper}</Text>
      </View>
      <Text style={styles.sectionTitle}>{t.playersManagement}</Text>
      {["Whitelist", "Operator", "Kick / Ban"].map((item) => (
        <View key={item} style={styles.settingRow}>
          <Ionicons name="shield-checkmark-outline" size={20} color={colors.green} />
          <Text style={[styles.cardLabel, { flex: 1 }]}>{item}</Text>
          <Ionicons name="lock-closed-outline" size={16} color={colors.muted} />
        </View>
      ))}
    </ScrollView>
  );

  // -------------- MCPAKEL --------------
  const renderMcpakel = () => (
    <ScrollView contentContainerStyle={[styles.content, { paddingTop: 20, paddingBottom: insets.bottom + 40 }]}>
      <View style={styles.mcpakelHero}>
        <View style={styles.mcpakelAvatar}>
          <Ionicons name="game-controller" size={38} color={colors.text} />
        </View>
        <Text style={styles.mcpakelName}>Alex Pakel</Text>
        <Text style={styles.mcpakelHandle}>@MCPAKEL</Text>
        <Text style={styles.mcpakelSub}>{t.mcpakelSub}</Text>
      </View>

      <Pressable testID="mcpakel-youtube" onPress={() => void Linking.openURL("https://youtube.com/@AlexPakel")}
        style={({ pressed }) => [styles.socialCard, { backgroundColor: "#F0313115" }, pressed && styles.pressed]}>
        <View style={[styles.socialIcon, { backgroundColor: "#F03131" }]}><Ionicons name="logo-youtube" size={24} color={colors.text} /></View>
        <View style={styles.flex}><Text style={styles.socialTitle}>YouTube</Text><Text style={styles.mutedText}>Alex Pakel</Text></View>
        <Text style={[styles.socialCta, { color: "#F03131" }]}>{t.followMe}</Text>
      </Pressable>
      <Pressable testID="mcpakel-tiktok" onPress={() => void Linking.openURL("https://tiktok.com/@mcpakel")}
        style={({ pressed }) => [styles.socialCard, { backgroundColor: "#00000030" }, pressed && styles.pressed]}>
        <View style={[styles.socialIcon, { backgroundColor: "#000000" }]}><Ionicons name="logo-tiktok" size={22} color={colors.text} /></View>
        <View style={styles.flex}><Text style={styles.socialTitle}>TikTok</Text><Text style={styles.mutedText}>@MCPAKEL</Text></View>
        <Text style={[styles.socialCta, { color: colors.text }]}>{t.followMe}</Text>
      </Pressable>
      <Pressable testID="mcpakel-shop" onPress={() => void Linking.openURL("https://lynk.id/mcpakelstore")}
        style={({ pressed }) => [styles.socialCard, { backgroundColor: "#10B98115" }, pressed && styles.pressed]}>
        <View style={[styles.socialIcon, { backgroundColor: colors.green }]}><Ionicons name="storefront-outline" size={22} color={colors.bg} /></View>
        <View style={styles.flex}><Text style={styles.socialTitle}>Shop MCPAKEL</Text><Text style={styles.mutedText}>lynk.id/mcpakelstore</Text></View>
        <Text style={[styles.socialCta, { color: colors.green }]}>{t.shopMe}</Text>
      </Pressable>
      <Pressable testID="mcpakel-donate" onPress={() => void Linking.openURL("https://sociabuzz.com/alexpakell/tribe")}
        style={({ pressed }) => [styles.socialCard, { backgroundColor: "#EC489915" }, pressed && styles.pressed]}>
        <View style={[styles.socialIcon, { backgroundColor: colors.pink }]}><Ionicons name="heart" size={22} color={colors.text} /></View>
        <View style={styles.flex}><Text style={styles.socialTitle}>Donate</Text><Text style={styles.mutedText}>sociabuzz.com/alexpakell</Text></View>
        <Text style={[styles.socialCta, { color: colors.pink }]}>{t.donateMe}</Text>
      </Pressable>
    </ScrollView>
  );

  // -------------- SETTINGS --------------
  const renderSettings = () => (
    <ScrollView contentContainerStyle={[styles.content, { paddingTop: 20, paddingBottom: insets.bottom + 40 }]}>
      <Text style={styles.sectionTitle}>{t.language}</Text>
      <Segment
        options={[{ key: "id" as Language, label: "Indonesia" }, { key: "en" as Language, label: "English" }]}
        value={lang}
        onChange={setLang}
        testIDPrefix="lang"
      />
      <Text style={styles.sectionTitle}>{t.serverSettings}</Text>
      {config && hasServers ? (
        <View style={styles.formCard}>
          <Field label={t.server} value={config.server_name} onChangeText={(value) => setConfig({ ...config, server_name: value })} />
          <Field label={t.motd} value={config.motd} onChangeText={(value) => setConfig({ ...config, motd: value })} />
          <View style={styles.fieldRow}>
            <Field label={t.port} value={String(config.port)} keyboardType="number-pad" onChangeText={(value) => setConfig({ ...config, port: Number(value) || 0 })} />
            <Field label={t.maxPlayers} value={String(config.max_players)} keyboardType="number-pad" onChangeText={(value) => setConfig({ ...config, max_players: Number(value) || 0 })} />
          </View>
          <View style={styles.fieldRow}>
            <Field label={t.minRam} value={`${config.min_ram}`} keyboardType="number-pad" onChangeText={(value) => setConfig({ ...config, min_ram: Number(value) || 0 })} />
            <Field label={t.maxRam} value={`${config.max_ram}`} keyboardType="number-pad" onChangeText={(value) => setConfig({ ...config, max_ram: Number(value) || 0 })} />
          </View>
          <Text style={styles.fieldLabel}>{t.runtimeVersion}</Text>
          <Segment
            options={[
              { key: "auto" as JavaVersion, label: t.javaAuto },
              { key: "21" as JavaVersion, label: t.java21 },
              { key: "25" as JavaVersion, label: t.java25 },
            ]}
            value={config.java_version}
            onChange={(java_version) => setConfig({ ...config, java_version })}
            testIDPrefix="java"
          />
          <View style={styles.toggleRow}>
            <View style={{ flex: 1, paddingRight: 12 }}>
              <Text style={styles.cardLabel}>PVP</Text>
              <Text style={styles.mutedText}>{t.pvpHint}</Text>
            </View>
            <Switch testID="pvp-toggle" value={config.pvp} onValueChange={(value) => setConfig({ ...config, pvp: value })}
              trackColor={{ false: colors.raised, true: colors.green }} thumbColor={colors.text} />
          </View>
          <View style={styles.toggleRow}>
            <View style={{ flex: 1, paddingRight: 12 }}>
              <Text style={styles.cardLabel}>Online mode</Text>
              <Text style={styles.mutedText}>{t.onlineModeHint}</Text>
            </View>
            <Switch testID="online-mode-toggle" value={config.online_mode} onValueChange={(value) => setConfig({ ...config, online_mode: value })}
              trackColor={{ false: colors.raised, true: colors.green }} thumbColor={colors.text} />
          </View>
          <PrimaryButton testID="save-server-settings" label={t.saveBtn} icon="save-outline" onPress={() => void saveConfig()} disabled={busy} />
        </View>
      ) : (
        <View style={styles.emptyCard}>
          <Ionicons name="alert-circle-outline" size={26} color={colors.amber} />
          <Text style={styles.helper}>{t.noActiveServer}</Text>
        </View>
      )}
    </ScrollView>
  );

  // -------------- CREATE MODAL --------------
  const renderCreateModal = () => (
    <Modal visible={showCreate} animationType="slide" transparent onRequestClose={() => setShowCreate(false)}>
      <KeyboardAvoidingView behavior={Platform.OS === "ios" ? "padding" : undefined} style={styles.modalOverlay}>
        <Pressable testID="create-scrim" style={StyleSheet.absoluteFill} onPress={() => setShowCreate(false)} />
        <View style={[styles.modalSheet, { paddingBottom: Math.max(insets.bottom, 16) + 12 }]}>
          <View style={styles.modalHandle} />
          <View style={styles.modalHeader}>
            <View>
              <Text style={styles.eyebrow}>{t.createTitle}</Text>
              <Text style={styles.modalTitle}>{t.createServer}</Text>
            </View>
            <Pressable testID="close-create" onPress={() => setShowCreate(false)} style={styles.iconBtn}>
              <Ionicons name="close" size={20} color={colors.text} />
            </Pressable>
          </View>
          <ScrollView keyboardShouldPersistTaps="handled" style={{ maxHeight: 420 }} contentContainerStyle={{ gap: 12 }}>
            <Field
              testID="new-server-name"
              label={t.serverName}
              value={newServer.name}
              placeholder={t.serverNameHint}
              onChangeText={(value) => setNewServer({ ...newServer, name: value })}
            />
            <View>
              <Text style={styles.fieldLabel}>{t.runtimeVersion}</Text>
              <Segment
                options={[
                  { key: "auto" as JavaVersion, label: t.javaAuto },
                  { key: "21" as JavaVersion, label: t.java21 },
                  { key: "25" as JavaVersion, label: t.java25 },
                ]}
                value={newServer.java_version}
                onChange={(java_version) => setNewServer({ ...newServer, java_version })}
                testIDPrefix="new-java"
              />
            </View>
            <View style={styles.fieldRow}>
              <Field testID="new-min-ram" label={t.minRam} value={String(newServer.min_ram)} keyboardType="number-pad" onChangeText={(v) => setNewServer({ ...newServer, min_ram: Number(v) || 0 })} />
              <Field testID="new-max-ram" label={t.maxRam} value={String(newServer.max_ram)} keyboardType="number-pad" onChangeText={(v) => setNewServer({ ...newServer, max_ram: Number(v) || 0 })} />
            </View>
            <Field testID="new-port" label={t.port} value={String(newServer.port)} keyboardType="number-pad" onChangeText={(v) => setNewServer({ ...newServer, port: Number(v) || 0 })} />
            <Text style={styles.helper}>{t.afterCreateHint}</Text>
          </ScrollView>
          <View style={{ gap: 8, marginTop: 14 }}>
            <PrimaryButton testID="create-server-submit" label={t.createBtn} icon="rocket-outline" onPress={() => void createServer()} disabled={busy} />
            <PrimaryButton testID="create-server-cancel" label={t.cancel} icon="close-circle-outline" tone="dark" onPress={() => setShowCreate(false)} />
          </View>
        </View>
      </KeyboardAvoidingView>
    </Modal>
  );

  // -------------- SERVER LIST MODAL --------------
  const renderServerListModal = () => (
    <Modal visible={showServerList} animationType="slide" transparent onRequestClose={() => setShowServerList(false)}>
      <View style={styles.modalOverlay}>
        <Pressable testID="server-list-scrim" style={StyleSheet.absoluteFill} onPress={() => setShowServerList(false)} />
        <View style={[styles.modalSheet, { paddingBottom: Math.max(insets.bottom, 16) + 12, maxHeight: "80%" }]}>
          <View style={styles.modalHandle} />
          <View style={styles.modalHeader}>
            <View>
              <Text style={styles.eyebrow}>{t.switch.toUpperCase()}</Text>
              <Text style={styles.modalTitle}>{t.yourServers}</Text>
            </View>
            <Pressable testID="close-server-list" onPress={() => setShowServerList(false)} style={styles.iconBtn}>
              <Ionicons name="close" size={20} color={colors.text} />
            </Pressable>
          </View>
          <ScrollView contentContainerStyle={{ gap: 10 }}>
            {servers.map((server) => (
              <View key={server.id} style={[styles.serverItem, server.active && styles.serverItemActive]}>
                <View style={styles.serverIcon}>
                  <Ionicons name="server-outline" size={22} color={server.active ? colors.green : colors.muted} />
                </View>
                <View style={styles.flex}>
                  <Text style={styles.cardLabel} numberOfLines={1}>{server.name}</Text>
                  <Text style={styles.mutedText} numberOfLines={2}>
                    {server.jar_name || t.noJarYet}
                    {`  ·  RAM ${server.max_ram}MB  ·  :${server.port}`}
                  </Text>
                </View>
                <View style={{ gap: 6, alignItems: "flex-end" }}>
                  {server.active ? (
                    <Text style={styles.activeChip}>{t.activeLabel}</Text>
                  ) : (
                    <Pressable testID={`activate-${server.id}`} onPress={() => void activateServer(server.id)} style={styles.miniBtn}>
                      <Text style={styles.miniBtnText}>{t.activate.toUpperCase()}</Text>
                    </Pressable>
                  )}
                  <Pressable testID={`delete-${server.id}`} onPress={() => setConfirmDeleteId(server.id)} style={styles.deleteBtn}>
                    <Ionicons name="trash-outline" size={18} color={colors.red} />
                  </Pressable>
                </View>
              </View>
            ))}
            <PrimaryButton testID="server-list-create" label={t.createServer} icon="add-circle-outline"
              onPress={() => { setShowServerList(false); setTimeout(() => setShowCreate(true), 250); }} />
          </ScrollView>
        </View>
      </View>
    </Modal>
  );

  // -------------- DELETE CONFIRM --------------
  const renderDeleteConfirm = () => (
    <Modal visible={!!confirmDeleteId} animationType="fade" transparent onRequestClose={() => setConfirmDeleteId(null)}>
      <View style={[styles.modalOverlay, { justifyContent: "center", paddingHorizontal: 32 }]}>
        <View style={styles.confirmSheet}>
          <Ionicons name="trash-outline" size={30} color={colors.red} />
          <Text style={styles.heroTitle}>{t.deleteServer}</Text>
          <Text style={styles.helper}>{t.deleteConfirm}</Text>
          <View style={styles.actionsRow}>
            <PrimaryButton testID="delete-cancel" label={t.cancel} icon="close" tone="dark" onPress={() => setConfirmDeleteId(null)} flex />
            <PrimaryButton testID="delete-confirm" label={t.deleteConfirmYes} icon="trash-outline" tone="red"
              onPress={() => confirmDeleteId && void deleteServer(confirmDeleteId)} flex />
          </View>
        </View>
      </View>
    </Modal>
  );

  return (
    <View style={styles.root}>
      {renderTopBar()}
      <View style={styles.flex}>
        {tab === "dashboard" && renderDashboard()}
        {tab === "console" && renderConsole()}
        {tab === "files" && renderFiles()}
        {tab === "players" && renderPlayers()}
        {tab === "mcpakel" && renderMcpakel()}
        {tab === "settings" && renderSettings()}
      </View>
      {renderDrawer()}
      {renderCreateModal()}
      {renderServerListModal()}
      {renderDeleteConfirm()}
    </View>
  );
}

const styles = StyleSheet.create({
  root: { flex: 1, backgroundColor: colors.bg },
  flex: { flex: 1 },
  loading: { flex: 1, backgroundColor: colors.bg, alignItems: "center", justifyContent: "center", gap: 14 },
  content: { paddingHorizontal: 20, gap: 14 },
  consoleWrap: { paddingHorizontal: 16, flexGrow: 1 },

  // Top bar
  topBar: { flexDirection: "row", alignItems: "center", gap: 12, paddingHorizontal: 14, paddingBottom: 12, backgroundColor: colors.bg, borderBottomWidth: 1, borderBottomColor: colors.border },
  iconBtn: { width: 40, height: 40, borderRadius: 12, backgroundColor: colors.raised, alignItems: "center", justifyContent: "center" },
  topBarCenter: { flex: 1 },
  topBarTitle: { color: colors.text, fontSize: 18, fontWeight: "800", letterSpacing: -0.3 },
  topBarSub: { color: colors.muted, fontSize: 11, fontWeight: "600", marginTop: 1 },

  // Drawer
  drawer: { position: "absolute", left: 0, top: 0, bottom: 0, width: 300, backgroundColor: "#12141C", borderRightWidth: 1, borderRightColor: colors.border, paddingHorizontal: 16 },
  drawerHeader: { flexDirection: "row", alignItems: "center", gap: 12, paddingBottom: 16, borderBottomWidth: 1, borderBottomColor: colors.border, marginBottom: 14 },
  drawerLogo: { width: 44, height: 44, borderRadius: 14, backgroundColor: "#064E3B", alignItems: "center", justifyContent: "center" },
  drawerBrand: { color: colors.text, fontSize: 18, fontWeight: "800", letterSpacing: -0.3 },
  drawerBrandSub: { color: colors.green, fontSize: 11, fontWeight: "800", letterSpacing: 2 },
  drawerActive: { paddingVertical: 12, paddingHorizontal: 14, backgroundColor: colors.card, borderRadius: 12, borderWidth: 1, borderColor: colors.border, marginBottom: 12 },
  drawerActiveName: { color: colors.text, fontSize: 16, fontWeight: "800", marginTop: 3 },
  drawerItem: { flexDirection: "row", alignItems: "center", gap: 14, paddingVertical: 12, paddingHorizontal: 14, borderRadius: 12, marginBottom: 4, position: "relative" },
  drawerItemActive: { backgroundColor: "#0F2924" },
  drawerItemLabel: { color: colors.muted, fontSize: 15, fontWeight: "700" },
  drawerItemLabelActive: { color: colors.text },
  drawerActiveBar: { position: "absolute", left: 0, top: 10, bottom: 10, width: 3, borderRadius: 3, backgroundColor: colors.green },
  drawerFoot: { color: colors.muted, fontSize: 10, textAlign: "center", paddingTop: 12, borderTopWidth: 1, borderTopColor: colors.border },

  eyebrow: { color: colors.green, fontSize: 11, fontWeight: "800", letterSpacing: 1.4 },
  title: { color: colors.text, fontSize: 28, fontWeight: "800", letterSpacing: -0.5, marginTop: 4 },
  sectionTitle: { color: colors.muted, fontSize: 12, fontWeight: "800", letterSpacing: 1.2, marginTop: 6 },

  statusPill: { flexDirection: "row", alignItems: "center", gap: 7, borderWidth: 1, borderRadius: 999, paddingHorizontal: 11, paddingVertical: 6 },
  dot: { width: 7, height: 7, borderRadius: 7, backgroundColor: colors.success },
  statusText: { fontSize: 11, fontWeight: "800" },

  welcomeCard: { backgroundColor: colors.card, borderWidth: 1, borderColor: colors.green, borderRadius: 20, padding: 22, alignItems: "flex-start", marginTop: 18, gap: 12 },
  iconOrb: { width: 58, height: 58, borderRadius: 18, backgroundColor: "#064E3B", alignItems: "center", justifyContent: "center" },
  heroTitle: { color: colors.text, fontSize: 22, fontWeight: "800", lineHeight: 28 },
  heroCopy: { color: colors.muted, fontSize: 15, lineHeight: 23 },
  helper: { color: colors.muted, fontSize: 13, lineHeight: 19 },
  actionsRow: { flexDirection: "row", gap: 10, alignSelf: "stretch" },

  button: { minHeight: 46, backgroundColor: colors.green, borderRadius: 12, flexDirection: "row", alignItems: "center", justifyContent: "center", gap: 8, paddingHorizontal: 16 },
  buttonText: { color: colors.bg, fontWeight: "800", fontSize: 12, letterSpacing: 0.3 },
  darkButton: { backgroundColor: colors.raised, borderWidth: 1, borderColor: colors.border },
  redButton: { backgroundColor: colors.red },
  blueButton: { backgroundColor: colors.blue },
  disabled: { opacity: 0.45 },
  pressed: { opacity: 0.72 },

  switcher: { flexDirection: "row", alignItems: "center", justifyContent: "space-between", backgroundColor: colors.card, borderWidth: 1, borderColor: colors.border, borderRadius: 14, paddingHorizontal: 14, paddingVertical: 12, gap: 12 },
  switcherLeft: { flexDirection: "row", alignItems: "center", gap: 12, flex: 1 },
  switcherLabel: { color: colors.green, fontSize: 10, fontWeight: "800", letterSpacing: 1 },
  switcherValue: { color: colors.text, fontSize: 15, fontWeight: "700", marginTop: 3 },

  jarRow: { backgroundColor: colors.card, borderRadius: 14, borderWidth: 1, borderColor: colors.border, padding: 13, flexDirection: "row", alignItems: "center", gap: 12 },
  jarIcon: { width: 42, height: 42, backgroundColor: "#064E3B", borderRadius: 11, alignItems: "center", justifyContent: "center" },
  activeChip: { color: colors.green, fontSize: 10, fontWeight: "800" },
  cardLabel: { color: colors.text, fontSize: 15, fontWeight: "700" },
  mutedText: { color: colors.muted, fontSize: 12, lineHeight: 18 },

  message: { backgroundColor: "#12352B", borderRadius: 10, padding: 11, flexDirection: "row", gap: 8, alignItems: "center" },
  messageText: { color: "#A7F3D0", fontSize: 13, flex: 1 },

  metricsGrid: { flexDirection: "row", flexWrap: "wrap", gap: 10 },
  metric: { width: "48%", minHeight: 95, backgroundColor: colors.card, borderRadius: 14, borderWidth: 1, borderColor: colors.border, padding: 13, gap: 7 },
  metricLabel: { color: colors.muted, fontSize: 12 },
  metricValue: { fontSize: 17, fontWeight: "800" },

  infoCard: { backgroundColor: colors.card, borderRadius: 16, padding: 16, borderWidth: 1, borderColor: colors.border, gap: 14 },
  infoHeader: { flexDirection: "row", justifyContent: "space-between", alignItems: "center" },
  infoLine: { flexDirection: "row", justifyContent: "space-between", borderTopWidth: 1, borderTopColor: colors.border, paddingTop: 12 },
  infoValue: { color: colors.text, fontWeight: "700", fontSize: 13 },

  actions: { flexDirection: "row", flexWrap: "wrap", gap: 9 },
  networkCard: { backgroundColor: "#102C29", borderRadius: 16, padding: 15, flexDirection: "row", alignItems: "center", gap: 12 },
  networkIcon: { width: 42, height: 42, borderRadius: 13, backgroundColor: "#064E3B", alignItems: "center", justifyContent: "center" },
  ipText: { color: colors.text, fontSize: 19, fontWeight: "800", marginVertical: 3 },
  copyButton: { alignItems: "center", gap: 4, padding: 6 },
  copyText: { color: colors.green, fontSize: 9, fontWeight: "800" },
  runtimeRow: { backgroundColor: colors.card, borderRadius: 14, borderWidth: 1, borderColor: colors.border, padding: 14, flexDirection: "row", alignItems: "center", gap: 11 },

  terminal: { backgroundColor: "#0A0D14", borderWidth: 1, borderColor: colors.border, borderRadius: 14, padding: 14, minHeight: 500 },
  logLine: { color: "#CBD5E1", fontSize: 12, lineHeight: 19, fontFamily: Platform.select({ ios: "Menlo", android: "monospace", default: "monospace" }) },
  errorLine: { color: "#FCA5A5" },
  warnLine: { color: "#FCD34D" },
  commandLine: { color: colors.green, fontWeight: "700" },
  emptyConsole: { flex: 1, alignItems: "center", justifyContent: "center", gap: 10, paddingVertical: 40 },
  commandBar: { flexDirection: "row", gap: 8, backgroundColor: colors.card, borderTopWidth: 1, borderTopColor: colors.border, paddingHorizontal: 13, paddingTop: 10 },
  commandInput: { flex: 1, minHeight: 46, maxHeight: 100, backgroundColor: colors.raised, borderRadius: 12, color: colors.text, paddingHorizontal: 14, fontSize: 13 },
  sendButton: { width: 46, height: 46, borderRadius: 12, backgroundColor: colors.green, alignItems: "center", justifyContent: "center" },

  pathBar: { backgroundColor: colors.raised, borderRadius: 10, padding: 12, flexDirection: "row", gap: 8, alignItems: "center" },
  fileRow: { backgroundColor: colors.card, borderRadius: 12, borderWidth: 1, borderColor: colors.border, padding: 14, flexDirection: "row", alignItems: "center", gap: 12 },
  emptyCard: { backgroundColor: colors.card, borderRadius: 16, borderWidth: 1, borderColor: colors.border, alignItems: "center", padding: 28, gap: 10 },
  settingRow: { minHeight: 52, backgroundColor: colors.card, borderRadius: 12, borderWidth: 1, borderColor: colors.border, padding: 14, flexDirection: "row", alignItems: "center", gap: 12 },
  segment: { flexDirection: "row", backgroundColor: colors.card, borderRadius: 12, padding: 4, borderWidth: 1, borderColor: colors.border, marginTop: 6 },
  segmentItem: { flex: 1, alignItems: "center", paddingVertical: 11, borderRadius: 9 },
  segmentActive: { backgroundColor: colors.green },
  segmentText: { color: colors.text, fontSize: 12, fontWeight: "700" },
  segmentTextActive: { color: colors.bg },

  formCard: { backgroundColor: colors.card, borderRadius: 16, borderWidth: 1, borderColor: colors.border, padding: 15, gap: 12 },
  fieldRow: { flexDirection: "row", gap: 10 },
  field: { flex: 1, gap: 6 },
  fieldLabel: { color: colors.muted, fontSize: 11, fontWeight: "700" },
  fieldInput: { minHeight: 44, borderRadius: 10, backgroundColor: colors.raised, color: colors.text, paddingHorizontal: 12, fontSize: 14, borderWidth: 1, borderColor: colors.border },
  toggleRow: { borderTopWidth: 1, borderTopColor: colors.border, paddingTop: 12, flexDirection: "row", justifyContent: "space-between", alignItems: "center" },

  mcpakelHero: { backgroundColor: colors.card, borderRadius: 20, borderWidth: 1, borderColor: colors.border, padding: 24, alignItems: "center", gap: 8 },
  mcpakelAvatar: { width: 90, height: 90, borderRadius: 90, backgroundColor: "#064E3B", alignItems: "center", justifyContent: "center", marginBottom: 6 },
  mcpakelName: { color: colors.text, fontSize: 22, fontWeight: "800" },
  mcpakelHandle: { color: colors.green, fontSize: 13, fontWeight: "700" },
  mcpakelSub: { color: colors.muted, fontSize: 13, textAlign: "center", marginTop: 6, lineHeight: 19 },
  socialCard: { borderRadius: 16, borderWidth: 1, borderColor: colors.border, padding: 14, flexDirection: "row", alignItems: "center", gap: 12 },
  socialIcon: { width: 44, height: 44, borderRadius: 12, alignItems: "center", justifyContent: "center" },
  socialTitle: { color: colors.text, fontSize: 16, fontWeight: "800" },
  socialCta: { fontSize: 11, fontWeight: "800", letterSpacing: 1 },

  modalOverlay: { flex: 1, backgroundColor: "rgba(0,0,0,0.6)", justifyContent: "flex-end" },
  modalSheet: { backgroundColor: colors.bg, borderTopLeftRadius: 24, borderTopRightRadius: 24, paddingHorizontal: 20, paddingTop: 12 },
  modalHandle: { width: 40, height: 4, borderRadius: 4, backgroundColor: colors.border, alignSelf: "center", marginBottom: 14 },
  modalHeader: { flexDirection: "row", justifyContent: "space-between", alignItems: "flex-end", marginBottom: 16 },
  modalTitle: { color: colors.text, fontSize: 22, fontWeight: "800", marginTop: 3 },

  confirmSheet: { backgroundColor: colors.card, borderRadius: 20, padding: 24, alignItems: "center", gap: 10 },
  serverItem: { flexDirection: "row", alignItems: "center", gap: 12, backgroundColor: colors.card, borderRadius: 14, borderWidth: 1, borderColor: colors.border, padding: 14 },
  serverItemActive: { borderColor: colors.green },
  serverIcon: { width: 42, height: 42, borderRadius: 12, backgroundColor: colors.raised, alignItems: "center", justifyContent: "center" },
  miniBtn: { backgroundColor: colors.raised, borderRadius: 10, paddingHorizontal: 12, paddingVertical: 8 },
  miniBtnText: { color: colors.text, fontSize: 10, fontWeight: "800", letterSpacing: 0.8 },
  deleteBtn: { padding: 8, borderRadius: 10, backgroundColor: "#3F1D1D" },
});
