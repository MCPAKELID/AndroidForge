const { withAndroidManifest, withMainApplication, withDangerousMod, createRunOncePlugin } = require("@expo/config-plugins");
const fs = require("fs");
const path = require("path");

const packageName = "com.mcplay.server";

function withManifest(config) {
  return withAndroidManifest(config, (mod) => {
    const manifest = mod.modResults.manifest;
    manifest["uses-permission"] = manifest["uses-permission"] || [];
    for (const name of ["android.permission.FOREGROUND_SERVICE", "android.permission.FOREGROUND_SERVICE_SPECIAL_USE", "android.permission.POST_NOTIFICATIONS"]) {
      if (!manifest["uses-permission"].some((permission) => permission.$?.["android:name"] === name)) {
        manifest["uses-permission"].push({ $: { "android:name": name } });
      }
    }
    const application = manifest.application?.[0];
    if (application) {
      application.service = application.service || [];
      if (!application.service.some((service) => service.$?.["android:name"] === `${packageName}.McplayForegroundService`)) {
        application.service.push({ $: { "android:name": `${packageName}.McplayForegroundService`, "android:exported": "false", "android:foregroundServiceType": "specialUse" }, "meta-data": [{ $: { "android:name": "android.app.PROPERTY_SPECIAL_USE_FGS_SUBTYPE", "android:value": "local_minecraft_server_process" } }] });
      }
    }
    return mod;
  });
}

function withMainApp(config) {
  return withMainApplication(config, (mod) => {
    let source = mod.modResults.contents;
    if (!source.includes("McplayForegroundPackage")) {
      const packageLine = source.match(/^package[^\n]+\n/m);
      const importStatement = packageLine?.[0].trimEnd().endsWith(";") ? `import ${packageName}.McplayForegroundPackage;\n` : `import ${packageName}.McplayForegroundPackage\n`;
      source = packageLine ? source.replace(packageLine[0], `${packageLine[0]}\n${importStatement}`) : `${importStatement}${source}`;
    }
    if (source.includes("packages.add(new PackageList(this).getPackages())")) {
      source = source.replace("packages.add(new PackageList(this).getPackages())", "packages.add(new PackageList(this).getPackages()); packages.add(new McplayForegroundPackage())");
    } else if (source.includes("return packages;")) {
      source = source.replace("return packages;", "packages.add(new McplayForegroundPackage());\n    return packages;");
    } else if (source.includes("PackageList(this).packages.apply")) {
      source = source.replace("PackageList(this).packages.apply {", "PackageList(this).packages.apply {\n      add(McplayForegroundPackage())");
    }
    mod.modResults.contents = source;
    return mod;
  });
}

function withSourceFiles(config) {
  return withDangerousMod(config, ["android", async (mod) => {
    const destination = path.join(mod.modRequest.platformProjectRoot, "app/src/main/java", ...packageName.split("."));
    fs.mkdirSync(destination, { recursive: true });
    for (const file of ["McplayForegroundService.java", "McplayForegroundModule.java", "McplayForegroundPackage.java"]) {
      fs.copyFileSync(path.join(mod.modRequest.projectRoot, "plugins", "android", file), path.join(destination, file));
    }
    return mod;
  }]);
}

module.exports = createRunOncePlugin((config) => withSourceFiles(withMainApp(withManifest(config))), "with-mcplay-foreground-service", "1.0.0");