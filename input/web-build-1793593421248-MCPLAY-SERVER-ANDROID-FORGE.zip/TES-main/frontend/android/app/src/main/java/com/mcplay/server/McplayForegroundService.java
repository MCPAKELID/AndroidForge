package com.mcplay.server;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Intent;
import android.os.Build;
import android.os.IBinder;
import androidx.annotation.Nullable;
import androidx.core.app.NotificationCompat;

public class McplayForegroundService extends Service {
  public static final String ACTION_STOP = "com.mcplay.server.STOP";
  private static final String CHANNEL_ID = "mcplay-server";

  @Override public void onCreate() {
    super.onCreate();
    NotificationManager manager = getSystemService(NotificationManager.class);
    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
      manager.createNotificationChannel(new NotificationChannel(CHANNEL_ID, "MCPLAY SERVER", NotificationManager.IMPORTANCE_LOW));
    }
  }

  @Override public int onStartCommand(Intent intent, int flags, int startId) {
    if (intent != null && ACTION_STOP.equals(intent.getAction())) {
      stopForeground(STOP_FOREGROUND_REMOVE);
      stopSelf();
      return START_NOT_STICKY;
    }
    Intent launchIntent = getPackageManager().getLaunchIntentForPackage(getPackageName());
    PendingIntent open = PendingIntent.getActivity(this, 10, launchIntent, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
    Intent stopIntent = new Intent(this, McplayForegroundService.class).setAction(ACTION_STOP);
    PendingIntent stop = PendingIntent.getService(this, 11, stopIntent, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
    Notification notification = new NotificationCompat.Builder(this, CHANNEL_ID)
      .setSmallIcon(android.R.drawable.ic_media_play)
      .setContentTitle("MCPLAY SERVER")
      .setContentText("● Server Online · proses tetap berjalan")
      .setContentIntent(open)
      .addAction(android.R.drawable.ic_menu_view, "OPEN", open)
      .addAction(android.R.drawable.ic_menu_close_clear_cancel, "STOP", stop)
      .setOngoing(true).setOnlyAlertOnce(true).build();
    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) startForeground(7412, notification, android.content.pm.ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE);
    else startForeground(7412, notification);
    return START_STICKY;
  }

  @Nullable @Override public IBinder onBind(Intent intent) { return null; }
}