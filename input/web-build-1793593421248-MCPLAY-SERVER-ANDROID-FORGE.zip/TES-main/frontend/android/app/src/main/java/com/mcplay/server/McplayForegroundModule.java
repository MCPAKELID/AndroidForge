package com.mcplay.server;

import android.content.Intent;
import androidx.core.content.ContextCompat;
import com.facebook.react.bridge.ReactApplicationContext;
import com.facebook.react.bridge.ReactContextBaseJavaModule;
import com.facebook.react.bridge.ReactMethod;

public class McplayForegroundModule extends ReactContextBaseJavaModule {
  public McplayForegroundModule(ReactApplicationContext context) { super(context); }
  @Override public String getName() { return "McplayForeground"; }
  @ReactMethod public void start() { ContextCompat.startForegroundService(getReactApplicationContext(), new Intent(getReactApplicationContext(), McplayForegroundService.class)); }
  @ReactMethod public void stop() { getReactApplicationContext().stopService(new Intent(getReactApplicationContext(), McplayForegroundService.class)); }
}