export type ServerStatus = "OFFLINE" | "STARTING" | "ONLINE" | "STOPPING";

export type JavaVersion = "auto" | "21" | "25";

export type ServerType = "paper" | "spigot" | "vanilla" | "custom";

export type ServerSummary = {
  id: string;
  name: string;
  directory: string;
  created_at: string;
  java_version: JavaVersion;
  min_ram: number;
  max_ram: number;
  port: number;
  server_type: ServerType;
  minecraft_version: string | null;
  has_jar: boolean;
  jar_name: string | null;
  active: boolean;
};

export type ServerState = {
  status: ServerStatus;
  server_id: string | null;
  server_name: string;
  minecraft_version: string | null;
  server_type: string;
  players_online: number;
  max_players: number;
  ram_used: number;
  ram_max: number;
  cpu_usage: number;
  uptime: number;
  tps: number | null;
  local_ip: string;
  port: number;
  jar: { name: string; size: number; type: string; version: string | null; active: boolean } | null;
  java: { available: boolean; version: string | null; architecture: string | null; message: string; supported_versions?: string[] };
  last_error: string | null;
};

export type ServerConfig = {
  server_name: string;
  port: number;
  max_players: number;
  motd: string;
  difficulty: string;
  gamemode: string;
  pvp: boolean;
  online_mode: boolean;
  view_distance: number;
  simulation_distance: number;
  network_mode: string;
  min_ram: number;
  max_ram: number;
  java_args: string;
  java_version: JavaVersion;
};

export type CreateServerInput = {
  name: string;
  java_version: JavaVersion;
  min_ram: number;
  max_ram: number;
  port: number;
};
