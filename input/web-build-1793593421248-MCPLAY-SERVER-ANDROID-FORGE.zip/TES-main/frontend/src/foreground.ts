import { NativeModules, Platform } from "react-native";

const nativeService = NativeModules.McplayForeground as { start?: () => void; stop?: () => void } | undefined;

export const startForegroundService = async () => {
  if (Platform.OS === "android") nativeService?.start?.();
};

export const stopForegroundService = async () => {
  if (Platform.OS === "android") nativeService?.stop?.();
};