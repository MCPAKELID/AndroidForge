import Constants from "expo-constants";
import type { CreateServerInput, ServerConfig, ServerState, ServerSummary } from "./types";

const baseUrl = String(Constants.expoConfig?.extra?.backendUrl ?? process.env.EXPO_BACKEND_URL ?? process.env.EXPO_PUBLIC_BACKEND_URL ?? "").replace(/\/$/, "");

async function request<T>(path: string, options?: RequestInit): Promise<T> {
  const response = await fetch(`${baseUrl}/api${path}`, { headers: { "Content-Type": "application/json", ...(options?.headers || {}) }, ...options });
  const body = await response.json();
  if (!response.ok) throw new Error(body.detail || "Permintaan gagal.");
  return body as T;
}

export const api = {
  state: () => request<ServerState>("/server/state"),
  config: () => request<ServerConfig>("/server/config"),
  saveConfig: (config: ServerConfig) => request<{ saved: boolean }>("/server/config", { method: "PUT", body: JSON.stringify(config) }),
  start: () => request<ServerState>("/server/start", { method: "POST" }),
  stop: () => request<ServerState>("/server/stop", { method: "POST" }),
  restart: () => request<ServerState>("/server/restart", { method: "POST" }),
  console: () => request<{ lines: string[] }>("/console"),
  command: (command: string) => request<{ sent: boolean }>("/console/command", { method: "POST", body: JSON.stringify({ command }) }),
  files: () => request<{ items: { name: string; path: string; directory: boolean; size: number }[] }>("/files"),
  listServers: () => request<{ servers: ServerSummary[] }>("/servers"),
  createServer: (payload: CreateServerInput) => request<{ server: ServerSummary }>("/servers", { method: "POST", body: JSON.stringify(payload) }),
  activateServer: (id: string) => request<{ activated: string }>(`/servers/${id}/activate`, { method: "POST" }),
  deleteServer: (id: string) => request<{ deleted: string }>(`/servers/${id}`, { method: "DELETE" }),
  importJar: async (uri: string, name: string) => {
    const form = new FormData();
    form.append("file", { uri, name, type: "application/java-archive" } as unknown as Blob);
    const response = await fetch(`${baseUrl}/api/server/import-jar`, { method: "POST", body: form });
    const body = await response.json();
    if (!response.ok) throw new Error(body.detail || "Import JAR gagal.");
    return body;
  },
};
