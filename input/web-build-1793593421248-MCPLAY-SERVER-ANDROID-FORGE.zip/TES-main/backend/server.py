from collections import deque
from datetime import datetime, timezone
from pathlib import Path
from threading import Lock, Thread
from uuid import uuid4
import json
import logging
import os
import re
import shutil
import socket
import subprocess
import time
from typing import Any, Dict, List, Optional

from dotenv import load_dotenv
from fastapi import APIRouter, FastAPI, File, HTTPException, UploadFile
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel, Field

ROOT_DIR = Path(__file__).parent
load_dotenv(ROOT_DIR / ".env")
DATA_DIR = Path(os.getenv("MCPLAY_DATA_DIR", "/tmp/mcplay_servers"))
DATA_DIR.mkdir(parents=True, exist_ok=True)
SERVERS_DIR = DATA_DIR / "servers"
SERVERS_DIR.mkdir(parents=True, exist_ok=True)
REGISTRY_PATH = DATA_DIR / "servers.json"

logging.basicConfig(level=logging.INFO, format="%(asctime)s - %(levelname)s - %(message)s")
logger = logging.getLogger("mcplay")

app = FastAPI(title="MCPLAY SERVER API")
api_router = APIRouter(prefix="/api")

DEFAULT_CONFIG: Dict[str, Any] = {
    "server_name": "MCPLAY SERVER",
    "port": 25565,
    "max_players": 20,
    "motd": "MCPLAY SERVER",
    "difficulty": "easy",
    "gamemode": "survival",
    "pvp": True,
    "online_mode": True,
    "view_distance": 10,
    "simulation_distance": 10,
    "network_mode": "LAN",
    "min_ram": 1024,
    "max_ram": 4096,
    "java_args": "",
    "java_version": "auto",
}

# Runtime state
process: Optional[subprocess.Popen] = None
process_lock = Lock()
log_buffer: deque = deque(maxlen=1000)
started_at: Optional[float] = None
server_status = "OFFLINE"
last_error: Optional[str] = None
active_server_id: Optional[str] = None
server_registry: List[Dict[str, Any]] = []
config: Dict[str, Any] = dict(DEFAULT_CONFIG)

# Paths for the currently active server
SERVER_DIR: Path = SERVERS_DIR
JAR_PATH: Path = SERVER_DIR / "server.jar"
PROPERTIES_PATH: Path = SERVER_DIR / "server.properties"
CONFIG_PATH: Path = SERVER_DIR / "config.json"


def save_registry() -> None:
    REGISTRY_PATH.write_text(
        json.dumps(
            {"servers": server_registry, "active_server_id": active_server_id},
            ensure_ascii=False,
            indent=2,
        )
    )


def set_active_paths(server_id: str) -> None:
    """Switch runtime paths + config to point to the given server."""
    global SERVER_DIR, JAR_PATH, PROPERTIES_PATH, CONFIG_PATH, active_server_id, config
    entry = next((item for item in server_registry if item["id"] == server_id), None)
    if not entry:
        raise HTTPException(status_code=404, detail="Server tidak ditemukan.")
    active_server_id = server_id
    SERVER_DIR = SERVERS_DIR / entry["directory"]
    SERVER_DIR.mkdir(parents=True, exist_ok=True)
    JAR_PATH = SERVER_DIR / "server.jar"
    PROPERTIES_PATH = SERVER_DIR / "server.properties"
    CONFIG_PATH = SERVER_DIR / "config.json"
    config = dict(DEFAULT_CONFIG)
    if CONFIG_PATH.exists():
        try:
            config.update(json.loads(CONFIG_PATH.read_text()))
        except (OSError, json.JSONDecodeError):
            logger.warning("Konfigurasi server %s tidak dapat dibaca, memakai default.", server_id)


def load_registry() -> None:
    global server_registry, active_server_id
    if REGISTRY_PATH.exists():
        try:
            stored = json.loads(REGISTRY_PATH.read_text())
            server_registry = stored.get("servers", [])
            active_server_id = stored.get("active_server_id")
        except (OSError, json.JSONDecodeError):
            server_registry = []
            active_server_id = None
    # Legacy migration: pick up an existing default server folder
    legacy_dir = SERVERS_DIR / "default"
    if not server_registry and (legacy_dir / "server.jar").exists():
        server_registry = [
            {
                "id": "default",
                "name": "MCPLAY SERVER",
                "directory": "default",
                "created_at": datetime.now(timezone.utc).isoformat(),
            }
        ]
        active_server_id = "default"
        save_registry()
    if active_server_id and any(item["id"] == active_server_id for item in server_registry):
        set_active_paths(active_server_id)
    elif server_registry:
        set_active_paths(server_registry[0]["id"])


class ServerConfigModel(BaseModel):
    server_name: str = Field(min_length=1, max_length=80)
    port: int = Field(default=25565, ge=1024, le=65535)
    max_players: int = Field(default=20, ge=1, le=500)
    motd: str = Field(default="MCPLAY SERVER", max_length=120)
    difficulty: str = "easy"
    gamemode: str = "survival"
    pvp: bool = True
    online_mode: bool = True
    view_distance: int = Field(default=10, ge=2, le=32)
    simulation_distance: int = Field(default=10, ge=2, le=32)
    network_mode: str = "LAN"
    min_ram: int = Field(default=1024, ge=512, le=16384)
    max_ram: int = Field(default=4096, ge=1024, le=32768)
    java_args: str = Field(default="", max_length=500)
    java_version: str = Field(default="auto", pattern="^(auto|21|25)$")


class CreateServerRequest(BaseModel):
    name: str = Field(min_length=1, max_length=80)
    java_version: str = Field(default="auto", pattern="^(auto|21|25)$")
    min_ram: int = Field(default=1024, ge=512, le=16384)
    max_ram: int = Field(default=4096, ge=1024, le=32768)
    port: int = Field(default=25565, ge=1024, le=65535)


class CommandInput(BaseModel):
    command: str = Field(min_length=1, max_length=500)


def slugify(name: str) -> str:
    slug = re.sub(r"[^a-z0-9]+", "-", name.lower()).strip("-")
    return slug or "server"


def read_properties() -> Dict[str, str]:
    if not PROPERTIES_PATH.exists():
        return {}
    result: Dict[str, str] = {}
    for line in PROPERTIES_PATH.read_text(errors="ignore").splitlines():
        if "=" in line and not line.lstrip().startswith("#"):
            key, value = line.split("=", 1)
            result[key.strip()] = value.strip()
    return result


def write_properties(values: Dict[str, Any]) -> None:
    props = read_properties()
    mapping = {
        "server_name": "server-name",
        "port": "server-port",
        "max_players": "max-players",
        "motd": "motd",
        "difficulty": "difficulty",
        "gamemode": "gamemode",
        "pvp": "pvp",
        "online_mode": "online-mode",
        "view_distance": "view-distance",
        "simulation_distance": "simulation-distance",
    }
    for field, key in mapping.items():
        if field in values:
            value = values[field]
            props[key] = str(value).lower() if isinstance(value, bool) else str(value)
    PROPERTIES_PATH.write_text("\n".join(f"{key}={value}" for key, value in props.items()) + "\n")


def local_ip() -> str:
    try:
        sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        sock.connect(("8.8.8.8", 80))
        address = sock.getsockname()[0]
        sock.close()
        return address
    except OSError:
        return "127.0.0.1"


def java_candidates() -> List[str]:
    candidates = [shutil.which("java") or ""]
    for name in ("java21", "java-21", "java25", "java-25"):
        found = shutil.which(name)
        if found:
            candidates.append(found)
    for env_name in ("JAVA_HOME_21", "JAVA_HOME_25", "JAVA_HOME"):
        java_home = os.getenv(env_name)
        if java_home:
            candidates.append(str(Path(java_home) / "bin" / "java"))
    return list(dict.fromkeys(candidate for candidate in candidates if candidate))


def java_major(version_line: str) -> Optional[int]:
    match = re.search(r'"?(\d+)', version_line)
    return int(match.group(1)) if match else None


def java_info() -> Dict[str, Any]:
    found_versions: Dict[str, str] = {}
    for candidate in java_candidates():
        try:
            result = subprocess.run([candidate, "-version"], capture_output=True, text=True, timeout=5)
            version_line = (result.stderr or result.stdout).splitlines()[0]
            major = java_major(version_line)
            if major in (21, 25):
                found_versions[str(major)] = candidate
        except (OSError, subprocess.SubprocessError, IndexError):
            continue
    selected = config.get("java_version", "auto")
    selected_path = found_versions.get(selected) if selected != "auto" else next(iter(found_versions.values()), None)
    architecture = os.uname().machine if hasattr(os, "uname") else "unknown"
    if not selected_path:
        installed = ", ".join(found_versions) or "tidak ada"
        return {
            "available": False,
            "version": None,
            "architecture": architecture,
            "supported_versions": list(found_versions),
            "message": f"Java 21/25 tidak ditemukan (terdeteksi: {installed}).",
        }
    try:
        result = subprocess.run([selected_path, "-version"], capture_output=True, text=True, timeout=5)
        version_line = (result.stderr or result.stdout).splitlines()[0]
        return {
            "available": True,
            "version": version_line.replace("java version ", "").strip('"'),
            "architecture": architecture,
            "supported_versions": list(found_versions),
            "selected": selected,
            "executable": selected_path,
            "message": "Java Runtime siap digunakan.",
        }
    except (OSError, subprocess.SubprocessError) as exc:
        return {
            "available": False,
            "version": None,
            "architecture": architecture,
            "supported_versions": list(found_versions),
            "message": f"Pengecekan Java gagal: {exc}",
        }


def parse_players() -> int:
    for line in reversed(log_buffer):
        match = re.search(r"There are (\d+) of a max of (\d+) players", line)
        if match:
            return int(match.group(1))
    return 0


def read_process_output(active_process: subprocess.Popen) -> None:
    global server_status, process, last_error
    try:
        if active_process.stdout:
            for line in active_process.stdout:
                clean = line.rstrip()
                if clean:
                    log_buffer.append(clean)
                    logger.info(clean)
                    if "Done (" in clean or "For help" in clean:
                        server_status = "ONLINE"
                    if "ERROR" in clean.upper() or "FAILED" in clean.upper():
                        last_error = clean
        active_process.wait()
    except Exception as exc:  # pragma: no cover - defensive
        last_error = str(exc)
    finally:
        with process_lock:
            if process is active_process:
                process = None
                server_status = "OFFLINE"


def process_memory_mb() -> float:
    if not process or process.poll() is not None:
        return 0.0
    try:
        output = subprocess.check_output(["ps", "-o", "rss=", "-p", str(process.pid)], text=True)
        return round(int(output.strip()) / 1024, 1)
    except (OSError, ValueError, subprocess.SubprocessError):
        return 0.0


def jar_type() -> str:
    name = (config.get("original_jar_name") or JAR_PATH.name).lower()
    if "paper" in name:
        return "Paper"
    if "spigot" in name:
        return "Spigot"
    if "vanilla" in name or name.startswith("minecraft") or name.startswith("server-"):
        return "Vanilla"
    return "Custom"


def detect_version() -> Optional[str]:
    source = config.get("original_jar_name") or JAR_PATH.name
    match = re.search(r"(\d+\.\d+(?:\.\d+)?)", source)
    return match.group(1) if match else None


def jar_details() -> Optional[Dict[str, Any]]:
    if not JAR_PATH.exists():
        return None
    display_name = config.get("original_jar_name") or JAR_PATH.name
    return {
        "name": display_name,
        "size": JAR_PATH.stat().st_size,
        "type": jar_type(),
        "version": detect_version(),
        "active": True,
    }


def current_state() -> Dict[str, Any]:
    props = read_properties()
    alive = process is not None and process.poll() is None
    status = server_status if alive or server_status in {"STARTING", "STOPPING"} else "OFFLINE"
    max_players = int(props.get("max-players", config["max_players"]))
    uptime = int(time.time() - started_at) if started_at and alive else 0
    return {
        "status": status,
        "server_id": active_server_id,
        "server_name": props.get("server-name", config["server_name"]),
        "minecraft_version": detect_version(),
        "server_type": jar_type(),
        "players_online": parse_players() if alive else 0,
        "max_players": max_players,
        "ram_used": process_memory_mb(),
        "ram_max": config["max_ram"] / 1024,
        "cpu_usage": 0,
        "uptime": uptime,
        "tps": None,
        "local_ip": local_ip(),
        "port": int(props.get("server-port", config["port"])),
        "jar": jar_details(),
        "java": java_info(),
        "last_error": last_error,
        "server_directory": str(SERVER_DIR),
        "bridge": "process-local",
    }


def server_summary(entry: Dict[str, Any]) -> Dict[str, Any]:
    directory = SERVERS_DIR / entry["directory"]
    cfg_path = directory / "config.json"
    cfg: Dict[str, Any] = dict(DEFAULT_CONFIG)
    if cfg_path.exists():
        try:
            cfg.update(json.loads(cfg_path.read_text()))
        except (OSError, json.JSONDecodeError):
            pass
    jar_path = directory / "server.jar"
    jar_exists = jar_path.exists() and jar_path.stat().st_size > 1024
    display_name = cfg.get("original_jar_name") or (jar_path.name if jar_exists else None)
    detected_type = "custom"
    detected_version: Optional[str] = None
    if display_name:
        lower = display_name.lower()
        if "paper" in lower:
            detected_type = "paper"
        elif "spigot" in lower:
            detected_type = "spigot"
        elif "vanilla" in lower or lower.startswith("minecraft") or lower.startswith("server-"):
            detected_type = "vanilla"
        match = re.search(r"(\d+\.\d+(?:\.\d+)?)", display_name)
        detected_version = match.group(1) if match else None
    return {
        "id": entry["id"],
        "name": entry["name"],
        "directory": entry["directory"],
        "created_at": entry.get("created_at"),
        "java_version": cfg.get("java_version", "auto"),
        "min_ram": cfg.get("min_ram", 1024),
        "max_ram": cfg.get("max_ram", 4096),
        "port": cfg.get("port", 25565),
        "server_type": detected_type,
        "minecraft_version": detected_version,
        "has_jar": jar_exists,
        "jar_name": display_name if jar_exists else None,
        "active": entry["id"] == active_server_id,
    }


# ---- API routes ----


@api_router.get("/")
async def root() -> Dict[str, str]:
    return {"message": "MCPLAY SERVER API ready"}


@api_router.get("/servers")
async def list_servers() -> Dict[str, Any]:
    return {"servers": [server_summary(entry) for entry in server_registry], "active_server_id": active_server_id}


@api_router.post("/servers")
async def create_server(payload: CreateServerRequest) -> Dict[str, Any]:
    global server_registry, active_server_id
    if payload.max_ram < payload.min_ram:
        raise HTTPException(status_code=400, detail="RAM maksimum harus lebih besar dari RAM minimum.")
    if process is not None and process.poll() is None:
        raise HTTPException(status_code=400, detail="Hentikan server yang sedang berjalan sebelum membuat server baru.")

    existing_dirs = {item["directory"] for item in server_registry}
    base = slugify(payload.name)
    directory = base
    counter = 2
    while directory in existing_dirs or (SERVERS_DIR / directory).exists():
        directory = f"{base}-{counter}"
        counter += 1

    server_id = uuid4().hex[:12]
    new_dir = SERVERS_DIR / directory
    new_dir.mkdir(parents=True, exist_ok=True)
    (new_dir / "eula.txt").write_text("eula=true\n")

    server_config = dict(DEFAULT_CONFIG)
    server_config.update(
        {
            "server_name": payload.name,
            "port": payload.port,
            "min_ram": payload.min_ram,
            "max_ram": payload.max_ram,
            "java_version": payload.java_version,
            "motd": payload.name,
        }
    )
    (new_dir / "config.json").write_text(json.dumps(server_config, ensure_ascii=False, indent=2))

    entry = {
        "id": server_id,
        "name": payload.name,
        "directory": directory,
        "created_at": datetime.now(timezone.utc).isoformat(),
    }
    server_registry.append(entry)
    active_server_id = server_id
    save_registry()
    set_active_paths(server_id)
    write_properties(server_config)
    log_buffer.clear()
    log_buffer.append(f"[MCPLAY] Server '{payload.name}' berhasil dibuat.")
    log_buffer.append("[MCPLAY] Silakan import JAR untuk server ini.")
    return {"server": server_summary(entry)}


@api_router.post("/servers/{server_id}/activate")
async def activate_server(server_id: str) -> Dict[str, Any]:
    if process is not None and process.poll() is None:
        raise HTTPException(status_code=400, detail="Hentikan server yang sedang berjalan sebelum berpindah.")
    set_active_paths(server_id)
    save_registry()
    log_buffer.clear()
    return {"activated": server_id, "state": current_state()}


@api_router.delete("/servers/{server_id}")
async def delete_server(server_id: str) -> Dict[str, Any]:
    global server_registry, active_server_id
    entry = next((item for item in server_registry if item["id"] == server_id), None)
    if not entry:
        raise HTTPException(status_code=404, detail="Server tidak ditemukan.")
    if server_id == active_server_id and process is not None and process.poll() is None:
        raise HTTPException(status_code=400, detail="Hentikan server terlebih dahulu sebelum menghapus.")
    directory = SERVERS_DIR / entry["directory"]
    if directory.exists():
        shutil.rmtree(directory, ignore_errors=True)
    server_registry = [item for item in server_registry if item["id"] != server_id]
    if active_server_id == server_id:
        active_server_id = server_registry[0]["id"] if server_registry else None
        if active_server_id:
            set_active_paths(active_server_id)
    save_registry()
    return {"deleted": server_id}


@api_router.get("/server/state")
async def get_state() -> Dict[str, Any]:
    return current_state()


@api_router.get("/server/config")
async def get_config() -> Dict[str, Any]:
    props = read_properties()
    merged = dict(config)
    for key, prop in [
        ("server_name", "server-name"), ("port", "server-port"), ("max_players", "max-players"),
        ("motd", "motd"), ("difficulty", "difficulty"), ("gamemode", "gamemode"),
        ("pvp", "pvp"), ("online_mode", "online-mode"),
        ("view_distance", "view-distance"), ("simulation_distance", "simulation-distance"),
    ]:
        if prop in props:
            value: Any = props[prop]
            if key in {"port", "max_players", "view_distance", "simulation_distance"}:
                try:
                    value = int(value)
                except ValueError:
                    value = merged[key]
            if key in {"pvp", "online_mode"}:
                value = value.lower() == "true"
            merged[key] = value
    return merged


@api_router.put("/server/config")
async def save_config(payload: ServerConfigModel) -> Dict[str, Any]:
    global config
    if not active_server_id:
        raise HTTPException(status_code=400, detail="Belum ada server aktif.")
    if payload.max_ram < payload.min_ram:
        raise HTTPException(status_code=400, detail="RAM maksimum harus lebih besar dari RAM minimum.")
    config = payload.model_dump()
    CONFIG_PATH.write_text(json.dumps(config, ensure_ascii=False, indent=2))
    write_properties(config)
    # Also update the registry entry's display name
    for item in server_registry:
        if item["id"] == active_server_id:
            item["name"] = payload.server_name
    save_registry()
    return {"saved": True, "config": config}


@api_router.post("/server/import-jar")
async def import_jar(file: UploadFile = File(...)) -> Dict[str, Any]:
    global config
    if not file.filename or not file.filename.lower().endswith(".jar"):
        raise HTTPException(status_code=400, detail="File harus berformat .jar.")
    if not active_server_id:
        raise HTTPException(status_code=400, detail="Belum ada server aktif. Buat server dulu.")
    with JAR_PATH.open("wb") as destination:
        while chunk := await file.read(1024 * 1024):
            destination.write(chunk)
    config["original_jar_name"] = file.filename
    CONFIG_PATH.write_text(json.dumps(config, ensure_ascii=False, indent=2))
    log_buffer.append(f"[MCPLAY] JAR aktif: {file.filename}")
    return {"success": True, "jar": jar_details()}


@api_router.post("/server/start")
async def start_server() -> Dict[str, Any]:
    global process, server_status, started_at, last_error
    with process_lock:
        if process and process.poll() is None:
            return current_state()
        if not active_server_id:
            raise HTTPException(status_code=400, detail="Belum ada server aktif.")
        if not JAR_PATH.exists():
            raise HTTPException(status_code=400, detail="Server JAR tidak ditemukan. Import JAR dulu.")
        runtime = java_info()
        java = runtime.get("executable")
        if not runtime["available"] or not java:
            raise HTTPException(status_code=400, detail="Java Runtime tidak ditemukan di perangkat ini.")
        server_status, last_error = "STARTING", None
        log_buffer.clear()
        log_buffer.append(f"[MCPLAY] Menjalankan {JAR_PATH.name}...")
        args = [java, f"-Xms{config['min_ram']}M", f"-Xmx{config['max_ram']}M"]
        if config.get("java_args"):
            args.extend(config["java_args"].split())
        args.extend(["-jar", str(JAR_PATH), "nogui"])
        try:
            process = subprocess.Popen(
                args, cwd=SERVER_DIR, stdin=subprocess.PIPE, stdout=subprocess.PIPE,
                stderr=subprocess.STDOUT, text=True, bufsize=1,
            )
            started_at = time.time()
            Thread(target=read_process_output, args=(process,), daemon=True).start()
        except OSError as exc:
            server_status, last_error = "OFFLINE", str(exc)
            raise HTTPException(status_code=500, detail="Server gagal dijalankan.") from exc
    return current_state()


@api_router.post("/server/stop")
async def stop_server(force: bool = False) -> Dict[str, Any]:
    global server_status
    with process_lock:
        if not process or process.poll() is not None:
            server_status = "OFFLINE"
            return current_state()
        server_status = "STOPPING"
        if force:
            process.kill()
        elif process.stdin:
            try:
                process.stdin.write("stop\n")
                process.stdin.flush()
            except (OSError, ValueError):
                process.kill()
    return current_state()


@api_router.post("/server/restart")
async def restart_server() -> Dict[str, Any]:
    await stop_server()
    deadline = time.time() + 15
    while process and process.poll() is None and time.time() < deadline:
        time.sleep(0.25)
    return await start_server()


@api_router.get("/console")
async def get_console() -> Dict[str, Any]:
    return {"lines": list(log_buffer), "status": current_state()["status"]}


@api_router.post("/console/command")
async def send_command(payload: CommandInput) -> Dict[str, Any]:
    if not process or process.poll() is not None or not process.stdin:
        raise HTTPException(status_code=400, detail="Server sedang offline.")
    try:
        process.stdin.write(payload.command.strip() + "\n")
        process.stdin.flush()
    except (OSError, ValueError) as exc:
        raise HTTPException(status_code=500, detail="Gagal mengirim command.") from exc
    log_buffer.append(f"> {payload.command.strip()}")
    return {"sent": True, "command": payload.command.strip()}


@api_router.get("/files")
async def list_files(path: str = "") -> Dict[str, Any]:
    if not active_server_id:
        return {"path": path, "items": []}
    root = (SERVER_DIR / path).resolve()
    if SERVER_DIR not in root.parents and root != SERVER_DIR:
        raise HTTPException(status_code=400, detail="Path tidak valid.")
    if not root.exists():
        return {"path": path, "items": []}
    items = []
    for item in sorted(root.iterdir(), key=lambda entry: (not entry.is_dir(), entry.name.lower())):
        items.append({
            "name": item.name,
            "path": str(item.relative_to(SERVER_DIR)),
            "directory": item.is_dir(),
            "size": item.stat().st_size if item.is_file() else 0,
        })
    return {"path": path, "items": items}


app.include_router(api_router)
app.add_middleware(CORSMiddleware, allow_credentials=True, allow_origins=["*"], allow_methods=["*"], allow_headers=["*"])


@app.on_event("startup")
async def startup() -> None:
    load_registry()


@app.on_event("shutdown")
async def shutdown() -> None:
    if process and process.poll() is None and process.stdin:
        try:
            process.stdin.write("stop\n")
            process.stdin.flush()
        except (OSError, ValueError):
            process.kill()
