"""MCPLAY SERVER API test suite (iteration 3).

Focus: verify the JAR-filename auto-detect fix.
 - import_jar must persist the original filename (config.json['original_jar_name']).
 - GET /api/server/state must expose jar.name/jar.type/jar.version + top-level server_type.
 - GET /api/servers summary must expose lowercase server_type + minecraft_version.
 - import_jar must return HTTP 400 when there is no active server (no legacy auto-create).
 - Switching the active server and reimporting a different-named JAR updates the summary.
"""

from __future__ import annotations

import io
import os
from typing import Iterator

import pytest
import requests


BASE_URL = (
    os.environ.get("EXPO_PUBLIC_BACKEND_URL", "").rstrip("/")
    or os.environ.get("EXPO_BACKEND_URL", "").rstrip("/")
    or "https://java-server-manager.preview.emergentagent.com"
)
API = f"{BASE_URL}/api"

# Fake but non-empty JAR bytes so JAR_PATH.stat().st_size > 1024 (has_jar = True).
FAKE_JAR_BYTES = b"PK\x03\x04fake-jar-bytes-for-mcplay-detection" * 64


# ------------------------------------------------------------------
# Fixtures
# ------------------------------------------------------------------


@pytest.fixture(scope="module")
def api_client() -> Iterator[requests.Session]:
    session = requests.Session()
    session.headers.update({"Content-Type": "application/json"})
    _purge_test_servers(session)
    yield session
    _purge_test_servers(session)


def _purge_test_servers(session: requests.Session) -> None:
    """Remove every TEST_-prefixed server that a previous run may have left."""
    try:
        response = session.get(f"{API}/servers", timeout=15)
        for server in response.json().get("servers", []):
            if server.get("name", "").startswith("TEST_"):
                session.delete(f"{API}/servers/{server['id']}", timeout=15)
    except requests.RequestException:
        pass


def _delete_all_servers(session: requests.Session) -> None:
    """Delete EVERY server so we can test the 'no active server' branch."""
    try:
        response = session.get(f"{API}/servers", timeout=15)
        for server in response.json().get("servers", []):
            session.delete(f"{API}/servers/{server['id']}", timeout=15)
    except requests.RequestException:
        pass


def _create_server(session: requests.Session, name: str, port: int) -> str:
    payload = {
        "name": name,
        "java_version": "auto",
        "min_ram": 1024,
        "max_ram": 2048,
        "port": port,
    }
    response = session.post(f"{API}/servers", json=payload, timeout=20)
    assert response.status_code == 200, response.text
    return response.json()["server"]["id"]


def _upload_jar(filename: str) -> requests.Response:
    files = {"file": (filename, io.BytesIO(FAKE_JAR_BYTES), "application/java-archive")}
    # Use a raw requests.post so multipart headers are set correctly.
    return requests.post(f"{API}/server/import-jar", files=files, timeout=30)


# ------------------------------------------------------------------
# Health
# ------------------------------------------------------------------


class TestHealth:
    def test_root(self, api_client: requests.Session) -> None:
        response = api_client.get(f"{API}/", timeout=15)
        assert response.status_code == 200
        assert "MCPLAY" in response.json().get("message", "")

    def test_state_shape(self, api_client: requests.Session) -> None:
        response = api_client.get(f"{API}/server/state", timeout=15)
        assert response.status_code == 200
        data = response.json()
        assert data["status"] in {"OFFLINE", "STARTING", "ONLINE", "STOPPING"}
        assert "java" in data and "supported_versions" in data["java"]
        assert "local_ip" in data and "port" in data


# ------------------------------------------------------------------
# Removed endpoints (regression)
# ------------------------------------------------------------------


class TestRemovedEndpoints:
    def test_minecraft_versions_removed(self, api_client: requests.Session) -> None:
        response = api_client.get(f"{API}/minecraft-versions", timeout=15)
        assert response.status_code == 404

    def test_redownload_removed(self, api_client: requests.Session) -> None:
        response = api_client.post(f"{API}/servers/anything/redownload", timeout=15)
        assert response.status_code == 404


# ------------------------------------------------------------------
# Import JAR – filename detection (main iteration-3 focus)
# ------------------------------------------------------------------


class TestImportJarDetection:
    """Verify that server_type + minecraft_version are derived from the
    original uploaded filename (bug fixed in server.py via `original_jar_name`)."""

    def test_import_without_active_server_returns_400(
        self, api_client: requests.Session
    ) -> None:
        """No legacy auto-create should occur; endpoint must fail cleanly."""
        _delete_all_servers(api_client)
        state = api_client.get(f"{API}/server/state", timeout=15).json()
        assert state["server_id"] is None, "expected no active server"

        response = _upload_jar("paper-1.21.1.jar")
        assert response.status_code == 400, response.text
        detail = response.json().get("detail", "")
        assert "server aktif" in detail.lower(), detail

    def test_import_paper_jar_detected(self, api_client: requests.Session) -> None:
        _delete_all_servers(api_client)
        server_id = _create_server(api_client, "TEST_PAPER", 25580)

        response = _upload_jar("paper-1.21.1.jar")
        assert response.status_code == 200, response.text
        jar = response.json()["jar"]
        assert jar["name"] == "paper-1.21.1.jar"
        assert jar["type"] == "Paper"
        assert jar["version"] == "1.21.1"

        # /server/state must reflect the detection
        state = api_client.get(f"{API}/server/state", timeout=15).json()
        assert state["jar"]["name"] == "paper-1.21.1.jar"
        assert state["jar"]["type"] == "Paper"
        assert state["jar"]["version"] == "1.21.1"
        assert state["server_type"] == "Paper"
        assert state["minecraft_version"] == "1.21.1"

        # /servers summary must expose lowercase server_type per API contract
        listing = api_client.get(f"{API}/servers", timeout=15).json()
        active = next(s for s in listing["servers"] if s["id"] == server_id)
        assert active["active"] is True
        assert active["server_type"] == "paper"
        assert active["minecraft_version"] == "1.21.1"
        assert active["has_jar"] is True
        assert active["jar_name"] == "paper-1.21.1.jar"

    def test_import_spigot_jar_detected(self, api_client: requests.Session) -> None:
        _delete_all_servers(api_client)
        server_id = _create_server(api_client, "TEST_SPIGOT", 25581)

        response = _upload_jar("spigot-1.20.6.jar")
        assert response.status_code == 200, response.text
        jar = response.json()["jar"]
        assert jar["name"] == "spigot-1.20.6.jar"
        assert jar["type"] == "Spigot"
        assert jar["version"] == "1.20.6"

        state = api_client.get(f"{API}/server/state", timeout=15).json()
        assert state["server_type"] == "Spigot"
        assert state["minecraft_version"] == "1.20.6"

        listing = api_client.get(f"{API}/servers", timeout=15).json()
        active = next(s for s in listing["servers"] if s["id"] == server_id)
        assert active["server_type"] == "spigot"
        assert active["minecraft_version"] == "1.20.6"

    def test_import_vanilla_jar_detected(self, api_client: requests.Session) -> None:
        _delete_all_servers(api_client)
        server_id = _create_server(api_client, "TEST_VANILLA", 25582)

        response = _upload_jar("minecraft_server.1.21.1.jar")
        assert response.status_code == 200, response.text
        jar = response.json()["jar"]
        assert jar["name"] == "minecraft_server.1.21.1.jar"
        assert jar["type"] == "Vanilla"
        assert jar["version"] == "1.21.1"

        state = api_client.get(f"{API}/server/state", timeout=15).json()
        assert state["server_type"] == "Vanilla"
        assert state["minecraft_version"] == "1.21.1"

        listing = api_client.get(f"{API}/servers", timeout=15).json()
        active = next(s for s in listing["servers"] if s["id"] == server_id)
        assert active["server_type"] == "vanilla"
        assert active["minecraft_version"] == "1.21.1"

    def test_activate_then_reimport_updates_summary(
        self, api_client: requests.Session
    ) -> None:
        """Switching active server + importing a different-named JAR must
        update the summary's server_type and minecraft_version."""
        _delete_all_servers(api_client)
        paper_id = _create_server(api_client, "TEST_SWITCH_PAPER", 25583)
        spigot_id = _create_server(api_client, "TEST_SWITCH_SPIGOT", 25584)

        # Second create call makes the spigot server active; go back to paper.
        activate_response = api_client.post(
            f"{API}/servers/{paper_id}/activate", timeout=15
        )
        assert activate_response.status_code == 200
        assert _upload_jar("paper-1.21.1.jar").status_code == 200

        # Now switch to the other server and import a spigot JAR.
        activate_response = api_client.post(
            f"{API}/servers/{spigot_id}/activate", timeout=15
        )
        assert activate_response.status_code == 200
        assert _upload_jar("spigot-1.20.6.jar").status_code == 200

        listing = api_client.get(f"{API}/servers", timeout=15).json()
        by_id = {s["id"]: s for s in listing["servers"]}

        assert by_id[paper_id]["server_type"] == "paper"
        assert by_id[paper_id]["minecraft_version"] == "1.21.1"
        assert by_id[paper_id]["jar_name"] == "paper-1.21.1.jar"

        assert by_id[spigot_id]["server_type"] == "spigot"
        assert by_id[spigot_id]["minecraft_version"] == "1.20.6"
        assert by_id[spigot_id]["jar_name"] == "spigot-1.20.6.jar"

        # The current active state should reflect the spigot server.
        state = api_client.get(f"{API}/server/state", timeout=15).json()
        assert state["server_id"] == spigot_id
        assert state["server_type"] == "Spigot"
        assert state["minecraft_version"] == "1.20.6"

    def test_import_rejects_non_jar(self, api_client: requests.Session) -> None:
        _delete_all_servers(api_client)
        _create_server(api_client, "TEST_NONJAR", 25585)
        files = {"file": ("notes.txt", io.BytesIO(b"hello"), "text/plain")}
        response = requests.post(f"{API}/server/import-jar", files=files, timeout=15)
        assert response.status_code == 400
        assert ".jar" in response.json()["detail"].lower()


# ------------------------------------------------------------------
# CRUD & validation (regression)
# ------------------------------------------------------------------


class TestServerCrud:
    def test_create_server_minimal_payload(self, api_client: requests.Session) -> None:
        _delete_all_servers(api_client)
        payload = {
            "name": "TEST_CRUD",
            "java_version": "21",
            "min_ram": 1024,
            "max_ram": 2048,
            "port": 25590,
        }
        response = api_client.post(f"{API}/servers", json=payload, timeout=20)
        assert response.status_code == 200, response.text
        server = response.json()["server"]
        assert server["name"] == "TEST_CRUD"
        assert server["server_type"] == "custom"
        assert server["minecraft_version"] is None
        assert server["has_jar"] is False
        assert server["active"] is True
        assert server["java_version"] == "21"
        assert server["max_ram"] == 2048

    def test_create_server_validates_ram(self, api_client: requests.Session) -> None:
        payload = {
            "name": "TEST_BADRAM",
            "min_ram": 4096,
            "max_ram": 1024,
            "port": 25591,
        }
        response = api_client.post(f"{API}/servers", json=payload, timeout=15)
        assert response.status_code == 400
        assert "RAM" in response.json()["detail"]

    def test_delete_server_and_verify_removed(
        self, api_client: requests.Session
    ) -> None:
        _delete_all_servers(api_client)
        server_id = _create_server(api_client, "TEST_DELETE", 25592)
        response = api_client.delete(f"{API}/servers/{server_id}", timeout=15)
        assert response.status_code == 200
        listing = api_client.get(f"{API}/servers", timeout=15).json()
        ids = [s["id"] for s in listing["servers"]]
        assert server_id not in ids


# ------------------------------------------------------------------
# Runtime error paths (regression)
# ------------------------------------------------------------------


class TestRuntimePaths:
    def test_start_returns_expected_error(self, api_client: requests.Session) -> None:
        _delete_all_servers(api_client)
        _create_server(api_client, "TEST_START", 25593)
        response = api_client.post(f"{API}/server/start", timeout=15)
        assert response.status_code == 400
        detail = response.json()["detail"]
        assert "JAR" in detail or "Java" in detail, detail

    def test_console_rejects_offline(self, api_client: requests.Session) -> None:
        response = api_client.post(
            f"{API}/console/command", json={"command": "list"}, timeout=15
        )
        assert response.status_code == 400
        assert "offline" in response.json()["detail"].lower()

    def test_files_reject_path_traversal(self, api_client: requests.Session) -> None:
        _delete_all_servers(api_client)
        _create_server(api_client, "TEST_FILES", 25594)
        response = api_client.get(
            f"{API}/files", params={"path": "../../"}, timeout=15
        )
        assert response.status_code == 400
