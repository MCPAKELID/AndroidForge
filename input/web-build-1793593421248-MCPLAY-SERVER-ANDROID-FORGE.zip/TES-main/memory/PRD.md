# MCPLAY SERVER — Product Requirements Document

## Ringkasan
MCPLAY SERVER adalah aplikasi Android (Expo) untuk menjalankan dan mengelola Minecraft Java Edition Server langsung di perangkat. Aplikasi ini menyediakan dashboard modern untuk membuat lebih dari satu server, memilih Java Runtime (Auto / 21 / 25), memantau proses, dan mengelolanya melalui LAN/hotspot/localhost.

## Fitur Utama
1. **Multi-Server + Import JAR**
   - `POST /api/servers` menerima `{name, java_version, min_ram, max_ram, port}` — sesederhana itu.
   - `POST /api/server/import-jar` menerima file `.jar`; nama asli disimpan di `config.json.original_jar_name`, tipe (Paper/Spigot/Vanilla/Custom) & versi Minecraft dideteksi otomatis dari nama file.
   - `GET /api/servers`, `POST /api/servers/{id}/activate`, `DELETE /api/servers/{id}` untuk manajemen multi-server.
   - Registry di `/tmp/mcplay_servers/servers.json` (path via `MCPLAY_DATA_DIR`).
2. **Import JAR** — `POST /api/server/import-jar` menyimpan `.jar` ke server aktif.
3. **Lifecycle** — Start/Stop/Restart menjalankan proses `java -jar` sungguhan dengan opsi RAM/args per server.
4. **Console real-time** — output subprocess ditampilkan lewat `GET /api/console`, input command via `POST /api/console/command`.
5. **File Manager** — daftar isi direktori server aktif (`GET /api/files`).
6. **Java Runtime detection** — auto-scan `java`, `java21`, `java25`, `JAVA_HOME_21/25`.
7. **Foreground Service (Android)** — plugin native `McplayForeground` mempertahankan proses saat aplikasi diminimize.
8. **Localization ID/EN** — semua label melalui `src/i18n.ts`.

## Navigasi Aplikasi
Bottom nav 6 tab (compact, testable):
- Dashboard, Console, File, Pemain, MCPAKEL, Pengaturan.
- Halaman MCPAKEL berdiri sendiri dengan hero avatar, tombol YouTube · TikTok · Shop · Donate (link resmi Alex Pakel).
- Halaman Pengaturan berisi language + `Pengaturan Server Aktif` (nama, MOTD, port, max players, RAM, Java version 21/25, PVP, Online mode).

## Alur First Run
1. Jika belum ada server, Dashboard menampilkan welcome card dengan tombol **BUAT SERVER** dan **IMPORT SERVER JAR**.
2. BUAT SERVER membuka bottom sheet: nama, Java Runtime (AUTO/21/25), RAM min/maks, port.
3. Setelah dibuat, server otomatis menjadi aktif dan Dashboard menampilkan metrik + tombol lifecycle.

## API Backend (FastAPI)
| Method | Path | Deskripsi |
| --- | --- | --- |
| GET | `/api/server/state` | Snapshot status + jar + java runtime + IP |
| GET | `/api/server/config` | Config server aktif (merge properties + config.json) |
| PUT | `/api/server/config` | Simpan config + tulis ke `server.properties` |
| GET | `/api/servers` | List semua server terdaftar |
| POST | `/api/servers` | Buat server baru (nama, Java, RAM, port) |
| POST | `/api/servers/{id}/activate` | Pilih server aktif |
| DELETE | `/api/servers/{id}` | Hapus server + direktori |
| POST | `/api/server/import-jar` | Upload JAR ke server aktif |
| POST | `/api/server/start` | Jalankan proses Java |
| POST | `/api/server/stop` | Kirim `stop` ke stdin proses |
| POST | `/api/server/restart` | Stop + Start berurutan |
| GET | `/api/console` | Log buffer real-time |
| POST | `/api/console/command` | Kirim command ke stdin |
| GET | `/api/files` | Daftar isi direktori server aktif |

## Tech Stack
- **Frontend**: Expo SDK 54, React Native, Expo Router (single-page tab UI), `expo-document-picker`, `expo-clipboard`, `expo-linking`.
- **Backend**: FastAPI + Uvicorn, subprocess Java, threading untuk streaming stdout.
- **Native Android**: Plugin `withMcplayForegroundService.js` + service Kotlin/Java untuk foreground service.
- **Storage**: File-based (JSON registry + per-server config.json + server.properties).

## Batasan Preview vs Produksi
- Preview cloud container Java-less → Java Runtime akan tampil `Tidak tersedia`. Di device Android real, aplikasi mendeteksi `java21`/`java25`.
- Foreground service hanya aktif pada build native Android (bukan Expo Go).
