# MCPLAY SERVER — Android Forge build package

This package keeps the original MCPLAY SERVER Expo / React Native source and native Android project.
The app UI and application code have not been rewritten.

## Project locations
- Expo / React Native project: `frontend/`
- Native Android Gradle project: `frontend/android/`
- Main screen: `frontend/app/index.tsx`
- Root navigation: `frontend/app/_layout.tsx`
- Required icon-font hook: `frontend/src/hooks/use-icon-fonts.ts`
- Android foreground service: `frontend/android/app/src/main/java/com/mcplay/server/`

## Import/build
1. Extract this ZIP completely. Do not copy only `frontend/android`; the Android Gradle project depends on the sibling `frontend/node_modules` and Expo source.
2. Install the JavaScript dependencies for `frontend/` using Yarn 1.22.22 (`yarn install`; if the environment blocks the package preinstall script, use `yarn install --ignore-scripts`).
3. In Android Forge, open/import the Gradle project at `frontend/android/` (not the ZIP root and not `frontend/`).
4. Use JDK 17 or 21 and Android SDK/NDK versions compatible with Expo SDK 54 / React Native 0.81.5. The Gradle wrapper properties pin Gradle 8.14.3.
5. Build the `release` variant / `assembleRelease`.

## Important
- This ZIP includes the original `src/hooks/use-icon-fonts.ts`. If that file is missing after extraction, the archive was not extracted completely.
- The original project uses Expo SDK 54, React Native 0.81.5, Kotlin 2.1.20, and Android Gradle Plugin resolved through the project plugin configuration.
- `gradle-wrapper.jar` is not included in the uploaded original project. If Android Forge requires the wrapper JAR instead of using its own Gradle installation, generate it from a Gradle 8.14.3 installation with `gradle wrapper --gradle-version 8.14.3`, or add the wrapper JAR from the matching Gradle distribution.
- Native C/C++ modules (Hermes, Worklets, Screens, Expo Modules Core) require a working NDK + CMake toolchain. A Gradle/Metro source fix cannot compensate for a missing or incompatible NDK compiler.
