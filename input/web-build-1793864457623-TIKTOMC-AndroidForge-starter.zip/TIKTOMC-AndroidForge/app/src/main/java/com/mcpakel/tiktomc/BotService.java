package com.mcpakel.tiktomc;

import android.app.*;
import android.content.*;
import android.os.*;
import java.io.File;

public class BotService extends Service {
    public static final String ACTION_START="com.mcpakel.tiktomc.START";
    public static final String ACTION_STOP="com.mcpakel.tiktomc.STOP";
    private static volatile boolean runtimeStarted=false;
    private Thread nodeThread;
    static { System.loadLibrary("node"); System.loadLibrary("tiktomc-native"); }
    public native int startNodeNative(String[] args);

    @Override public int onStartCommand(Intent intent,int flags,int startId) {
        String action=intent==null?ACTION_START:intent.getAction();
        if(ACTION_STOP.equals(action)) { stopForeground(STOP_FOREGROUND_REMOVE); stopSelf(); return START_NOT_STICKY; }
        startForeground(4101, notification("Menyiapkan TIKTOMC"));
        if(!runtimeStarted) startRuntime();
        return START_STICKY;
    }
    private void startRuntime() {
        synchronized(BotService.class) {
            if(runtimeStarted) return;
            runtimeStarted=true;
        }
        nodeThread=new Thread(() -> {
            File root=new File(getFilesDir(),"tiktomc");
            File entry=new File(root,"android-entry.js");
            if(!entry.exists()) { android.util.Log.e("TIKTOMC","Source belum diunduh: "+entry); return; }
            startNodeNative(new String[]{"node",entry.getAbsolutePath()});
        },"tiktomc-node");
        nodeThread.start();
    }
    private Notification notification(String text) {
        String channel="tiktomc_service";
        if(Build.VERSION.SDK_INT>=26) { NotificationChannel c=new NotificationChannel(channel,"TIKTOMC Service",NotificationManager.IMPORTANCE_LOW); getSystemService(NotificationManager.class).createNotificationChannel(c); }
        return new Notification.Builder(this,channel).setContentTitle("TIKTOMC aktif").setContentText(text).setSmallIcon(android.R.drawable.stat_notify_sync).build();
    }
    @Override public void onDestroy() { super.onDestroy(); }
    @Override public android.os.IBinder onBind(Intent i) { return null; }
}
