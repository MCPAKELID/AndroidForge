package com.mcpakel.tiktomc;

import android.Manifest;
import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Bundle;
import android.graphics.Color;
import android.view.Gravity;
import android.widget.*;

public class MainActivity extends Activity {
    private TextView status, console;
    private Button start, stop;
    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        getWindow().setStatusBarColor(Color.rgb(10,14,22));
        getWindow().setNavigationBarColor(Color.rgb(10,14,22));
        if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED)
            requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, 7);
        buildUi();
    }
    private void buildUi() {
        LinearLayout root = new LinearLayout(this); root.setOrientation(1); root.setPadding(22,28,22,18); root.setBackgroundColor(Color.rgb(10,14,22));
        TextView title = new TextView(this); title.setText("TIKTOMC"); title.setTextColor(Color.WHITE); title.setTextSize(27); title.setGravity(Gravity.CENTER_VERTICAL); title.setTypeface(null,1);
        TextView sub = new TextView(this); sub.setText("TIKTOK LIVE  /  MINECRAFT BRIDGE"); sub.setTextColor(Color.rgb(130,150,175)); sub.setTextSize(11);
        status = new TextView(this); status.setText("STATUS  •  STOPPED"); status.setTextColor(Color.rgb(255,190,80)); status.setPadding(0,26,0,18);
        start = new Button(this); start.setText("START"); start.setOnClickListener(v -> { Intent i=new Intent(this,BotService.class); i.setAction(BotService.ACTION_START); if(Build.VERSION.SDK_INT>=26) startForegroundService(i); else startService(i); status.setText("STATUS  •  STARTING"); });
        stop = new Button(this); stop.setText("STOP"); stop.setOnClickListener(v -> { Intent i=new Intent(this,BotService.class); i.setAction(BotService.ACTION_STOP); startService(i); status.setText("STATUS  •  STOP REQUESTED"); });
        console = new TextView(this); console.setText("Console TIKTOMC akan tampil di sini.\n\nRuntime Node.js harus dipasang sebelum build."); console.setTextColor(Color.rgb(190,205,220)); console.setTextSize(12); console.setPadding(12,12,12,12); console.setBackgroundColor(Color.rgb(20,27,39));
        ScrollView scroll = new ScrollView(this); scroll.addView(console);
        root.addView(title); root.addView(sub); root.addView(status); root.addView(start); root.addView(stop); root.addView(scroll,new LinearLayout.LayoutParams(-1,0,1)); setContentView(root);
    }
}
