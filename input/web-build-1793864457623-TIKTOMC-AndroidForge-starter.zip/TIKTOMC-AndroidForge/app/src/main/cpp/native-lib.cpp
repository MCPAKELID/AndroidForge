#include <jni.h>
#include <string>
#include <vector>
#include <android/log.h>
#include "node.h"

#define LOG_TAG "TIKTOMC-NODE"
#define LOGE(...) __android_log_print(ANDROID_LOG_ERROR, LOG_TAG, __VA_ARGS__)

extern "C" JNIEXPORT jint JNICALL
Java_com_mcpakel_tiktomc_BotService_startNodeNative(JNIEnv* env, jobject /* thiz */, jobjectArray args) {
    const jsize argc = env->GetArrayLength(args);
    std::vector<std::string> storage;
    std::vector<char*> argv;
    storage.reserve(argc);
    argv.reserve(argc);
    for (jsize i = 0; i < argc; ++i) {
        auto value = (jstring) env->GetObjectArrayElement(args, i);
        const char* chars = env->GetStringUTFChars(value, nullptr);
        storage.emplace_back(chars ? chars : "");
        if (chars) env->ReleaseStringUTFChars(value, chars);
        env->DeleteLocalRef(value);
    }
    for (auto& s : storage) argv.push_back(s.data());
    int result = node::Start(argc, argv.data());
    LOGE("Node runtime exited with code %d", result);
    return result;
}
