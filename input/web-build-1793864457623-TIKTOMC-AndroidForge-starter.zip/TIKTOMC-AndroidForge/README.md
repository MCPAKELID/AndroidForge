# TIKTOMC AndroidForge — Android native starter

This is the Android shell (Java/Kotlin-compatible Android project structure) for the TIKTOMC app.

## Important runtime requirement

The project intentionally does NOT bundle a fake/stub Node runtime. Before it can build, place a real Android ARM64 Node.js Mobile `libnode.so` and matching headers in:

- `app/src/main/jniLibs/arm64-v8a/libnode.so`
- `app/src/main/cpp/node-include/node.h` (plus the matching Node headers required by that build)

The runtime must be Node.js >=20 and built for Android arm64-v8a. Do not use the standard Linux Node binary; it is not an Android binary. The upstream Node.js docs state Android is not a supported official binary platform; Android builds require NDK configuration. See https://github.com/nodejs/node/blob/main/BUILDING.md#android.

## Current scope

- Native Android app shell, manual START/STOP controls, foreground service, JNI entry point.
- `BotService` expects the Android-specific entry script at `files/tiktomc/android-entry.js`.
- The GitHub source downloader, dependency installer, log bridge, and graceful Node shutdown are not yet wired in this starter.
- The current TIKTOMC `index.js` enforces Node >=20. Its `main.js` imports WhatsApp and must be patched to remove WhatsApp completely before launch.

## AndroidForge

Open this folder as a Gradle Android project. Build uses Android Gradle Plugin 8.7.3, compile SDK 35, NDK arm64-v8a, and CMake 3.22.1.

This starter is not yet a ready-to-install APK until the matching Node runtime is supplied and the downloader/installer layer is completed. Do not treat a successful shell build as proof that TIKTOMC itself can run.
