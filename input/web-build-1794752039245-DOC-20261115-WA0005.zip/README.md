# BlockRush Live Game v22 — AndroidForge Source

Game Minecraft 2D untuk live TikTok: penonton kirim gift / follow / like, dan game langsung bereaksi (TNT, petir, tornado, robot pembantu, meteor, dll).

## Hubungkan ke TikTok Live (lewat bridge Node.js milikmu)

Game ini tidak bisa membaca TikTok langsung dari dalam aplikasi Android, jadi ia terhubung ke bridge Node.js (TIKTOMC) lewat WebSocket.

1. Di bridge, atur env: `MINECRAFT_OUTBOUND_ENABLED=false` dan `WS_PORT=25601` (mode listener langsung), lalu jalankan `node main.js`.
2. Di game: **TIKTOK LIVE** → isi **Host**, **Port**, **Username** → **MULAI TERHUBUNG**.
   - Bridge jalan di HP yang sama (Termux): host `127.0.0.1`.
   - Bridge jalan di PC satu WiFi: host = IP PC (contoh `192.168.1.5`).
3. Status di HUD: `TERHUBUNG` → `LIVE` saat bridge sudah masuk ke live TikTok-mu. Putus otomatis tersambung lagi.
4. **HUBUNG OTOMATIS** = langsung tersambung tiap game dibuka. **TES EVENT** = kirim follow + gift palsu untuk mencoba.

## Event & Hadiah

- **EVENT TIKTOK** (menu TikTok → EVENT): follow, share, masuk live, like, komentar, subscribe, gift lain. Tiap event: ON/OFF, NOTIF tampil/tidak, efek, jumlah (misal follow = 1 TNT), tombol TES. Like: aksi tiap N like.
- **HADIAH LIVE** (24 slot, 6 per halaman): tiap slot = satu gift TikTok. Pilih nama gift dari daftar (gift yang pernah masuk saat live ditaruh paling atas, hijau) atau ketik nama persis. Atur ikon (14), efek, jumlah, teks, ON/OFF, dan **TAMPIL/SEMBUNYI** di baris atas (maks 8). Gift combo dikalikan jumlahnya.
- **Efek**: BLOK, TNT, HUJAN TNT, TURBO, NYAWA, PERISAI, PETIR, TORNADO, ROBOT, METEOR.
- Notifikasi di layar bisa dimatikan total di PENGATURAN.

Daftar gift bawaan (38 gift populer) adalah perkiraan; halaman streamdps.com tidak bisa diambil otomatis. Gift yang tidak ada di daftar tetap bisa diketik manual, dan setiap gift yang masuk saat live otomatis diingat.

## Cara main

- **Tombol Blok**: blok dipasang tepat di bawah kaki player, player naik ke atasnya. Tahan = menara cepat.
- **Ketuk / klik layar** memasang blok. Jika di bawahnya kosong, blok **jatuh** sampai menumpu ke blok/tanah. Jika blok bawah dihancurkan, blok di atasnya **tidak** jatuh.
- Celah 2 blok bisa dilewati player. Tombol TNT sudah dihapus (TNT sekarang dari gift/event).
- **Map & Karakter**: 5 map (Padang, Gurun, Salju, Nether, Malam) dan 7 karakter.
- **HUD TURUN** (Pengaturan): geser HUD ke bawah (kamera notch). Kiri atas = jumlah blok area terpasang, kanan = persen area.

## Kontrol

| Aksi | Sentuh | Keyboard | Mouse |
|---|---|---|---|
| Jalan | ◀ ▶ | A / D, panah | – |
| Lompat | ⬆ | W / Spasi | – |
| Lari | tombol lari | Shift | – |
| Blok di bawah player | tombol blok | E / Enter | – |
| Pasang blok di kotak | ketuk | F (depan) | klik kiri |
| Gali | mode beliung + ketuk | X / Z / Ctrl, S | klik kanan |
| Hadiah (uji manual) | ketuk ikon | 1–8 | klik ikon |
| Jeda | tombol jeda, Back | Esc / P | – |
| Menu: pengaturan / hadiah / tiktok / map | – | O / G / T / L | – |

## Build

Ekstrak ke workspace AndroidForge (root berisi `settings.gradle` & `build.gradle`), build modul `app` dengan JDK 17 dan Android SDK 35. Izin INTERNET sudah ada di manifest.

Application ID: `com.mcpakel.blockarea` — Versi 2.2 (versionCode 22).

Diuji dengan API Android tiruan (logika, input, tampilan) dan koneksi WebSocket nyata ke server `ws` dari TMine.js. APK asli / TikTok live asli belum dites di perangkat. Jika build error, kirim lognya.
