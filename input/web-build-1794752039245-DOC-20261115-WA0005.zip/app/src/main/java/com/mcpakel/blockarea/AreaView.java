package com.mcpakel.blockarea;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Rect;
import android.graphics.RectF;
import android.graphics.Typeface;
import android.media.AudioAttributes;
import android.media.SoundPool;
import android.os.Build;
import android.text.InputType;
import android.util.SparseArray;
import android.view.InputDevice;
import android.view.KeyEvent;
import android.view.MotionEvent;
import android.view.View;
import android.widget.EditText;

import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.util.Locale;
import java.util.Random;

/**
 * Block Rush (2D Minecraft style): place blocks under yourself and climb, mine, blow things up
 * with TNT. Input: touch, keyboard and mouse (Bluetooth / OTG / built-in) and simple gamepads.
 * Everything is drawn on one Canvas in a 512-unit wide world.
 */
public class AreaView extends View {
    // ---- world / layout -------------------------------------------------------------
    private static final float WORLD_W = 512f;
    private static final float BOARD_H = 1935f;
    private static final float MIN_LOGICAL_H = 700f;
    private static final float MAX_CONTROL_H = 384f;
    private static final float MIN_CONTROL_H = 140f;
    private static final int COLS = 10, ROWS = 40, BLOCK_TYPES = 48, TNT_TYPE = 28;
    private static final int BUILD_LIMIT_ROW = 0;
    private static final float GRID_X = 41f, GRID_Y = 132f, CELL = 43f;
    private static final float FLOOR_Y = GRID_Y + ROWS * CELL;
    private static final float PLAYER_H = CELL * 1.8f;          // fits through a 2-cell gap
    private static final float PLAYER_HALF_W = CELL * 0.30f;
    private static final float GRAVITY = 1850f, JUMP_SPEED = 720f;
    private static final float AREA_TOP = 176f;
    private static final float PLAYER_SCREEN_RATIO = 0.72f;
    private static final int SKY = 0xff38a6fd;

    private static final int MAX_INVENTORY = 100, MAX_TNT = 24;
    private static final int MAX_PARTICLES = 260, MAX_FX = 12;
    private static final int[] LADDER = {1, 2, 3, 4, 5, 33, 6, 10, 11};
    private static final int[] ORES = {12, 13, 14, 15, 16, 17, 18};

    // Inner compartments of hud_bar.png (source pixels): start,end pairs.
    private static final int[] BAR_SEG = {42, 145, 156, 265, 276, 396, 407, 527, 539, 660,
            672, 797, 808, 933, 945, 1067, 1078, 1200, 1211, 1336, 1347, 1471, 1483, 1607,
            1618, 1741, 1753, 1859, 1870, 1974};

    private static final int ROLE_NONE = 0, ROLE_LEFT = 1, ROLE_RIGHT = 2, ROLE_JUMP = 3,
            ROLE_RUN = 4, ROLE_PICK = 5, ROLE_BUILD = 6, ROLE_GRID = 7, ROLE_PAUSE = 8,
            ROLE_GIFT = 9;
    private static final int SCREEN_MENU = 0, SCREEN_GAME = 1, SCREEN_PAUSE = 2,
            SCREEN_SETTINGS = 3, SCREEN_GIFTS = 4, SCREEN_TIKTOK = 5, SCREEN_EVENTS = 6,
            SCREEN_LOOKS = 7, SCREEN_PICK = 8, SCREENS = 9;

    private static final int MAX_TORNADO = 3, MAX_ROBOT = 6, MAX_METEOR = 6, MAX_BOLT = 4, FEED_LINES = 5;
    private static final float TNT_FUSE = 1.4f, ROBOT_LIFE = 14f, TORNADO_LIFE = 8f, FX_TIME = 0.7f, BOLT_TIME = 0.45f;
    private static final int GIFT_PAGE = 6, PICK_PAGE = 16;
    // Map themes: sky next to the arena, ground texture (top, middle, deep), ground shade.
    private static final int[] MAP_SKY = {0xff5bbafd, 0xffffcd78, 0xffcde1f5, 0xff962319, 0xff141a46};
    private static final int[][] MAP_GROUND = {{0, 1, 2}, {10, 11, 2}, {45, 1, 2}, {19, 19, 24}, {0, 1, 2}};
    private static final int[] MAP_SHADE = {0, 0, 0, 0, 0x66000000};

    // UI button ids
    private static final int B_PLAY = 1, B_GIFTS = 2, B_SETTINGS = 3, B_RESUME = 4, B_RETRY = 5,
            B_MENU = 6, B_TIKTOK = 7, B_LOOKS = 8,
            B_SOUND = 10, B_BUTTONS = 11, B_UNLIMITED = 12, B_SPEED = 13, B_HUD_MINUS = 14,
            B_RESET = 15, B_BACK = 16, B_HUD_PLUS = 17, B_RESET_GIFTS = 18, B_FEED = 19,
            B_PAGE_PREV = 20, B_PAGE_NEXT = 21,
            B_T_HOST = 30, B_T_PORT = 31, B_T_USER = 32, B_T_AUTO = 33, B_T_START = 34, B_T_EVENTS = 35,
            B_T_TEST = 36, B_T_GIFTS = 37,
            B_MAP_PREV = 40, B_MAP_NEXT = 41, B_CHAR_PREV = 42, B_CHAR_NEXT = 43,
            B_LIKE_MINUS = 50, B_LIKE_PLUS = 51, B_LIKE_AMT = 52, B_E_RESET = 53,
            B_PICK_MANUAL = 60, B_PICK_CLEAR = 61,
            B_E_ON = 300, B_E_NOTIF = 320, B_E_EFFECT = 340, B_E_MINUS = 360, B_E_AMOUNT = 380, B_E_PLUS = 400,
            B_G_ON = 1000, B_G_SHOW = 1030, B_G_ICON = 1060, B_G_NAME = 1090, B_G_EFFECT = 1120,
            B_G_MINUS = 1150, B_G_AMOUNT = 1180, B_G_PLUS = 1210, B_G_LABEL = 1240, B_E_TEST = 420, B_PICK_ITEM = 2000;

    private interface TextResult { void done(String text); }

    private static final class TouchPoint {
        int role, arg;
        boolean mouse;
        float x, y;
        TouchPoint(int role, float x, float y) { this.role = role; this.x = x; this.y = y; }
    }

    private final Paint paint = new Paint();
    private final RectF tmp = new RectF();
    private final Random rnd = new Random();
    private final GameSettings cfg;
    private final int[][] blocks = new int[ROWS][COLS];
    private final long[][] blockPlacedAt = new long[ROWS][COLS];
    private final RectF[] giftRects = new RectF[GameSettings.GIFTS];
    private final int[] giftIdx = new int[GameSettings.GIFTS];
    private int giftCount = 0;
    private final RectF pauseRect = new RectF(460f, 4f, 504f, 48f);
    private final Bitmap[] blockTextures = new Bitmap[BLOCK_TYPES];
    private final int[] blockColor = new int[BLOCK_TYPES];
    private final Bitmap[] giftIcons = new Bitmap[GameSettings.ICONS];
    private final Bitmap[][] characterFrames = new Bitmap[3][5];
    private final float[][] characterBottom = new float[3][5];
    private final Bitmap[] tntFrames = new Bitmap[7], boomFrames = new Bitmap[8];
    private final Bitmap[] charPreview = new Bitmap[GameSettings.CHARS];
    private int loadedMap = -1, loadedChar = -1;
    private final LiveClient live = new LiveClient();
    private final int[] backTo = new int[SCREENS];
    private int giftPage = 0, pickPage = 0, pickSlot = 0;
    private final float[] blockDrop = new float[ROWS * COLS], blockDropV = new float[ROWS * COLS];
    private final SparseArray<TouchPoint> touches = new SparseArray<>();

    // UI hit boxes recorded while drawing a menu screen.
    private final RectF[] uiRects = new RectF[120];
    private final int[] uiIds = new int[120];
    private int uiCount = 0;

    private Bitmap arena, fontAtlas, placementFrame, menuBackground, pauseIcon;
    private Bitmap hudBar, hudCube, hudTrophy, hudHp;
    private Bitmap leftImage, rightImage, runImage, pickImage, blockImage, jumpImage;

    private final RectF[] hit = new RectF[6];
    private final RectF[] icon = new RectF[6];

    // ---- player ---------------------------------------------------------------------
    private float playerX, playerFeet, velocityY;
    private float cameraY, cameraTarget;
    private float animationClock, stepClock, impactVy;
    private long lastFrameNanos;
    private boolean grounded = true, wasGrounded = true, facingRight = true;
    private boolean jumpRequested = false;
    private int walkFrame = 0, runFrame = 0, jumpFrame = 0;

    // ---- input state ----------------------------------------------------------------
    private boolean touchLeft, touchRight, touchJump, touchBuild;
    private boolean keyLeft, keyRight, keyJump, keyBuild, keyShift, keyMineFront, keyMineDown;
    private boolean padLeft, padRight;
    private boolean sprintToggle = false;
    private boolean leftHeld, rightHeld, jumpHeld, buildHeld;
    private boolean breakMode = false;
    private boolean mouseActive = false;
    private boolean gridHeld = false, gridMine = false;
    private int hoverCol = -1, hoverRow = -1;
    private int targetCol = -1, targetRow = -1;
    private int hitArg = -1;
    private float buildCooldown = 0f, gridCooldown = 0f, mineCooldown = 0f;

    // ---- game state -----------------------------------------------------------------
    private int screen = SCREEN_MENU;
    private int inventory = MAX_INVENTORY, winCount = 0;
    private float hp = 100f;
    private float gameClock = 0f, regenClock = 0f, lastPlaceSound = -1f;
    private float turboUntil = -1f, shieldUntil = -1f;
    private String toastText = "";
    private float toastUntil = -1f;
    private final float[] giftFlash = new float[GameSettings.GIFTS];
    private int rainLeft = 0;
    private float rainClock = 0f;
    private long playerPlaceUntilNanos = 0L;
    private float pressCenterX = -1000f, pressCenterY = -1000f;
    private long pressUntilNanos = 0L;
    private int countdownValue = -1;
    private long countdownNextNanos = 0L;
    private float shake = 0f;

    // TNT entities.
    private final boolean[] tntOn = new boolean[MAX_TNT];
    private final float[] tntY = new float[MAX_TNT], tntVy = new float[MAX_TNT], tntFuse = new float[MAX_TNT];
    private final int[] tntCol = new int[MAX_TNT];

    // Particles and explosion rings.
    private final float[] px = new float[MAX_PARTICLES], py = new float[MAX_PARTICLES];
    private final float[] pvx = new float[MAX_PARTICLES], pvy = new float[MAX_PARTICLES];
    private final float[] plife = new float[MAX_PARTICLES];
    private final int[] pcol = new int[MAX_PARTICLES];
    private final float[] fxX = new float[MAX_FX], fxY = new float[MAX_FX], fxT = new float[MAX_FX],
            fxS = new float[MAX_FX];

    // Tornadoes, helper robots, meteors, lightning bolts.
    private final boolean[] twOn = new boolean[MAX_TORNADO];
    private final float[] twX = new float[MAX_TORNADO], twY = new float[MAX_TORNADO],
            twLife = new float[MAX_TORNADO], twHit = new float[MAX_TORNADO];
    private final int[] twDir = new int[MAX_TORNADO];
    private final boolean[] rbOn = new boolean[MAX_ROBOT];
    private final float[] rbX = new float[MAX_ROBOT], rbY = new float[MAX_ROBOT],
            rbLife = new float[MAX_ROBOT], rbAct = new float[MAX_ROBOT];
    private final int[] rbCol = new int[MAX_ROBOT], rbDir = new int[MAX_ROBOT];
    private final boolean[] mtOn = new boolean[MAX_METEOR];
    private final float[] mtX = new float[MAX_METEOR], mtY = new float[MAX_METEOR],
            mtVx = new float[MAX_METEOR], mtVy = new float[MAX_METEOR];
    private final float[] blT = new float[MAX_BOLT], blY = new float[MAX_BOLT];
    private final int[] blCol = new int[MAX_BOLT];
    private float flash = 0f;
    private final int[] pend = new int[GameSettings.EFFECTS];
    private float pendClock = 0f;

    // TikTok notifications (feed) and like counter.
    private final String[] feedText = new String[FEED_LINES];
    private final float[] feedUntil = new float[FEED_LINES];
    private final int[] feedColor = new int[FEED_LINES];
    private int likeAcc = 0;
    private boolean recentDirty = false;
    private float lastRecentSave = 0f;

    // Sound.
    private SoundPool pool;
    private int sJump, sLand, sStep, sRun;

    public AreaView(Context context) {
        super(context);
        cfg = new GameSettings(context);
        fontAtlas = load("font/pixel_font.png");
        placementFrame = load("blocks/placement_frame.png");
        hudBar = load("ui/hud_bar.png");
        hudCube = load("ui/hud_cube.png");
        hudTrophy = load("ui/hud_trophy.png");
        hudHp = load("ui/hud_hp.png");
        leftImage = load("ui/control_left.png");
        rightImage = load("ui/control_right.png");
        runImage = load("ui/control_run.png");
        pickImage = load("ui/control_pickaxe.png");
        blockImage = load("ui/control_block.png");
        jumpImage = load("ui/control_jump.png");
        menuBackground = load("menu/background.jpg");
        pauseIcon = load("menu/icon_pause.png");

        for (int i = 0; i < uiRects.length; i++) uiRects[i] = new RectF();
        for (int i = 0; i < BLOCK_TYPES; i++) {
            blockTextures[i] = load(String.format(Locale.US, "blocks/block_%02d.png", i));
            blockColor[i] = averageColor(blockTextures[i]);
        }
        for (int i = 0; i < 7; i++) tntFrames[i] = load("fx/tnt_" + i + ".png");
        for (int i = 0; i < 8; i++) boomFrames[i] = load("fx/boom_" + i + ".png");
        applyLook();
        for (int i = 0; i < GameSettings.ICONS; i++) giftIcons[i] = load("ui/gift_icon_" + i + ".png");
        for (int i = 0; i < GameSettings.GIFTS; i++) giftRects[i] = new RectF();
        for (int r = 0; r < ROWS; r++) for (int c = 0; c < COLS; c++) blocks[r][c] = -1;
        for (int i = 0; i < 6; i++) { hit[i] = new RectF(); icon[i] = new RectF(); }
        for (int i = 0; i < MAX_FX; i++) fxT[i] = -1f;

        playerX = GRID_X + (COLS * CELL) / 2f;
        playerFeet = FLOOR_Y;
        paint.setFilterBitmap(false);
        paint.setAntiAlias(false);

        initSound();
        if (cfg.autoConnect && cfg.user.trim().length() > 0) startLive();
        setFocusable(true);
        setFocusableInTouchMode(true);
        if (Build.VERSION.SDK_INT >= 26) setDefaultFocusHighlightEnabled(false);
        requestFocus();
    }

    // ================================================================================
    // Resources
    // ================================================================================
    private Bitmap load(String path) {
        InputStream in = null;
        try {
            in = getContext().getAssets().open(path);
            return BitmapFactory.decodeStream(in);
        } catch (Exception e) {
            return null;
        } finally {
            try { if (in != null) in.close(); } catch (Exception ignored) { }
        }
    }

    private int averageColor(Bitmap b) {
        if (b == null || b.getWidth() < 4 || b.getHeight() < 4) return 0xff8a8a8a;
        long r = 0, g = 0, bl = 0;
        int n = 0;
        for (int yy = 0; yy < 4; yy++) {
            for (int xx = 0; xx < 4; xx++) {
                int p = b.getPixel((xx * 2 + 1) * b.getWidth() / 8, (yy * 2 + 1) * b.getHeight() / 8);
                r += (p >> 16) & 255; g += (p >> 8) & 255; bl += p & 255; n++;
            }
        }
        return 0xff000000 | ((int) (r / n) << 16) | ((int) (g / n) << 8) | (int) (bl / n);
    }

    /** Fraction of the bitmap height that is transparent at the bottom (so feet sit on the floor). */
    private float bottomPadding(Bitmap b) {
        if (b == null) return 0f;
        int w = b.getWidth(), h = b.getHeight();
        for (int y = h - 1; y >= 0; y--) {
            for (int x = 0; x < w; x += 2) {
                if (((b.getPixel(x, y) >> 24) & 255) > 40) return (h - 1 - y) / (float) h;
            }
        }
        return 0f;
    }

    /** Loads the arena picture and the character frames for the selected map / character. */
    private void applyLook() {
        if (loadedMap != cfg.map) {
            arena = load(cfg.map == 0 ? "area/arena_reference.png" : "area/arena_" + cfg.map + ".png");
            loadedMap = cfg.map;
        }
        if (loadedChar != cfg.character) {
            String pre = cfg.character == 0 ? "" : "c" + cfg.character + "_";
            String[] actions = {"walk", "run", "jump"};
            for (int a = 0; a < 3; a++) {
                for (int f = 0; f < 5; f++) {
                    characterFrames[a][f] = load("character/" + pre + actions[a] + "_" + f + ".png");
                    characterBottom[a][f] = bottomPadding(characterFrames[a][f]);
                }
            }
            loadedChar = cfg.character;
        }
    }

    private Bitmap previewOf(int ch) {
        if (charPreview[ch] == null) charPreview[ch] = load("character/" + (ch == 0 ? "" : "c" + ch + "_") + "walk_0.png");
        return charPreview[ch];
    }

    private void startLive() { live.start(cfg.host, cfg.port, cfg.user); }

    private void initSound() {
        try {
            AudioAttributes attrs = new AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_GAME)
                    .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION).build();
            pool = new SoundPool.Builder().setMaxStreams(6).setAudioAttributes(attrs).build();
            sJump = loadSound("jump");
            sLand = loadSound("land");
            sStep = loadSound("footstep");
            sRun = loadSound("run_step");
        } catch (Throwable t) {
            pool = null;
        }
    }

    private int loadSound(String name) {
        try {
            File f = new File(getContext().getCacheDir(), "snd_" + name + ".wav");
            if (!f.exists() || f.length() == 0) {
                InputStream in = getContext().getAssets().open("sounds/" + name + ".wav");
                FileOutputStream out = new FileOutputStream(f);
                byte[] buf = new byte[4096];
                int n;
                while ((n = in.read(buf)) > 0) out.write(buf, 0, n);
                out.close();
                in.close();
            }
            return pool.load(f.getAbsolutePath(), 1);
        } catch (Throwable t) {
            return 0;
        }
    }

    private void play(int id, float volume, float rate) {
        if (pool == null || !cfg.sound || id == 0) return;
        try { pool.play(id, volume, volume, 1, 0, rate); } catch (Throwable ignored) { }
    }

    /** Called by the activity when it is destroyed. */
    public void release() {
        live.stop();
        if (pool != null) {
            try { pool.release(); } catch (Throwable ignored) { }
            pool = null;
        }
    }

    protected long now() { return System.nanoTime(); }

    // ================================================================================
    // Layout helpers
    // ================================================================================
    private float scale() { return Math.min(getWidth() / WORLD_W, getHeight() / MIN_LOGICAL_H); }
    private float offsetX() { return (getWidth() - WORLD_W * scale()) * 0.5f; }
    private float logicalHeight() { return getHeight() / Math.max(0.001f, scale()); }
    private float controlHeight() {
        if (!cfg.showButtons) return 0f;
        return Math.min(MAX_CONTROL_H, Math.max(MIN_CONTROL_H, logicalHeight() - BOARD_H));
    }
    private float controlTop() { return logicalHeight() - controlHeight(); }
    private float hudOff() { return Math.max(0, Math.min(80, cfg.hudOffset)); }
    private float areaTop() { return Math.min(AREA_TOP + hudOff(), Math.max(0f, controlTop() - 360f)); }
    private float boardViewportHeight() { return Math.max(360f, controlTop() - areaTop()); }
    private float worldToScreenY(float y) { return areaTop() + y - cameraY; }
    private int clamp(int value, int min, int max) { return Math.max(min, Math.min(max, value)); }
    private float clampFloat(float v, float min, float max) { return Math.max(min, Math.min(max, v)); }
    private int playerColumn() { return clamp((int) ((playerX - GRID_X) / CELL), 0, COLS - 1); }
    private float toLogicalX(float pxv) { return (pxv - offsetX()) / Math.max(0.001f, scale()); }
    private float toLogicalY(float pyv) { return pyv / Math.max(0.001f, scale()); }
    private float minCamera() { return -PLAYER_H * 1.2f; }
    private float maxCamera() { return Math.max(minCamera(), FLOOR_Y + 260f - boardViewportHeight()); }

    /** Row of the cell the player's feet are in (the cell a block under the player will fill). */
    private int feetRow() {
        return (int) Math.floor((playerFeet - 1f - GRID_Y) / CELL);
    }

    // ================================================================================
    // Board queries
    // ================================================================================
    private int topBlockRow(int col) {
        for (int r = BUILD_LIMIT_ROW; r < ROWS; r++) if (blocks[r][col] >= 0) return r;
        return ROWS;
    }

    private int blockCount() {
        int n = 0;
        for (int[] row : blocks) for (int v : row) if (v >= 0) n++;
        return n;
    }

    private int areaPercent() {
        return Math.min(100, Math.round(blockCount() * 100f / (COLS * ROWS)));
    }

    // Floor row = dirt, then every material lasts two rows.
    private int materialForRow(int row) {
        int layer = (ROWS - 1) - row;
        int idx = layer == 0 ? 0 : 1 + (layer - 1) / 2;
        return LADDER[idx % LADDER.length];
    }

    private int pickType(int row) {
        int base = materialForRow(row);
        if (base == 2 && rnd.nextInt(100) < 12) return ORES[rnd.nextInt(ORES.length)];
        return base;
    }

    private boolean isSprint() { return sprintToggle || keyShift; }
    private boolean turboOn() { return gameClock < turboUntil; }
    private boolean shieldOn() { return gameClock < shieldUntil; }

    private void layoutControls() {
        float y = controlTop() + (controlHeight() - 84f) / 2f;
        float[] xs = {2, 86, 170, 268, 352, 436};
        for (int i = 0; i < 6; i++) {
            hit[i].set(xs[i] - 4, y - 4, xs[i] + 78, y + 82);
            icon[i].set(xs[i] + 2, y + 2, xs[i] + 76, y + 80);
        }
    }

    /** Only gifts that are active AND set to "tampil" are shown, centered and sized to fit. */
    private void layoutGifts() {
        float off = hudOff();
        pauseRect.set(460f, 4f + off, 504f, 48f + off);
        giftCount = 0;
        for (int i = 0; i < GameSettings.GIFTS && giftCount < GameSettings.SHOWN_MAX; i++) {
            if (cfg.gifts[i].on && cfg.gifts[i].show) giftIdx[giftCount++] = i;
        }
        if (giftCount == 0) return;
        float gap = 6f;
        float tw = Math.min(60f, (478f - (giftCount - 1) * gap) / giftCount);
        float th = tw * 129f / 162f + 17f;
        float total = giftCount * tw + (giftCount - 1) * gap;
        float x = (WORLD_W - total) / 2f, y = 93f + off;
        for (int k = 0; k < giftCount; k++) {
            giftRects[k].set(x, y, x + tw, y + th);
            x += tw + gap;
        }
    }

    // ================================================================================
    // Drawing primitives
    // ================================================================================
    private void drawBitmap(Canvas canvas, Bitmap bitmap, RectF dst) {
        if (bitmap == null) return;
        paint.setAlpha(255); paint.setFilterBitmap(false); paint.clearShadowLayer();
        canvas.drawBitmap(bitmap, null, dst, paint);
    }

    private void blit(Canvas c, Bitmap b, float l, float t, float r, float bt, boolean smooth) {
        if (b == null) return;
        tmp.set(l, t, r, bt);
        paint.setAlpha(255); paint.setFilterBitmap(smooth);
        c.drawBitmap(b, null, tmp, paint);
        paint.setFilterBitmap(false);
    }

    private void fill(Canvas c, float l, float t, float r, float b, int color) {
        paint.setStyle(Paint.Style.FILL);
        paint.setColor(color);
        c.drawRect(l, t, r, b, paint);
    }

    private void roundRect(Canvas c, float l, float t, float r, float b, float rad, int color) {
        tmp.set(l, t, r, b);
        paint.setStyle(Paint.Style.FILL);
        paint.setColor(color);
        c.drawRoundRect(tmp, rad, rad, paint);
    }

    /** Dark plate with a gold frame, matching the HUD sprite sheet. */
    private void drawPlate(Canvas c, float l, float t, float r, float b, int fillColor) {
        roundRect(c, l, t, r, b, 8f, 0xff0b0c10);
        roundRect(c, l + 1.5f, t + 1.5f, r - 1.5f, b - 1.5f, 7f, 0xffe9b61a);
        roundRect(c, l + 3.5f, t + 3.5f, r - 3.5f, b - 3.5f, 5f, 0xff7a5a0a);
        roundRect(c, l + 4.5f, t + 4.5f, r - 4.5f, b - 4.5f, 4f, fillColor);
    }

    private void textRaw(Canvas c, String text, float cx, float cy, float size, int color, float stroke) {
        paint.setTypeface(Typeface.create("sans-serif-black", Typeface.BOLD));
        paint.setTextAlign(Paint.Align.CENTER);
        paint.setTextSize(size);
        float y = cy + size * 0.36f;
        if (stroke > 0f) {
            paint.setStrokeWidth(stroke);
            paint.setStyle(Paint.Style.STROKE);
            paint.setColor(0xff111318);
            c.drawText(text, cx, y, paint);
        }
        paint.setStyle(Paint.Style.FILL);
        paint.setColor(color);
        c.drawText(text, cx, y, paint);
    }

    /** Text shrunk to fit maxW. */
    private void text(Canvas c, String s, float cx, float cy, float size, int color, float stroke, float maxW) {
        paint.setTypeface(Typeface.create("sans-serif-black", Typeface.BOLD));
        paint.setTextSize(size);
        float w = paint.measureText(s);
        if (w > maxW && w > 0f) size = size * maxW / w;
        textRaw(c, s, cx, cy, size, color, stroke);
    }

    private boolean pressedAt(RectF r) {
        return now() < pressUntilNanos && pressCenterX >= r.left && pressCenterX <= r.right
                && pressCenterY >= r.top && pressCenterY <= r.bottom;
    }

    private void addHit(RectF r, int id) {
        if (uiCount >= uiRects.length) return;
        uiRects[uiCount].set(r);
        uiIds[uiCount] = id;
        uiCount++;
    }

    private int uiAt(float x, float y) {
        for (int i = uiCount - 1; i >= 0; i--) if (uiRects[i].contains(x, y)) return uiIds[i];
        return -1;
    }

    /** style: 0 normal, 1 primary (green), 2 danger (red), 3 on (green), 4 off (grey). */
    private void drawButton(Canvas c, float l, float t, float r, float b, String label, int style, int id, float size) {
        RectF rect = new RectF(l, t, r, b);
        addHit(rect, id);
        boolean pr = pressedAt(rect);
        float off = pr ? 2f : 0f;
        int fillC;
        switch (style) {
            case 1: fillC = 0xff2f9a42; break;
            case 2: fillC = 0xff9a3030; break;
            case 3: fillC = 0xff2f9a42; break;
            case 4: fillC = 0xff4b505e; break;
            default: fillC = 0xff2b3040; break;
        }
        roundRect(c, l, t + 4f, r, b + 4f, 9f, 0x88000000);
        drawPlate(c, l, t + off, r, b + off, fillC);
        roundRect(c, l + 6f, t + off + 6f, r - 6f, t + off + 6f + (b - t) * 0.22f, 3f, 0x26ffffff);
        text(c, label, (l + r) / 2f, (t + b) / 2f + off, size, 0xffffffff, 4f, (r - l) - 20f);
    }

    private void drawChip(Canvas c, float l, float t, float r, float b, String label, int style, int id, float size) {
        RectF rect = new RectF(l, t, r, b);
        if (id >= 0) addHit(rect, id);
        boolean pr = id >= 0 && pressedAt(rect);
        int fillC;
        switch (style) {
            case 3: fillC = 0xff2f9a42; break;
            case 4: fillC = 0xff4b505e; break;
            case 5: fillC = 0xff1a1d27; break;
            default: fillC = 0xff353b4f; break;
        }
        roundRect(c, l, t, r, b, 6f, 0xff0b0c10);
        roundRect(c, l + 1.5f, t + 1.5f, r - 1.5f, b - 1.5f, 5f, pr ? 0xffffe27a : 0xffb98a10);
        roundRect(c, l + 3f, t + 3f, r - 3f, b - 3f, 4f, fillC);
        text(c, label, (l + r) / 2f, (t + b) / 2f, size, 0xffffffff, 3f, (r - l) - 8f);
    }

    private void drawMenuBackground(Canvas canvas, int dim) {
        float h = logicalHeight();
        fill(canvas, 0, 0, WORLD_W, h, 0xff12151f);
        if (menuBackground != null) {
            float bgW = h * menuBackground.getWidth() / Math.max(1f, menuBackground.getHeight());
            if (bgW < WORLD_W) bgW = WORLD_W;
            float left = (WORLD_W - bgW) * 0.5f;
            tmp.set(left, 0, left + bgW, h);
            paint.setAlpha(255); paint.setFilterBitmap(true);
            canvas.drawBitmap(menuBackground, null, tmp, paint);
            paint.setFilterBitmap(false);
        }
        fill(canvas, 0, 0, WORLD_W, h, dim);
    }

    // ================================================================================
    // Main draw loop
    // ================================================================================
    @Override protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        if (getWidth() <= 0 || getHeight() <= 0) return;
        float sc = scale();
        canvas.drawColor(0xff0b0d14);
        canvas.save();
        canvas.translate(offsetX(), 0f);
        canvas.scale(sc, sc);
        canvas.clipRect(0f, 0f, WORLD_W, logicalHeight());
        uiCount = 0;

        if (screen == SCREEN_MENU) {
            drawMenuScreen(canvas);
        } else if (screen == SCREEN_SETTINGS) {
            drawSettingsScreen(canvas);
        } else if (screen == SCREEN_GIFTS) {
            drawGiftsScreen(canvas);
        } else if (screen == SCREEN_TIKTOK) {
            drawTikTokScreen(canvas);
        } else if (screen == SCREEN_EVENTS) {
            drawEventsScreen(canvas);
        } else if (screen == SCREEN_LOOKS) {
            drawLooksScreen(canvas);
        } else if (screen == SCREEN_PICK) {
            drawPickScreen(canvas);
        } else {
            drawGame(canvas);
            if (screen == SCREEN_PAUSE) drawPauseScreen(canvas);
        }
        canvas.restore();

        if (screen == SCREEN_GAME) updatePhysics();
        postInvalidateOnAnimation();
    }

    private void drawGame(Canvas canvas) {
        applyLook();
        layoutControls();
        layoutGifts();
        if (lastFrameNanos == 0) {
            cameraY = clampFloat(playerFeet - boardViewportHeight() * PLAYER_SCREEN_RATIO,
                    minCamera(), maxCamera());
        }
        float top = areaTop();
        canvas.drawColor(SKY);
        if (arena != null) {
            tmp.set(0, top - cameraY, WORLD_W, top + BOARD_H - cameraY);
            drawBitmap(canvas, arena, tmp);
        }

        canvas.save();
        canvas.clipRect(0, top, WORLD_W, logicalHeight());
        if (shake > 0.01f) {
            canvas.translate((rnd.nextFloat() - 0.5f) * shake * 7f, (rnd.nextFloat() - 0.5f) * shake * 7f);
        }
        drawSideFill(canvas);
        drawGround(canvas);
        drawPlacedBlocks(canvas);
        drawTnt(canvas);
        drawPlacementTarget(canvas);
        drawPlayer(canvas);
        drawEffects(canvas);
        canvas.restore();

        drawHud(canvas);
        drawGiftRow(canvas);
        drawMinimap(canvas);
        drawHpPanel(canvas);
        drawFeed(canvas);
        if (cfg.showButtons) drawControls(canvas);
        if (toastUntil > gameClock) drawToast(canvas);
        if (countdownValue >= 0) drawRoundCountdown(canvas);
    }

    /** The reference arena image has raised ground outside the walls; hide it so the floor is consistent. */
    private void drawSideFill(Canvas canvas) {
        float y0 = worldToScreenY(FLOOR_Y - 90f), y1 = worldToScreenY(FLOOR_Y);
        int c = MAP_SKY[cfg.map];
        fill(canvas, 0, y0, 19f, y1, c);
        fill(canvas, 493f, y0, WORLD_W, y1, c);
    }

    /** Ground of the selected map: soil continues behind the on-screen buttons. */
    private void drawGround(Canvas canvas) {
        float fy = worldToScreenY(FLOOR_Y);
        float bottom = logicalHeight();
        if (fy >= bottom) return;
        int[] g = MAP_GROUND[cfg.map];
        for (int r = 0; ; r++) {
            float y = fy + r * CELL;
            if (y >= bottom) break;
            if (y + CELL < areaTop()) continue;
            int type = r == 0 ? g[0] : (r <= 4 ? g[1] : g[2]);
            Bitmap tex = blockTextures[type];
            for (int c = -1; c <= COLS + 1; c++) {
                float x = GRID_X + c * CELL;
                blit(canvas, tex, x, y, x + CELL, y + CELL, false);
            }
            if (r >= 1) {
                int a = Math.min(120, 14 + r * 14);
                fill(canvas, 0, y, WORLD_W, y + CELL, a << 24);
            }
            if (MAP_SHADE[cfg.map] != 0) fill(canvas, 0, y, WORLD_W, y + CELL, MAP_SHADE[cfg.map]);
        }
    }

    // ---- menu screens ---------------------------------------------------------------
    private String tikTokLabel() {
        return live.isRunning() ? "TIKTOK LIVE  [" + live.status + "]" : "TIKTOK LIVE";
    }

    private void drawMenuScreen(Canvas canvas) {
        drawMenuBackground(canvas, 0x80000000);
        float h = logicalHeight();
        float cx = WORLD_W / 2f;
        float titleY = h * 0.17f;
        textRaw(canvas, "BLOCK RUSH", cx, titleY, 50f, 0xffffd34a, 8f);
        textRaw(canvas, "MINECRAFT 2D  -  LIVE GAME", cx, titleY + 40f, 14f, 0xffffffff, 4f);

        float w = 330f, l = cx - w / 2f, r = cx + w / 2f;
        float y = h * 0.31f;
        drawButton(canvas, l, y, r, y + 66f, "MAIN", 1, B_PLAY, 30f);
        y += 66f + 14f;
        drawButton(canvas, l, y, r, y + 54f, tikTokLabel(), 0, B_TIKTOK, 19f);
        y += 54f + 10f;
        drawButton(canvas, l, y, r, y + 54f, "HADIAH  (" + cfg.activeGifts() + " aktif)", 0, B_GIFTS, 19f);
        y += 54f + 10f;
        drawButton(canvas, l, y, r, y + 54f, "MAP & KARAKTER", 0, B_LOOKS, 19f);
        y += 54f + 10f;
        drawButton(canvas, l, y, r, y + 54f, "PENGATURAN", 0, B_SETTINGS, 20f);

        float hy = h - 70f;
        textRaw(canvas, "KEYBOARD: A/D jalan  W/Spasi lompat  E blok  F blok depan  X gali  1-8 hadiah",
                cx, hy, 10.5f, 0xffffffff, 3.5f);
        textRaw(canvas, "MOUSE: klik kiri pasang blok  klik kanan gali  |  SENTUH: ketuk kotak untuk pasang",
                cx, hy + 17f, 10.5f, 0xffffffff, 3.5f);
        textRaw(canvas, "Esc = jeda   |   O pengaturan  T tiktok  G hadiah  L map/karakter",
                cx, hy + 34f, 10.5f, 0xffffffff, 3.5f);
    }

    private void drawPauseScreen(Canvas canvas) {
        float h = logicalHeight();
        fill(canvas, 0, 0, WORLD_W, h, 0xc0000000);
        float cx = WORLD_W / 2f;
        float pw = 340f, ph = 456f;
        float pl = cx - pw / 2f, pt = Math.max(8f, (h - ph) / 2f);
        drawPlate(canvas, pl, pt, pl + pw, pt + ph, 0xee161922);
        textRaw(canvas, "JEDA", cx, pt + 34f, 32f, 0xffffd34a, 6f);
        float l = pl + 26f, r = pl + pw - 26f;
        float y = pt + 66f;
        drawButton(canvas, l, y, r, y + 50f, "LANJUT", 1, B_RESUME, 22f);
        y += 50f + 9f;
        drawButton(canvas, l, y, r, y + 42f, tikTokLabel(), 0, B_TIKTOK, 16f);
        y += 42f + 9f;
        drawButton(canvas, l, y, r, y + 42f, "HADIAH", 0, B_GIFTS, 17f);
        y += 42f + 9f;
        drawButton(canvas, l, y, r, y + 42f, "MAP & KARAKTER", 0, B_LOOKS, 17f);
        y += 42f + 9f;
        drawButton(canvas, l, y, r, y + 42f, "PENGATURAN", 0, B_SETTINGS, 17f);
        y += 42f + 9f;
        drawButton(canvas, l, y, r, y + 42f, "ULANG", 0, B_RETRY, 17f);
        y += 42f + 9f;
        drawButton(canvas, l, y, r, y + 42f, "MENU UTAMA", 2, B_MENU, 17f);
    }

    private void drawTitle(Canvas canvas, String title, float y) {
        textRaw(canvas, title, WORLD_W / 2f, y, 32f, 0xffffd34a, 6f);
    }

    private void drawSettingsScreen(Canvas canvas) {
        drawMenuBackground(canvas, 0xb0000000);
        float h = logicalHeight();
        float cx = WORLD_W / 2f;
        drawTitle(canvas, "PENGATURAN", Math.max(34f, h * 0.09f));
        float w = 440f, l = cx - w / 2f, r = cx + w / 2f;
        float y = Math.max(34f, h * 0.09f) + 36f;
        float rowH = 46f, gap = 8f;

        drawSettingRow(canvas, l, r, y, rowH, "SUARA", cfg.sound ? "ON" : "OFF", cfg.sound, B_SOUND);
        y += rowH + gap;
        drawSettingRow(canvas, l, r, y, rowH, "TOMBOL DI LAYAR", cfg.showButtons ? "TAMPIL" : "SEMBUNYI",
                cfg.showButtons, B_BUTTONS);
        y += rowH + gap;
        drawSettingRow(canvas, l, r, y, rowH, "BLOK TAK TERBATAS", cfg.unlimited ? "ON" : "OFF", cfg.unlimited, B_UNLIMITED);
        y += rowH + gap;
        drawSettingRow(canvas, l, r, y, rowH, "KECEPATAN PASANG", GameSettings.SPEED_NAMES[cfg.speed], true, B_SPEED);
        y += rowH + gap;
        drawSettingRow(canvas, l, r, y, rowH, "NOTIF TIKTOK DI LAYAR", cfg.feed ? "TAMPIL" : "SEMBUNYI", cfg.feed, B_FEED);
        y += rowH + gap;
        // HUD offset: moves the whole top HUD down (camera cut-outs / notches).
        RectF hudRow = new RectF(l, y, r, y + rowH);
        drawPlate(canvas, l, y, r, y + rowH, 0xff1b1f2b);
        text(canvas, "HUD TURUN", l + 18f + 110f, y + rowH / 2f, 17f, 0xffffffff, 4f, 220f);
        drawChip(canvas, r - 150f, y + 8f, r - 118f, y + rowH - 8f, "-", 0, B_HUD_MINUS, 18f);
        drawChip(canvas, r - 118f, y + 8f, r - 50f, y + rowH - 8f, String.valueOf(cfg.hudOffset), 5, -1, 15f);
        drawChip(canvas, r - 50f, y + 8f, r - 12f, y + rowH - 8f, "+", 0, B_HUD_PLUS, 18f);
        y += rowH + gap + 4f;
        float bw = (w - 16f) / 3f;
        drawButton(canvas, l, y, l + bw, y + 44f, "TIKTOK", 0, B_TIKTOK, 15f);
        drawButton(canvas, l + bw + 8f, y, l + 2 * bw + 8f, y + 44f, "HADIAH", 0, B_GIFTS, 15f);
        drawButton(canvas, l + 2 * bw + 16f, y, r, y + 44f, "MAP/KARAKTER", 0, B_LOOKS, 13f);
        y += 44f + 14f;
        textRaw(canvas, "Matikan tombol layar jika bermain dengan keyboard + mouse.", cx, y, 10.5f, 0xffdddddd, 3f);
        y += 24f;
        drawButton(canvas, l, y, cx - 6f, y + 46f, "RESET", 2, B_RESET, 17f);
        drawButton(canvas, cx + 6f, y, r, y + 46f, "KEMBALI", 1, B_BACK, 17f);
    }

    private void drawSettingRow(Canvas c, float l, float r, float y, float h, String label, String value,
                                boolean on, int id) {
        RectF rect = new RectF(l, y, r, y + h);
        addHit(rect, id);
        drawPlate(c, l, y, r, y + h, pressedAt(rect) ? 0xff2d3345 : 0xff1b1f2b);
        text(c, label, l + 18f + 110f, y + h / 2f, 17f, 0xffffffff, 4f, 220f);
        drawChip(c, r - 128f, y + 8f, r - 12f, y + h - 8f, value, on ? 3 : 4, -1, 15f);
    }

    /** Row whose value chip is wide (text fields). */
    private void drawValueRow(Canvas c, float l, float r, float y, float h, String label, String value, int id) {
        RectF rect = new RectF(l, y, r, y + h);
        addHit(rect, id);
        drawPlate(c, l, y, r, y + h, pressedAt(rect) ? 0xff2d3345 : 0xff1b1f2b);
        text(c, label, l + 14f + 48f, y + h / 2f, 15f, 0xffffffff, 4f, 100f);
        drawChip(c, l + 112f, y + 7f, r - 10f, y + h - 7f, value, 5, -1, 15f);
    }

    private int giftPages() { return (GameSettings.GIFTS + GIFT_PAGE - 1) / GIFT_PAGE; }

    private void drawGiftsScreen(Canvas canvas) {
        drawMenuBackground(canvas, 0xc0000000);
        float h = logicalHeight();
        float cx = WORLD_W / 2f;
        giftPage = clamp(giftPage, 0, giftPages() - 1);
        drawTitle(canvas, "HADIAH LIVE", 32f);
        textRaw(canvas, "Aktif " + cfg.activeGifts() + "  -  tampil di atas " + cfg.shownGifts() + "/"
                + GameSettings.SHOWN_MAX + "  -  halaman " + (giftPage + 1) + "/" + giftPages(), cx, 60f, 11f, 0xffffffff, 3f);
        float top = 74f, bottomReserve = 112f;
        float rowH = Math.max(66f, Math.min(96f, (h - top - bottomReserve) / GIFT_PAGE - 4f));
        float y = top;
        for (int k = 0; k < GIFT_PAGE; k++) {
            int i = giftPage * GIFT_PAGE + k;
            if (i >= GameSettings.GIFTS) break;
            drawGiftSettingRow(canvas, i, y, rowH);
            y += rowH + 4f;
        }
        y = Math.max(y + 4f, Math.min(h - bottomReserve + 6f, y + 4f));
        drawButton(canvas, 14f, y, cx - 6f, y + 42f, "< SEBELUMNYA", 0, B_PAGE_PREV, 15f);
        drawButton(canvas, cx + 6f, y, WORLD_W - 14f, y + 42f, "BERIKUTNYA >", 0, B_PAGE_NEXT, 15f);
        y += 42f + 8f;
        drawButton(canvas, 14f, y, cx - 6f, y + 42f, "RESET HADIAH", 2, B_RESET_GIFTS, 15f);
        drawButton(canvas, cx + 6f, y, WORLD_W - 14f, y + 42f, "KEMBALI", 1, B_BACK, 15f);
    }

    /** Two-line row: [icon] / [ON][TAMPIL][gift name]  and  [effect][-][n][+][tile text]. */
    private void drawGiftSettingRow(Canvas c, int i, float y, float h) {
        GameSettings.Gift g = cfg.gifts[i];
        float l = 8f, r = WORLD_W - 8f, pad = 4f;
        drawPlate(c, l, y, r, y + h, g.on ? 0xff1b2230 : 0xff15171e);
        float ih = h - 14f, iw = Math.min(ih * 162f / 129f, 86f);
        ih = iw * 129f / 162f;
        float ix = l + 9f, iy = y + (h - ih) / 2f;
        RectF ir = new RectF(ix, iy, ix + iw, iy + ih);
        addHit(ir, B_G_ICON + i);
        roundRect(c, ir.left - 1.5f, ir.top - 1.5f, ir.right + 1.5f, ir.bottom + 1.5f, 4f, 0xff0b0c10);
        blit(c, giftIcons[g.icon], ir.left, ir.top, ir.right, ir.bottom, true);
        text(c, "#" + (i + 1), ir.left + 12f, ir.top + 6f, 10f, 0xffffffff, 3f, 22f);
        float x0 = ix + iw + 8f;
        float ch = (h - 18f) / 2f;
        float y1 = y + 7f, y2 = y + h - 7f - ch;
        float x = x0;
        drawChip(c, x, y1, x + 46f, y1 + ch, g.on ? "ON" : "OFF", g.on ? 3 : 4, B_G_ON + i, 13f);
        x += 46f + pad;
        drawChip(c, x, y1, x + 72f, y1 + ch, g.show ? "TAMPIL" : "SEMBUNYI", g.show ? 3 : 4, B_G_SHOW + i, 11f);
        x += 72f + pad;
        String nm = g.name == null || g.name.trim().length() == 0 ? "(pilih gift...)" : g.name.trim();
        drawChip(c, x, y1, r - 8f, y1 + ch, nm, g.name == null || g.name.trim().length() == 0 ? 5 : 0, B_G_NAME + i, 13f);
        x = x0;
        drawChip(c, x, y2, x + 96f, y2 + ch, GameSettings.EFFECT_NAMES[g.effect], 0, B_G_EFFECT + i, 12f);
        x += 96f + pad;
        drawChip(c, x, y2, x + 26f, y2 + ch, "-", 0, B_G_MINUS + i, 17f);
        x += 26f;
        drawChip(c, x, y2, x + 44f, y2 + ch, String.valueOf(g.amount), 5, B_G_AMOUNT + i, 14f);
        x += 44f;
        drawChip(c, x, y2, x + 26f, y2 + ch, "+", 0, B_G_PLUS + i, 17f);
        x += 26f + pad;
        boolean custom = g.label != null && g.label.trim().length() > 0;
        drawChip(c, x, y2, r - 8f, y2 + ch, custom ? g.label.trim() : g.autoLabel() + " (auto)",
                custom ? 0 : 5, B_G_LABEL + i, 12f);
    }

    // ---- gift picker (live names) ------------------------------------------------------
    private String[] pickList() {
        java.util.ArrayList<String> out = new java.util.ArrayList<>();
        if (cfg.recent != null) {
            for (String s : cfg.recent.split("\\|")) {
                if (s.trim().length() == 0) continue;
                boolean dup = false;
                for (String o : out) if (GameSettings.norm(o).equals(GameSettings.norm(s))) dup = true;
                if (!dup) out.add(s.trim());
            }
        }
        for (String s : GiftCatalog.NAMES) {
            boolean dup = false;
            for (String o : out) if (GameSettings.norm(o).equals(GameSettings.norm(s))) dup = true;
            if (!dup) out.add(s);
        }
        return out.toArray(new String[0]);
    }

    private int catalogIndex(String name) {
        String n = GameSettings.norm(name);
        for (int i = 0; i < GiftCatalog.size(); i++) if (GameSettings.norm(GiftCatalog.NAMES[i]).equals(n)) return i;
        return -1;
    }

    private boolean isRecent(String name) {
        if (cfg.recent == null) return false;
        String n = GameSettings.norm(name);
        for (String s : cfg.recent.split("\\|")) if (GameSettings.norm(s).equals(n) && n.length() > 0) return true;
        return false;
    }

    private void drawPickScreen(Canvas canvas) {
        drawMenuBackground(canvas, 0xc8000000);
        float h = logicalHeight(), cx = WORLD_W / 2f;
        String[] list = pickList();
        int pages = Math.max(1, (list.length + PICK_PAGE - 1) / PICK_PAGE);
        pickPage = clamp(pickPage, 0, pages - 1);
        GameSettings.Gift g = cfg.gifts[clamp(pickSlot, 0, GameSettings.GIFTS - 1)];
        drawTitle(canvas, "PILIH GIFT", 32f);
        textRaw(canvas, "Slot #" + (pickSlot + 1) + "  -  hijau = gift yang pernah masuk saat live  -  hal "
                + (pickPage + 1) + "/" + pages, cx, 60f, 10.5f, 0xffffffff, 3f);
        float top = 76f, bw = (WORLD_W - 14f * 2f - 8f) / 2f;
        float bh = Math.max(34f, Math.min(44f, (h - top - 130f) / (PICK_PAGE / 2) - 6f));
        for (int k = 0; k < PICK_PAGE; k++) {
            int idx = pickPage * PICK_PAGE + k;
            if (idx >= list.length) break;
            float x = 14f + (k % 2) * (bw + 8f), y = top + (k / 2) * (bh + 6f);
            String name = list[idx];
            int ci = catalogIndex(name);
            String label = name + (ci >= 0 ? "  (" + GiftCatalog.COINS[ci] + ")" : "");
            boolean cur = GameSettings.norm(name).equals(GameSettings.norm(g.name));
            drawChip(canvas, x, y, x + bw, y + bh, label, cur ? 3 : (isRecent(name) ? 3 : 0), B_PICK_ITEM + k, 13f);
            if (cur) fill(canvas, x + 4f, y + bh - 6f, x + bw - 4f, y + bh - 3f, 0xffffe14a);
        }
        float y = top + (PICK_PAGE / 2) * (bh + 6f) + 6f;
        drawButton(canvas, 14f, y, cx - 6f, y + 40f, "< SEBELUMNYA", 0, B_PAGE_PREV, 14f);
        drawButton(canvas, cx + 6f, y, WORLD_W - 14f, y + 40f, "BERIKUTNYA >", 0, B_PAGE_NEXT, 14f);
        y += 40f + 8f;
        float tw = (WORLD_W - 28f - 16f) / 3f;
        drawButton(canvas, 14f, y, 14f + tw, y + 42f, "KETIK NAMA", 0, B_PICK_MANUAL, 14f);
        drawButton(canvas, 22f + tw, y, 22f + 2 * tw, y + 42f, "KOSONGKAN", 2, B_PICK_CLEAR, 14f);
        drawButton(canvas, 30f + 2 * tw, y, WORLD_W - 14f, y + 42f, "KEMBALI", 1, B_BACK, 14f);
    }

    // ---- TikTok connection ---------------------------------------------------------------
    private void drawTikTokScreen(Canvas canvas) {
        drawMenuBackground(canvas, 0xc0000000);
        float h = logicalHeight(), cx = WORLD_W / 2f;
        drawTitle(canvas, "TIKTOK LIVE", 34f);
        float w = 460f, l = cx - w / 2f, r = cx + w / 2f;
        float y = 62f, rowH = 44f, gap = 7f;
        drawValueRow(canvas, l, r, y, rowH, "HOST", cfg.host.length() == 0 ? "(isi host)" : cfg.host, B_T_HOST);
        y += rowH + gap;
        drawValueRow(canvas, l, r, y, rowH, "PORT", String.valueOf(cfg.port), B_T_PORT);
        y += rowH + gap;
        drawValueRow(canvas, l, r, y, rowH, "USERNAME", cfg.user.length() == 0 ? "(isi @username TikTok)" : "@" + cfg.user, B_T_USER);
        y += rowH + gap;
        drawSettingRow(canvas, l, r, y, rowH, "HUBUNG OTOMATIS", cfg.autoConnect ? "ON" : "OFF", cfg.autoConnect, B_T_AUTO);
        y += rowH + gap + 2f;
        boolean on = live.isRunning();
        drawButton(canvas, l, y, r, y + 58f, on ? "BERHENTI" : "MULAI TERHUBUNG", on ? 2 : 1, B_T_START, 22f);
        y += 58f + 10f;

        String st = on ? live.status : "MATI";
        int col = "LIVE".equals(st) ? 0xff5be06a : ("TERHUBUNG".equals(st) || "MENGHUBUNGKAN".equals(st)) ? 0xffffd34a
                : "MATI".equals(st) ? 0xffbbbbbb : 0xffff6a5a;
        drawPlate(canvas, l, y, r, y + 54f, 0xff12151f);
        fill(canvas, l + 14f, y + 14f, l + 24f, y + 24f, col);
        textRaw(canvas, "STATUS: " + st + (on && live.viewers > 0 ? "   penonton " + live.viewers : ""),
                cx + 6f, y + 19f, 13f, col, 3f);
        String msg = on ? live.message : "Belum terhubung";
        text(canvas, msg == null ? "" : msg, cx, y + 40f, 11f, 0xffdddddd, 3f, w - 24f);
        y += 54f + 10f;

        float bw = (w - 16f) / 3f;
        drawButton(canvas, l, y, l + bw, y + 46f, "EVENT >", 0, B_T_EVENTS, 15f);
        drawButton(canvas, l + bw + 8f, y, l + 2 * bw + 8f, y + 46f, "HADIAH >", 0, B_T_GIFTS, 15f);
        drawButton(canvas, l + 2 * bw + 16f, y, r, y + 46f, "TES EVENT", 0, B_T_TEST, 15f);
        y += 46f + 12f;
        String[] help = {
                "Game ini membaca bridge Node.js milikmu (TIKTOMC) lewat WebSocket.",
                "Di bridge: MINECRAFT_OUTBOUND_ENABLED=false  dan  WS_PORT=25601.",
                "Satu HP: jalankan Node di Termux, host 127.0.0.1. HP + PC: isi IP PC.",
                "Isi username, tekan MULAI. Gift/follow/like penonton jadi aksi di game."};
        for (int i = 0; i < help.length; i++) textRaw(canvas, help[i], cx, y + i * 16f, 10.5f, 0xffffffff, 3f);
        y += help.length * 16f + 10f;
        drawButton(canvas, l, y, r, y + 46f, "KEMBALI", 1, B_BACK, 17f);
    }

    // ---- event rules ----------------------------------------------------------------------
    private void drawEventsScreen(Canvas canvas) {
        drawMenuBackground(canvas, 0xc4000000);
        float h = logicalHeight(), cx = WORLD_W / 2f;
        drawTitle(canvas, "EVENT TIKTOK", 32f);
        textRaw(canvas, "Pilih apa yang terjadi di game saat event masuk  (gift diatur di menu HADIAH)",
                cx, 58f, 10.5f, 0xffffffff, 3f);
        float l = 8f, r = WORLD_W - 8f;
        float y = 74f, rowH = 54f;
        for (int i = 0; i < GameSettings.EVENTS; i++) {
            GameSettings.Rule ru = cfg.rules[i];
            drawPlate(canvas, l, y, r, y + rowH, ru.on ? 0xff1b2230 : 0xff15171e);
            text(canvas, GameSettings.EVENT_NAMES[i], l + 58f, y + rowH / 2f, 13f, 0xffffffff, 4f, 100f);
            float ch = rowH - 20f, cy0 = y + 10f, x = l + 112f;
            drawChip(canvas, x, cy0, x + 40f, cy0 + ch, ru.on ? "ON" : "OFF", ru.on ? 3 : 4, B_E_ON + i, 12f);
            x += 44f;
            drawChip(canvas, x, cy0, x + 58f, cy0 + ch, ru.notify ? "NOTIF" : "TANPA", ru.notify ? 3 : 4, B_E_NOTIF + i, 11f);
            x += 62f;
            drawChip(canvas, x, cy0, x + 84f, cy0 + ch, GameSettings.EFFECT_NAMES[ru.effect], 0, B_E_EFFECT + i, 11f);
            x += 88f;
            drawChip(canvas, x, cy0, x + 24f, cy0 + ch, "-", 0, B_E_MINUS + i, 16f);
            x += 24f;
            drawChip(canvas, x, cy0, x + 40f, cy0 + ch, String.valueOf(ru.amount), 5, B_E_AMOUNT + i, 14f);
            x += 40f;
            drawChip(canvas, x, cy0, x + 24f, cy0 + ch, "+", 0, B_E_PLUS + i, 16f);
            x += 28f;
            drawChip(canvas, x, cy0, r - 6f, cy0 + ch, "TES", 0, B_E_TEST + i, 11f);
            y += rowH + 4f;
        }
        // LIKE rule fires once per N likes.
        drawPlate(canvas, l, y, r, y + 46f, 0xff1b1f2b);
        text(canvas, "LIKE: aksi tiap", l + 100f, y + 23f, 13f, 0xffffffff, 4f, 170f);
        float ch = 26f, cy0 = y + 10f, x = l + 200f;
        drawChip(canvas, x, cy0, x + 28f, cy0 + ch, "-", 0, B_LIKE_MINUS, 16f);
        x += 28f;
        drawChip(canvas, x, cy0, x + 56f, cy0 + ch, String.valueOf(cfg.likeEvery), 5, B_LIKE_AMT, 14f);
        x += 56f;
        drawChip(canvas, x, cy0, x + 28f, cy0 + ch, "+", 0, B_LIKE_PLUS, 16f);
        text(canvas, "like", x + 52f, y + 23f, 13f, 0xffffffff, 4f, 40f);
        y += 46f + 10f;
        drawButton(canvas, 14f, y, cx - 6f, y + 44f, "RESET EVENT", 2, B_E_RESET, 15f);
        drawButton(canvas, cx + 6f, y, WORLD_W - 14f, y + 44f, "KEMBALI", 1, B_BACK, 15f);
    }

    // ---- map + character ------------------------------------------------------------------
    private void drawLooksScreen(Canvas canvas) {
        applyLook();
        drawMenuBackground(canvas, 0xc0000000);
        float h = logicalHeight(), cx = WORLD_W / 2f;
        drawTitle(canvas, "MAP & KARAKTER", 34f);
        // Map card
        float y = 64f;
        textRaw(canvas, "MAP AREA", cx, y, 15f, 0xffffffff, 4f);
        y += 14f;
        float pw = 300f, ph = 150f, pl = cx - pw / 2f;
        drawPlate(canvas, pl - 6f, y, pl + pw + 6f, y + ph + 12f, 0xff10131b);
        if (arena != null) {
            int aw = arena.getWidth(), ah = arena.getHeight();
            int sh = Math.min(ah, (int) (aw * ph / pw));
            int sy = Math.max(0, Math.min(ah - sh, (int) (ah * 0.56f)));
            tmp.set(pl, y + 6f, pl + pw, y + 6f + ph);
            paint.setAlpha(255); paint.setFilterBitmap(true);
            canvas.drawBitmap(arena, new Rect(0, sy, aw, sy + sh), tmp, paint);
            paint.setFilterBitmap(false);
        }
        drawChip(canvas, pl - 56f, y + ph / 2f - 20f, pl - 14f, y + ph / 2f + 22f, "<", 0, B_MAP_PREV, 22f);
        drawChip(canvas, pl + pw + 14f, y + ph / 2f - 20f, pl + pw + 56f, y + ph / 2f + 22f, ">", 0, B_MAP_NEXT, 22f);
        y += ph + 12f + 20f;
        textRaw(canvas, GameSettings.MAP_NAMES[cfg.map] + "  (" + (cfg.map + 1) + "/" + GameSettings.MAPS + ")",
                cx, y, 18f, 0xffffd34a, 5f);

        // Character card
        y += 36f;
        textRaw(canvas, "KARAKTER", cx, y, 15f, 0xffffffff, 4f);
        y += 14f;
        float cw = 150f, chh = 170f, cl = cx - cw / 2f;
        drawPlate(canvas, cl - 6f, y, cl + cw + 6f, y + chh + 12f, 0xff10131b);
        Bitmap pv = previewOf(cfg.character);
        if (pv != null) {
            float sc2 = Math.min((cw - 10f) / pv.getWidth(), (chh - 6f) / pv.getHeight());
            float bw2 = pv.getWidth() * sc2, bh2 = pv.getHeight() * sc2;
            blit(canvas, pv, cx - bw2 / 2f, y + 6f + (chh - bh2), cx + bw2 / 2f, y + 6f + chh, false);
        }
        drawChip(canvas, cl - 56f, y + chh / 2f - 20f, cl - 14f, y + chh / 2f + 22f, "<", 0, B_CHAR_PREV, 22f);
        drawChip(canvas, cl + cw + 14f, y + chh / 2f - 20f, cl + cw + 56f, y + chh / 2f + 22f, ">", 0, B_CHAR_NEXT, 22f);
        y += chh + 12f + 20f;
        textRaw(canvas, GameSettings.CHAR_NAMES[cfg.character] + "  (" + (cfg.character + 1) + "/" + GameSettings.CHARS + ")",
                cx, y, 18f, 0xffffd34a, 5f);
        y += 22f;
        drawButton(canvas, cx - 150f, y, cx + 150f, y + 48f, "KEMBALI", 1, B_BACK, 18f);
    }

    // ---- world objects ------------------------------------------------------------
    private void drawPlacedBlocks(Canvas canvas) {
        long t = now();
        for (int row = BUILD_LIMIT_ROW; row < ROWS; row++) {
            float base = worldToScreenY(GRID_Y + row * CELL);
            for (int col = 0; col < COLS; col++) {
                int type = blocks[row][col];
                if (type < 0) continue;
                float y = base + blockDrop[row * COLS + col];
                if (y > logicalHeight() || y + CELL < areaTop()) continue;
                float x = GRID_X + col * CELL;
                blit(canvas, blockTextures[type], x, y, x + CELL, y + CELL, false);
                long placed = blockPlacedAt[row][col];
                if (placed > 0L) {
                    float age = (t - placed) / 1_000_000_000f;
                    if (age >= 0f && age < 0.6f) {
                        int a = (int) (200 * (1f - age / 0.6f));
                        fill(canvas, x, y, x + CELL, y + CELL, (a << 24) | 0x00ffffff);
                    }
                }
            }
        }
    }

    private void drawPlacementTarget(Canvas canvas) {
        int col, row;
        boolean valid;
        if (breakMode) {
            if (mouseActive && hoverCol >= 0) { col = hoverCol; row = hoverRow; }
            else { col = targetCol; row = targetRow; }
            valid = col >= 0 && row >= 0 && blocks[row][col] >= 0;
        } else if (mouseActive && hoverCol >= 0 && hoverRow >= 0) {
            col = hoverCol; row = hoverRow;
            valid = blocks[row][col] < 0;
        } else {
            col = playerColumn(); row = feetRow();
            valid = row >= BUILD_LIMIT_ROW && blocks[row][col] < 0;
        }
        if (col < 0 || col >= COLS || row < BUILD_LIMIT_ROW || row >= ROWS) return;
        float x = GRID_X + col * CELL;
        float y = worldToScreenY(GRID_Y + row * CELL);
        RectF cell = new RectF(x + 1.5f, y + 1.5f, x + CELL - 1.5f, y + CELL - 1.5f);
        if (!breakMode && valid && blockTextures[materialForRow(row)] != null) {
            paint.setAlpha(90);
            canvas.drawBitmap(blockTextures[materialForRow(row)], null, cell, paint);
            paint.setAlpha(255);
        }
        if (placementFrame != null) drawBitmap(canvas, placementFrame, cell);
        paint.setStyle(Paint.Style.STROKE);
        paint.setStrokeWidth(3f);
        paint.setColor(breakMode ? 0xffff5555 : (valid ? 0xff42ef69 : 0xffffa030));
        canvas.drawRect(cell, paint);
        paint.setStyle(Paint.Style.FILL);
    }

    /** TNT sprite: red block, lit fuse, then flashes white right before the explosion. */
    private void drawTnt(Canvas canvas) {
        for (int i = 0; i < MAX_TNT; i++) {
            if (!tntOn[i]) continue;
            int frame = 0;
            float f = tntFuse[i];
            float pulse = 0f;
            if (f >= 0f) {
                float elapsed = TNT_FUSE - f;
                frame = elapsed < 0.35f ? 1 : 2;
                if (f < 0.55f) {
                    frame = 3 + Math.min(3, (int) ((0.55f - f) / 0.55f * 4f));
                    pulse = (0.55f - f) * 6f;
                }
            }
            float w = CELL * 1.04f + pulse, h = w * 200f / 150f;
            float cx = GRID_X + tntCol[i] * CELL + CELL / 2f;
            float bottom = worldToScreenY(tntY[i] + CELL) + 1.5f + pulse * 0.5f;
            blit(canvas, tntFrames[frame], cx - w / 2f, bottom - h, cx + w / 2f, bottom, false);
        }
    }

    private void drawPlayer(Canvas canvas) {
        boolean spr = isSprint();
        int action = !grounded ? 2 : ((leftHeld || rightHeld) ? (spr ? 1 : 0) : 0);
        int frame = action == 2 ? jumpFrame : (action == 1 ? runFrame : walkFrame);
        Bitmap sprite = characterFrames[action][frame];
        if (sprite == null) return;
        float unit = PLAYER_H / (233f * 0.93f);
        float w = sprite.getWidth() * unit, h = sprite.getHeight() * unit;
        float feet = worldToScreenY(playerFeet) + characterBottom[action][frame] * h;
        tmp.set(playerX - w / 2, feet - h, playerX + w / 2, feet);
        long t = now();
        boolean placing = t < playerPlaceUntilNanos;
        if (placing) {
            float k = (playerPlaceUntilNanos - t) / 220000000f;
            float pulse = (float) Math.sin((1f - k) * Math.PI);
            tmp.offset(facingRight ? pulse * 4f : -pulse * 4f, 0f);
        }
        canvas.save();
        if (!facingRight) canvas.scale(-1, 1, playerX, 0);
        drawBitmap(canvas, sprite, tmp);
        canvas.restore();
        if (shieldOn()) {
            paint.setStyle(Paint.Style.STROKE);
            paint.setStrokeWidth(2.5f);
            paint.setColor(0xaa5ad8ff);
            canvas.drawCircle(playerX, worldToScreenY(playerFeet) - PLAYER_H * 0.5f, PLAYER_H * 0.62f, paint);
            paint.setStyle(Paint.Style.FILL);
        }
    }

    private void drawEffects(Canvas canvas) {
        drawTornadoes(canvas);
        drawRobots(canvas);
        drawMeteors(canvas);
        drawBolts(canvas);
        // Explosion sprite animation (spark -> fireball -> smoke).
        for (int i = 0; i < MAX_FX; i++) {
            if (fxT[i] < 0f) continue;
            int frame = Math.min(7, (int) (fxT[i] / FX_TIME * 8f));
            float s = fxS[i], cx = fxX[i], cy = worldToScreenY(fxY[i]);
            blit(canvas, boomFrames[frame], cx - s / 2f, cy - s / 2f, cx + s / 2f, cy + s / 2f, false);
        }
        for (int i = 0; i < MAX_PARTICLES; i++) {
            if (plife[i] <= 0f) continue;
            float a = Math.min(1f, plife[i] * 2.5f);
            int c = ((int) (255 * a) << 24) | (pcol[i] & 0x00ffffff);
            float sy = worldToScreenY(py[i]);
            fill(canvas, px[i] - 2.5f, sy - 2.5f, px[i] + 2.5f, sy + 2.5f, c);
        }
        if (flash > 0.01f) fill(canvas, 0, areaTop(), WORLD_W, controlTop(), ((int) (flash * 150f) << 24) | 0x00ffffff);
    }

    private void drawTornadoes(Canvas canvas) {
        for (int i = 0; i < MAX_TORNADO; i++) {
            if (!twOn[i]) continue;
            float sy = worldToScreenY(twY[i]);
            float fade = Math.min(1f, twLife[i] * 1.2f);
            for (int k = 0; k < 7; k++) {
                float w = 16f + k * 13f;
                float wob = (float) Math.sin(gameClock * 11f + k * 0.9f) * (3f + k * 1.6f);
                float y = sy - 8f - k * 19f;
                int col = ((int) (215 * fade) << 24) | ((k & 1) == 0 ? 0x00d8e4f0 : 0x00a4b8cc);
                roundRect(canvas, twX[i] - w / 2f + wob, y - 9f, twX[i] + w / 2f + wob, y + 9f, 9f, col);
            }
            fill(canvas, twX[i] - 3f, sy - 4f, twX[i] + 3f, sy, 0x66ffffff);
        }
    }

    private void drawRobots(Canvas canvas) {
        for (int i = 0; i < MAX_ROBOT; i++) {
            if (!rbOn[i]) continue;
            float cx = rbX[i], feet = worldToScreenY(rbY[i]) - (float) Math.abs(Math.sin(gameClock * 7f + i)) * 2f;
            fill(canvas, cx - 9f, feet - 7f, cx - 3f, feet, 0xff3a3f4c);
            fill(canvas, cx + 3f, feet - 7f, cx + 9f, feet, 0xff3a3f4c);
            fill(canvas, cx - 13f, feet - 25f, cx + 13f, feet - 7f, 0xff111318);
            fill(canvas, cx - 12f, feet - 24f, cx + 12f, feet - 8f, 0xffb9c1d0);
            fill(canvas, cx - 12f, feet - 24f, cx + 12f, feet - 20f, 0xffe4e9f2);
            fill(canvas, cx - 9f, feet - 38f, cx + 9f, feet - 25f, 0xff111318);
            fill(canvas, cx - 8f, feet - 37f, cx + 8f, feet - 26f, 0xffd5dbe7);
            fill(canvas, cx - 5f, feet - 34f, cx - 1.5f, feet - 29f, 0xff38e0ff);
            fill(canvas, cx + 1.5f, feet - 34f, cx + 5f, feet - 29f, 0xff38e0ff);
            fill(canvas, cx - 1f, feet - 44f, cx + 1f, feet - 38f, 0xff111318);
            boolean blink = ((int) (gameClock * 4f) & 1) == 0;
            fill(canvas, cx - 3f, feet - 48f, cx + 3f, feet - 43f, blink ? 0xffff4a4a : 0xff8a2a2a);
            fill(canvas, cx - 17f, feet - 23f, cx - 13f, feet - 12f, 0xff8b93a3);
            fill(canvas, cx + 13f, feet - 23f, cx + 17f, feet - 12f, 0xff8b93a3);
        }
    }

    private void drawMeteors(Canvas canvas) {
        for (int i = 0; i < MAX_METEOR; i++) {
            if (!mtOn[i]) continue;
            float sy = worldToScreenY(mtY[i]);
            float len = (float) Math.sqrt(mtVx[i] * mtVx[i] + mtVy[i] * mtVy[i]);
            float ux = mtVx[i] / Math.max(1f, len), uy = mtVy[i] / Math.max(1f, len);
            paint.setStyle(Paint.Style.FILL);
            for (int k = 6; k >= 1; k--) {
                float r = 17f - k * 2f;
                int a = 160 - k * 22;
                paint.setColor((a << 24) | 0x00ff7a1e);
                canvas.drawCircle(mtX[i] - ux * k * 12f, sy - uy * k * 12f, r, paint);
            }
            paint.setColor(0xff7a3414);
            canvas.drawCircle(mtX[i], sy, 18f, paint);
            paint.setColor(0xffff7a1e);
            canvas.drawCircle(mtX[i], sy, 15f, paint);
            paint.setColor(0xffffd25a);
            canvas.drawCircle(mtX[i] - 2f, sy - 2f, 8f, paint);
        }
    }

    private void drawBolts(Canvas canvas) {
        for (int i = 0; i < MAX_BOLT; i++) {
            if (blT[i] < 0f) continue;
            float cx = GRID_X + blCol[i] * CELL + CELL / 2f;
            float y0 = areaTop() - 20f, y1 = worldToScreenY(blY[i]);
            int seed = (int) (blT[i] * 45f) + blCol[i] * 7;
            float prevX = cx + 6f;
            float a = 1f - blT[i] / BOLT_TIME;
            int glow = ((int) (110 * a) << 24) | 0x00ffe55a;
            int core = ((int) (255 * a) << 24) | 0x00fffbe0;
            int n = 0;
            for (float y = y0; y < y1; y += 24f, n++) {
                float nx = cx + (((seed + n * 53) % 29) - 14f) * (y + 24f >= y1 ? 0.15f : 0.5f);
                float h = Math.min(24f, y1 - y);
                fill(canvas, Math.min(prevX, nx) - 6f, y, Math.max(prevX, nx) + 6f, y + h, glow);
                fill(canvas, Math.min(prevX, nx) - 1.5f, y, Math.max(prevX, nx) + 1.5f, y + h, core);
                prevX = nx;
            }
            paint.setStyle(Paint.Style.FILL);
            paint.setColor(glow);
            canvas.drawCircle(cx, y1, 22f * (0.6f + a), paint);
        }
    }

    // ---- HUD ----------------------------------------------------------------------
    private void drawHud(Canvas canvas) {
        float top = areaTop(), off = hudOff();
        // Solid panel behind the HUD so the arena never shows through the sprites.
        fill(canvas, 0, 0, WORLD_W, top, 0xff12141c);
        fill(canvas, 0, 0, WORLD_W, 3f, 0xff1d212e);
        fill(canvas, 0, top - 3f, WORLD_W, top, 0xffe9b61a);
        fill(canvas, 0, top - 5f, WORLD_W, top - 3f, 0xff0b0c10);

        canvas.save();
        canvas.translate(0f, off);
        // Row 1: area blocks placed | trophies | area %, pause. (No frames around the numbers.)
        blit(canvas, hudCube, 12f, 5f, 12f + 38f * 131f / 151f, 43f, true);
        drawAtlasTextFit(canvas, blockCount() + "/" + (COLS * ROWS), 102f, 26f, 18f, 92f);

        float tw = 196f, th = tw * 162f / 791f, tl = (WORLD_W - tw) / 2f - 14f, tt = 5f;
        blit(canvas, hudTrophy, tl, tt, tl + tw, tt + th, true);
        drawAtlasTextFit(canvas, winCount + "/10", tl + tw * 0.5f, tt + th * 0.5f, 15f, tw * 0.34f);

        drawAtlasTextFit(canvas, areaPercent() + "%", 410f, 26f, 18f, 70f);

        // Row 2: segmented progress bar (15 compartments) = filled area.
        float bx = 7f, by = 50f, bw = 498f, bh = bw * 151f / 2016f;
        blit(canvas, hudBar, bx, by, bx + bw, by + bh, true);
        float k = bw / 2016f;
        float fillSegs = areaPercent() / 100f * (BAR_SEG.length / 2);
        for (int i = 0; i < BAR_SEG.length / 2; i++) {
            float part = Math.max(0f, Math.min(1f, fillSegs - i));
            if (part <= 0f) continue;
            float l = bx + BAR_SEG[i * 2] * k;
            float r = l + (BAR_SEG[i * 2 + 1] - BAR_SEG[i * 2]) * k * part;
            float t = by + 38f * k, b = by + 100f * k;
            fill(canvas, l, t, r, b, 0xff2fd24a);
            fill(canvas, l, t, r, t + (b - t) * 0.35f, 0xff7cf08a);
        }
        canvas.restore();
        drawPauseControl(canvas);

        // TikTok connection status line.
        if (live.isRunning()) {
            String st = live.status;
            int col = "LIVE".equals(st) ? 0xff5be06a : ("TERPUTUS".equals(st) || "ERROR".equals(st) || "OFFLINE".equals(st))
                    ? 0xffff6a5a : 0xffffd34a;
            fill(canvas, 9f, top - 17f, 15f, top - 11f, col);
            String msg = "TIKTOK " + st + ("LIVE".equals(st) ? "  " + live.message : "");
            paint.setTypeface(Typeface.create("sans-serif-black", Typeface.BOLD));
            paint.setTextSize(10f);
            float w = paint.measureText(msg);
            textRaw(canvas, msg, 20f + w / 2f, top - 14f, 10f, col, 3f);
        }
    }

    private void drawPauseControl(Canvas canvas) {
        boolean pr = pressedAt(pauseRect);
        drawPlate(canvas, pauseRect.left, pauseRect.top + 2f, pauseRect.right, pauseRect.bottom - 2f,
                pr ? 0xff3a4058 : 0xff191c26);
        float cx = pauseRect.centerX(), cy = pauseRect.centerY();
        fill(canvas, cx - 7f, cy - 8f, cx - 2.5f, cy + 8f, 0xffffffff);
        fill(canvas, cx + 2.5f, cy - 8f, cx + 7f, cy + 8f, 0xffffffff);
    }

    private void drawGiftRow(Canvas canvas) {
        for (int k = 0; k < giftCount; k++) {
            GameSettings.Gift g = cfg.gifts[giftIdx[k]];
            RectF r = giftRects[k];
            boolean active = (g.effect == GameSettings.E_TURBO && turboOn())
                    || (g.effect == GameSettings.E_SHIELD && shieldOn());
            boolean flash = giftFlash[giftIdx[k]] > 0f;
            drawPlate(canvas, r.left, r.top, r.right, r.bottom, 0xff1a1d28);
            float iw = r.width() - 10f, ih = iw * 129f / 162f;
            blit(canvas, giftIcons[g.icon], r.left + 5f, r.top + 5f, r.left + 5f + iw, r.top + 5f + ih, true);
            text(canvas, g.shownLabel(), r.centerX(), r.bottom - 11f, 12f, 0xffffffff, 4f, r.width() - 6f);
            if (flash || active) {
                paint.setStyle(Paint.Style.STROKE);
                paint.setStrokeWidth(2.5f);
                paint.setColor(active ? 0xff5ad8ff : 0xffffe14a);
                canvas.drawRoundRect(r, 8f, 8f, paint);
                paint.setStyle(Paint.Style.FILL);
            }
        }
    }

    private void drawMinimap(Canvas canvas) {
        float x0 = 495.5f, x1 = 508f;
        float top = areaTop() + 6f, bottom = controlTop() - 8f, h = bottom - top;
        if (h < 40f) return;
        float gridH = ROWS * CELL;
        fill(canvas, x0 - 1.5f, top - 3f, x1 + 1.5f, bottom + 1.5f, 0xff0a0d18);
        fill(canvas, x0, top, x1, bottom, 0xff1c2340);
        fill(canvas, x0, top - 2f, x1, top + 1f, 0xffffc928);
        float rowH = h / ROWS;
        for (int r = 0; r < ROWS; r++) {
            int type = -1;
            for (int c = 0; c < COLS && type < 0; c++) type = blocks[r][c];
            if (type < 0) continue;
            float y = top + r * rowH;
            fill(canvas, x0 + 1f, y + 0.4f, x1 - 1f, y + rowH, blockColor[type]);
        }
        float vTop = top + clampFloat((cameraY - GRID_Y) / gridH, 0f, 1f) * h;
        float vBot = top + clampFloat((cameraY + boardViewportHeight() - GRID_Y) / gridH, 0f, 1f) * h;
        paint.setStyle(Paint.Style.STROKE);
        paint.setStrokeWidth(1.2f);
        paint.setColor(0xccffffff);
        canvas.drawRect(x0 - 1f, vTop, x1 + 1f, Math.max(vTop + 4f, vBot), paint);
        float py2 = top + clampFloat((playerFeet - PLAYER_H * 0.5f - GRID_Y) / gridH, 0f, 1f) * h;
        paint.setStyle(Paint.Style.FILL);
        paint.setColor(0xffff9a3c);
        canvas.drawCircle(x0 - 3.5f, py2, 2.4f, paint);
    }

    private void drawHpPanel(Canvas canvas) {
        float w = 176f, h = w * 134f / 641f;
        float x = GRID_X + COLS * CELL - w - 4f, y = controlTop() - h - 8f;
        float k = w / 641f;
        blit(canvas, hudHp, x, y, x + w, y + h, true);
        float ix0 = x + 130f * k, ix1 = x + 596f * k, iy0 = y + 46f * k, iy1 = y + 92f * k;
        float f = clampFloat(hp / 100f, 0f, 1f);
        if (f > 0f) {
            int c1 = shieldOn() ? 0xff4ad0ff : 0xffe02a2a, c2 = shieldOn() ? 0xff9ae8ff : 0xffff6a6a;
            fill(canvas, ix0, iy0, ix0 + (ix1 - ix0) * f, iy1, c1);
            fill(canvas, ix0, iy0, ix0 + (ix1 - ix0) * f, iy0 + (iy1 - iy0) * 0.35f, c2);
        }
    }

    private void drawFeed(Canvas canvas) {
        if (!cfg.feed) return;
        float baseY = controlTop() - 22f;
        for (int i = 0; i < FEED_LINES; i++) {
            if (feedText[i] == null) continue;
            float left = feedUntil[i] - gameClock;
            if (left <= 0f) { feedText[i] = null; continue; }
            float y = baseY - i * 17f;
            int a = (int) (255 * Math.min(1f, left * 1.5f));
            paint.setTypeface(Typeface.create("sans-serif-black", Typeface.BOLD));
            float size = 11.5f;
            paint.setTextSize(size);
            float w = paint.measureText(feedText[i]);
            if (w > 270f) { size = size * 270f / w; w = 270f; }
            fill(canvas, 4f, y - 9f, 12f + w, y + 8f, (a / 3 << 24));
            textRaw(canvas, feedText[i], 8f + w / 2f, y, size, (a << 24) | (feedColor[i] & 0x00ffffff), 3f);
        }
    }

    private void drawToast(Canvas canvas) {
        float k = Math.min(1f, (toastUntil - gameClock) * 3f);
        if (k <= 0f) return;
        text(canvas, toastText, WORLD_W / 2f, areaTop() + 52f, 22f, 0xffffffff, 6f, 440f);
    }

    private void drawRoundCountdown(Canvas canvas) {
        float cx = WORLD_W * 0.5f;
        float cy = areaTop() + boardViewportHeight() * 0.46f;
        roundRect(canvas, cx - 88f, cy - 70f, cx + 88f, cy + 70f, 18f, 0xb9000000);
        paint.setStyle(Paint.Style.STROKE);
        paint.setStrokeWidth(4f);
        paint.setColor(0xffffc928);
        tmp.set(cx - 88f, cy - 70f, cx + 88f, cy + 70f);
        canvas.drawRoundRect(tmp, 18f, 18f, paint);
        paint.setStyle(Paint.Style.FILL);
        drawAtlasText(canvas, String.valueOf(countdownValue), cx, cy, 76f);
    }

    private Rect fontSource(char ch) {
        switch (ch) {
            case '0': return new Rect(254, 529, 369, 649);
            case '1': return new Rect(395, 529, 484, 649);
            case '2': return new Rect(499, 529, 613, 649);
            case '3': return new Rect(627, 529, 739, 649);
            case '4': return new Rect(751, 529, 872, 649);
            case '5': return new Rect(890, 529, 1005, 649);
            case '6': return new Rect(1022, 529, 1139, 649);
            case '7': return new Rect(1155, 529, 1266, 649);
            case '8': return new Rect(1285, 529, 1399, 649);
            case '9': return new Rect(1416, 529, 1533, 649);
            case '/': return new Rect(1432, 655, 1520, 765);
            case '%': return new Rect(643, 763, 758, 873);
            default: return null;
        }
    }

    private float atlasWidth(String text, float targetHeight) {
        float total = 0f;
        for (int i = 0; i < text.length(); i++) {
            Rect r = fontSource(text.charAt(i));
            if (r != null) total += targetHeight * (r.width() / (float) r.height()) + 2f;
        }
        return total > 0f ? total - 2f : 0f;
    }

    private void drawAtlasTextFit(Canvas canvas, String text, float cx, float cy, float h, float maxW) {
        float w = atlasWidth(text, h);
        if (w > maxW && w > 0f) h = h * maxW / w;
        drawAtlasText(canvas, text, cx, cy, h);
    }

    private void drawAtlasText(Canvas canvas, String text, float centerX, float centerY, float targetHeight) {
        if (fontAtlas == null || text == null || text.length() == 0) return;
        float x = centerX - atlasWidth(text, targetHeight) / 2f;
        for (int i = 0; i < text.length(); i++) {
            Rect src = fontSource(text.charAt(i));
            if (src == null) continue;
            float w = targetHeight * src.width() / (float) src.height();
            tmp.set(x, centerY - targetHeight / 2f, x + w, centerY + targetHeight / 2f);
            paint.setAlpha(255);
            paint.setFilterBitmap(false);
            canvas.drawBitmap(fontAtlas, src, tmp, paint);
            x += w + 2f;
        }
    }

    private void drawControls(Canvas canvas) {
        Bitmap[] images = {leftImage, rightImage, runImage, pickImage, blockImage, jumpImage};
        final int[] roles = {ROLE_LEFT, ROLE_RIGHT, ROLE_RUN, ROLE_PICK, ROLE_BUILD, ROLE_JUMP};
        for (int i = 0; i < 6; i++) {
            boolean held = false;
            for (int p = 0; p < touches.size(); p++) {
                if (touches.valueAt(p).role == roles[i]) { held = true; break; }
            }
            if (i == 0 && keyLeft) held = true;
            if (i == 1 && keyRight) held = true;
            if (i == 4 && keyBuild) held = true;
            if (i == 5 && keyJump) held = true;
            boolean active = (i == 2 && isSprint()) || (i == 3 && breakMode);
            if (active) {
                paint.setStyle(Paint.Style.FILL);
                paint.setColor(i == 3 ? 0x5537cfff : 0x55ffc928);
                canvas.drawRoundRect(icon[i], 18, 18, paint);
            }
            tmp.set(icon[i]);
            if (held) {
                float cx = tmp.centerX(), cy = tmp.centerY();
                tmp.inset(tmp.width() * 0.055f, tmp.height() * 0.055f);
                tmp.offset(cx - tmp.centerX(), cy - tmp.centerY());
            }
            drawBitmap(canvas, images[i], tmp);
            if (i == 4 && !cfg.unlimited) {
                drawAtlasTextFit(canvas, String.valueOf(inventory), icon[i].centerX(), icon[i].top - 7f, 13f, 44f);
            }
        }
    }

    // ================================================================================
    // Game rules
    // ================================================================================
    private void startGame() {
        resetGame();
        screen = SCREEN_GAME;
    }

    private void resetGame() {
        for (int r = 0; r < ROWS; r++) {
            for (int c = 0; c < COLS; c++) { blocks[r][c] = -1; blockPlacedAt[r][c] = 0L; }
        }
        playerX = GRID_X + (COLS * CELL) / 2f;
        playerFeet = FLOOR_Y;
        velocityY = 0f;
        cameraY = 0f; cameraTarget = 0f;
        grounded = true; wasGrounded = true;
        facingRight = true;
        targetCol = -1; targetRow = -1;
        countdownValue = -1; countdownNextNanos = 0L; winCount = 0;
        inventory = MAX_INVENTORY; hp = 100f; likeAcc = 0;
        turboUntil = -1f; shieldUntil = -1f; toastUntil = -1f;
        rainLeft = 0; shake = 0f; gameClock = 0f;
        buildCooldown = 0f; gridCooldown = 0f;
        breakMode = false;
        clearEffects();
        releaseAllInput();
        lastFrameNanos = 0L;
    }

    private void clearEffects() {
        for (int i = 0; i < MAX_TNT; i++) tntOn[i] = false;
        for (int i = 0; i < MAX_PARTICLES; i++) plife[i] = 0f;
        for (int i = 0; i < MAX_FX; i++) fxT[i] = -1f;
        for (int i = 0; i < MAX_TORNADO; i++) twOn[i] = false;
        for (int i = 0; i < MAX_ROBOT; i++) rbOn[i] = false;
        for (int i = 0; i < MAX_METEOR; i++) mtOn[i] = false;
        for (int i = 0; i < MAX_BOLT; i++) blT[i] = -1f;
        for (int i = 0; i < pend.length; i++) pend[i] = 0;
        for (int i = 0; i < blockDrop.length; i++) { blockDrop[i] = 0f; blockDropV[i] = 0f; }
        for (int i = 0; i < FEED_LINES; i++) feedText[i] = null;
        flash = 0f;
        while (live.poll() != null) { }
        for (int i = 0; i < GameSettings.GIFTS; i++) giftFlash[i] = 0f;
    }

    private void resetBoardAfterWin() {
        for (int r = 0; r < ROWS; r++) for (int c = 0; c < COLS; c++) {
            blocks[r][c] = -1;
            blockPlacedAt[r][c] = 0L;
        }
        playerX = GRID_X + (COLS * CELL) / 2f;
        playerFeet = FLOOR_Y;
        velocityY = 0f;
        grounded = true;
        cameraY = 0f; cameraTarget = 0f;
        facingRight = true;
        targetCol = -1; targetRow = -1;
        hp = 100f;
        clearEffects();
        lastFrameNanos = now();
    }

    private void toast(String text) {
        toastText = text;
        toastUntil = gameClock + 1.6f;
    }

    private boolean withinRange(int col, int row) {
        float playerRow = (playerFeet - GRID_Y) / CELL;
        float dx = col - playerColumn(), dy = row - playerRow;
        return Math.sqrt(dx * dx + dy * dy) <= 10.0;
    }

    private boolean cellOverlapsPlayer(int col, int row) {
        float l = GRID_X + col * CELL, t = GRID_Y + row * CELL;
        return playerX + PLAYER_HALF_W > l + 1f && playerX - PLAYER_HALF_W < l + CELL - 1f
                && t + CELL > playerFeet - PLAYER_H + 1f && t < playerFeet - 1f;
    }

    private boolean canSpend() { return cfg.unlimited || inventory > 0; }

    private void spend() {
        if (!cfg.unlimited && inventory > 0) inventory--;
    }

    private void afterPlace(int col, int row) {
        blockPlacedAt[row][col] = now();
        spawnBurst(GRID_X + col * CELL + CELL / 2f, GRID_Y + row * CELL + CELL / 2f,
                blockColor[blocks[row][col]], 3, 90f);
        if (gameClock - lastPlaceSound > 0.06f) {
            lastPlaceSound = gameClock;
            play(sLand, 0.45f, 1.5f);
        }
        playerPlaceUntilNanos = now() + 200000000L;
        if (blockCount() >= COLS * ROWS && countdownValue < 0) {
            countdownValue = 15;
            countdownNextNanos = now() + 620000000L;
        }
    }

    /** Row where a block put at (col,row) comes to rest: it falls until the cell below is solid or the floor. */
    private int landingRow(int col, int row) {
        int r = row;
        while (r + 1 < ROWS && blocks[r + 1][col] < 0) r++;
        return r;
    }

    /** True when a block falling from row to land would pass through the player. */
    private boolean fallHitsPlayer(int col, int row, int land) {
        for (int r = row + 1; r <= land; r++) if (cellOverlapsPlayer(col, r)) return true;
        return false;
    }

    /** Puts a block into the world; it drops from (col,row) to its resting row. Returns that row. */
    private int putBlock(int col, int row) {
        int land = landingRow(col, row);
        blocks[land][col] = pickType(land);
        blockDrop[land * COLS + col] = -(land - row) * CELL;
        blockDropV[land * COLS + col] = 0f;
        return land;
    }

    /**
     * Minecraft pillar placement: a block appears in the cell under the player's feet and the
     * player is moved straight on top of it. In mid-air with nothing below, the block drops down
     * to the ground (or onto the nearest block) and the player simply falls onto it.
     */
    private boolean placeUnderPlayer() {
        if (screen != SCREEN_GAME || countdownValue >= 0) return false;
        int col = playerColumn();
        int row = feetRow();
        if (row < BUILD_LIMIT_ROW) { toast("SUDAH PALING ATAS"); return false; }
        if (row >= ROWS || blocks[row][col] >= 0) return false;
        if (!canSpend()) { toast("BLOK HABIS"); return false; }
        int land = landingRow(col, row);
        if (land != row) {
            if (fallHitsPlayer(col, row, land)) return false;
            putBlock(col, row);
            spend();
            afterPlace(col, land);
            return true;
        }
        float newFeet = GRID_Y + row * CELL;
        if (blockedAt(playerX, newFeet - PLAYER_H, newFeet)) { toast("ATAP TERHALANG"); return false; }
        blocks[row][col] = pickType(row);
        spend();
        playerFeet = newFeet;
        velocityY = 0f;
        grounded = true;
        afterPlace(col, row);
        return true;
    }

    /** Places a block into an empty cell (tap / mouse click). The cell under the player lifts the player. */
    private boolean placeAt(int col, int row) {
        if (screen != SCREEN_GAME || countdownValue >= 0) return false;
        if (col < 0 || col >= COLS || row < BUILD_LIMIT_ROW || row >= ROWS) return false;
        if (blocks[row][col] >= 0) return false;
        if (cellOverlapsPlayer(col, row)) {
            if (col == playerColumn() && row == feetRow()) return placeUnderPlayer();
            toast("ADA PLAYER");
            return false;
        }
        if (!withinRange(col, row)) { toast("TERLALU JAUH"); return false; }
        if (!canSpend()) { toast("BLOK HABIS"); return false; }
        int land = landingRow(col, row);
        if (fallHitsPlayer(col, row, land)) { toast("ADA PLAYER"); return false; }
        putBlock(col, row);
        spend();
        afterPlace(col, land);
        return true;
    }

    /** Places a block in front of the player at feet level (or on top when that cell is taken). */
    private boolean placeFront() {
        int col = playerColumn() + (facingRight ? 1 : -1);
        if (col < 0 || col >= COLS) return false;
        int row = feetRow();
        if (row >= 0 && row < ROWS && blocks[row][col] >= 0) row--;
        return placeAt(col, row);
    }

    private boolean breakBlockAt(int col, int row) {
        if (col < 0 || col >= COLS || row < BUILD_LIMIT_ROW || row >= ROWS) return false;
        if (blocks[row][col] < 0 || !withinRange(col, row)) return false;
        spawnBurst(GRID_X + col * CELL + CELL / 2f, GRID_Y + row * CELL + CELL / 2f,
                blockColor[blocks[row][col]], 7, 150f);
        blocks[row][col] = -1;
        blockPlacedAt[row][col] = 0L;
        blockDrop[row * COLS + col] = 0f;
        if (inventory < MAX_INVENTORY) inventory++;
        play(sStep, 0.8f, 1.6f);
        // Blocks above never fall. Only the player can lose its footing.
        if (grounded && !hasSurfaceAtFeet(playerX, playerFeet)) {
            grounded = false;
            velocityY = 0f;
        }
        return true;
    }

    private void mineFront() {
        int col = playerColumn() + (facingRight ? 1 : -1);
        if (col < 0 || col >= COLS) return;
        int feetRow = (int) Math.floor((playerFeet - 2f - GRID_Y) / CELL);
        int[] order = {feetRow, feetRow + 1, feetRow - 1};
        for (int r : order) {
            if (breakBlockAt(col, r)) { targetCol = col; targetRow = r; return; }
        }
    }

    private void mineDown() {
        int col = playerColumn();
        int row = (int) Math.floor((playerFeet + 2f - GRID_Y) / CELL);
        if (breakBlockAt(col, row)) { targetCol = col; targetRow = row; }
    }

    // ---- TNT / gifts / events -------------------------------------------------------
    private boolean spawnTnt(int col, float fuse) {
        if (col < 0 || col >= COLS) return false;
        int slot = -1;
        for (int i = 0; i < MAX_TNT; i++) if (!tntOn[i]) { slot = i; break; }
        if (slot < 0) return false;
        float surface = GRID_Y + topBlockRow(col) * CELL;
        float y = Math.max(GRID_Y - CELL, cameraY - CELL);
        y = Math.min(y, surface - CELL);
        tntOn[slot] = true;
        tntCol[slot] = col;
        tntY[slot] = y;
        tntVy[slot] = 0f;
        tntFuse[slot] = fuse;
        return true;
    }

    /** slot = index into the list of gifts that are currently shown. */
    private void triggerShownGift(int slot) {
        layoutGifts();
        if (slot < 0 || slot >= giftCount) return;
        triggerGift(giftIdx[slot]);
    }

    /** Manual tap / key on a gift tile: same effect a viewer's gift would have. */
    private void triggerGift(int i) {
        if (screen != SCREEN_GAME || countdownValue >= 0 || i < 0 || i >= GameSettings.GIFTS) return;
        GameSettings.Gift g = cfg.gifts[i];
        giftFlash[i] = 0.4f;
        applyEffect(g.effect, g.amount);
        toast(g.toast());
    }

    /** Runs an effect now (instant ones) or queues it (spawned ones appear one after another). */
    private void applyEffect(int effect, int amount) {
        effect = Math.max(0, Math.min(GameSettings.EFFECTS - 1, effect));
        amount = Math.max(1, Math.min(amount, GameSettings.EFFECT_MAX[effect] * 3));
        switch (effect) {
            case GameSettings.E_BLOCK: inventory = Math.min(MAX_INVENTORY, inventory + amount); break;
            case GameSettings.E_RAIN: rainLeft = Math.min(120, rainLeft + amount); rainClock = 0f; break;
            case GameSettings.E_TURBO: turboUntil = Math.max(turboUntil, gameClock) + amount; break;
            case GameSettings.E_HEAL: hp = Math.min(100f, hp + amount); break;
            case GameSettings.E_SHIELD: shieldUntil = Math.max(shieldUntil, gameClock) + amount; break;
            default: pend[effect] = Math.min(100, pend[effect] + amount); break;
        }
    }

    private void updatePending(float dt) {
        pendClock -= dt;
        if (pendClock > 0f) return;
        pendClock = 0.2f;
        if (pend[GameSettings.E_TNT] > 0 && spawnTnt(rnd.nextInt(COLS), -1f)) pend[GameSettings.E_TNT]--;
        if (pend[GameSettings.E_LIGHTNING] > 0) { strikeLightning(rnd.nextInt(COLS)); pend[GameSettings.E_LIGHTNING]--; }
        if (pend[GameSettings.E_TORNADO] > 0 && spawnTornado()) pend[GameSettings.E_TORNADO]--;
        if (pend[GameSettings.E_ROBOT] > 0 && spawnRobot()) pend[GameSettings.E_ROBOT]--;
        if (pend[GameSettings.E_METEOR] > 0 && spawnMeteor(rnd.nextInt(COLS))) pend[GameSettings.E_METEOR]--;
    }

    private float surfaceY(int col) {
        return GRID_Y + topBlockRow(clamp(col, 0, COLS - 1)) * CELL;
    }

    private void spawnFx(float cx, float cy, float size) {
        for (int k = 0; k < MAX_FX; k++) {
            if (fxT[k] < 0f) { fxT[k] = 0f; fxX[k] = cx; fxY[k] = cy; fxS[k] = size; return; }
        }
    }

    private void hurtPlayer(float amount) {
        if (shieldOn()) return;
        hp -= amount;
        if (hp <= 0f) respawnPlayer();
    }

    // -- lightning
    private void strikeLightning(int col) {
        col = clamp(col, 0, COLS - 1);
        int top = topBlockRow(col);
        float y = top < ROWS ? GRID_Y + top * CELL : FLOOR_Y;
        for (int k = 0; k < MAX_BOLT; k++) {
            if (blT[k] < 0f) { blT[k] = 0f; blCol[k] = col; blY[k] = y; break; }
        }
        float cx = GRID_X + col * CELL + CELL / 2f;
        for (int k = 0; k < 2; k++) {
            int row = top + k;
            if (row >= ROWS || blocks[row][col] < 0) break;
            spawnBurst(cx, GRID_Y + row * CELL + CELL / 2f, blockColor[blocks[row][col]], 6, 200f);
            blocks[row][col] = -1;
            blockPlacedAt[row][col] = 0L;
            blockDrop[row * COLS + col] = 0f;
        }
        spawnBurst(cx, y, 0xfffff08a, 12, 260f);
        flash = 0.5f;
        shake = Math.max(shake, 0.7f);
        play(sLand, 1f, 1.8f);
        if (Math.abs(playerX - cx) < CELL * 0.8f && playerFeet <= y + CELL * 2f) hurtPlayer(18f);
        if (grounded && !hasSurfaceAtFeet(playerX, playerFeet)) grounded = false;
    }

    // -- tornado: wanders across the arena and eats the top block of every column it passes
    private boolean spawnTornado() {
        for (int i = 0; i < MAX_TORNADO; i++) {
            if (twOn[i]) continue;
            boolean fromLeft = rnd.nextBoolean();
            twOn[i] = true;
            twDir[i] = fromLeft ? 1 : -1;
            twX[i] = fromLeft ? GRID_X + CELL * 0.5f : GRID_X + COLS * CELL - CELL * 0.5f;
            twLife[i] = TORNADO_LIFE;
            twHit[i] = 0.3f;
            twY[i] = surfaceY((int) ((twX[i] - GRID_X) / CELL));
            return true;
        }
        return false;
    }

    private void updateTornado(float dt) {
        for (int i = 0; i < MAX_TORNADO; i++) {
            if (!twOn[i]) continue;
            twLife[i] -= dt;
            if (twLife[i] <= 0f) { twOn[i] = false; continue; }
            twX[i] += twDir[i] * 95f * dt;
            float lo = GRID_X + CELL * 0.4f, hi = GRID_X + COLS * CELL - CELL * 0.4f;
            if (twX[i] < lo) { twX[i] = lo; twDir[i] = 1; }
            if (twX[i] > hi) { twX[i] = hi; twDir[i] = -1; }
            int col = clamp((int) ((twX[i] - GRID_X) / CELL), 0, COLS - 1);
            float target = surfaceY(col);
            twY[i] += (target - twY[i]) * Math.min(1f, dt * 6f);
            twHit[i] -= dt;
            if (twHit[i] <= 0f) {
                twHit[i] = 0.4f;
                int row = topBlockRow(col);
                if (row < ROWS && blocks[row][col] >= 0) {
                    spawnBurst(GRID_X + col * CELL + CELL / 2f, GRID_Y + row * CELL + CELL / 2f,
                            blockColor[blocks[row][col]], 6, 170f);
                    blocks[row][col] = -1;
                    blockPlacedAt[row][col] = 0L;
                    blockDrop[row * COLS + col] = 0f;
                    if (grounded && !hasSurfaceAtFeet(playerX, playerFeet)) grounded = false;
                }
            }
            if (Math.abs(playerX - twX[i]) < CELL * 0.5f && Math.abs(playerFeet - twY[i]) < CELL * 1.2f
                    && !shieldOn()) {
                velocityY = -430f; grounded = false;
            }
        }
    }

    // -- helper robot: wanders on top of the blocks and keeps building pillars
    private boolean spawnRobot() {
        for (int i = 0; i < MAX_ROBOT; i++) {
            if (rbOn[i]) continue;
            rbOn[i] = true;
            rbCol[i] = rnd.nextInt(COLS);
            rbDir[i] = rnd.nextBoolean() ? 1 : -1;
            rbLife[i] = ROBOT_LIFE;
            rbAct[i] = 0.4f;
            rbX[i] = GRID_X + rbCol[i] * CELL + CELL / 2f;
            rbY[i] = surfaceY(rbCol[i]) - CELL * 2f;
            return true;
        }
        return false;
    }

    private void updateRobots(float dt) {
        for (int i = 0; i < MAX_ROBOT; i++) {
            if (!rbOn[i]) continue;
            rbLife[i] -= dt;
            if (rbLife[i] <= 0f) {
                spawnBurst(rbX[i], rbY[i] - 20f, 0xffb9c1d0, 8, 160f);
                rbOn[i] = false;
                continue;
            }
            rbX[i] += (GRID_X + rbCol[i] * CELL + CELL / 2f - rbX[i]) * Math.min(1f, dt * 8f);
            float target = surfaceY(rbCol[i]);
            if (rbY[i] < target) rbY[i] = Math.min(target, rbY[i] + 700f * dt);
            else rbY[i] += (target - rbY[i]) * Math.min(1f, dt * 12f);
            rbAct[i] -= dt;
            if (rbAct[i] > 0f) continue;
            rbAct[i] = 0.42f;
            int col = rbCol[i];
            int row = topBlockRow(col) - 1;
            if (rnd.nextInt(100) < 68 && row >= BUILD_LIMIT_ROW && !cellOverlapsPlayer(col, row)) {
                blocks[row][col] = pickType(row);
                blockPlacedAt[row][col] = now();
                spawnBurst(GRID_X + col * CELL + CELL / 2f, GRID_Y + row * CELL + CELL / 2f,
                        blockColor[blocks[row][col]], 3, 90f);
                play(sLand, 0.3f, 1.7f);
                if (blockCount() >= COLS * ROWS && countdownValue < 0) {
                    countdownValue = 15;
                    countdownNextNanos = now() + 620000000L;
                }
            } else {
                int next = col + rbDir[i];
                if (next < 0 || next >= COLS) { rbDir[i] = -rbDir[i]; next = col + rbDir[i]; }
                rbCol[i] = clamp(next, 0, COLS - 1);
            }
        }
    }

    // -- meteor
    private boolean spawnMeteor(int col) {
        for (int i = 0; i < MAX_METEOR; i++) {
            if (mtOn[i]) continue;
            col = clamp(col, 0, COLS - 1);
            float tx = GRID_X + col * CELL + CELL / 2f;
            float surface = surfaceY(col);
            float sy = Math.min(cameraY - 60f, surface - 420f);
            float sx = clampFloat(tx + (rnd.nextBoolean() ? -1f : 1f) * (60f + rnd.nextInt(110)),
                    GRID_X - 20f, GRID_X + COLS * CELL + 20f);
            float vy = 640f;
            float t = Math.max(0.3f, (surface - sy) / vy);
            mtOn[i] = true;
            mtX[i] = sx; mtY[i] = sy;
            mtVx[i] = (tx - sx) / t;
            mtVy[i] = vy;
            return true;
        }
        return false;
    }

    private void updateMeteors(float dt) {
        for (int i = 0; i < MAX_METEOR; i++) {
            if (!mtOn[i]) continue;
            mtX[i] += mtVx[i] * dt;
            mtY[i] += mtVy[i] * dt;
            if (rnd.nextInt(3) == 0) spawnBurst(mtX[i], mtY[i], 0xffff9a1e, 1, 60f);
            int col = clamp((int) ((mtX[i] - GRID_X) / CELL), 0, COLS - 1);
            float surface = surfaceY(col);
            if (mtY[i] + 12f >= surface) {
                mtOn[i] = false;
                int row = Math.min(ROWS - 1, topBlockRow(col));
                blastAt(col, row, GRID_X + col * CELL + CELL / 2f, surface, 2.7f, CELL * 6.6f);
            }
        }
    }

    private void updateBolts(float dt) {
        for (int i = 0; i < MAX_BOLT; i++) {
            if (blT[i] < 0f) continue;
            blT[i] += dt;
            if (blT[i] > BOLT_TIME) blT[i] = -1f;
        }
        flash = Math.max(0f, flash - dt * 2.4f);
    }

    private void updateDrops(float dt) {
        for (int idx = 0; idx < blockDrop.length; idx++) {
            if (blockDrop[idx] >= 0f) continue;
            blockDropV[idx] = Math.min(1500f, blockDropV[idx] + 2800f * dt);
            blockDrop[idx] += blockDropV[idx] * dt;
            if (blockDrop[idx] >= 0f) {
                blockDrop[idx] = 0f;
                blockDropV[idx] = 0f;
                int r = idx / COLS, c = idx % COLS;
                if (blocks[r][c] >= 0) {
                    spawnBurst(GRID_X + c * CELL + CELL / 2f, GRID_Y + r * CELL + CELL, blockColor[blocks[r][c]], 3, 80f);
                    play(sLand, 0.35f, 1.3f);
                }
            }
        }
    }

    // -- TNT explosion (also used by meteors)
    private void explode(int i) {
        int col = tntCol[i];
        int row = Math.round((tntY[i] - GRID_Y) / CELL);
        float cx = GRID_X + col * CELL + CELL / 2f, cy = tntY[i] + CELL / 2f;
        tntOn[i] = false;
        blastAt(col, row, cx, cy, 2.24f, CELL * 5.4f);
    }

    private void blastAt(int col, int row, float cx, float cy, float radius, float fxSize) {
        float r2 = radius * radius + 0.1f;
        int reach = (int) Math.ceil(radius);
        for (int dr = -reach; dr <= reach; dr++) {
            for (int dc = -reach; dc <= reach; dc++) {
                if (dr * dr + dc * dc > r2) continue;
                int r = row + dr, c = col + dc;
                if (r < BUILD_LIMIT_ROW || r >= ROWS || c < 0 || c >= COLS || blocks[r][c] < 0) continue;
                spawnBurst(GRID_X + c * CELL + CELL / 2f, GRID_Y + r * CELL + CELL / 2f,
                        blockColor[blocks[r][c]], 4, 260f);
                blocks[r][c] = -1;
                blockPlacedAt[r][c] = 0L;
                blockDrop[r * COLS + c] = 0f;
            }
        }
        for (int j = 0; j < MAX_TNT; j++) {   // chain reaction
            if (!tntOn[j]) continue;
            float dx = GRID_X + tntCol[j] * CELL + CELL / 2f - cx, dy = tntY[j] + CELL / 2f - cy;
            if (Math.sqrt(dx * dx + dy * dy) < CELL * (radius + 0.4f) && (tntFuse[j] < 0f || tntFuse[j] > 0.12f)) {
                tntFuse[j] = 0.12f;
            }
        }
        spawnFx(cx, cy, fxSize);
        spawnBurst(cx, cy, 0xffff9a1e, 14, 320f);
        spawnBurst(cx, cy, 0xff555555, 10, 220f);
        shake = 1f;
        play(sLand, 1f, 0.5f);

        float pdx = playerX - cx, pdy = (playerFeet - PLAYER_H * 0.5f) - cy;
        float dist = (float) Math.sqrt(pdx * pdx + pdy * pdy);
        float reachPx = CELL * (radius + 0.2f);
        if (dist < reachPx) {
            if (!shieldOn()) hp -= 12f + 38f * (1f - dist / reachPx);
            velocityY = -520f;
            grounded = false;
            if (hp <= 0f) respawnPlayer();
        }
        if (grounded && !hasSurfaceAtFeet(playerX, playerFeet)) grounded = false;
    }

    // ---- TikTok events ---------------------------------------------------------------
    private void addFeed(String text, int color) {
        if (!cfg.feed) return;
        for (int i = FEED_LINES - 1; i > 0; i--) {
            feedText[i] = feedText[i - 1]; feedUntil[i] = feedUntil[i - 1]; feedColor[i] = feedColor[i - 1];
        }
        feedText[0] = text; feedUntil[0] = gameClock + 6f; feedColor[0] = color;
    }

    private void pollLive() {
        LiveClient.Event e;
        int n = 0;
        while (n++ < 12 && (e = live.poll()) != null) handleLive(e);
        if (recentDirty && gameClock - lastRecentSave > 8f) {
            recentDirty = false;
            lastRecentSave = gameClock;
            cfg.save();
        }
    }

    private int ruleFor(String type) {
        if (type.equals("follow")) return GameSettings.EV_FOLLOW;
        if (type.equals("share")) return GameSettings.EV_SHARE;
        if (type.equals("join")) return GameSettings.EV_JOIN;
        if (type.equals("like")) return GameSettings.EV_LIKE;
        if (type.equals("chat")) return GameSettings.EV_CHAT;
        if (type.equals("subscribe")) return GameSettings.EV_SUB;
        return -1;
    }

    private void handleLive(LiveClient.Event e) {
        String who = e.user == null || e.user.length() == 0 ? "anonymous" : e.user;
        if (e.type.equals("gift")) {
            String name = e.giftName == null ? "" : e.giftName;
            if (name.length() > 0) { cfg.rememberGift(name); recentDirty = true; }
            String what = (name.length() > 0 ? name : "gift") + (e.count > 1 ? " x" + e.count : "");
            GameSettings.Gift g = cfg.findGift(name, e.giftId);
            if (g != null) {
                for (int i = 0; i < GameSettings.GIFTS; i++) if (cfg.gifts[i] == g) giftFlash[i] = 0.5f;
                applyEffect(g.effect, g.amount * Math.max(1, e.count));
                addFeed(who + " kirim " + what + "  >  " + GameSettings.toast(g.effect, g.amount * Math.max(1, e.count)), 0xffffe14a);
            } else {
                GameSettings.Rule r = cfg.rules[GameSettings.EV_GIFT];
                if (!r.on) return;
                applyEffect(r.effect, r.amount * Math.max(1, e.count));
                if (r.notify) addFeed(who + " kirim " + what + "  >  "
                        + GameSettings.toast(r.effect, r.amount * Math.max(1, e.count)), 0xffffe14a);
            }
            return;
        }
        int idx = ruleFor(e.type);
        if (idx < 0) return;
        GameSettings.Rule r = cfg.rules[idx];
        int times = 1;
        if (idx == GameSettings.EV_LIKE) {
            likeAcc += Math.max(1, e.count);
            int every = Math.max(1, cfg.likeEvery);
            times = likeAcc / every;
            likeAcc %= every;
            if (times <= 0) return;
        }
        if (!r.on) return;
        fireRule(idx, who, e, times);
    }

    private void fireRule(int idx, String who, LiveClient.Event e, int times) {
        GameSettings.Rule r = cfg.rules[idx];
        int amount = r.amount * times;
        applyEffect(r.effect, amount);
        if (!r.notify) return;
        String verb;
        switch (idx) {
            case GameSettings.EV_FOLLOW: verb = "follow"; break;
            case GameSettings.EV_SHARE: verb = "share"; break;
            case GameSettings.EV_JOIN: verb = "masuk live"; break;
            case GameSettings.EV_LIKE: verb = "like"; break;
            case GameSettings.EV_CHAT: verb = "komentar"; break;
            default: verb = "subscribe"; break;
        }
        addFeed(who + " " + verb + "  >  " + GameSettings.toast(r.effect, amount), 0xff7fe6ff);
    }

    /** "TES" buttons: pushes a fake event through the same path as a real one. */
    private void testRule(int idx) {
        LiveClient.Event e = new LiveClient.Event();
        e.user = "penonton";
        e.type = idx == GameSettings.EV_FOLLOW ? "follow" : idx == GameSettings.EV_SHARE ? "share"
                : idx == GameSettings.EV_JOIN ? "join" : idx == GameSettings.EV_LIKE ? "like"
                : idx == GameSettings.EV_CHAT ? "chat" : idx == GameSettings.EV_SUB ? "subscribe" : "gift";
        if (idx == GameSettings.EV_LIKE) e.count = Math.max(1, cfg.likeEvery);
        if (idx == GameSettings.EV_GIFT) e.giftName = "Gift Tes";
        live.inject(e);
    }

    private void respawnPlayer() {
        hp = 100f;
        int col = COLS / 2;
        playerX = GRID_X + col * CELL + CELL / 2f;
        playerFeet = GRID_Y + topBlockRow(col) * CELL;
        velocityY = 0f;
        grounded = true;
        toast("KAMU KEMBALI!");
    }

    private void spawnBurst(float x, float y, int color, int n, float speed) {
        for (int k = 0; k < n; k++) {
            int slot = -1;
            for (int i = 0; i < MAX_PARTICLES; i++) if (plife[i] <= 0f) { slot = i; break; }
            if (slot < 0) return;
            double ang = rnd.nextDouble() * Math.PI * 2.0;
            float sp = speed * (0.35f + rnd.nextFloat() * 0.65f);
            px[slot] = x; py[slot] = y;
            pvx[slot] = (float) Math.cos(ang) * sp;
            pvy[slot] = (float) Math.sin(ang) * sp - 90f;
            plife[slot] = 0.5f + rnd.nextFloat() * 0.5f;
            pcol[slot] = color;
        }
    }

    // ================================================================================
    // Physics
    // ================================================================================
    private boolean hasSurfaceAtFeet(float x, float feet) {
        if (Math.abs(feet - FLOOR_Y) < 2f) return true;
        int col = (int) ((x - GRID_X) / CELL);
        if (col < 0 || col >= COLS) return false;
        for (int row = BUILD_LIMIT_ROW; row < ROWS; row++) {
            if (blocks[row][col] < 0) continue;
            float top = GRID_Y + row * CELL;
            if (Math.abs(feet - top) < 2f) return true;
        }
        return false;
    }

    private float landingSurface(float x, float oldFeet, float newFeet) {
        float best = Float.POSITIVE_INFINITY;
        if (oldFeet <= FLOOR_Y && newFeet >= FLOOR_Y) best = FLOOR_Y;
        int col = (int) ((x - GRID_X) / CELL);
        if (col < 0 || col >= COLS) return best;
        for (int row = BUILD_LIMIT_ROW; row < ROWS; row++) {
            if (blocks[row][col] < 0) continue;
            float top = GRID_Y + row * CELL;
            if (oldFeet <= top + 1f && newFeet >= top - 1f && top < best) best = top;
        }
        return best;
    }

    private float ceilingSurface(float x, float oldTop, float newTop) {
        float best = Float.NEGATIVE_INFINITY;
        float left = x - PLAYER_HALF_W, right = x + PLAYER_HALF_W;
        int first = clamp((int) ((left - GRID_X) / CELL), 0, COLS - 1);
        int last = clamp((int) ((right - GRID_X) / CELL), 0, COLS - 1);
        for (int col = first; col <= last; col++) {
            for (int row = BUILD_LIMIT_ROW; row < ROWS; row++) {
                if (blocks[row][col] < 0) continue;
                float bottom = GRID_Y + (row + 1) * CELL;
                if (oldTop >= bottom - 1f && newTop <= bottom + 1f && bottom > best) best = bottom;
            }
        }
        return best;
    }

    private boolean blockedAt(float x, float top, float feet) {
        float left = x - PLAYER_HALF_W, right = x + PLAYER_HALF_W;
        int first = clamp((int) ((left - GRID_X) / CELL), 0, COLS - 1);
        int last = clamp((int) ((right - GRID_X) / CELL), 0, COLS - 1);
        for (int col = first; col <= last; col++) {
            for (int row = BUILD_LIMIT_ROW; row < ROWS; row++) {
                if (blocks[row][col] < 0) continue;
                float l = GRID_X + col * CELL, r = l + CELL;
                float t = GRID_Y + row * CELL, b = t + CELL;
                if (right > l + 1f && left < r - 1f && feet > t + 1f && top < b - 1f) return true;
            }
        }
        return false;
    }

    private void resolvePlayerOverlap() {
        float top = playerFeet - PLAYER_H;
        if (!blockedAt(playerX, top, playerFeet)) return;
        for (float d = 2f; d <= CELL * 2f; d += 2f) {
            float left = clampFloat(playerX - d, GRID_X + PLAYER_HALF_W, GRID_X + COLS * CELL - PLAYER_HALF_W);
            if (!blockedAt(left, top, playerFeet)) { playerX = left; return; }
            float right = clampFloat(playerX + d, GRID_X + PLAYER_HALF_W, GRID_X + COLS * CELL - PLAYER_HALF_W);
            if (!blockedAt(right, top, playerFeet)) { playerX = right; return; }
        }
        for (float lift = 2f; lift <= PLAYER_H; lift += 2f) {
            if (!blockedAt(playerX, top - lift, playerFeet - lift)) {
                playerFeet -= lift;
                velocityY = 0f;
                grounded = hasSurfaceAtFeet(playerX, playerFeet);
                return;
            }
        }
    }

    private void updatePhysics() {
        long t = now();
        if (lastFrameNanos == 0) lastFrameNanos = t;
        float dt = Math.min(0.032f, (t - lastFrameNanos) / 1_000_000_000f);
        lastFrameNanos = t;
        if (dt <= 0f) return;
        gameClock += dt;

        updateEffects(dt);

        if (countdownValue >= 0) {
            if (t >= countdownNextNanos) {
                if (countdownValue == 1) {
                    winCount = Math.min(10, winCount + 1);
                    countdownValue = -1;
                    resetBoardAfterWin();
                    return;
                }
                countdownValue--;
                long delay = countdownValue <= 3 ? 1350000000L : 620000000L;
                countdownNextNanos = t + delay;
            }
            return;
        }

        updateTnt(dt);
        pollLive();
        updatePending(dt);
        updateTornado(dt);
        updateRobots(dt);
        updateMeteors(dt);
        updateBolts(dt);
        updateDrops(dt);

        regenClock += dt;
        if (regenClock >= 0.25f) {
            regenClock = 0f;
            if (inventory < MAX_INVENTORY) inventory++;
        }

        // Held actions repeat at the configured build speed.
        buildCooldown -= dt;
        gridCooldown -= dt;
        mineCooldown -= dt;
        if (buildHeld && buildCooldown <= 0f) {
            placeUnderPlayer();
            buildCooldown = cfg.placeInterval();
        }
        if (gridHeld && targetCol >= 0 && targetRow >= 0 && gridCooldown <= 0f) {
            if (gridMine || breakMode) breakBlockAt(targetCol, targetRow);
            else placeAt(targetCol, targetRow);
            gridCooldown = (gridMine || breakMode) ? Math.max(0.08f, cfg.placeInterval()) : cfg.placeInterval();
        }
        if (keyMineFront && mineCooldown <= 0f) { mineFront(); mineCooldown = 0.15f; }
        if (keyMineDown && mineCooldown <= 0f) { mineDown(); mineCooldown = 0.15f; }

        updatePlayer(dt);

        if (blockCount() >= COLS * ROWS && countdownValue < 0) {
            countdownValue = 15;
            countdownNextNanos = t + 620000000L;
        }
    }

    private void updateEffects(float dt) {
        for (int i = 0; i < GameSettings.GIFTS; i++) if (giftFlash[i] > 0f) giftFlash[i] -= dt;
        shake = Math.max(0f, shake - dt * 3f);
        for (int i = 0; i < MAX_FX; i++) {
            if (fxT[i] < 0f) continue;
            fxT[i] += dt;
            if (fxT[i] > FX_TIME) fxT[i] = -1f;
        }
        for (int i = 0; i < MAX_PARTICLES; i++) {
            if (plife[i] <= 0f) continue;
            plife[i] -= dt;
            pvy[i] += 700f * dt;
            px[i] += pvx[i] * dt;
            py[i] += pvy[i] * dt;
        }
    }

    private void updateTnt(float dt) {
        if (rainLeft > 0) {
            rainClock -= dt;
            if (rainClock <= 0f) {
                rainClock = 0.28f;
                rainLeft--;
                spawnTnt(rnd.nextInt(COLS), -1f);
            }
        }
        for (int i = 0; i < MAX_TNT; i++) {
            if (!tntOn[i]) continue;
            float surface = GRID_Y + topBlockRow(tntCol[i]) * CELL;
            boolean supported = tntY[i] + CELL >= surface - 0.5f;
            if (!supported) {
                tntVy[i] = Math.min(1100f, tntVy[i] + 1600f * dt);
                tntY[i] += tntVy[i] * dt;
                if (tntY[i] + CELL >= surface) {
                    tntY[i] = surface - CELL;
                    tntVy[i] = 0f;
                    if (tntFuse[i] < 0f) tntFuse[i] = TNT_FUSE;
                }
            } else {
                tntY[i] = surface - CELL;
                tntVy[i] = 0f;
                if (tntFuse[i] < 0f) tntFuse[i] = TNT_FUSE;
            }
            if (tntFuse[i] >= 0f) {
                tntFuse[i] -= dt;
                if (tntFuse[i] <= 0f) explode(i);
            }
        }
    }

    private void updatePlayer(float dt) {
        boolean spr = isSprint();
        float speed = (spr ? 245f : 145f) * (turboOn() ? 1.5f : 1f);
        float dx = 0f;
        if (leftHeld && !rightHeld) { dx = -speed * dt; facingRight = false; }
        if (rightHeld && !leftHeld) { dx = speed * dt; facingRight = true; }

        resolvePlayerOverlap();

        float candidateX = clampFloat(playerX + dx, GRID_X + PLAYER_HALF_W, GRID_X + COLS * CELL - PLAYER_HALF_W);
        if (Math.abs(dx) > 0.001f) {
            if (!blockedAt(candidateX, playerFeet - PLAYER_H, playerFeet)) {
                playerX = candidateX;
            } else {
                float low = 0f, high = 1f;
                for (int i = 0; i < 12; i++) {
                    float mid = (low + high) * 0.5f;
                    float test = playerX + (candidateX - playerX) * mid;
                    if (blockedAt(test, playerFeet - PLAYER_H, playerFeet)) high = mid;
                    else low = mid;
                }
                playerX = playerX + (candidateX - playerX) * low;
            }
        }

        if (grounded && !hasSurfaceAtFeet(playerX, playerFeet)) grounded = false;

        if ((jumpRequested || jumpHeld) && grounded) {
            velocityY = -JUMP_SPEED * (turboOn() ? 1.08f : 1f);
            grounded = false;
            play(sJump, 0.7f, 1f);
        }
        jumpRequested = false;

        wasGrounded = grounded;
        if (!grounded) {
            float oldFeet = playerFeet;
            float oldTop = oldFeet - PLAYER_H;
            velocityY += GRAVITY * dt;
            float nextFeet = oldFeet + velocityY * dt;
            float nextTop = nextFeet - PLAYER_H;

            if (velocityY < 0f) {
                float ceiling = ceilingSurface(playerX, oldTop, nextTop);
                if (ceiling != Float.NEGATIVE_INFINITY) {
                    nextFeet = ceiling + PLAYER_H;
                    velocityY = 0f;
                }
            } else {
                float landing = landingSurface(playerX, oldFeet, nextFeet);
                if (landing != Float.POSITIVE_INFINITY) {
                    nextFeet = landing;
                    impactVy = velocityY;
                    velocityY = 0f;
                    grounded = true;
                }
            }
            playerFeet = nextFeet;
            if (grounded && !wasGrounded && impactVy > 380f) play(sLand, 0.6f, 1f);
        } else {
            velocityY = 0f;
        }

        // Camera follows the player vertically.
        float desiredCamera = playerFeet - boardViewportHeight() * PLAYER_SCREEN_RATIO;
        cameraTarget = clampFloat(desiredCamera, minCamera(), maxCamera());
        cameraY += (cameraTarget - cameraY) * Math.min(1f, dt * 8f);

        animationClock += dt;
        if (!grounded) {
            if (animationClock > 0.11f) { jumpFrame = (jumpFrame + 1) % 5; animationClock = 0f; }
        } else if (leftHeld != rightHeld) {
            float delay = spr ? 0.075f : 0.13f;
            if (animationClock > delay) {
                if (spr) runFrame = (runFrame + 1) % 5;
                else walkFrame = (walkFrame + 1) % 5;
                animationClock = 0f;
            }
            stepClock += dt;
            float iv = spr ? 0.17f : 0.30f;
            if (stepClock >= iv) { stepClock = 0f; play(spr ? sRun : sStep, 0.5f, 1f); }
        } else {
            walkFrame = 0; animationClock = 0f; stepClock = 0.1f;
        }
    }

    // ================================================================================
    // Input: touch + mouse
    // ================================================================================
    private int roleAt(float x, float y) {
        hitArg = -1;
        layoutGifts();
        if (x >= pauseRect.left - 6f && x <= pauseRect.right + 6f
                && y >= pauseRect.top - 4f && y <= pauseRect.bottom + 6f) return ROLE_PAUSE;
        if (countdownValue >= 0) return ROLE_NONE;
        if (cfg.showButtons) {
            layoutControls();
            final int[] roles = {ROLE_LEFT, ROLE_RIGHT, ROLE_RUN, ROLE_PICK, ROLE_BUILD, ROLE_JUMP};
            for (int i = 0; i < 6; i++) if (hit[i].contains(x, y)) return roles[i];
        }
        for (int k = 0; k < giftCount; k++) {
            if (giftRects[k].contains(x, y)) { hitArg = k; return ROLE_GIFT; }
        }
        if (y >= areaTop() && y < controlTop() && x >= GRID_X && x < GRID_X + COLS * CELL) return ROLE_GRID;
        return ROLE_NONE;
    }

    private void updateTarget(float x, float y) {
        int col = (int) Math.floor((x - GRID_X) / CELL);
        int row = (int) Math.floor((y - areaTop() + cameraY - GRID_Y) / CELL);
        targetCol = (col >= 0 && col < COLS) ? col : -1;
        targetRow = (row >= 0 && row < ROWS) ? row : -1;
    }

    private void updateHover(float x, float y) {
        int col = (int) Math.floor((x - GRID_X) / CELL);
        int row = (int) Math.floor((y - areaTop() + cameraY - GRID_Y) / CELL);
        boolean inside = y >= areaTop() && y < controlTop() && col >= 0 && col < COLS;
        hoverCol = inside ? col : -1;
        hoverRow = (inside && row >= 0 && row < ROWS) ? row : -1;
    }

    private void addPointer(MotionEvent e, int index) {
        int id = e.getPointerId(index);
        float x = toLogicalX(e.getX(index)), y = toLogicalY(e.getY(index));
        boolean mouse = e.getToolType(index) == MotionEvent.TOOL_TYPE_MOUSE;
        int role = roleAt(x, y);
        TouchPoint t = new TouchPoint(role, x, y);
        t.arg = hitArg;
        t.mouse = mouse;
        touches.put(id, t);

        mouseActive = mouse;
        if (mouse) updateHover(x, y);

        if (role == ROLE_PAUSE) {
            pressCenterX = x; pressCenterY = y;
            pressUntilNanos = now() + 220000000L;
        } else if (role == ROLE_RUN) {
            sprintToggle = !sprintToggle;
        } else if (role == ROLE_PICK) {
            breakMode = !breakMode;
        } else if (role == ROLE_BUILD) {
            breakMode = false;
            placeUnderPlayer();
            buildCooldown = cfg.placeInterval() * 2f;
        } else if (role == ROLE_JUMP) {
            jumpRequested = true;
        } else if (role == ROLE_GIFT) {
            triggerShownGift(t.arg);
        } else if (role == ROLE_GRID) {
            updateTarget(x, y);
            boolean right = mouse && (e.getButtonState() & MotionEvent.BUTTON_SECONDARY) != 0;
            gridMine = right;
            gridHeld = true;
            if (right || breakMode) breakBlockAt(targetCol, targetRow);
            else placeAt(targetCol, targetRow);
            gridCooldown = cfg.placeInterval() * 2f;
        }
        refreshHeldButtons();
    }

    private void updatePointers(MotionEvent e) {
        for (int i = 0; i < e.getPointerCount(); i++) {
            int id = e.getPointerId(i);
            TouchPoint t = touches.get(id);
            if (t == null) continue;
            t.x = toLogicalX(e.getX(i));
            t.y = toLogicalY(e.getY(i));
            if ((t.role == ROLE_LEFT || t.role == ROLE_RIGHT) && t.y >= controlTop() && t.x >= 0f && t.x < 164f) {
                t.role = t.x < 83f ? ROLE_LEFT : ROLE_RIGHT;
            }
            if (t.role == ROLE_GRID) {
                int oc = targetCol, orow = targetRow;
                updateTarget(t.x, t.y);
                if (t.mouse) updateHover(t.x, t.y);
                // Dragging onto a new cell acts right away (no waiting for the repeat timer).
                if (gridHeld && (targetCol != oc || targetRow != orow) && targetCol >= 0 && targetRow >= 0) {
                    if (gridMine || breakMode) breakBlockAt(targetCol, targetRow);
                    else placeAt(targetCol, targetRow);
                    gridCooldown = cfg.placeInterval();
                }
            }
        }
        refreshHeldButtons();
    }

    private void releasePointer(MotionEvent e, int index) {
        int id = e.getPointerId(index);
        TouchPoint t = touches.get(id);
        if (t != null && t.role == ROLE_GRID) {
            gridHeld = false;
            gridMine = false;
        } else if (t != null && t.role == ROLE_PAUSE) {
            pauseGame();
            pressUntilNanos = now() + 140000000L;
        }
        touches.remove(id);
        refreshHeldButtons();
    }

    private void refreshHeldButtons() {
        touchLeft = touchRight = touchJump = touchBuild = false;
        for (int i = 0; i < touches.size(); i++) {
            int role = touches.valueAt(i).role;
            if (role == ROLE_LEFT) touchLeft = true;
            if (role == ROLE_RIGHT) touchRight = true;
            if (role == ROLE_JUMP) touchJump = true;
            if (role == ROLE_BUILD) touchBuild = true;
        }
        leftHeld = touchLeft || keyLeft || padLeft;
        rightHeld = touchRight || keyRight || padRight;
        jumpHeld = touchJump || keyJump;
        buildHeld = touchBuild || keyBuild;
    }

    private void releaseAllInput() {
        touches.clear();
        keyLeft = keyRight = keyJump = keyBuild = keyShift = keyMineFront = keyMineDown = false;
        padLeft = padRight = false;
        gridHeld = false; gridMine = false;
        jumpRequested = false;
        refreshHeldButtons();
    }

    @Override public boolean onTouchEvent(MotionEvent event) {
        int action = event.getActionMasked();
        int index = event.getActionIndex();

        if (screen != SCREEN_GAME) {
            if (action == MotionEvent.ACTION_DOWN) {
                pressCenterX = toLogicalX(event.getX(index));
                pressCenterY = toLogicalY(event.getY(index));
                pressUntilNanos = now() + 220000000L;
            } else if (action == MotionEvent.ACTION_UP) {
                int id = uiAt(toLogicalX(event.getX(index)), toLogicalY(event.getY(index)));
                pressUntilNanos = now() + 140000000L;
                if (id >= 0) onUi(id);
            }
            invalidate();
            return true;
        }

        switch (action) {
            case MotionEvent.ACTION_DOWN:
            case MotionEvent.ACTION_POINTER_DOWN:
                addPointer(event, index);
                break;
            case MotionEvent.ACTION_MOVE:
                updatePointers(event);
                break;
            case MotionEvent.ACTION_POINTER_UP:
                releasePointer(event, index);
                break;
            case MotionEvent.ACTION_UP:
                releasePointer(event, index);
                touches.clear();
                gridHeld = false;
                gridMine = false;
                refreshHeldButtons();
                break;
            case MotionEvent.ACTION_CANCEL:
                touches.clear();
                gridHeld = false;
                gridMine = false;
                jumpRequested = false;
                refreshHeldButtons();
                break;
            default:
                break;
        }
        invalidate();
        return true;
    }

    /** Mouse hover and gamepad sticks arrive as generic motion events. */
    @Override public boolean onGenericMotionEvent(MotionEvent e) {
        int src = e.getSource();
        int action = e.getActionMasked();
        if ((src & InputDevice.SOURCE_JOYSTICK) == InputDevice.SOURCE_JOYSTICK
                && action == MotionEvent.ACTION_MOVE) {
            float ax = e.getAxisValue(MotionEvent.AXIS_X);
            float hat = e.getAxisValue(MotionEvent.AXIS_HAT_X);
            padLeft = ax < -0.45f || hat < -0.5f;
            padRight = ax > 0.45f || hat > 0.5f;
            refreshHeldButtons();
            return true;
        }
        if (action == MotionEvent.ACTION_HOVER_MOVE || action == MotionEvent.ACTION_HOVER_ENTER) {
            mouseActive = true;
            updateHover(toLogicalX(e.getX()), toLogicalY(e.getY()));
            return true;
        }
        if (action == MotionEvent.ACTION_HOVER_EXIT) {
            hoverCol = -1; hoverRow = -1;
            return true;
        }
        return super.onGenericMotionEvent(e);
    }

    // ================================================================================
    // Menu actions
    // ================================================================================
    private void open(int target) {
        if (target == screen) return;
        backTo[target] = screen;
        screen = target;
        if (target == SCREEN_GIFTS) giftPage = 0;
    }

    private void leaveTo(int target) {
        screen = target;
        if (target == SCREEN_MENU) lastFrameNanos = 0L;
    }

    private void goBack() {
        int t = backTo[screen];
        leaveTo(t == screen ? SCREEN_MENU : t);
    }

    private int stepFor(int effect) {
        return (effect == GameSettings.E_BLOCK || effect == GameSettings.E_HEAL) ? 5 : 1;
    }

    private void onUi(int id) {
        if (id >= B_G_ON && id < B_G_LABEL + GameSettings.GIFTS) { onGiftUi(id); return; }
        if (id >= B_E_ON && id < B_E_TEST + GameSettings.EVENTS) { onEventUi(id); return; }
        if (id >= B_PICK_ITEM && id < B_PICK_ITEM + PICK_PAGE) { onPickItem(id - B_PICK_ITEM); return; }
        switch (id) {
            case B_PLAY: startGame(); break;
            case B_GIFTS: open(SCREEN_GIFTS); break;
            case B_SETTINGS: open(SCREEN_SETTINGS); break;
            case B_TIKTOK: open(SCREEN_TIKTOK); break;
            case B_LOOKS: open(SCREEN_LOOKS); break;
            case B_T_EVENTS: open(SCREEN_EVENTS); break;
            case B_T_GIFTS: open(SCREEN_GIFTS); break;
            case B_RESUME: resumeGame(); break;
            case B_RETRY: startGame(); break;
            case B_MENU: leaveTo(SCREEN_MENU); break;
            case B_SOUND: cfg.sound = !cfg.sound; cfg.save(); break;
            case B_BUTTONS: cfg.showButtons = !cfg.showButtons; cfg.save(); break;
            case B_UNLIMITED: cfg.unlimited = !cfg.unlimited; cfg.save(); break;
            case B_SPEED: cfg.speed = (cfg.speed + 1) % GameSettings.SPEED_NAMES.length; cfg.save(); break;
            case B_FEED: cfg.feed = !cfg.feed; cfg.save(); break;
            case B_HUD_MINUS: cfg.hudOffset = Math.max(0, cfg.hudOffset - 8); cfg.save(); break;
            case B_HUD_PLUS: cfg.hudOffset = Math.min(80, cfg.hudOffset + 8); cfg.save(); break;
            case B_RESET: cfg.resetDefaults(); cfg.save(); break;
            case B_RESET_GIFTS: cfg.resetGifts(); cfg.save(); break;
            case B_E_RESET: cfg.resetRules(); cfg.save(); break;
            case B_BACK: goBack(); break;
            case B_PAGE_PREV:
                if (screen == SCREEN_PICK) pickPage = Math.max(0, pickPage - 1);
                else giftPage = (giftPage + giftPages() - 1) % giftPages();
                break;
            case B_PAGE_NEXT:
                if (screen == SCREEN_PICK) pickPage++;
                else giftPage = (giftPage + 1) % giftPages();
                break;
            case B_MAP_PREV: cfg.map = (cfg.map + GameSettings.MAPS - 1) % GameSettings.MAPS; cfg.save(); break;
            case B_MAP_NEXT: cfg.map = (cfg.map + 1) % GameSettings.MAPS; cfg.save(); break;
            case B_CHAR_PREV: cfg.character = (cfg.character + GameSettings.CHARS - 1) % GameSettings.CHARS; cfg.save(); break;
            case B_CHAR_NEXT: cfg.character = (cfg.character + 1) % GameSettings.CHARS; cfg.save(); break;
            case B_T_HOST:
                askText("Host bridge (127.0.0.1 atau IP PC)", cfg.host, false, 60, new TextResult() {
                    @Override public void done(String s) { cfg.host = s.trim(); cfg.save(); }
                });
                break;
            case B_T_PORT:
                askText("Port bridge (contoh 25601)", String.valueOf(cfg.port), true, 5, new TextResult() {
                    @Override public void done(String s) {
                        try { cfg.port = Math.max(1, Math.min(65535, Integer.parseInt(s.trim()))); } catch (Exception ignored) { return; }
                        cfg.save();
                    }
                });
                break;
            case B_T_USER:
                askText("Username TikTok (tanpa @)", cfg.user, false, 40, new TextResult() {
                    @Override public void done(String s) { cfg.user = s.trim().replace("@", ""); cfg.save(); }
                });
                break;
            case B_T_AUTO: cfg.autoConnect = !cfg.autoConnect; cfg.save(); break;
            case B_T_START:
                if (live.isRunning()) live.stop();
                else { cfg.save(); startLive(); }
                break;
            case B_T_TEST: testLive(); break;
            case B_LIKE_MINUS: cfg.likeEvery = Math.max(1, cfg.likeEvery - (cfg.likeEvery > 20 ? 10 : 1)); cfg.save(); break;
            case B_LIKE_PLUS: cfg.likeEvery = Math.min(500, cfg.likeEvery + (cfg.likeEvery >= 20 ? 10 : 1)); cfg.save(); break;
            case B_LIKE_AMT:
                askText("Aksi tiap berapa like (1-500)", String.valueOf(cfg.likeEvery), true, 3, new TextResult() {
                    @Override public void done(String s) {
                        try { cfg.likeEvery = Math.max(1, Math.min(500, Integer.parseInt(s.trim()))); } catch (Exception ignored) { return; }
                        cfg.save();
                    }
                });
                break;
            case B_PICK_MANUAL: {
                final GameSettings.Gift g = cfg.gifts[clamp(pickSlot, 0, GameSettings.GIFTS - 1)];
                askText("Nama gift persis seperti di TikTok", g.name == null ? "" : g.name, false, 30, new TextResult() {
                    @Override public void done(String s) {
                        g.name = s.trim();
                        if (g.name.length() > 0) g.on = true;
                        int ci = catalogIndex(g.name);
                        if (ci >= 0) g.icon = GiftCatalog.ICON[ci];
                        cfg.save();
                        leaveTo(backTo[SCREEN_PICK]);
                    }
                });
                break;
            }
            case B_PICK_CLEAR: {
                GameSettings.Gift g = cfg.gifts[clamp(pickSlot, 0, GameSettings.GIFTS - 1)];
                g.name = ""; g.on = false; g.show = false;
                cfg.save();
                goBack();
                break;
            }
            default: break;
        }
    }

    /** "TES EVENT" on the TikTok screen: one follow + the first active gift. */
    private void testLive() {
        LiveClient.Event e = new LiveClient.Event();
        e.type = "follow"; e.user = "penonton";
        live.inject(e);
        for (GameSettings.Gift g : cfg.gifts) {
            if (!g.on || g.name == null || g.name.trim().length() == 0) continue;
            LiveClient.Event ge = new LiveClient.Event();
            ge.type = "gift"; ge.user = "penonton"; ge.giftName = g.name; ge.count = 1;
            live.inject(ge);
            break;
        }
        screen = SCREEN_GAME;
        if (blockCount() == 0 && gameClock <= 0f) resetGame();
        lastFrameNanos = now();
        toast("EVENT TES DIKIRIM");
    }

    private void onPickItem(int k) {
        String[] list = pickList();
        int idx = pickPage * PICK_PAGE + k;
        if (idx < 0 || idx >= list.length) return;
        GameSettings.Gift g = cfg.gifts[clamp(pickSlot, 0, GameSettings.GIFTS - 1)];
        g.name = list[idx];
        g.on = true;
        int ci = catalogIndex(g.name);
        if (ci >= 0) g.icon = GiftCatalog.ICON[ci];
        cfg.save();
        goBack();
    }

    private void onEventUi(int id) {
        int base;
        if (id >= B_E_TEST) base = B_E_TEST;
        else if (id >= B_E_PLUS) base = B_E_PLUS;
        else if (id >= B_E_AMOUNT) base = B_E_AMOUNT;
        else if (id >= B_E_MINUS) base = B_E_MINUS;
        else if (id >= B_E_EFFECT) base = B_E_EFFECT;
        else if (id >= B_E_NOTIF) base = B_E_NOTIF;
        else base = B_E_ON;
        final int i = id - base;
        if (i < 0 || i >= GameSettings.EVENTS) return;
        final GameSettings.Rule r = cfg.rules[i];
        switch (base) {
            case B_E_ON: r.on = !r.on; break;
            case B_E_NOTIF: r.notify = !r.notify; break;
            case B_E_EFFECT: r.effect = (r.effect + 1) % GameSettings.EFFECTS; r.clampAmount(); break;
            case B_E_MINUS: r.amount -= stepFor(r.effect); r.clampAmount(); break;
            case B_E_PLUS: r.amount += stepFor(r.effect); r.clampAmount(); break;
            case B_E_AMOUNT:
                askText("Jumlah (1-" + GameSettings.EFFECT_MAX[r.effect] + ")", String.valueOf(r.amount), true, 3,
                        new TextResult() {
                            @Override public void done(String s) {
                                try { r.amount = Integer.parseInt(s.trim()); } catch (Exception ignored) { return; }
                                r.clampAmount();
                                cfg.save();
                            }
                        });
                return;
            case B_E_TEST:
                cfg.save();
                testRuleInGame(i);
                return;
            default: return;
        }
        cfg.save();
    }

    private void testRuleInGame(int idx) {
        testRule(idx);
        screen = SCREEN_GAME;
        if (lastFrameNanos == 0L) resetGame();
        lastFrameNanos = now();
    }

    private void onGiftUi(int id) {
        int base;
        if (id >= B_G_LABEL) base = B_G_LABEL;
        else if (id >= B_G_PLUS) base = B_G_PLUS;
        else if (id >= B_G_AMOUNT) base = B_G_AMOUNT;
        else if (id >= B_G_MINUS) base = B_G_MINUS;
        else if (id >= B_G_EFFECT) base = B_G_EFFECT;
        else if (id >= B_G_NAME) base = B_G_NAME;
        else if (id >= B_G_ICON) base = B_G_ICON;
        else if (id >= B_G_SHOW) base = B_G_SHOW;
        else base = B_G_ON;
        int i = id - base;
        if (i < 0 || i >= GameSettings.GIFTS) return;
        final GameSettings.Gift g = cfg.gifts[i];
        switch (base) {
            case B_G_ON: g.on = !g.on; break;
            case B_G_SHOW: g.show = !g.show; break;
            case B_G_ICON: g.icon = (g.icon + 1) % GameSettings.ICONS; break;
            case B_G_NAME: pickSlot = i; pickPage = 0; open(SCREEN_PICK); break;
            case B_G_EFFECT:
                g.effect = (g.effect + 1) % GameSettings.EFFECTS;
                g.clampAmount();
                break;
            case B_G_MINUS: g.amount -= stepFor(g.effect); g.clampAmount(); break;
            case B_G_PLUS: g.amount += stepFor(g.effect); g.clampAmount(); break;
            case B_G_AMOUNT:
                askText("Jumlah (1-" + GameSettings.EFFECT_MAX[g.effect] + ")", String.valueOf(g.amount), true, 3,
                        new TextResult() {
                            @Override public void done(String s) {
                                try { g.amount = Integer.parseInt(s.trim()); } catch (Exception ignored) { return; }
                                g.clampAmount();
                                cfg.save();
                            }
                        });
                return;
            case B_G_LABEL:
                askText("Teks hadiah (kosong = otomatis)", g.label == null ? "" : g.label, false, 9,
                        new TextResult() {
                            @Override public void done(String s) {
                                g.label = s.trim();
                                cfg.save();
                            }
                        });
                return;
            default: return;
        }
        cfg.save();
    }

    /** Simple text / number prompt (works with the on-screen and a hardware keyboard). */
    private void askText(String title, String initial, boolean numeric, final int maxLen, final TextResult cb) {
        try {
            final EditText input = new EditText(getContext());
            input.setText(initial);
            input.setSingleLine(true);
            input.setInputType(numeric ? InputType.TYPE_CLASS_NUMBER : InputType.TYPE_CLASS_TEXT);
            input.setSelectAllOnFocus(true);
            new AlertDialog.Builder(getContext())
                    .setTitle(title)
                    .setView(input)
                    .setPositiveButton("OK", new DialogInterface.OnClickListener() {
                        @Override public void onClick(DialogInterface d, int which) {
                            String s = input.getText().toString();
                            if (s.length() > maxLen) s = s.substring(0, maxLen);
                            cb.done(s);
                        }
                    })
                    .setNegativeButton("Batal", null)
                    .show();
        } catch (Throwable ignored) { }
    }

    // ================================================================================
    // Input: keyboard / gamepad buttons / activity hooks
    // ================================================================================
    public void pauseGame() {
        if (screen != SCREEN_GAME) return;
        screen = SCREEN_PAUSE;
        if (recentDirty) { recentDirty = false; cfg.save(); }
        releaseAllInput();
    }

    private void resumeGame() {
        screen = SCREEN_GAME;
        lastFrameNanos = now();
    }

    /** Called from Activity.onPause. */
    public void onHostPause() {
        pauseGame();
        releaseAllInput();
    }

    /** Back button. Returns true when the game consumed it. */
    public boolean handleBack() {
        if (screen == SCREEN_GAME) { pauseGame(); return true; }
        if (screen == SCREEN_PAUSE) { resumeGame(); return true; }
        if (screen != SCREEN_MENU) { goBack(); return true; }
        return false;
    }

    @Override public void onWindowFocusChanged(boolean hasWindowFocus) {
        super.onWindowFocusChanged(hasWindowFocus);
        if (!hasWindowFocus) {
            if (screen == SCREEN_GAME) pauseGame();
            releaseAllInput();
        }
    }

    @Override protected void onDetachedFromWindow() {
        release();
        super.onDetachedFromWindow();
    }

    @Override public boolean onKeyDown(int keyCode, KeyEvent event) {
        return handleKeyEvent(event) || super.onKeyDown(keyCode, event);
    }

    @Override public boolean onKeyUp(int keyCode, KeyEvent event) {
        return handleKeyEvent(event) || super.onKeyUp(keyCode, event);
    }

    /**
     * Keyboard / gamepad handling. The activity forwards every key event here, so
     * input works even when the view does not hold focus (Bluetooth / OTG keyboards).
     */
    public boolean handleKeyEvent(KeyEvent e) {
        int code = e.getKeyCode();
        boolean down = e.getAction() == KeyEvent.ACTION_DOWN;
        boolean up = e.getAction() == KeyEvent.ACTION_UP;
        if (!down && !up) return false;
        boolean fresh = down && e.getRepeatCount() == 0;
        if (code == KeyEvent.KEYCODE_BACK) return false;   // handled by Activity.onBackPressed

        if (screen == SCREEN_MENU) {
            if (fresh && isConfirmKey(code)) { startGame(); return true; }
            if (fresh && code == KeyEvent.KEYCODE_O) { open(SCREEN_SETTINGS); return true; }
            if (fresh && code == KeyEvent.KEYCODE_G) { open(SCREEN_GIFTS); return true; }
            if (fresh && code == KeyEvent.KEYCODE_T) { open(SCREEN_TIKTOK); return true; }
            if (fresh && code == KeyEvent.KEYCODE_L) { open(SCREEN_LOOKS); return true; }
            return code == KeyEvent.KEYCODE_ESCAPE;
        }
        if (screen == SCREEN_SETTINGS) {
            if (fresh && (isConfirmKey(code) || code == KeyEvent.KEYCODE_ESCAPE)) { goBack(); return true; }
            if (fresh && code == KeyEvent.KEYCODE_S) { onUi(B_SOUND); return true; }
            if (fresh && code == KeyEvent.KEYCODE_B) { onUi(B_BUTTONS); return true; }
            if (fresh && code == KeyEvent.KEYCODE_U) { onUi(B_UNLIMITED); return true; }
            if (fresh && code == KeyEvent.KEYCODE_V) { onUi(B_SPEED); return true; }
            if (fresh && code == KeyEvent.KEYCODE_G) { open(SCREEN_GIFTS); return true; }
            if (fresh && code == KeyEvent.KEYCODE_T) { open(SCREEN_TIKTOK); return true; }
            if (fresh && code == KeyEvent.KEYCODE_L) { open(SCREEN_LOOKS); return true; }
            return false;
        }
        if (screen == SCREEN_GIFTS) {
            if (fresh && (isConfirmKey(code) || code == KeyEvent.KEYCODE_ESCAPE)) { goBack(); return true; }
            if (fresh && code == KeyEvent.KEYCODE_DPAD_LEFT) { onUi(B_PAGE_PREV); return true; }
            if (fresh && code == KeyEvent.KEYCODE_DPAD_RIGHT) { onUi(B_PAGE_NEXT); return true; }
            if (fresh && code >= KeyEvent.KEYCODE_1 && code <= KeyEvent.KEYCODE_6) {
                int i = giftPage * GIFT_PAGE + (code - KeyEvent.KEYCODE_1);
                if (i < GameSettings.GIFTS) onUi(B_G_ON + i);
                return true;
            }
            return false;
        }
        if (screen == SCREEN_TIKTOK) {
            if (fresh && code == KeyEvent.KEYCODE_ESCAPE) { goBack(); return true; }
            if (fresh && isConfirmKey(code)) { onUi(B_T_START); return true; }
            return false;
        }
        if (screen == SCREEN_EVENTS || screen == SCREEN_PICK) {
            if (fresh && code == KeyEvent.KEYCODE_ESCAPE) { goBack(); return true; }
            return false;
        }
        if (screen == SCREEN_LOOKS) {
            if (fresh && (isConfirmKey(code) || code == KeyEvent.KEYCODE_ESCAPE)) { goBack(); return true; }
            if (fresh && code == KeyEvent.KEYCODE_DPAD_LEFT) { onUi(B_MAP_PREV); return true; }
            if (fresh && code == KeyEvent.KEYCODE_DPAD_RIGHT) { onUi(B_MAP_NEXT); return true; }
            if (fresh && code == KeyEvent.KEYCODE_DPAD_UP) { onUi(B_CHAR_PREV); return true; }
            if (fresh && code == KeyEvent.KEYCODE_DPAD_DOWN) { onUi(B_CHAR_NEXT); return true; }
            return false;
        }
        if (screen == SCREEN_PAUSE) {
            if (fresh && (isConfirmKey(code) || code == KeyEvent.KEYCODE_ESCAPE || code == KeyEvent.KEYCODE_P
                    || code == KeyEvent.KEYCODE_BUTTON_START)) { resumeGame(); return true; }
            if (fresh && code == KeyEvent.KEYCODE_R) { startGame(); return true; }
            if (fresh && code == KeyEvent.KEYCODE_M) { leaveTo(SCREEN_MENU); return true; }
            if (fresh && code == KeyEvent.KEYCODE_O) { open(SCREEN_SETTINGS); return true; }
            if (fresh && code == KeyEvent.KEYCODE_G) { open(SCREEN_GIFTS); return true; }
            if (fresh && code == KeyEvent.KEYCODE_T) { open(SCREEN_TIKTOK); return true; }
            if (fresh && code == KeyEvent.KEYCODE_L) { open(SCREEN_LOOKS); return true; }
            return false;
        }

        // ---- in game ----
        switch (code) {
            case KeyEvent.KEYCODE_A:
            case KeyEvent.KEYCODE_DPAD_LEFT:
                keyLeft = down; break;
            case KeyEvent.KEYCODE_D:
            case KeyEvent.KEYCODE_DPAD_RIGHT:
                keyRight = down; break;
            case KeyEvent.KEYCODE_W:
            case KeyEvent.KEYCODE_DPAD_UP:
            case KeyEvent.KEYCODE_SPACE:
            case KeyEvent.KEYCODE_BUTTON_A:
                if (fresh) jumpRequested = true;
                keyJump = down; break;
            case KeyEvent.KEYCODE_SHIFT_LEFT:
            case KeyEvent.KEYCODE_SHIFT_RIGHT:
            case KeyEvent.KEYCODE_BUTTON_R1:
                keyShift = down; break;
            case KeyEvent.KEYCODE_E:
            case KeyEvent.KEYCODE_ENTER:
            case KeyEvent.KEYCODE_NUMPAD_ENTER:
            case KeyEvent.KEYCODE_BUTTON_X:
            case KeyEvent.KEYCODE_BUTTON_R2:
                if (fresh) {
                    breakMode = false;
                    placeUnderPlayer();
                    buildCooldown = cfg.placeInterval() * 2f;
                }
                keyBuild = down; break;
            case KeyEvent.KEYCODE_F:
                if (fresh) placeFront();
                break;
            case KeyEvent.KEYCODE_S:
            case KeyEvent.KEYCODE_DPAD_DOWN:
                keyMineDown = down; if (down) mineCooldown = Math.min(mineCooldown, 0f); break;
            case KeyEvent.KEYCODE_X:
            case KeyEvent.KEYCODE_Z:
            case KeyEvent.KEYCODE_CTRL_LEFT:
            case KeyEvent.KEYCODE_CTRL_RIGHT:
            case KeyEvent.KEYCODE_BUTTON_B:
                keyMineFront = down; if (down) mineCooldown = Math.min(mineCooldown, 0f); break;
            case KeyEvent.KEYCODE_Q:
            case KeyEvent.KEYCODE_BUTTON_Y:
                if (fresh) { breakMode = !breakMode; toast(breakMode ? "MODE BELIUNG" : "MODE BLOK"); }
                break;
            case KeyEvent.KEYCODE_P:
            case KeyEvent.KEYCODE_ESCAPE:
            case KeyEvent.KEYCODE_BUTTON_START:
            case KeyEvent.KEYCODE_MENU:
                if (fresh) pauseGame();
                break;
            default:
                if (code >= KeyEvent.KEYCODE_1 && code <= KeyEvent.KEYCODE_8) {
                    if (fresh) triggerShownGift(code - KeyEvent.KEYCODE_1);
                } else if (code >= KeyEvent.KEYCODE_NUMPAD_1 && code <= KeyEvent.KEYCODE_NUMPAD_8) {
                    if (fresh) triggerShownGift(code - KeyEvent.KEYCODE_NUMPAD_1);
                } else {
                    return false;
                }
        }
        refreshHeldButtons();
        return true;
    }

    private boolean isConfirmKey(int code) {
        return code == KeyEvent.KEYCODE_ENTER || code == KeyEvent.KEYCODE_NUMPAD_ENTER
                || code == KeyEvent.KEYCODE_SPACE || code == KeyEvent.KEYCODE_DPAD_CENTER
                || code == KeyEvent.KEYCODE_BUTTON_A || code == KeyEvent.KEYCODE_BUTTON_START;
    }
}
