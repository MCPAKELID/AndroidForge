package com.mcpakel.blockarea;

/**
 * Built-in list of popular TikTok gifts (name + approximate coin value). The game matches the gift
 * NAME sent by the bridge, so any gift that is missing here can still be typed in by hand, and gifts
 * seen live are remembered automatically.
 */
public final class GiftCatalog {
    private GiftCatalog() { }

    public static final String[] NAMES = {
            "Rose", "TikTok", "GG", "Ice Cream Cone", "Heart Me", "Finger Heart", "Ice Cream", "Rosa",
            "Perfume", "Doughnut", "Cap", "Butterfly", "Cupid's Bow", "Hand Heart", "Hand Hearts",
            "Confetti", "Balloon Gift Box", "Sunglasses", "Gold Boxing Gloves", "Corgi", "Air Dancer",
            "Panda Hug", "Money Gun", "Swan", "Train", "Galaxy", "Fireworks", "Diamond Crown",
            "Cherry Blossoms", "Whale Diving", "Leon the Kitten", "Sports Car", "Diamond Gun",
            "Drama Queen", "Yacht", "Phoenix", "Lion", "TikTok Universe"};
    public static final int[] COINS = {
            1, 1, 1, 1, 1, 5, 5, 10,
            20, 30, 99, 88, 99, 100, 100,
            100, 100, 199, 299, 299, 300,
            499, 500, 699, 899, 1000, 1088, 1499,
            1500, 2150, 4888, 4999, 5000,
            5000, 7000, 25999, 29999, 44999};
    /** Icon (0..7 are real gift pictures) used when a catalog gift is picked. */
    public static final int[] ICON = {
            1, 0, 0, 4, 7, 2, 4, 3,
            3, 4, 6, 6, 5, 5, 5,
            6, 6, 6, 7, 7, 6,
            7, 6, 6, 6, 7, 6, 6,
            6, 7, 7, 7, 6,
            6, 7, 7, 7, 7};

    public static int size() { return NAMES.length; }
}
