package com.mcpakel.blockarea;

import android.content.Context;
import android.content.SharedPreferences;

/** Persistent settings: sound, HUD, look (map / character), TikTok connection, gift slots and event rules. */
public final class GameSettings {
    public static final int GIFTS = 24;          // gift slots (each reacts to one TikTok gift)
    public static final int SHOWN_MAX = 8;       // tiles that fit in the top row
    public static final int ICONS = 14;
    public static final int E_BLOCK = 0, E_TNT = 1, E_RAIN = 2, E_TURBO = 3, E_HEAL = 4, E_SHIELD = 5,
            E_LIGHTNING = 6, E_TORNADO = 7, E_ROBOT = 8, E_METEOR = 9;
    public static final int EFFECTS = 10;
    public static final String[] EFFECT_NAMES = {"BLOK", "TNT", "HUJAN TNT", "TURBO", "NYAWA", "PERISAI",
            "PETIR", "TORNADO", "ROBOT", "METEOR"};
    public static final int[] EFFECT_MAX = {100, 50, 30, 60, 100, 60, 30, 5, 8, 20};
    public static final int[] EFFECT_COLOR = {0xff47d16a, 0xffe0a030, 0xff4fc3d9, 0xffe6c83a, 0xff7ae07a,
            0xff9a7ae0, 0xfff3e24a, 0xff8fb3d9, 0xffa0a8b8, 0xffff7a3a};
    public static final int[] EFFECT_ICON = {13, 8, 8, 3, 5, 6, 9, 10, 11, 12};
    public static final String[] SPEED_NAMES = {"NORMAL", "CEPAT", "SUPER"};
    public static final float[] SPEED_INTERVAL = {0.12f, 0.065f, 0.03f};

    public static final int EV_FOLLOW = 0, EV_SHARE = 1, EV_JOIN = 2, EV_LIKE = 3, EV_CHAT = 4, EV_SUB = 5,
            EV_GIFT = 6;
    public static final int EVENTS = 7;
    public static final String[] EVENT_NAMES = {"FOLLOW", "SHARE", "MASUK LIVE", "LIKE", "KOMENTAR",
            "SUBSCRIBE", "GIFT LAIN"};

    public static final String[] MAP_NAMES = {"PADANG", "GURUN", "SALJU", "NETHER", "MALAM"};
    public static final String[] CHAR_NAMES = {"STEVE", "ALEX", "ZOMBIE", "NINJA", "PINKY", "KSATRIA", "ES"};
    public static final int MAPS = 5, CHARS = 7;

    /** One gift slot: reacts to a TikTok gift name and may show as a tile in the top row. */
    public static final class Gift {
        public boolean on, show;
        public int icon, effect, amount;
        public String label = "", name = "";

        public String autoLabel() { return GameSettings.autoLabel(effect, amount); }

        /** Custom text when set, otherwise generated from the amount. */
        public String shownLabel() {
            String t = label == null ? "" : label.trim();
            return t.length() > 0 ? t : autoLabel();
        }

        public String toast() { return GameSettings.toast(effect, amount); }

        public void clampAmount() { amount = GameSettings.clampAmount(effect, amount); }
    }

    /** Reaction to a TikTok event (follow, share, ...). */
    public static final class Rule {
        public boolean on, notify;
        public int effect, amount;
        public void clampAmount() { amount = GameSettings.clampAmount(effect, amount); }
    }

    public static String autoLabel(int effect, int amount) {
        switch (effect) {
            case E_BLOCK: return "+" + amount;
            case E_HEAL: return amount + "%";
            case E_TURBO:
            case E_SHIELD: return amount + "s";
            default: return "x" + amount;
        }
    }

    public static String toast(int effect, int amount) {
        switch (effect) {
            case E_BLOCK: return "+" + amount + " BLOK";
            case E_TNT: return amount + " TNT";
            case E_RAIN: return "HUJAN TNT x" + amount;
            case E_TURBO: return "TURBO " + amount + " DETIK";
            case E_HEAL: return "NYAWA +" + amount + "%";
            case E_SHIELD: return "PERISAI " + amount + " DETIK";
            case E_LIGHTNING: return amount + " PETIR";
            case E_TORNADO: return amount + " TORNADO";
            case E_ROBOT: return amount + " ROBOT";
            default: return amount + " METEOR";
        }
    }

    public static int clampAmount(int effect, int amount) {
        return Math.max(1, Math.min(EFFECT_MAX[Math.max(0, Math.min(EFFECTS - 1, effect))], amount));
    }

    // slot defaults: gift name, icon, effect, amount, on/show
    private static final Object[][] DEFAULTS = {
            {"Rose", 1, E_BLOCK, 30, true}, {"TikTok", 0, E_TNT, 1, true}, {"Finger Heart", 2, E_TNT, 3, true},
            {"Doughnut", 4, E_LIGHTNING, 2, true}, {"Hand Hearts", 5, E_METEOR, 1, true},
            {"Corgi", 6, E_TORNADO, 1, false}, {"Galaxy", 7, E_ROBOT, 3, false}, {"Lion", 8, E_RAIN, 20, false}};

    // events: on, notify, effect, amount
    private static final Object[][] EVENT_DEFAULTS = {
            {true, true, E_TNT, 1}, {true, true, E_TNT, 2}, {false, false, E_BLOCK, 5}, {false, false, E_BLOCK, 5},
            {false, false, E_BLOCK, 2}, {true, true, E_METEOR, 1}, {false, true, E_TNT, 1}};

    public boolean sound = true;
    public boolean showButtons = true;
    public boolean unlimited = false;
    public boolean feed = true;                  // show TikTok notifications on screen
    public boolean autoConnect = false;
    public int speed = 1;
    public int hudOffset = 0;                    // pushes the HUD down (notch / camera cut-out)
    public int map = 0, character = 0;
    public int likeEvery = 10;                   // LIKE rule fires once per N likes
    public String host = "127.0.0.1", user = "";
    public int port = 25601;
    public String recent = "";                   // recently seen live gift names, '|' separated
    public final Gift[] gifts = new Gift[GIFTS];
    public final Rule[] rules = new Rule[EVENTS];
    private final SharedPreferences prefs;

    public GameSettings(Context context) {
        SharedPreferences p = null;
        try { p = context.getSharedPreferences("blockrush_settings", Context.MODE_PRIVATE); } catch (Throwable ignored) { }
        prefs = p;
        for (int i = 0; i < GIFTS; i++) gifts[i] = new Gift();
        for (int i = 0; i < EVENTS; i++) rules[i] = new Rule();
        resetDefaults();
        load();
    }

    public void resetDefaults() {
        sound = true; showButtons = true; unlimited = false; speed = 1; feed = true; hudOffset = 0;
        resetGifts();
        resetRules();
    }

    public void resetGifts() {
        for (int i = 0; i < GIFTS; i++) {
            Gift g = gifts[i];
            if (i < DEFAULTS.length) {
                g.name = (String) DEFAULTS[i][0]; g.icon = (Integer) DEFAULTS[i][1];
                g.effect = (Integer) DEFAULTS[i][2]; g.amount = (Integer) DEFAULTS[i][3];
                g.on = (Boolean) DEFAULTS[i][4]; g.show = g.on;
            } else {
                g.name = ""; g.icon = 0; g.effect = E_TNT; g.amount = 1; g.on = false; g.show = false;
            }
            g.label = "";
        }
    }

    public void resetRules() {
        for (int i = 0; i < EVENTS; i++) {
            Rule r = rules[i];
            r.on = (Boolean) EVENT_DEFAULTS[i][0]; r.notify = (Boolean) EVENT_DEFAULTS[i][1];
            r.effect = (Integer) EVENT_DEFAULTS[i][2]; r.amount = (Integer) EVENT_DEFAULTS[i][3];
        }
        likeEvery = 10;
    }

    /** Number of tiles shown in the top row. */
    public int shownGifts() {
        int n = 0;
        for (Gift g : gifts) if (g.on && g.show && n < SHOWN_MAX) n++;
        return n;
    }

    public int activeGifts() {
        int n = 0;
        for (Gift g : gifts) if (g.on) n++;
        return n;
    }

    public float placeInterval() { return SPEED_INTERVAL[Math.max(0, Math.min(SPEED_INTERVAL.length - 1, speed))]; }

    /** Finds the active gift slot for a TikTok gift (by name, ignoring case / spaces / plural s, or by id). */
    public Gift findGift(String giftName, int giftId) {
        String n = norm(giftName);
        for (Gift g : gifts) {
            if (!g.on || g.name == null || g.name.trim().length() == 0) continue;
            String m = norm(g.name);
            if (m.length() > 0 && m.equals(n)) return g;
            if (giftId > 0 && m.equals(String.valueOf(giftId))) return g;
        }
        return null;
    }

    public static String norm(String s) {
        if (s == null) return "";
        StringBuilder b = new StringBuilder();
        for (int i = 0; i < s.length(); i++) {
            char c = Character.toLowerCase(s.charAt(i));
            if ((c >= 'a' && c <= 'z') || (c >= '0' && c <= '9')) b.append(c);
        }
        if (b.length() > 3 && b.charAt(b.length() - 1) == 's') b.setLength(b.length() - 1);
        return b.toString();
    }

    public void rememberGift(String name) {
        if (name == null || name.trim().length() == 0) return;
        String n = name.trim().replace("|", " ");
        StringBuilder b = new StringBuilder(n);
        int count = 1;
        for (String s : recent.split("\\|")) {
            if (s.length() == 0 || norm(s).equals(norm(n)) || count >= 16) continue;
            b.append('|').append(s);
            count++;
        }
        recent = b.toString();
    }

    private void load() {
        if (prefs == null) return;
        try {
            sound = prefs.getBoolean("sound", sound);
            showButtons = prefs.getBoolean("buttons", showButtons);
            unlimited = prefs.getBoolean("unlimited", unlimited);
            feed = prefs.getBoolean("feed", feed);
            autoConnect = prefs.getBoolean("auto", autoConnect);
            speed = Math.max(0, Math.min(SPEED_NAMES.length - 1, prefs.getInt("speed", speed)));
            hudOffset = Math.max(0, Math.min(80, prefs.getInt("hud", hudOffset)));
            map = Math.max(0, Math.min(MAPS - 1, prefs.getInt("map", map)));
            character = Math.max(0, Math.min(CHARS - 1, prefs.getInt("char", character)));
            likeEvery = Math.max(1, Math.min(500, prefs.getInt("likeEvery", likeEvery)));
            host = prefs.getString("host", host);
            user = prefs.getString("user", user);
            port = Math.max(1, Math.min(65535, prefs.getInt("port", port)));
            recent = prefs.getString("recent", recent);
            for (int i = 0; i < GIFTS; i++) {
                Gift g = gifts[i];
                String k = "g" + i + "_";
                g.on = prefs.getBoolean(k + "on", g.on);
                g.show = prefs.getBoolean(k + "show", g.show);
                g.icon = Math.max(0, Math.min(ICONS - 1, prefs.getInt(k + "icon", g.icon)));
                g.effect = Math.max(0, Math.min(EFFECTS - 1, prefs.getInt(k + "effect", g.effect)));
                g.amount = prefs.getInt(k + "amount", g.amount);
                g.label = prefs.getString(k + "label", g.label);
                g.name = prefs.getString(k + "name", g.name);
                g.clampAmount();
            }
            for (int i = 0; i < EVENTS; i++) {
                Rule r = rules[i];
                String k = "e" + i + "_";
                r.on = prefs.getBoolean(k + "on", r.on);
                r.notify = prefs.getBoolean(k + "notify", r.notify);
                r.effect = Math.max(0, Math.min(EFFECTS - 1, prefs.getInt(k + "effect", r.effect)));
                r.amount = prefs.getInt(k + "amount", r.amount);
                r.clampAmount();
            }
        } catch (Throwable ignored) { }
    }

    public void save() {
        if (prefs == null) return;
        try {
            SharedPreferences.Editor e = prefs.edit();
            e.putBoolean("sound", sound);
            e.putBoolean("buttons", showButtons);
            e.putBoolean("unlimited", unlimited);
            e.putBoolean("feed", feed);
            e.putBoolean("auto", autoConnect);
            e.putInt("speed", speed);
            e.putInt("hud", hudOffset);
            e.putInt("map", map);
            e.putInt("char", character);
            e.putInt("likeEvery", likeEvery);
            e.putString("host", host == null ? "" : host);
            e.putString("user", user == null ? "" : user);
            e.putInt("port", port);
            e.putString("recent", recent == null ? "" : recent);
            for (int i = 0; i < GIFTS; i++) {
                Gift g = gifts[i];
                String k = "g" + i + "_";
                e.putBoolean(k + "on", g.on);
                e.putBoolean(k + "show", g.show);
                e.putInt(k + "icon", g.icon);
                e.putInt(k + "effect", g.effect);
                e.putInt(k + "amount", g.amount);
                e.putString(k + "label", g.label == null ? "" : g.label);
                e.putString(k + "name", g.name == null ? "" : g.name);
            }
            for (int i = 0; i < EVENTS; i++) {
                Rule r = rules[i];
                String k = "e" + i + "_";
                e.putBoolean(k + "on", r.on);
                e.putBoolean(k + "notify", r.notify);
                e.putInt(k + "effect", r.effect);
                e.putInt(k + "amount", r.amount);
            }
            e.apply();
        } catch (Throwable ignored) { }
    }
}
