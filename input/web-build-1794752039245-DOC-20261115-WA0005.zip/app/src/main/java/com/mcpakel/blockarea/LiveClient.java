package com.mcpakel.blockarea;

import java.io.InputStream;
import java.io.OutputStream;
import java.net.InetSocketAddress;
import java.net.Socket;
import java.security.SecureRandom;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.ConcurrentLinkedQueue;

/**
 * Minimal WebSocket client (RFC 6455, plain ws://) for the TikTok Live bridge (Node.js).
 * It sends host_start with the TikTok username and turns the bridge's JSON events into {@link Event}s
 * that the game polls from its own thread. Reconnects automatically while started.
 */
public final class LiveClient {
    /** One TikTok event. type: gift, like, follow, share, join, chat, subscribe. */
    public static final class Event {
        public String type = "", user = "", giftName = "", text = "";
        public int giftId, count = 1, coin;
        public long totalCoin;
    }

    public volatile String status = "MATI";       // MATI, MENGHUBUNGKAN, TERHUBUNG, LIVE, OFFLINE, ERROR, TERPUTUS
    public volatile String message = "";
    public volatile int viewers = 0;
    private final ConcurrentLinkedQueue<Event> queue = new ConcurrentLinkedQueue<>();
    private volatile boolean wanted = false;
    private volatile Socket socket;
    private Thread thread;
    private String host = "127.0.0.1", user = "";
    private int port = 25601;
    private int generation = 0;

    public boolean isRunning() { return wanted; }

    public synchronized void start(String host, int port, String user) {
        stop();
        this.host = host == null ? "" : host.trim();
        this.port = port;
        this.user = user == null ? "" : user.trim().replace("@", "");
        if (this.host.length() == 0 || this.user.length() == 0) {
            status = "ERROR"; message = this.user.length() == 0 ? "Isi username TikTok dulu." : "Isi host dulu.";
            return;
        }
        wanted = true;
        status = "MENGHUBUNGKAN"; message = "";
        final int gen = ++generation;
        thread = new Thread(new Runnable() { @Override public void run() { loop(gen); } }, "LiveClient");
        thread.setDaemon(true);
        thread.start();
    }

    public synchronized void stop() {
        wanted = false;
        generation++;
        Socket s = socket;
        socket = null;
        if (s != null) {
            try { s.close(); } catch (Throwable ignored) { }
        }
        status = "MATI"; message = "";
        viewers = 0;
    }

    public Event poll() { return queue.poll(); }

    /** Test / manual injection (also used by the "TES" button). */
    public void inject(Event e) {
        queue.add(e);
        trim();
    }

    private void trim() {
        while (queue.size() > 300) queue.poll();
    }

    private boolean alive(int gen) { return wanted && gen == generation; }

    private void loop(int gen) {
        int delay = 2000;
        while (alive(gen)) {
            Socket s = null;
            try {
                status = "MENGHUBUNGKAN"; message = host + ":" + port;
                s = new Socket();
                s.connect(new InetSocketAddress(host, port), 8000);
                s.setTcpNoDelay(true);
                s.setSoTimeout(70000);
                socket = s;
                if (!alive(gen)) break;
                handshake(s);
                status = "TERHUBUNG"; message = "Menunggu live @" + user;
                delay = 2000;
                send(s, "{\"type\":\"subscribe\",\"playerName\":\"BlockRush\",\"playerUUID\":\"\",\"tiktok\":\""
                        + esc(user) + "\"}");
                send(s, "{\"type\":\"host_start\",\"tiktok\":\"" + esc(user) + "\"}");
                readLoop(s, gen);
            } catch (Throwable t) {
                if (alive(gen)) { status = "TERPUTUS"; message = String.valueOf(t.getMessage()); }
            } finally {
                if (s != null) try { s.close(); } catch (Throwable ignored) { }
            }
            if (!alive(gen)) break;
            if (!"ERROR".equals(status)) status = "TERPUTUS";
            for (int waited = 0; waited < delay && alive(gen); waited += 100) {
                try { Thread.sleep(100); } catch (InterruptedException e) { return; }
            }
            delay = Math.min(10000, delay + 1500);
        }
    }

    // ---- WebSocket framing -------------------------------------------------------------
    private static final SecureRandom RND = new SecureRandom();

    private void handshake(Socket s) throws Exception {
        byte[] k = new byte[16];
        RND.nextBytes(k);
        String key = b64(k);
        String req = "GET / HTTP/1.1\r\nHost: " + host + ":" + port + "\r\nUpgrade: websocket\r\n"
                + "Connection: Upgrade\r\nSec-WebSocket-Key: " + key + "\r\nSec-WebSocket-Version: 13\r\n\r\n";
        OutputStream out = s.getOutputStream();
        out.write(req.getBytes("UTF-8"));
        out.flush();
        InputStream in = s.getInputStream();
        StringBuilder head = new StringBuilder();
        int c;
        while ((c = in.read()) >= 0) {
            head.append((char) c);
            int n = head.length();
            if (n >= 4 && head.charAt(n - 1) == '\n' && head.charAt(n - 2) == '\r'
                    && head.charAt(n - 3) == '\n' && head.charAt(n - 4) == '\r') break;
            if (n > 8192) throw new Exception("Header terlalu panjang");
        }
        if (head.indexOf(" 101") < 0) throw new Exception("Bukan server WebSocket (bridge TikTok?)");
    }

    private void readLoop(Socket s, int gen) throws Exception {
        InputStream in = s.getInputStream();
        StringBuilder text = new StringBuilder();
        java.io.ByteArrayOutputStream frag = new java.io.ByteArrayOutputStream();
        long lastPing = System.currentTimeMillis();
        while (alive(gen)) {
            int b0;
            try { b0 = in.read(); } catch (java.net.SocketTimeoutException e) {
                send(s, "{\"type\":\"ping\"}");
                continue;
            }
            if (b0 < 0) throw new Exception("Koneksi ditutup server");
            int b1 = in.read();
            if (b1 < 0) throw new Exception("Koneksi ditutup server");
            boolean fin = (b0 & 0x80) != 0;
            int op = b0 & 0x0f;
            long len = b1 & 0x7f;
            if (len == 126) len = (in.read() << 8) | in.read();
            else if (len == 127) { len = 0; for (int i = 0; i < 8; i++) len = (len << 8) | in.read(); }
            boolean masked = (b1 & 0x80) != 0;
            byte[] mask = new byte[4];
            if (masked) readFully(in, mask, 4);
            if (len > 4_000_000L) throw new Exception("Frame terlalu besar");
            byte[] data = new byte[(int) len];
            readFully(in, data, data.length);
            if (masked) for (int i = 0; i < data.length; i++) data[i] ^= mask[i & 3];
            if (op == 0x8) throw new Exception("Server menutup koneksi");
            if (op == 0x9) { sendFrame(s, 0xA, data); continue; }
            if (op == 0xA) continue;
            if (op == 0x1 || op == 0x0) {
                if (op == 0x1) frag.reset();
                frag.write(data, 0, data.length);
                if (fin) {
                    handle(new String(frag.toByteArray(), "UTF-8"));
                    frag.reset();
                }
            }
            long now = System.currentTimeMillis();
            if (now - lastPing > 25000) { lastPing = now; send(s, "{\"type\":\"ping\"}"); }
        }
    }

    private static void readFully(InputStream in, byte[] b, int n) throws Exception {
        int off = 0;
        while (off < n) {
            int r = in.read(b, off, n - off);
            if (r < 0) throw new Exception("Koneksi ditutup server");
            off += r;
        }
    }

    private void send(Socket s, String text) throws Exception { sendFrame(s, 0x1, text.getBytes("UTF-8")); }

    private synchronized void sendFrame(Socket s, int op, byte[] payload) throws Exception {
        OutputStream out = s.getOutputStream();
        byte[] mask = new byte[4];
        RND.nextBytes(mask);
        int n = payload.length;
        java.io.ByteArrayOutputStream f = new java.io.ByteArrayOutputStream(n + 14);
        f.write(0x80 | op);
        if (n < 126) f.write(0x80 | n);
        else if (n < 65536) { f.write(0x80 | 126); f.write(n >> 8); f.write(n & 255); }
        else { f.write(0x80 | 127); for (int i = 7; i >= 0; i--) f.write((int) (((long) n >> (8 * i)) & 255)); }
        f.write(mask, 0, 4);
        for (int i = 0; i < n; i++) f.write(payload[i] ^ mask[i & 3]);
        out.write(f.toByteArray());
        out.flush();
    }

    private static final String B64 = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/";

    static String b64(byte[] d) {
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < d.length; i += 3) {
            int v = (d[i] & 255) << 16 | (i + 1 < d.length ? (d[i + 1] & 255) << 8 : 0) | (i + 2 < d.length ? d[i + 2] & 255 : 0);
            sb.append(B64.charAt((v >> 18) & 63)).append(B64.charAt((v >> 12) & 63));
            sb.append(i + 1 < d.length ? B64.charAt((v >> 6) & 63) : '=');
            sb.append(i + 2 < d.length ? B64.charAt(v & 63) : '=');
        }
        return sb.toString();
    }

    private static String esc(String s) {
        return s.replace("\\", "\\\\").replace("\"", "\\\"");
    }

    // ---- bridge messages ------------------------------------------------------------------
    void handle(String json) {
        Map<String, String> m = parseFlat(json);
        String ev = m.get("event");
        if (ev == null) ev = m.get("type");
        if (ev == null) return;
        ev = ev.toLowerCase();
        if (ev.equals("host_status") || ev.equals("live_status")) {
            String st = m.get("status");
            String live = m.get("live");
            String user2 = m.get("tiktok");
            if ("true".equals(live) || "live".equals(st)) { status = "LIVE"; message = "@" + (user2 == null ? user : user2); }
            else if ("false".equals(live) || "offline".equals(st)) { status = "OFFLINE"; message = m.get("message") == null ? "Live tidak aktif" : m.get("message"); }
            else if ("error".equals(st)) { status = "ERROR"; message = m.get("message") == null ? "Error dari bridge" : m.get("message"); }
            else if ("connecting".equals(st) || "reconnecting".equals(st)) { status = "MENGHUBUNGKAN"; message = "TikTok @" + user; }
            else if ("stopped".equals(st)) { status = "TERHUBUNG"; message = "Dihentikan"; }
            return;
        }
        if (ev.equals("viewers")) { viewers = toInt(m.get("viewerCount"), toInt(m.get("count"), viewers)); return; }
        Event e = new Event();
        e.type = ev;
        if (ev.equals("sub") || ev.equals("subscribe") || ev.equals("subscription")) e.type = "subscribe";
        else if (!(ev.equals("gift") || ev.equals("like") || ev.equals("follow") || ev.equals("share")
                || ev.equals("join") || ev.equals("chat") || ev.equals("member"))) return;
        if (ev.equals("member")) e.type = "join";
        e.user = firstNonEmpty(m.get("username"), m.get("uniqueId"), m.get("nickname"), "anonymous");
        e.giftName = firstNonEmpty(m.get("giftName"), "", "", "");
        e.giftId = toInt(m.get("giftId"), 0);
        e.count = Math.max(1, toInt(m.get("count"), toInt(m.get("repeatCount"), toInt(m.get("likeCount"), 1))));
        e.coin = toInt(m.get("coin"), toInt(m.get("diamondCount"), 0));
        e.totalCoin = e.coin * (long) e.count;
        e.text = firstNonEmpty(m.get("message"), m.get("comment"), "", "");
        // Gift packets without a delta flag duplicate combo steps; the bridge already de-duplicates.
        queue.add(e);
        trim();
    }

    private static String firstNonEmpty(String a, String b, String c, String d) {
        if (a != null && a.length() > 0) return a;
        if (b != null && b.length() > 0) return b;
        if (c != null && c.length() > 0) return c;
        return d == null ? "" : d;
    }

    private static int toInt(String s, int def) {
        if (s == null) return def;
        try { return (int) Math.round(Double.parseDouble(s.trim())); } catch (Exception e) { return def; }
    }

    /** Reads the top-level key/values of a JSON object (nested values are skipped). */
    static Map<String, String> parseFlat(String s) {
        Map<String, String> out = new HashMap<>();
        int i = 0, n = s.length();
        while (i < n && s.charAt(i) != '{') i++;
        i++;
        while (i < n) {
            while (i < n && (s.charAt(i) == ' ' || s.charAt(i) == ',' || s.charAt(i) == '\n' || s.charAt(i) == '\r' || s.charAt(i) == '\t')) i++;
            if (i >= n || s.charAt(i) == '}') break;
            if (s.charAt(i) != '"') { i++; continue; }
            int[] end = new int[1];
            String key = readString(s, i, end);
            i = end[0];
            while (i < n && (s.charAt(i) == ' ' || s.charAt(i) == ':')) i++;
            if (i >= n) break;
            char c = s.charAt(i);
            if (c == '"') {
                String v = readString(s, i, end);
                i = end[0];
                out.put(key, v);
            } else if (c == '{' || c == '[') {
                i = skipNested(s, i);
            } else {
                int j = i;
                while (j < n && s.charAt(j) != ',' && s.charAt(j) != '}') j++;
                out.put(key, s.substring(i, j).trim());
                i = j;
            }
        }
        return out;
    }

    private static String readString(String s, int start, int[] end) {
        StringBuilder b = new StringBuilder();
        int i = start + 1, n = s.length();
        while (i < n) {
            char c = s.charAt(i);
            if (c == '"') { i++; break; }
            if (c == '\\' && i + 1 < n) {
                char d = s.charAt(i + 1);
                if (d == 'u' && i + 5 < n) {
                    try { b.append((char) Integer.parseInt(s.substring(i + 2, i + 6), 16)); } catch (Exception e) { b.append('?'); }
                    i += 6;
                    continue;
                }
                b.append(d == 'n' ? '\n' : d == 't' ? '\t' : d == 'r' ? '\r' : d);
                i += 2;
                continue;
            }
            b.append(c);
            i++;
        }
        end[0] = i;
        return b.toString();
    }

    private static int skipNested(String s, int start) {
        int depth = 0, i = start, n = s.length();
        boolean inStr = false;
        while (i < n) {
            char c = s.charAt(i);
            if (inStr) {
                if (c == '\\') i++;
                else if (c == '"') inStr = false;
            } else if (c == '"') inStr = true;
            else if (c == '{' || c == '[') depth++;
            else if (c == '}' || c == ']') { depth--; if (depth == 0) return i + 1; }
            i++;
        }
        return n;
    }
}
