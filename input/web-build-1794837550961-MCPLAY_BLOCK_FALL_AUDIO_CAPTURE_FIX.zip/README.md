# BlockRush Live Game v23 — AndroidForge Source

Game Minecraft 2D untuk live TikTok: penonton kirim gift / follow / like, dan game langsung bereaksi (TNT, petir, tornado, robot, meteor, monster, dll).

## Hubungkan ke TikTok Live

**Mode LANGSUNG (bawaan, tanpa Node.js):** menu **TIKTOK LIVE** → isi **Username** (yang sedang LIVE) → **MULAI TERHUBUNG**. Game membuka WebSocket sendiri ke `wss://ws.eulerstream.com`. Isi **API KEY** (eulerstream.com) bila server memintanya.
> Mode ini belum bisa dites dari sini (butuh internet + akun live). Format pesan dibaca secara toleran; kalau ada yang tidak cocok, kirim isi status/pesannya.

**Mode NODE.JS BRIDGE:** tetap tersedia (tombol NODE.JS BRIDGE). Di bridge TIKTOMC: `MINECRAFT_OUTBOUND_ENABLED=false`, `WS_PORT=25601`; di game isi host/port. Mode ini sudah diuji dengan `TMine.js` asli.

**HUBUNG OTOMATIS** = langsung tersambung saat game dibuka. **TES** = kirim follow + gift palsu.

## Hadiah & Event

- **HADIAH** (24 slot): satu slot = satu gift TikTok → **tepat** satu efek yang kamu atur (mis. Mawar = 1 TNT → hanya 1 TNT). Atur nama gift (pilih dari ±750 gift Indonesia / cari / ketik), gambar, efek, jumlah, teks, ON/OFF, TAMPIL/SEMBUNYI (maks 8 tampil; yang disembunyikan tetap memicu efek) dan tombol **TES** per baris. Mengetuk gambar gift di atas layar juga memicu efeknya.
- Notifikasi: "asep mengirim 1x mawar".
- Gambar gift diambil dari sprite sheet milikmu; hanya gift yang pasti cocok yang diberi gambar aslinya, sisanya kotak hadiah. Ketuk gambar di baris gift untuk memilih gambar lain.
- **EVENT**: follow, share, masuk, like, komentar, subscribe, gift lain → efek + jumlah + TES.
- **Efek**: BLOK, TNT, HUJAN TNT, TURBO, NYAWA (nyawa tambahan), PERISAI (kebal beberapa saat), PETIR (menembus dalam), TORNADO (menggali, blok beterbangan), ROBOT (memasang blok berurutan ke samping), METEOR, MONSTER (sapuan laser sangat merusak).

## Aturan

- Blok per **lapisan**: 10 blok ke samping = 1 lapisan, HUD menampilkan `N/40`. 40 lapisan penuh → hitung mundur → menang.
- Hitung mundur **batal** kalau ada blok hancur. Mulai hitungan, kecepatan, dan target menang bisa diatur.
- Pemain bisa mati (atur di PENGATURAN > GAME), nyawa/HP bisa disembunyikan. Efek & event tetap jalan saat jeda / mati.
- Blok hanya bisa dipasang bila menempel tanah/blok. Tombol **DEPAN** (atau F) memasang blok di depan player seperti Minecraft Bedrock.
- **MAP & KARAKTER** hanya dari menu utama.

## Kontrol

| Aksi | Sentuh | Keyboard | Mouse |
|---|---|---|---|
| Jalan | ◀ ▶ | A / D | – |
| Lompat | ⬆ | W / Spasi | – |
| Lari | tombol lari | Shift | – |
| Blok di bawah | tombol blok | E / Enter | – |
| Blok di depan | DEPAN | F | – |
| Pasang / gali | ketuk / mode beliung | X / Z, S | klik kiri / kanan |
| Hadiah (uji) | ketuk ikon | 1–8 | klik ikon |
| Jeda | tombol jeda, Back | Esc / P | – |
| Menu | – | O / G / T / L | – |

## Build

Ekstrak ke workspace AndroidForge, build modul `app` dengan JDK 17, Android SDK 35. Application ID `com.mcpakel.blockarea` — Versi 2.3 (versionCode 23). Izin INTERNET sudah ada.

Diuji dengan API Android tiruan (logika, input, tampilan). APK asli / TikTok live asli belum dites di perangkat.
