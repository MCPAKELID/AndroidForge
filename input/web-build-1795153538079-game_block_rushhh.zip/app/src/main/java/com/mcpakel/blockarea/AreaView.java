package com.mcpakel.blockarea;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Rect;
import android.graphics.RectF;
import android.graphics.Typeface;
import android.media.AudioAttributes;
import android.media.MediaPlayer;
import android.media.SoundPool;
import android.os.Build;
import android.text.InputType;
import android.util.SparseArray;
import android.view.InputDevice;
import android.view.KeyEvent;
import android.view.MotionEvent;
import android.view.View;
import android.widget.EditText;

import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.util.Locale;
import java.util.Random;

/**
 * Block Rush (2D Minecraft style): place blocks under yourself and climb, mine, blow things up
 * with TNT. Input: touch, keyboard and mouse (Bluetooth / OTG / built-in) and simple gamepads.
 * Everything is drawn on one Canvas in a 512-unit wide world.
 */
public class AreaView extends View {
    // ---- world / layout -------------------------------------------------------------
    private static final float WORLD_W = 512f;
    private static final float BOARD_H = 1935f;
    private static final float MIN_LOGICAL_H = 700f;
    private static final float MAX_CONTROL_H = 384f;
    private static final float MIN_CONTROL_H = 140f;
    private static final int COLS = 10, ROWS = 40, BLOCK_TYPES = 48, TNT_TYPE = 28;
    private static final int BUILD_LIMIT_ROW = 0;
    private static final float GRID_X = 41f, GRID_Y = 132f, CELL = 43f;
    private static final float FLOOR_Y = GRID_Y + ROWS * CELL;
    private static final float PLAYER_H = CELL * 1.8f;          // fits through a 2-cell gap
    private static final float PLAYER_HALF_W = CELL * 0.30f;
    private static final float GRAVITY = 1850f, JUMP_SPEED = 720f;
    private static final float AREA_TOP = 176f;
    private static final float PLAYER_SCREEN_RATIO = 0.72f;
    private static final int SKY = 0xff38a6fd;

    private static final int MAX_INVENTORY = 100, MAX_TNT = 24;
    private static final int MAX_PARTICLES = 260, MAX_FX = 12;
    private static final int[] LADDER = {1, 2, 3, 4, 5, 33, 6, 10, 11};
    private static final int[] ORES = {12, 13, 14, 15, 16, 17, 18};

    // Inner compartments of hud_bar.png (source pixels): start,end pairs.
    private static final int[] BAR_SEG = {42, 145, 156, 265, 276, 396, 407, 527, 539, 660,
            672, 797, 808, 933, 945, 1067, 1078, 1200, 1211, 1336, 1347, 1471, 1483, 1607,
            1618, 1741, 1753, 1859, 1870, 1974};

    private static final int ROLE_NONE = 0, ROLE_LEFT = 1, ROLE_RIGHT = 2, ROLE_JUMP = 3,
            ROLE_RUN = 4, ROLE_PICK = 5, ROLE_BUILD = 6, ROLE_GRID = 7, ROLE_PAUSE = 8,
            ROLE_GIFT = 9;
    private static final int SCREEN_MENU = 0, SCREEN_GAME = 1, SCREEN_PAUSE = 2,
            SCREEN_SETTINGS = 3, SCREEN_GIFTS = 4, SCREEN_TIKTOK = 5, SCREEN_EVENTS = 6,
            SCREEN_LOOKS = 7, SCREEN_PICK = 8, SCREEN_ICONS = 9, SCREEN_LOADING = 10, SCREEN_MOD = 11, SCREEN_FX = 12, SCREEN_BTNS = 13, SCREENS = 14;

    private static final int MAX_TORNADO = 3, MAX_ROBOT = 10, MAX_METEOR = 6, MAX_BOLT = 4, FEED_LINES = 5;
    private static final int MAX_DEBRIS = 64, LIGHTNING_DEPTH = 5;
    private static final float TNT_FUSE = 1.4f, FX_TIME = 0.7f, BOLT_TIME = 0.45f;
    private static final int GIFT_PAGE = 5, PICK_PAGE = 14, ICON_PAGE = 36;
    // Map themes: sky next to the arena, ground texture (top, middle, deep), ground shade.
    private static final int[] MAP_SKY = {0xff38a1fc, 0xff2a0c10};
    private static final int[][] MAP_GROUND = {{0, 1, 2}, {19, 25, 24}};
    private static final int[] MAP_SHADE = {0, 0x33000000};

    // UI button ids
    private static final int B_PLAY = 1, B_GIFTS = 2, B_SETTINGS = 3, B_RESUME = 4, B_RETRY = 5,
            B_MENU = 6, B_TIKTOK = 7, B_LOOKS = 8, B_MODS = 9, B_MOD_RELOAD = 75, B_MOD_TOG = 3400,
            B_SOUND = 10, B_BUTTONS = 11, B_UNLIMITED = 12, B_SPEED = 13, B_HUD_MINUS = 14,
            B_RESET = 15, B_BACK = 16, B_HUD_PLUS = 17, B_RESET_GIFTS = 18, B_FEED = 19,
            B_PAGE_PREV = 20, B_PAGE_NEXT = 21,
            B_T_HOST = 30, B_T_PORT = 31, B_T_USER = 32, B_T_AUTO = 33, B_T_START = 34, B_T_EVENTS = 35,
            B_T_TEST = 36, B_T_GIFTS = 37,
            B_MAP_PREV = 40, B_MAP_NEXT = 41, B_CHAR_PREV = 42, B_CHAR_NEXT = 43,
            B_LIKE_MINUS = 50, B_LIKE_PLUS = 51, B_LIKE_AMT = 52, B_E_RESET = 53,
            B_PICK_MANUAL = 60, B_PICK_CLEAR = 61, B_PICK_SEARCH = 62, B_TILE_MINUS = 65, B_TILE_PLUS = 66,
            B_T_MODE = 38, B_T_KEY = 39, B_T_WEB = 45, B_T_MODE2 = 44, B_TAB = 70, B_STEP_M = 3000, B_STEP_V = 3100, B_STEP_P = 3200, B_TOG = 3300,
            B_G_TEST = 1270, B_G_SND = 1300, B_G_SNDX = 1330, B_E_SHOW = 440, B_E_SND = 460, B_E_SNDX = 480, B_ICON_ITEM = 4000, B_FX_ITEM = 4400, B_BTN_EDIT = 90, B_BE_SM = 91, B_BE_SP = 92, B_BE_AM = 93, B_BE_AP = 94, B_BE_RESET = 95, B_RESET_AREA = 97, B_LINK_YT = 98, B_LINK_TT = 99,
            B_E_ON = 300, B_E_NOTIF = 320, B_E_EFFECT = 340, B_E_MINUS = 360, B_E_AMOUNT = 380, B_E_PLUS = 400,
            B_G_ON = 1000, B_G_SHOW = 1030, B_G_ICON = 1060, B_G_NAME = 1090, B_G_EFFECT = 1120,
            B_G_MINUS = 1150, B_G_AMOUNT = 1180, B_G_PLUS = 1210, B_G_LABEL = 1240, B_E_TEST = 420, B_PICK_ITEM = 2000;

    private interface TextResult { void done(String text); }

    private static final class TouchPoint {
        int role, arg;
        boolean mouse;
        float x, y;
        TouchPoint(int role, float x, float y) { this.role = role; this.x = x; this.y = y; }
    }

    private final Paint paint = new Paint();
    private final RectF tmp = new RectF();
    private final Random rnd = new Random();
    private final GameSettings cfg;
    private final int[][] blocks = new int[ROWS][COLS];
    private final long[][] blockPlacedAt = new long[ROWS][COLS];
    private final RectF[] giftRects = new RectF[GameSettings.GIFTS];
    private final int[] giftIdx = new int[GameSettings.GIFTS];
    private final boolean[] tileEv = new boolean[GameSettings.GIFTS];       // tile k is an event, not a gift
    private final float[] ruleFlash = new float[GameSettings.EVENTS];
    private final Bitmap[] evIcon = new Bitmap[GameSettings.EVENTS];
    private float tileExtra = 0f;                                           // 2nd row of tiles pushes the HUD down
    private int giftCount = 0;
    private final RectF pauseRect = new RectF(460f, 4f, 504f, 48f);
    private final Bitmap[] blockTextures = new Bitmap[BLOCK_TYPES];
    private final int[] blockColor = new int[BLOCK_TYPES];
    private final Bitmap[] fxIcon = new Bitmap[GameSettings.EFFECTS];
    private final Bitmap[] giftSprite = new Bitmap[256];
    private final Bitmap[] robotFrames = new Bitmap[3], tornadoFrames = new Bitmap[3], monsterFrames = new Bitmap[3];
    private final java.util.HashMap<String, Bitmap> glyphs = new java.util.HashMap<>();
    private final Bitmap[][] characterFrames = new Bitmap[3][5];
    private final float[][] characterBottom = new float[3][5];
    private final Bitmap[] tntFrames = new Bitmap[7], boomFrames = new Bitmap[8];
    private final Bitmap[] charPreview = new Bitmap[GameSettings.CHARS];
    private int loadedMap = -1, loadedChar = -1;
    private final LiveClient live = new LiveClient();
    private final int[] backTo = new int[SCREENS];
    private int giftPage = 0, pickPage = 0, pickSlot = 0, iconPage = 0, settingsTab = 0;
    private String pickQuery = "";
    private String[] pickCache = null;
    private String pickCacheQuery = null;
    private final float[] blockDrop = new float[ROWS * COLS], blockDropV = new float[ROWS * COLS];
    private final SparseArray<TouchPoint> touches = new SparseArray<>();

    // UI hit boxes recorded while drawing a menu screen.
    private final RectF[] uiRects = new RectF[120];
    private final int[] uiIds = new int[120];
    private int uiCount = 0;

    private Bitmap arena, fontAtlas, placementFrame, menuBackground, pauseIcon;
    private Bitmap hudBar, hudCube, hudTrophy, hudHp;
    private Bitmap leftImage, rightImage, runImage, pickImage, blockImage, jumpImage;

    private final RectF[] hit = new RectF[6];
    private final RectF[] icon = new RectF[6];

    // ---- player ---------------------------------------------------------------------
    private float playerX, playerFeet, velocityY;
    private float cameraY, cameraTarget;
    private float animationClock, stepClock, impactVy;
    private long lastFrameNanos;
    private boolean grounded = true, wasGrounded = true, facingRight = true;
    private boolean jumpRequested = false;
    private int walkFrame = 0, runFrame = 0, jumpFrame = 0;

    // ---- input state ----------------------------------------------------------------
    private boolean touchLeft, touchRight, touchJump, touchBuild;
    private boolean keyLeft, keyRight, keyJump, keyBuild, keyShift, keyMineFront, keyMineDown;
    private boolean padLeft, padRight;
    private boolean sprintToggle = false;
    private boolean leftHeld, rightHeld, jumpHeld, buildHeld;
    private boolean breakMode = false;
    private boolean mouseActive = false;
    private boolean gridHeld = false, gridMine = false;
    private int hoverCol = -1, hoverRow = -1;
    private int targetCol = -1, targetRow = -1;
    private int hitArg = -1;
    private float buildCooldown = 0f, gridCooldown = 0f, mineCooldown = 0f;

    // ---- game state -----------------------------------------------------------------
    private int screen = SCREEN_LOADING;
    private ModManager mods;
    private GiftWeb giftWeb;
    private MediaPlayer music;
    private boolean hostActive = true;
    private int loadStage = 0, nextAfterLoad = SCREEN_MENU;
    private long loadStartNanos = 0L;
    private float loadShown = 0f;
    private Bitmap bannerYt, bannerTt;
    private int modPage = 0;
    private static final int LOAD_STAGES = 8;
    private int inventory = MAX_INVENTORY, winCount = 0;
    private float hp = 100f;
    private float gameClock = 0f, regenClock = 0f, lastPlaceSound = -1f;
    private float shieldUntil = -1f;
    private String toastText = "";
    private float toastUntil = -1f;
    private final float[] giftFlash = new float[GameSettings.GIFTS];
    private int rainLeft = 0;
    private float rainClock = 0f;
    private long playerPlaceUntilNanos = 0L;
    private float pressCenterX = -1000f, pressCenterY = -1000f;
    private long pressUntilNanos = 0L;
    private int countdownValue = -1;
    private float cdClock = 0f, cancelT = 0f;
    private float shake = 0f;
    private boolean sessionActive = false, dead = false, gameExists = false;
    private int lives = 0;
    private float hurtFlash = 0f, shieldHit = 0f, healT = 0f, lastShieldSnd = -1f, winFlashT = 0f,
            lastEventSnd = -1f, lastHurtSnd = -1f;

    // TNT entities.
    private final boolean[] tntOn = new boolean[MAX_TNT];
    private final float[] tntY = new float[MAX_TNT], tntVy = new float[MAX_TNT], tntFuse = new float[MAX_TNT];
    private final int[] tntCol = new int[MAX_TNT];

    // Particles and explosion rings.
    private final float[] px = new float[MAX_PARTICLES], py = new float[MAX_PARTICLES];
    private final float[] pvx = new float[MAX_PARTICLES], pvy = new float[MAX_PARTICLES];
    private final float[] plife = new float[MAX_PARTICLES];
    private final int[] pcol = new int[MAX_PARTICLES];
    private final float[] fxX = new float[MAX_FX], fxY = new float[MAX_FX], fxT = new float[MAX_FX],
            fxS = new float[MAX_FX];

    // Tornadoes, helper robots, meteors, lightning bolts.
    private final boolean[] twOn = new boolean[MAX_TORNADO];
    private final float[] twX = new float[MAX_TORNADO], twY = new float[MAX_TORNADO],
            twLife = new float[MAX_TORNADO], twHit = new float[MAX_TORNADO];
    private final float[] dbX = new float[MAX_DEBRIS], dbY = new float[MAX_DEBRIS], dbVx = new float[MAX_DEBRIS],
            dbVy = new float[MAX_DEBRIS], dbRot = new float[MAX_DEBRIS], dbLife = new float[MAX_DEBRIS];
    private final int[] dbType = new int[MAX_DEBRIS];
    // Monster (one at a time): 0 enter, 1 charge, 2 beam, 3 leave
    private boolean moOn = false;
    private int moPhase = 0;
    private float moX, moY, moT, moDig, moDir = 1f, moAlpha = 1f;
    private final int[] twDir = new int[MAX_TORNADO];
    private final boolean[] rbOn = new boolean[MAX_ROBOT];
    private final float[] rbX = new float[MAX_ROBOT], rbY = new float[MAX_ROBOT],
            rbLife = new float[MAX_ROBOT], rbAct = new float[MAX_ROBOT];
    private final int[] rbCol = new int[MAX_ROBOT], rbDir = new int[MAX_ROBOT];
    private final int[] rbTR = new int[MAX_ROBOT], rbTC = new int[MAX_ROBOT];
    private final float[] rbHold = new float[MAX_ROBOT];
    private final String[] rbName = new String[MAX_ROBOT], twName = new String[MAX_TORNADO];
    private final boolean[] rbOut = new boolean[MAX_ROBOT];
    private final float[] rbIdle = new float[MAX_ROBOT], rbFade = new float[MAX_ROBOT];
    private final float[] twVy = new float[MAX_TORNADO], twFeet = new float[MAX_TORNADO];
    private String moName = "";
    // v28: nuclear missile (falls from the sky), TNT thrower (a boy), dragon (side view), drill machine, auto zoom
    private static final int MAX_NUKE = 4, MAX_THROWER = 2, MAX_THROWN = 14, MAX_DRILL = 3;
    private final boolean[] nkOn = new boolean[MAX_NUKE], nkBoom = new boolean[MAX_NUKE];
    private final float[] nkX = new float[MAX_NUKE], nkY = new float[MAX_NUKE], nkVy = new float[MAX_NUKE],
            nkT = new float[MAX_NUKE], nkBy = new float[MAX_NUKE];
    private final String[] nkName = new String[MAX_NUKE];
    private final boolean[] thOn = new boolean[MAX_THROWER], thIn = new boolean[MAX_THROWER], thOut = new boolean[MAX_THROWER],
            thPend = new boolean[MAX_THROWER];
    private final float[] thX = new float[MAX_THROWER], thY = new float[MAX_THROWER], thT = new float[MAX_THROWER],
            thClock = new float[MAX_THROWER], thPose = new float[MAX_THROWER];
    private final int[] thDir = new int[MAX_THROWER];
    private final String[] thName = new String[MAX_THROWER];
    private final boolean[] pjOn = new boolean[MAX_THROWN];
    private final float[] pjX = new float[MAX_THROWN], pjY = new float[MAX_THROWN], pjVx = new float[MAX_THROWN],
            pjVy = new float[MAX_THROWN], pjRot = new float[MAX_THROWN];
    private final int[] pjCol = new int[MAX_THROWN];
    private final boolean[] drOn = new boolean[MAX_DRILL];
    private final int[] drState = new int[MAX_DRILL], drRow = new int[MAX_DRILL], drCol = new int[MAX_DRILL];
    private final float[] drX = new float[MAX_DRILL], drY = new float[MAX_DRILL], drT = new float[MAX_DRILL],
            drDust = new float[MAX_DRILL], drSnd = new float[MAX_DRILL], drFade = new float[MAX_DRILL];
    private final String[] drName = new String[MAX_DRILL];
    private boolean bsOn = false;                  // dragon: 0 fly in, 1 charge, 2 flame, 3 leave
    private int bsPhase = 0, bsFace = 1;
    private float bsX, bsY, bsT, bsDig, bsAimX, bsAimY, bsSnd, bsBlast;
    private String bsName = "";
    private float zoom = 1f, zoomHold = 0f;
    private static final float ZOOM_OUT = 0.68f;
    private int tntRot = 0;
    private int blastSnd = 0;                      // sound override for the next blastAt()
    private final Bitmap[] thrFrames = new Bitmap[8], dragonF = new Bitmap[6], dragonR = new Bitmap[2],
            nukeBoom = new Bitmap[5], drillFrames = new Bitmap[12];
    private Bitmap nukeBody;
    private int sBoom1, sBoom2, sBoomBig, sFuse2, sThrow, sFlame, sBoss, sNuke, sWhistle, sDrill;
    private float deadT = 0f, protectUntil = -1f;
    private int underCol = -1;                 // last column used by the place-under-player button
    private final boolean[] mtOn = new boolean[MAX_METEOR];
    private final float[] mtX = new float[MAX_METEOR], mtY = new float[MAX_METEOR],
            mtVx = new float[MAX_METEOR], mtVy = new float[MAX_METEOR];
    private final float[] blT = new float[MAX_BOLT], blY = new float[MAX_BOLT];
    private final int[] blCol = new int[MAX_BOLT];
    private float flash = 0f;
    private final int[] pend = new int[GameSettings.EFFECTS];
    @SuppressWarnings("unchecked")
    private final java.util.ArrayList<String>[] pendWho = new java.util.ArrayList[GameSettings.EFFECTS];
    private float pendClock = 0f;

    // TikTok notifications (feed) and like counter.
    private final String[] feedText = new String[FEED_LINES];
    private final float[] feedUntil = new float[FEED_LINES];
    private final int[] feedColor = new int[FEED_LINES], feedIcon = new int[FEED_LINES];
    private final String[] feedName = new String[FEED_LINES];
    private int likeAcc = 0;
    private boolean recentDirty = false;
    private float lastRecentSave = 0f;

    // Sound.
    private SoundPool pool;
    private final int[] sSteps = new int[3], sRuns = new int[3], sPuts = new int[2];
    private int stepRot = 0, putRot = 0;
    private int sJump, sLand, sPlace, sBreak, sNoGo, sClick, sFuse,
            sLightning, sTornado, sMeteorFall, sMeteorHit, sRobot, sRobotPlace, sHeal, sShieldOn, sShieldBlock,
            sHurt, sDie, sMonster, sBeam, sCharge, sTick, sCancel, sWin, sLose, sGift, sFollow, sLike, sJoin,
            sShare, sChat;

    public AreaView(Context context) {
        super(context);
        cfg = new GameSettings(context);
        mods = new ModManager(context, cfg);
        giftWeb = new GiftWeb(context.getCacheDir());
        for (int i = 0; i < pendWho.length; i++) pendWho[i] = new java.util.ArrayList<>();
        for (int i = 0; i < uiRects.length; i++) uiRects[i] = new RectF();
        for (int i = 0; i < GameSettings.GIFTS; i++) giftRects[i] = new RectF();
        for (int r = 0; r < ROWS; r++) for (int c = 0; c < COLS; c++) blocks[r][c] = -1;
        for (int i = 0; i < 6; i++) { hit[i] = new RectF(); icon[i] = new RectF(); }
        for (int i = 0; i < MAX_FX; i++) fxT[i] = -1f;

        playerX = GRID_X + (COLS * CELL) / 2f;
        playerFeet = FLOOR_Y;
        paint.setFilterBitmap(false);
        paint.setAntiAlias(false);

        if (cfg.autoConnect && cfg.user.trim().length() > 0) startLive();
        setFocusable(true);
        setFocusableInTouchMode(true);
        if (Build.VERSION.SDK_INT >= 26) setDefaultFocusHighlightEnabled(false);
        requestFocus();
    }

    // ================================================================================
    // Resources
    // ================================================================================
    private Bitmap load(String path) {
        InputStream in = null;
        try {
            in = mods == null ? null : mods.open(path);
            if (in == null) in = getContext().getAssets().open(path);
            return BitmapFactory.decodeStream(in);
        } catch (Exception e) {
            return null;
        } finally {
            try { if (in != null) in.close(); } catch (Exception ignored) { }
        }
    }

    private int averageColor(Bitmap b) {
        if (b == null || b.getWidth() < 4 || b.getHeight() < 4) return 0xff8a8a8a;
        long r = 0, g = 0, bl = 0;
        int n = 0;
        for (int yy = 0; yy < 4; yy++) {
            for (int xx = 0; xx < 4; xx++) {
                int p = b.getPixel((xx * 2 + 1) * b.getWidth() / 8, (yy * 2 + 1) * b.getHeight() / 8);
                r += (p >> 16) & 255; g += (p >> 8) & 255; bl += p & 255; n++;
            }
        }
        return 0xff000000 | ((int) (r / n) << 16) | ((int) (g / n) << 8) | (int) (bl / n);
    }

    /** Fraction of the bitmap height that is transparent at the bottom (so feet sit on the floor). */
    private float bottomPadding(Bitmap b) {
        if (b == null) return 0f;
        int w = b.getWidth(), h = b.getHeight();
        for (int y = h - 1; y >= 0; y--) {
            for (int x = 0; x < w; x += 2) {
                if (((b.getPixel(x, y) >> 24) & 255) > 40) return (h - 1 - y) / (float) h;
            }
        }
        return 0f;
    }

    // ---- staged loading (loading screen) ----------------------------------------------------
    private void loadStep() {
        switch (loadStage) {
            case 0:
                menuBackground = load("menu/background.jpg");
                pauseIcon = load("menu/icon_pause.png");
                bannerYt = load("ui/banner_youtube.png");
                bannerTt = load("ui/banner_tiktok.png");
                break;
            case 1:
                fontAtlas = load("font/pixel_font.png");
                placementFrame = load("blocks/placement_frame.png");
                hudBar = load("ui/hud_bar.png");
                hudCube = load("ui/hud_cube.png");
                hudTrophy = load("ui/hud_trophy.png");
                hudHp = load("ui/hud_hp.png");
                leftImage = load("ui/control_left.png");
                rightImage = load("ui/control_right.png");
                runImage = load("ui/control_run.png");
                pickImage = load("ui/control_pickaxe.png");
                blockImage = load("ui/control_block.png");
                jumpImage = load("ui/control_jump.png");
                break;
            case 2:
                for (int i = 0; i < BLOCK_TYPES; i++) {
                    blockTextures[i] = load(String.format(Locale.US, "blocks/block_%02d.png", i));
                    blockColor[i] = averageColor(blockTextures[i]);
                }
                break;
            case 3:
                for (int i = 0; i < 7; i++) tntFrames[i] = load("fx/tnt_" + i + ".png");
                for (int i = 0; i < 8; i++) boomFrames[i] = load("fx/boom_" + i + ".png");
                applyLook();
                break;
            case 4: {
                final String[] fxNames = {"block", "tnt", "tnt", "none", "heart", "shield", "lightning", "tornado", "robot",
                        "meteor", "monster", "missile", "thrower", "boss", "drill"};
                for (int i = 0; i < GameSettings.EFFECTS; i++) {
                    fxIcon[i] = load("ui/fx_" + fxNames[i] + ".png");
                    if (fxIcon[i] == null) fxIcon[i] = glyph("bolt");
                }
                final String[] evNames = {"follow", "share", "join", "like", "chat", "sub", "gift"};
                for (int i = 0; i < GameSettings.EVENTS; i++) evIcon[i] = load("ui/ev_" + evNames[i] + ".png");
                for (int i = 0; i < 3; i++) {
                    robotFrames[i] = load("fx/robot_" + i + ".png");
                    tornadoFrames[i] = load("fx/tornado_" + i + ".png");
                    monsterFrames[i] = load("fx/monster_" + i + ".png");
                }
                for (int i = 0; i < 8; i++) thrFrames[i] = load("fx/thr_" + i + ".png");
                for (int i = 0; i < 6; i++) dragonF[i] = load("fx/dragon_f" + i + ".png");
                for (int i = 0; i < 2; i++) dragonR[i] = load("fx/dragon_r" + i + ".png");
                nukeBody = load("fx/nuke_0.png");
                for (int i = 0; i < 5; i++) nukeBoom[i] = load("fx/nuke_boom_" + i + ".png");
                for (int i = 0; i < 12; i++) drillFrames[i] = load("fx/drill_" + i + ".png");
                break;
            }
            case 5: {
                final String[] gl = {"play", "pause", "gear", "gift", "wifi", "bolt", "palette", "sound_on", "sound_off", "back",
                        "plus", "minus", "check", "cross", "eye", "eye_off", "refresh", "home", "heart", "tap", "flask", "user",
                        "timer", "trophy", "keyboard", "trash", "list", "map"};
                for (String n : gl) glyph(n);
                break;
            }
            case 6:
                initSound();
                break;
            default:
                giftWeb.ensureCatalog();
                break;
        }
        loadStage++;
    }

    /** Runs the loading steps again (after a mod was switched) and then opens {@code next}. */
    private void beginLoad(int next) {
        glyphs.clear();
        for (int i = 0; i < giftSprite.length; i++) giftSprite[i] = null;
        for (int i = 0; i < charPreview.length; i++) charPreview[i] = null;
        loadedMap = -1; loadedChar = -1;
        if (pool != null) { try { pool.release(); } catch (Throwable ignored) { } pool = null; }
        stopMusic();
        mods.scan();
        loadStage = 0;
        loadShown = 0f;
        loadStartNanos = 0L;
        nextAfterLoad = next;
        screen = SCREEN_LOADING;
    }

    private void advanceLoading() {
        long t = now();
        if (loadStartNanos == 0L) { loadStartNanos = t; return; }
        if (loadStage < LOAD_STAGES) {
            try { loadStep(); } catch (Throwable ignored) { loadStage++; }
        }
        float real = loadStage / (float) LOAD_STAGES;
        float timed = Math.min(1f, (t - loadStartNanos) / 1.2e9f);
        loadShown = Math.max(loadShown, Math.min(real, timed));
        if (loadStage >= LOAD_STAGES && t - loadStartNanos > 1.0e9f) {
            loadShown = 1f;
            screen = nextAfterLoad;
            lastFrameNanos = 0L;
            applyMusic();
        }
    }

    private void drawLoading(Canvas canvas) {
        float h = logicalHeight(), cx = WORLD_W / 2f;
        drawMenuBackground(canvas, 0xb0000000);
        textRaw(canvas, "BLOCK RUSH", cx, h * 0.36f, 54f, 0xffffd34a, 8f);
        textRaw(canvas, "MINECRAFT 2D  -  LIVE GAME", cx, h * 0.36f + 42f, 14f, 0xffffffff, 4f);
        float bw = 320f, bx = cx - bw / 2f, by = h * 0.55f;
        roundRect(canvas, bx - 4f, by - 4f, bx + bw + 4f, by + 24f, 10f, 0xff0b0c10);
        roundRect(canvas, bx, by, bx + bw, by + 20f, 8f, 0xff262b3b);
        float f = clampFloat(loadShown, 0f, 1f);
        if (f > 0.02f) {
            roundRect(canvas, bx, by, bx + bw * f, by + 20f, 8f, 0xff3bbf52);
            roundRect(canvas, bx + 2f, by + 2f, bx + bw * f - 2f, by + 8f, 4f, 0x44ffffff);
        }
        textRaw(canvas, "MEMUAT...  " + (int) (f * 100f) + "%", cx, by + 44f, 15f, 0xffffffff, 4f);
        String[] tips = {"Kirim gift ke live untuk memicu efek", "Ketuk gambar gift di atas untuk uji efek",
                "10 blok ke samping = 1 lapisan, 40 lapisan = menang", "Perisai menahan semua kerusakan sementara"};
        textRaw(canvas, tips[(int) ((now() / 2_500_000_000L) % tips.length)], cx, by + 74f, 11f, 0xffdddddd, 3f);
    }

    /** Loads the arena picture and the character frames for the selected map / character. */
    private void applyLook() {
        if (loadedMap != cfg.map) {
            arena = load(cfg.map == 0 ? "area/arena_reference.png" : "area/arena_" + cfg.map + ".png");
            loadedMap = cfg.map;
        }
        if (loadedChar != cfg.character) {
            String pre = cfg.character == 0 ? "" : "c" + cfg.character + "_";
            String[] actions = {"walk", "run", "jump"};
            for (int a = 0; a < 3; a++) {
                for (int f = 0; f < 5; f++) {
                    characterFrames[a][f] = load("character/" + pre + actions[a] + "_" + f + ".png");
                    characterBottom[a][f] = bottomPadding(characterFrames[a][f]);
                }
            }
            loadedChar = cfg.character;
        }
    }

    private Bitmap previewOf(int ch) {
        if (charPreview[ch] == null) charPreview[ch] = load("character/" + (ch == 0 ? "" : "c" + ch + "_") + "walk_0.png");
        return charPreview[ch];
    }

    private void startLive() {
        live.start(cfg.liveMode == 0 ? LiveClient.MODE_DIRECT : LiveClient.MODE_BRIDGE, cfg.host, cfg.port, cfg.user, cfg.apiKey);
    }

    /** Small UI glyph (assets/ui/ic_<name>.png), loaded once. */
    private Bitmap glyph(String name) {
        Bitmap b = glyphs.get(name);
        if (b == null && !glyphs.containsKey(name)) {
            b = load("ui/ic_" + name + ".png");
            glyphs.put(name, b);
        }
        return b;
    }

    /** Gift sprite cell (0..255), loaded on first use. */
    private Bitmap spriteCell(int cell) {
        if (cell < 0 || cell >= 256) return null;
        if (giftSprite[cell] == null) giftSprite[cell] = load("gift/g" + cell + ".png");
        return giftSprite[cell];
    }

    /** Icon id: 0..EFFECTS-1 = effect picture, 100+cell = gift sprite. */
    private Bitmap iconBitmap(int id) {
        if (id >= GiftCatalog.SPRITE_BASE) return spriteCell(id - GiftCatalog.SPRITE_BASE);
        if (id >= 0 && id < GameSettings.EFFECTS) return fxIcon[id];
        return spriteCell(255);
    }

    /** Picture for a gift: mod icon or real web picture when the slot uses the automatic icon, else the built-in sprite. */
    private Bitmap giftBitmap(String name, int icon) {
        if (name != null && name.length() > 0 && (icon == GiftCatalog.GENERIC_ICON || icon == GiftCatalog.iconFor(name))) {
            ModManager.ModGift mg = mods == null ? null : mods.giftFor(name);
            if (mg != null) { Bitmap b = mods.iconOf(mg); if (b != null) return b; }
            Bitmap w = giftWeb == null ? null : giftWeb.get(name);
            if (w != null) return w;
            return iconBitmap(GiftCatalog.GENERIC_ICON);     // website picture still loading / offline: plain gift box (never the bundled sheet)
        }
        return iconBitmap(icon);
    }

    private void initSound() {
        try {
            AudioAttributes attrs = captureAttrs(AudioAttributes.CONTENT_TYPE_SONIFICATION);
            pool = new SoundPool.Builder().setMaxStreams(10).setAudioAttributes(attrs).build();
            sJump = loadSound("sfx_jump"); sLand = loadSound("sfx_land"); for (int i = 0; i < 3; i++) { sSteps[i] = loadSound("sfx_step" + (i + 1)); sRuns[i] = loadSound("sfx_run" + (i + 1)); }
            for (int i = 0; i < 2; i++) sPuts[i] = loadSound("sfx_put" + (i + 1));
            sPlace = loadSound("sfx_place"); sBreak = loadSound("sfx_break");
            sNoGo = loadSound("sfx_nogo"); sClick = loadSound("sfx_click"); sFuse = loadSound("sfx_fuse");
            sBoom1 = loadSound("sfx_boom1"); sBoom2 = loadSound("sfx_boom2"); sBoomBig = loadSound("sfx_boom_big");
            sFuse2 = loadSound("sfx_fuse2"); sThrow = loadSound("sfx_throw");
            sNuke = loadSound("sfx_nuke"); sWhistle = loadSound("sfx_whistle"); sDrill = loadSound("sfx_drill");
            sFlame = loadSound("sfx_flame"); sBoss = loadSound("sfx_boss");
            sLightning = loadSound("sfx_lightning"); sTornado = loadSound("sfx_tornado");
            sMeteorFall = loadSound("sfx_meteor_fall"); sMeteorHit = loadSound("sfx_meteor_hit");
            sRobot = loadSound("sfx_robot"); sRobotPlace = loadSound("sfx_robot_place"); sHeal = loadSound("sfx_heal");
            sShieldOn = loadSound("sfx_shield_on"); sShieldBlock = loadSound("sfx_shield_block");
            sHurt = loadSound("sfx_hurt"); sDie = loadSound("sfx_die"); sMonster = loadSound("sfx_monster");
            sBeam = loadSound("sfx_beam"); sCharge = loadSound("sfx_charge"); sTick = loadSound("sfx_tick");
            sCancel = loadSound("sfx_cancel"); sWin = loadSound("sfx_win"); sLose = loadSound("sfx_lose");
            sGift = loadSound("sfx_gift"); sFollow = loadSound("sfx_follow"); sLike = loadSound("sfx_like");
            sJoin = loadSound("sfx_join"); sShare = loadSound("sfx_share"); sChat = loadSound("sfx_chat");
        } catch (Throwable t) {
            pool = null;
        }
    }

    private int loadSound(String name) {
        try {
            File mf = mods == null ? null : mods.find("sounds/" + name + ".wav");
            if (mf != null) return pool.load(mf.getAbsolutePath(), 1);
            File f = new File(getContext().getCacheDir(), "snd28_" + name + ".wav");
            if (!f.exists() || f.length() == 0) {
                InputStream in = getContext().getAssets().open("sounds/" + name + ".wav");
                FileOutputStream out = new FileOutputStream(f);
                byte[] buf = new byte[4096];
                int n;
                while ((n = in.read(buf)) > 0) out.write(buf, 0, n);
                out.close();
                in.close();
            }
            return pool.load(f.getAbsolutePath(), 1);
        } catch (Throwable t) {
            return 0;
        }
    }

    private void play(int id, float volume, float rate) {
        if (pool == null || !cfg.sound || id == 0) return;
        float v = volume * cfg.sfxVol / 100f;
        if (v <= 0.002f) return;
        try { pool.play(id, v, v, 1, 0, rate); } catch (Throwable ignored) { }
    }

    /** Button click sound (own on/off switch, follows the effect volume). */
    private void playUi() {
        if (pool == null || !cfg.clickSound || sClick == 0 || cfg.sfxVol <= 0) return;
        float v = 0.75f * cfg.sfxVol / 100f;
        try { pool.play(sClick, v, v, 1, 0, 1f); } catch (Throwable ignored) { }
    }

    private MediaPlayer makeMusic() throws Exception {
        File mf = mods.find("music/bgm.wav");
        String path;
        if (mf != null) path = mf.getAbsolutePath();
        else {
            File f = new File(getContext().getCacheDir(), "bgm_v24.wav");
            if (!f.exists() || f.length() == 0) {
                InputStream in = getContext().getAssets().open("music/bgm.wav");
                FileOutputStream out = new FileOutputStream(f);
                byte[] buf = new byte[8192];
                int n;
                while ((n = in.read(buf)) > 0) out.write(buf, 0, n);
                out.close();
                in.close();
            }
            path = f.getAbsolutePath();
        }
        MediaPlayer mp = new MediaPlayer();
        mp.setAudioAttributes(captureAttrs(AudioAttributes.CONTENT_TYPE_MUSIC));
        mp.setDataSource(path);
        mp.setLooping(true);
        mp.prepare();
        return mp;
    }

    /** Starts / pauses / re-volumes the background music from the settings. */
    private void applyMusic() {
        try {
            boolean want = cfg.musicOn && cfg.musicVol > 0 && hostActive && screen != SCREEN_LOADING;
            if (want && music == null) music = makeMusic();
            if (music == null) return;
            float v = cfg.musicVol / 100f * 0.6f;
            music.setVolume(v, v);
            if (want && !music.isPlaying()) music.start();
            else if (!want && music.isPlaying()) music.pause();
        } catch (Throwable t) {
            music = null;
        }
    }

    private void stopMusic() {
        if (music == null) return;
        try { music.release(); } catch (Throwable ignored) { }
        music = null;
    }

    // ---- custom effect sounds (own audio file per gift / event) -----------------------------
    public interface SoundPicker { void pick(int kind, int index); }

    private SoundPicker soundPicker;
    private final java.util.HashMap<String, MediaPlayer> customPlayers = new java.util.HashMap<>();

    public void setSoundPicker(SoundPicker sp) { soundPicker = sp; }

    private AudioAttributes captureAttrs(int contentType) {
        AudioAttributes.Builder b = new AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_GAME).setContentType(contentType);
        if (Build.VERSION.SDK_INT >= 29) b.setAllowedCapturePolicy(AudioAttributes.ALLOW_CAPTURE_BY_ALL);   // screen recorder / live can hear it
        return b.build();
    }

    /** Plays the user's own sound file; false when none is set / it cannot be played (then the default sound plays). */
    private boolean playCustom(String path) {
        if (path == null || path.length() == 0) return false;
        if (!cfg.sound) return true;
        try {
            File f = new File(path);
            if (!f.exists()) return false;
            MediaPlayer old = customPlayers.remove(path);
            if (old != null) { try { old.stop(); } catch (Throwable ignored) { } try { old.release(); } catch (Throwable ignored) { } }
            final String key = path;
            final MediaPlayer mp = new MediaPlayer();
            mp.setAudioAttributes(captureAttrs(AudioAttributes.CONTENT_TYPE_SONIFICATION));
            mp.setDataSource(path);
            float v = Math.max(0f, Math.min(1f, cfg.sfxVol / 100f));
            mp.setVolume(v, v);
            mp.setOnPreparedListener(new MediaPlayer.OnPreparedListener() {
                @Override public void onPrepared(MediaPlayer m) { try { m.start(); } catch (Throwable ignored) { } }
            });
            mp.setOnCompletionListener(new MediaPlayer.OnCompletionListener() {
                @Override public void onCompletion(MediaPlayer m) {
                    if (customPlayers.get(key) == m) customPlayers.remove(key);
                    try { m.release(); } catch (Throwable ignored) { }
                }
            });
            mp.setOnErrorListener(new MediaPlayer.OnErrorListener() {
                @Override public boolean onError(MediaPlayer m, int what, int extra) {
                    if (customPlayers.get(key) == m) customPlayers.remove(key);
                    try { m.release(); } catch (Throwable ignored) { }
                    return true;
                }
            });
            customPlayers.put(path, mp);
            mp.prepareAsync();
            return true;
        } catch (Throwable t) {
            return false;
        }
    }

    /** kind 0 = gift slot, 1 = event rule. Called by the activity after the file was copied into the app. */
    public void onSoundPicked(int kind, int index, String path, String name) {
        if (kind == 0 && index >= 0 && index < GameSettings.GIFTS) {
            GameSettings.Gift g = cfg.gifts[index];
            deleteOwnSound(g.sound); g.sound = path; g.soundName = name;
        } else if (kind == 1 && index >= 0 && index < GameSettings.EVENTS) {
            GameSettings.Rule r = cfg.rules[index];
            deleteOwnSound(r.sound); r.sound = path; r.soundName = name;
        } else return;
        cfg.save();
        toast("SUARA DIPASANG");
        playCustom(path);
    }

    private void deleteOwnSound(String path) {
        if (path == null || path.length() == 0) return;
        try { if (path.contains("/sfx/")) new File(path).delete(); } catch (Throwable ignored) { }
    }

    private void clearSound(int kind, int index) {
        if (kind == 0 && index >= 0 && index < GameSettings.GIFTS) {
            GameSettings.Gift g = cfg.gifts[index]; deleteOwnSound(g.sound); g.sound = ""; g.soundName = "";
        } else if (kind == 1 && index >= 0 && index < GameSettings.EVENTS) {
            GameSettings.Rule r = cfg.rules[index]; deleteOwnSound(r.sound); r.sound = ""; r.soundName = "";
        } else return;
        cfg.save();
    }

    private void pickSound(int kind, int index) {
        if (soundPicker == null) { toast("PEMILIH FILE TIDAK TERSEDIA"); return; }
        try { soundPicker.pick(kind, index); } catch (Throwable t) { toast("TIDAK BISA MEMBUKA FILE"); }
    }

    /** Called by the activity when it is destroyed. */
    public void release() {
        for (MediaPlayer m : customPlayers.values()) { try { m.release(); } catch (Throwable ignored) { } }
        customPlayers.clear();
        live.stop();
        stopMusic();
        if (giftWeb != null) giftWeb.shutdown();
        if (pool != null) {
            try { pool.release(); } catch (Throwable ignored) { }
            pool = null;
        }
    }

    protected long now() { return System.nanoTime(); }

    // ================================================================================
    // Layout helpers
    // ================================================================================
    private float scale() { return Math.min(getWidth() / WORLD_W, getHeight() / MIN_LOGICAL_H); }
    private float offsetX() { return (getWidth() - WORLD_W * scale()) * 0.5f; }
    private float logicalHeight() { return getHeight() / Math.max(0.001f, scale()); }
    private float controlHeight() {
        if (!cfg.showButtons) return 0f;
        return Math.min(MAX_CONTROL_H, Math.max(MIN_CONTROL_H, logicalHeight() - BOARD_H));
    }
    private float controlTop() { return logicalHeight() - controlHeight(); }
    private float hudOff() { return Math.max(0, Math.min(80, cfg.hudOffset)); }
    /** Bottom edge of the HUD block (gift row etc.). */
    private float hudTop() { return Math.min(AREA_TOP + hudOff() + tileExtra, Math.max(0f, controlTop() - 360f)); }
    /** Where the arena starts: 0 when the HUD is transparent (arena visible behind it). */
    private float areaTop() { return cfg.hudTransparent ? 0f : hudTop(); }
    private float boardViewportHeight() { return Math.max(360f, controlTop() - areaTop()); }
    private float worldToScreenY(float y) { return areaTop() + y - cameraY; }
    private int clamp(int value, int min, int max) { return Math.max(min, Math.min(max, value)); }
    private float clampFloat(float v, float min, float max) { return Math.max(min, Math.min(max, v)); }
    private int playerColumn() { return clamp((int) ((playerX - GRID_X) / CELL), 0, COLS - 1); }
    private float toLogicalX(float pxv) { return (pxv - offsetX()) / Math.max(0.001f, scale()); }
    private float toLogicalY(float pyv) { return pyv / Math.max(0.001f, scale()); }
    private float minCamera() {
        float base = -PLAYER_H * 1.2f;
        if (!cfg.hudTransparent) return base;
        // transparent HUD covers the arena: keep the top row (and the player's whole jump) visible just below the HUD
        return Math.min(base, GRID_Y - hudTop() / zoom - JUMP_SPEED * JUMP_SPEED / (2f * GRAVITY) - PLAYER_H - 12f);
    }
    private float maxCamera() { return Math.max(minCamera(), FLOOR_Y + 260f - viewH()); }
    /** Height of the world that is visible (more than the screen height when zoomed out). */
    private float viewH() { return boardViewportHeight() / zoom; }
    /** Top of the visible world, just below the HUD when that is transparent. */
    private float vTop() { return cameraY + (cfg.hudTransparent ? hudTop() / zoom : 0f); }
    private float exX() { return (1f / zoom - 1f) * WORLD_W / 2f; }
    private float worldX(float x) { return WORLD_W / 2f + (x - WORLD_W / 2f) / zoom; }
    private float worldY(float y) { float t = areaTop(); return t + (y - t) / zoom; }

    /** Row of the cell the player's feet are in (the cell a block under the player will fill). */
    private int feetRow() {
        return (int) Math.floor((playerFeet - 1f - GRID_Y) / CELL);
    }

    // ================================================================================
    // Board queries
    // ================================================================================
    private int topBlockRow(int col) {
        for (int r = BUILD_LIMIT_ROW; r < ROWS; r++) if (blocks[r][col] >= 0) return r;
        return ROWS;
    }

    private int blockCount() {
        int n = 0;
        for (int[] row : blocks) for (int v : row) if (v >= 0) n++;
        return n;
    }

    /** Number of completely filled rows (10 blocks across = 1 layer). */
    private int layerCount() {
        int n = 0;
        for (int r = 0; r < ROWS; r++) {
            boolean full = true;
            for (int c = 0; c < COLS; c++) if (blocks[r][c] < 0) { full = false; break; }
            if (full) n++;
        }
        return n;
    }

    private int areaPercent() {
        return Math.min(100, Math.round(layerCount() * 100f / ROWS));
    }

    // Floor row = dirt, then every material lasts two rows.
    private int materialForRow(int row) {
        int layer = (ROWS - 1) - row;
        int idx = layer == 0 ? 0 : 1 + (layer - 1) / 2;
        return LADDER[idx % LADDER.length];
    }

    private int pickType(int row) {
        int base = materialForRow(row);
        if (base == 2 && rnd.nextInt(100) < 12) return ORES[rnd.nextInt(ORES.length)];
        return base;
    }

    private boolean isSprint() { return sprintToggle || keyShift; }
    private boolean shieldOn() { return gameClock < shieldUntil; }

    private static final String[] BTN_NAMES = {"KIRI", "KANAN", "LARI", "GALI", "BLOK", "LOMPAT"};
    private int btnSel = 4;
    private int btnDrag = -1;
    private float btnDragX, btnDragY;

    /** Default centre and size of control button i (0..5 bottom bar). */
    private void btnBase(int i, float[] out) {
        float y = controlTop() + (controlHeight() - 84f) / 2f;
        float[] xs = {2, 86, 170, 268, 352, 436};
        out[0] = xs[i] + 39f; out[1] = y + 41f; out[2] = 74f; out[3] = 78f;
    }

    private float btnMinY() { return screen == SCREEN_BTNS ? 232f : 150f; }

    /** Final rectangle of button i with the user's offset + size, kept on screen. */
    private void btnRect(int i, RectF out) {
        float[] b = new float[4];
        btnBase(i, b);
        float s = cfg.btnSc[i] / 100f, w = b[2] * s, h = b[3] * s;
        float cx = b[0] + cfg.btnDx[i], cy = b[1] + cfg.btnDy[i];
        cx = clampFloat(cx, w / 2f + 1f, WORLD_W - w / 2f - 1f);
        float maxY = Math.max(btnMinY() + h / 2f, logicalHeight() - h / 2f - 1f);
        cy = clampFloat(cy, btnMinY() + h / 2f, maxY);
        out.set(cx - w / 2f, cy - h / 2f, cx + w / 2f, cy + h / 2f);
    }

    private void layoutControls() {
        RectF r = new RectF();
        for (int i = 0; i < 6; i++) {
            btnRect(i, r);
            icon[i].set(r);
            hit[i].set(r.left - 4f, r.top - 4f, r.right + 4f, r.bottom + 4f);
        }
    }

    /** Moves button i so its centre follows (cx, cy); the offset is stored relative to the default place. */
    private void moveBtn(int i, float cx, float cy) {
        float[] b = new float[4];
        btnBase(i, b);
        cfg.btnDx[i] = Math.round(clampFloat(cx - b[0], -600f, 600f));
        cfg.btnDy[i] = Math.round(clampFloat(cy - b[1], -1600f, 1600f));
        RectF r = new RectF();
        btnRect(i, r);                                   // re-clamp what is stored to what is shown
        cfg.btnDx[i] = Math.round(r.centerX() - b[0]);
        cfg.btnDy[i] = Math.round(r.centerY() - b[1]);
    }

    private void drawButtonsEditor(Canvas canvas) {
        drawMenuBackground(canvas, 0xd0000000);
        float h = logicalHeight(), cx = WORLD_W / 2f;
        layoutControls();
        // the dashed zone where the buttons sit by default
        fill(canvas, 0, controlTop(), WORLD_W, h, 0x33ffffff);
        drawTitle(canvas, "ATUR TOMBOL", 30f);
        textRaw(canvas, "Seret tombol ke tempat nyaman. Ketuk tombol untuk memilih, lalu atur ukurannya.", cx, 54f, 10f, 0xffffffff, 3f);
        textRaw(canvas, "Terpilih: " + BTN_NAMES[btnSel], cx, 76f, 15f, 0xffffe14a, 4f);
        float l = 14f, r = WORLD_W - 14f, y = 90f, rh = 38f;
        drawSizeRow(canvas, l, r, y, rh, "UKURAN " + BTN_NAMES[btnSel], cfg.btnSc[btnSel], B_BE_SM, B_BE_SP);
        y += rh + 6f;
        int avg = 0; for (int i = 0; i < GameSettings.BTNS; i++) avg += cfg.btnSc[i];
        drawSizeRow(canvas, l, r, y, rh, "UKURAN SEMUA", avg / GameSettings.BTNS, B_BE_AM, B_BE_AP);
        y += rh + 6f;
        drawEntry(canvas, l, y, cx - 6f, y + 40f, "trash", "RESET", 2, B_BE_RESET, 15f);
        drawEntry(canvas, cx + 6f, y, r, y + 40f, "home", "SELESAI", 1, B_BACK, 15f);
        // the buttons themselves (same pictures as in the game)
        Bitmap[] images = {leftImage, rightImage, runImage, pickImage, blockImage, jumpImage};
        RectF rr = new RectF();
        for (int i = 0; i < 6; i++) {
            btnRect(i, rr);
            if (i == btnSel) { roundRect(canvas, rr.left - 4f, rr.top - 4f, rr.right + 4f, rr.bottom + 4f, 14f, 0x66ffe14a); }
            drawBitmap(canvas, images[i], rr);
            if (i == btnSel) outline(canvas, rr, 0xffffe14a);
        }
    }

    private float rectCx(int i) { RectF r = new RectF(); btnRect(i, r); return r.centerX(); }
    private float rectCy(int i) { RectF r = new RectF(); btnRect(i, r); return r.centerY(); }

    private void outline(Canvas c, RectF r, int color) {
        paint.setStyle(Paint.Style.STROKE); paint.setStrokeWidth(3f); paint.setColor(color);
        c.drawRoundRect(r, 12f, 12f, paint);
        paint.setStyle(Paint.Style.FILL);
    }

    private void drawSizeRow(Canvas c, float l, float r, float y, float h, String label, int pct, int idMinus, int idPlus) {
        drawPlate(c, l, y, r, y + h, 0xff1b1f2b);
        text(c, label, l + 118f, y + h / 2f, 13f, 0xffffffff, 3.5f, 216f);
        drawChip(c, r - 190f, y + 4f, r - 150f, y + h - 4f, "-", 0, idMinus, 20f);
        text(c, pct + "%", r - 100f, y + h / 2f, 16f, 0xffffe14a, 4f, 80f);
        drawChip(c, r - 50f, y + 4f, r - 10f, y + h - 4f, "+", 0, idPlus, 20f);
    }

    /** Touch handling of the button editor: drag moves the selected button. Returns true when the event is used. */
    private boolean buttonsEditorTouch(MotionEvent e) {
        int a = e.getActionMasked();
        float x = toLogicalX(e.getX()), y = toLogicalY(e.getY());
        if (a == MotionEvent.ACTION_DOWN) {
            if (uiAt(x, y) >= 0) return false;                         // a chip of the panel
            RectF r = new RectF();
            for (int k = GameSettings.BTNS - 1; k >= 0; k--) {
                btnRect(k, r);
                r.inset(-6f, -6f);
                if (r.contains(x, y)) {
                    btnSel = k; btnDrag = k;
                    float[] b = new float[4]; btnRect(k, r);
                    btnDragX = x - r.centerX(); btnDragY = y - r.centerY();
                    return true;
                }
            }
            return false;
        }
        if (a == MotionEvent.ACTION_MOVE && btnDrag >= 0) {
            moveBtn(btnDrag, x - btnDragX, y - btnDragY);
            return true;
        }
        if ((a == MotionEvent.ACTION_UP || a == MotionEvent.ACTION_CANCEL) && btnDrag >= 0) {
            btnDrag = -1;
            cfg.save();
            return true;
        }
        return false;
    }

    /** Only gifts that are active AND set    /** Only gifts that are active AND set to "tampil" are shown (up to the chosen tile count), centered. */
    private void layoutGifts() {
        float off = hudOff();
        pauseRect.set(460f, 4f + off, 504f, 48f + off);
        giftCount = 0;
        tileExtra = 0f;
        int maxTiles = Math.min(GameSettings.SHOWN_MAX, cfg.tileCount);
        for (int i = 0; i < GameSettings.GIFTS && giftCount < maxTiles; i++) {
            if (cfg.gifts[i].on && cfg.gifts[i].show) { giftIdx[giftCount] = i; tileEv[giftCount++] = false; }
        }
        for (int i = 0; i < GameSettings.EVENTS && giftCount < maxTiles; i++) {
            if (cfg.rules[i].on && cfg.rules[i].show) { giftIdx[giftCount] = i; tileEv[giftCount++] = true; }
        }
        if (giftCount == 0) return;
        float gap = 5f;
        int perRow = Math.min(8, giftCount);
        float tw = Math.min(58f, (476f - (perRow - 1) * gap) / perRow);
        float th = tw + 14f, y0 = 96f + off;
        for (int k = 0; k < giftCount; k++) {
            int row = k / 8, col = k % 8;
            int inRow = row == 0 ? Math.min(8, giftCount) : giftCount - 8;
            float total = inRow * tw + (inRow - 1) * gap;
            float x = (WORLD_W - total) / 2f + col * (tw + gap), y = y0 + row * (th + 4f);
            giftRects[k].set(x, y, x + tw, y + th);
        }
        if (giftCount > 8) tileExtra = th + 4f;
    }

    // ================================================================================
    // Drawing primitives
    // ================================================================================
    private void drawBitmap(Canvas canvas, Bitmap bitmap, RectF dst) {
        if (bitmap == null) return;
        paint.setAlpha(255); paint.setFilterBitmap(false); paint.clearShadowLayer();
        canvas.drawBitmap(bitmap, null, dst, paint);
    }

    private void blit(Canvas c, Bitmap b, float l, float t, float r, float bt, boolean smooth) {
        if (b == null) return;
        tmp.set(l, t, r, bt);
        paint.setAlpha(255); paint.setFilterBitmap(smooth);
        c.drawBitmap(b, null, tmp, paint);
        paint.setFilterBitmap(false);
    }

    /** Draw keeping the picture's aspect ratio, centred in the box. */
    private void blitFit(Canvas c, Bitmap b, float l, float t, float r, float bt) {
        if (b == null) return;
        float bw = b.getWidth(), bh = b.getHeight();
        float s = Math.min((r - l) / bw, (bt - t) / bh);
        float w = bw * s, h = bh * s, cx = (l + r) / 2f, cy = (t + bt) / 2f;
        blit(c, b, cx - w / 2f, cy - h / 2f, cx + w / 2f, cy + h / 2f, true);
    }

    private void fill(Canvas c, float l, float t, float r, float b, int color) {
        paint.setStyle(Paint.Style.FILL);
        paint.setColor(color);
        c.drawRect(l, t, r, b, paint);
    }

    private void roundRect(Canvas c, float l, float t, float r, float b, float rad, int color) {
        tmp.set(l, t, r, b);
        paint.setStyle(Paint.Style.FILL);
        paint.setColor(color);
        c.drawRoundRect(tmp, rad, rad, paint);
    }

    /** Dark plate with a gold frame, matching the HUD sprite sheet. */
    private void drawPlate(Canvas c, float l, float t, float r, float b, int fillColor) {
        roundRect(c, l, t, r, b, 8f, 0xff0b0c10);
        roundRect(c, l + 1.5f, t + 1.5f, r - 1.5f, b - 1.5f, 7f, 0xffe9b61a);
        roundRect(c, l + 3.5f, t + 3.5f, r - 3.5f, b - 3.5f, 5f, 0xff7a5a0a);
        roundRect(c, l + 4.5f, t + 4.5f, r - 4.5f, b - 4.5f, 4f, fillColor);
    }

    private String T(String s) { return cfg.lang == 0 ? s : I18n.tr(cfg.lang, s); }
    private String feedLine(String who, String what) { return who + " > " + T(" " + what).trim(); }
    private String feedGift(String who, int n, String nm) { return who + " > " + T(" mengirim ").trim() + " " + n + "x " + nm; }

    private boolean literal = false;              // true: draw as given (names, feed), not translated

    private void textRaw(Canvas c, String text, float cx, float cy, float size, int color, float stroke) {
        if (!literal && cfg.lang != 0) text = I18n.tr(cfg.lang, text);
        paint.setTypeface(Typeface.create("sans-serif-black", Typeface.BOLD));
        if (text == null || text.length() == 0) return;
        paint.setTextAlign(Paint.Align.CENTER);
        paint.setTextSize(size);
        float y = cy + size * 0.36f;
        if (stroke > 0f) {
            paint.setStrokeWidth(stroke);
            paint.setStyle(Paint.Style.STROKE);
            paint.setColor(0xff111318);
            c.drawText(text, cx, y, paint);
        }
        paint.setStyle(Paint.Style.FILL);
        paint.setColor(color);
        c.drawText(text, cx, y, paint);
    }

    /** Text shrunk to fit maxW. */
    private void text(Canvas c, String s, float cx, float cy, float size, int color, float stroke, float maxW) {
        if (!literal && cfg.lang != 0) s = I18n.tr(cfg.lang, s);
        paint.setTypeface(Typeface.create("sans-serif-black", Typeface.BOLD));
        paint.setTextSize(size);
        float w = paint.measureText(s);
        if (w > maxW && w > 0f) size = size * maxW / w;
        textRaw(c, s, cx, cy, size, color, stroke);
    }

    private boolean pressedAt(RectF r) {
        return now() < pressUntilNanos && pressCenterX >= r.left && pressCenterX <= r.right
                && pressCenterY >= r.top && pressCenterY <= r.bottom;
    }

    private void addHit(RectF r, int id) {
        if (uiCount >= uiRects.length) return;
        uiRects[uiCount].set(r);
        uiIds[uiCount] = id;
        uiCount++;
    }

    private int uiAt(float x, float y) {
        for (int i = uiCount - 1; i >= 0; i--) if (uiRects[i].contains(x, y)) return uiIds[i];
        return -1;
    }

    /** style: 0 normal, 1 primary (green), 2 danger (red), 3 on (green), 4 off (grey). */
    private void drawButton(Canvas c, float l, float t, float r, float b, String label, int style, int id, float size) {
        RectF rect = new RectF(l, t, r, b);
        addHit(rect, id);
        boolean pr = pressedAt(rect);
        float off = pr ? 2f : 0f;
        int fillC;
        switch (style) {
            case 1: fillC = 0xff2f9a42; break;
            case 2: fillC = 0xff9a3030; break;
            case 3: fillC = 0xff2f9a42; break;
            case 4: fillC = 0xff4b505e; break;
            default: fillC = 0xff2b3040; break;
        }
        roundRect(c, l, t + 4f, r, b + 4f, 9f, 0x88000000);
        drawPlate(c, l, t + off, r, b + off, fillC);
        roundRect(c, l + 6f, t + off + 6f, r - 6f, t + off + 6f + (b - t) * 0.22f, 3f, 0x26ffffff);
        text(c, label, (l + r) / 2f, (t + b) / 2f + off, size, 0xffffffff, 4f, (r - l) - 20f);
    }

    private void drawChip(Canvas c, float l, float t, float r, float b, String label, int style, int id, float size) {
        RectF rect = new RectF(l, t, r, b);
        if (id >= 0) addHit(rect, id);
        boolean pr = id >= 0 && pressedAt(rect);
        int fillC;
        switch (style) {
            case 3: fillC = 0xff2f9a42; break;
            case 4: fillC = 0xff4b505e; break;
            case 5: fillC = 0xff1a1d27; break;
            default: fillC = 0xff353b4f; break;
        }
        roundRect(c, l, t, r, b, 6f, 0xff0b0c10);
        roundRect(c, l + 1.5f, t + 1.5f, r - 1.5f, b - 1.5f, 5f, pr ? 0xffffe27a : 0xffb98a10);
        roundRect(c, l + 3f, t + 3f, r - 3f, b - 3f, 4f, fillC);
        text(c, label, (l + r) / 2f, (t + b) / 2f, size, 0xffffffff, 3f, (r - l) - 8f);
    }

    private void drawMenuBackground(Canvas canvas, int dim) {
        float h = logicalHeight();
        fill(canvas, 0, 0, WORLD_W, h, 0xff12151f);
        if (menuBackground != null) {
            float bgW = h * menuBackground.getWidth() / Math.max(1f, menuBackground.getHeight());
            if (bgW < WORLD_W) bgW = WORLD_W;
            float left = (WORLD_W - bgW) * 0.5f;
            tmp.set(left, 0, left + bgW, h);
            paint.setAlpha(255); paint.setFilterBitmap(true);
            canvas.drawBitmap(menuBackground, null, tmp, paint);
            paint.setFilterBitmap(false);
        }
        fill(canvas, 0, 0, WORLD_W, h, dim);
    }

    // ================================================================================
    // Main draw loop
    // ================================================================================
    @Override protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        if (getWidth() <= 0 || getHeight() <= 0) return;
        float sc = scale();
        canvas.drawColor(0xff0b0d14);
        canvas.save();
        canvas.translate(offsetX(), 0f);
        canvas.scale(sc, sc);
        canvas.clipRect(0f, 0f, WORLD_W, logicalHeight());
        uiCount = 0;

        if (screen == SCREEN_MENU) {
            drawMenuScreen(canvas);
        } else if (screen == SCREEN_SETTINGS) {
            drawSettingsScreen(canvas);
        } else if (screen == SCREEN_GIFTS) {
            drawGiftsScreen(canvas);
        } else if (screen == SCREEN_TIKTOK) {
            drawTikTokScreen(canvas);
        } else if (screen == SCREEN_EVENTS) {
            drawEventsScreen(canvas);
        } else if (screen == SCREEN_LOOKS) {
            drawLooksScreen(canvas);
        } else if (screen == SCREEN_PICK) {
            drawPickScreen(canvas);
        } else if (screen == SCREEN_ICONS) {
            drawIconsScreen(canvas);
        } else if (screen == SCREEN_FX) {
            drawFxScreen(canvas);
        } else if (screen == SCREEN_BTNS) {
            drawButtonsEditor(canvas);
        } else if (screen == SCREEN_LOADING) {
            drawLoading(canvas);
        } else if (screen == SCREEN_MOD) {
            drawModScreen(canvas);
        } else {
            drawGame(canvas);
            if (screen == SCREEN_PAUSE) drawPauseScreen(canvas);
        }
        canvas.restore();

        if (screen == SCREEN_LOADING) advanceLoading();
        else if (sessionActive) updatePhysics();
        postInvalidateOnAnimation();
    }

    private void drawGame(Canvas canvas) {
        applyLook();
        layoutControls();
        layoutGifts();
        if (lastFrameNanos == 0) {
            cameraY = clampFloat(playerFeet - viewH() * PLAYER_SCREEN_RATIO,
                    minCamera(), maxCamera());
        }
        float top = areaTop();
        canvas.drawColor(MAP_SKY[cfg.map]);

        canvas.save();
        canvas.clipRect(0, top, WORLD_W, logicalHeight());
        if (zoom < 0.999f) canvas.scale(zoom, zoom, WORLD_W / 2f, top);
        if (arena != null) {
            tmp.set(0, top - cameraY, WORLD_W, top + BOARD_H - cameraY);
            drawBitmap(canvas, arena, tmp);
        }
        if (shake > 0.01f) {
            canvas.translate((rnd.nextFloat() - 0.5f) * shake * 7f, (rnd.nextFloat() - 0.5f) * shake * 7f);
        }
        drawSideFill(canvas);
        drawGround(canvas);
        drawPlacedBlocks(canvas);
        drawTnt(canvas);
        drawPlacementTarget(canvas);
        drawPlayer(canvas);
        drawEffects(canvas);
        canvas.restore();

        drawHud(canvas);
        drawGiftRow(canvas);
        drawMinimap(canvas);
        drawHpPanel(canvas);
        drawFeed(canvas);
        drawDeadBanner(canvas);
        if (cfg.showButtons) drawControls(canvas);
        if (toastUntil > gameClock) drawToast(canvas);
        if (countdownValue >= 0 || cancelT > 0f) drawRoundCountdown(canvas);
    }

    /** The reference arena image has raised ground outside the walls; hide it so the floor is consistent. */
    private void drawSideFill(Canvas canvas) {
        float y0 = worldToScreenY(FLOOR_Y - 90f), y1 = worldToScreenY(FLOOR_Y);
        int c = MAP_SKY[cfg.map];
        fill(canvas, -exX() - 2f, y0, 19f, y1, c);
        fill(canvas, 493f, y0, WORLD_W + exX() + 2f, y1, c);
    }

    /** Ground of the selected map: soil continues behind the on-screen buttons. */
    private void drawGround(Canvas canvas) {
        float fy = worldToScreenY(FLOOR_Y);
        float bottom = areaTop() + (logicalHeight() - areaTop()) / zoom;
        float ex = exX();
        int cx0 = -1 - (int) Math.ceil(ex / CELL), cx1 = COLS + 1 + (int) Math.ceil(ex / CELL);
        if (fy >= bottom) return;
        int[] g = MAP_GROUND[cfg.map];
        for (int r = 0; ; r++) {
            float y = fy + r * CELL;
            if (y >= bottom) break;
            if (y + CELL < areaTop()) continue;
            int type = r == 0 ? g[0] : (r <= 4 ? g[1] : g[2]);
            Bitmap tex = blockTextures[type];
            for (int c = cx0; c <= cx1; c++) {
                float x = GRID_X + c * CELL;
                blit(canvas, tex, x, y, x + CELL, y + CELL, false);
            }
            if (r >= 1) {
                int a = Math.min(120, 14 + r * 14);
                fill(canvas, -ex - 2f, y, WORLD_W + ex + 2f, y + CELL, a << 24);
            }
            if (MAP_SHADE[cfg.map] != 0) fill(canvas, -ex - 2f, y, WORLD_W + ex + 2f, y + CELL, MAP_SHADE[cfg.map]);
        }
    }

    // ---- UI building blocks ---------------------------------------------------------------
    private void drawGlyph(Canvas c, String name, float cx, float cy, float size) {
        Bitmap b = glyph(name);
        if (b != null) blit(c, b, cx - size / 2f, cy - size / 2f, cx + size / 2f, cy + size / 2f, true);
    }

    /** Big menu button with an icon on the left. style: 0 normal, 1 primary, 2 danger. */
    private void drawEntry(Canvas c, float l, float t, float r, float b, String gl, String label, int style, int id, float size) {
        RectF rect = new RectF(l, t, r, b);
        addHit(rect, id);
        boolean pr = pressedAt(rect);
        float off = pr ? 2f : 0f;
        int fillC = style == 1 ? 0xff2f9a42 : style == 2 ? 0xff9a3030 : 0xff2b3040;
        roundRect(c, l, t + 4f, r, b + 4f, 9f, 0x88000000);
        drawPlate(c, l, t + off, r, b + off, fillC);
        roundRect(c, l + 6f, t + off + 6f, r - 6f, t + off + 6f + (b - t) * 0.22f, 3f, 0x26ffffff);
        float ih = b - t, gs = ih * 0.52f;
        drawGlyph(c, gl, l + ih * 0.62f, (t + b) / 2f + off, gs);
        text(c, label, (l + ih * 1.1f + r - 10f) / 2f, (t + b) / 2f + off, size, 0xffffffff, 4f, r - l - ih * 1.1f - 14f);
    }

    /** Small chip with an optional bitmap icon on the left. */
    private void drawChipIcon(Canvas c, float l, float t, float r, float b, Bitmap icon, String label, int style, int id, float size) {
        drawChip(c, l, t, r, b, "", style, id, size);
        float ih = b - t - 8f;
        float tx = (l + r) / 2f, maxW = r - l - 8f;
        if (icon != null) {
            blit(c, icon, l + 5f, t + 4f, l + 5f + ih, t + 4f + ih, true);
            tx = (l + 8f + ih + r - 4f) / 2f;
            maxW = r - l - ih - 14f;
        }
        text(c, label, tx, (t + b) / 2f, size, 0xffffffff, 3f, maxW);
    }

    /** Row with a switch on the right. */
    private void drawToggleRow(Canvas c, float l, float r, float y, float h, String gl, String label, boolean on, int k) {
        RectF rect = new RectF(l, y, r, y + h);
        addHit(rect, B_TOG + k);
        drawPlate(c, l, y, r, y + h, pressedAt(rect) ? 0xff2d3345 : 0xff1b1f2b);
        drawGlyph(c, gl, l + 30f, y + h / 2f, 26f);
        text(c, label, l + 56f + 104f, y + h / 2f, 16f, 0xffffffff, 4f, 208f);
        float sw = 62f, sh = 28f, sx = r - 16f - sw, sy = y + (h - sh) / 2f;
        roundRect(c, sx - 2f, sy - 2f, sx + sw + 2f, sy + sh + 2f, sh / 2f + 2f, 0xff0b0c10);
        roundRect(c, sx, sy, sx + sw, sy + sh, sh / 2f, on ? 0xff2f9a42 : 0xff4b505e);
        float kx = on ? sx + sw - sh / 2f : sx + sh / 2f;
        paint.setStyle(Paint.Style.FILL);
        paint.setColor(0xffffffff);
        c.drawCircle(kx, sy + sh / 2f, sh / 2f - 3f, paint);
        text(c, on ? "ON" : "OFF", on ? sx + 18f : sx + sw - 18f, sy + sh / 2f, 11f, 0xffffffff, 3f, 26f);
    }

    /** Row with [-] value [+]  (pm=false: tapping the value just cycles it). */
    private void drawStepRow(Canvas c, float l, float r, float y, float h, String gl, String label, String value,
                             int k, boolean pm) {
        drawPlate(c, l, y, r, y + h, 0xff1b1f2b);
        drawGlyph(c, gl, l + 30f, y + h / 2f, 26f);
        text(c, label, l + 56f + 96f, y + h / 2f, 16f, 0xffffffff, 4f, 192f);
        float ch = h - 16f, cy0 = y + 8f;
        if (pm) {
            drawChip(c, r - 190f, cy0, r - 158f, cy0 + ch, "-", 0, B_STEP_M + k, 18f);
            drawChip(c, r - 158f, cy0, r - 58f, cy0 + ch, value, 5, B_STEP_V + k, 15f);
            drawChip(c, r - 58f, cy0, r - 16f, cy0 + ch, "+", 0, B_STEP_P + k, 18f);
        } else {
            drawChip(c, r - 190f, cy0, r - 16f, cy0 + ch, value, 0, B_STEP_V + k, 15f);
        }
    }

    private int statusColor(String st) {
        return "LIVE".equals(st) ? 0xff5be06a : ("TERHUBUNG".equals(st) || "MENGHUBUNGKAN".equals(st)) ? 0xffffd34a
                : "MATI".equals(st) ? 0xffbbbbbb : 0xffff6a5a;
    }

    // ---- menu screens ---------------------------------------------------------------
    private void drawMenuScreen(Canvas canvas) {
        drawMenuBackground(canvas, 0x80000000);
        float h = logicalHeight();
        float cx = WORLD_W / 2f;
        float titleY = h * 0.15f;
        textRaw(canvas, "BLOCK RUSH", cx, titleY, 50f, 0xffffd34a, 8f);
        textRaw(canvas, "MINECRAFT 2D  -  LIVE GAME", cx, titleY + 40f, 14f, 0xffffffff, 4f);

        float w = 340f, l = cx - w / 2f, r = cx + w / 2f;
        float y = h * 0.28f;
        drawEntry(canvas, l, y, r, y + 68f, "play", gameExists ? "LANJUT" : "MAIN", 1, B_PLAY, 30f);
        y += 68f + 8f;
        if (gameExists) {
            drawEntry(canvas, l, y, r, y + 40f, "refresh", "ULANG AREA", 2, B_RESET_AREA, 15f);
            y += 40f + 8f;
        }
        y += 6f;
        drawEntry(canvas, l, y, r, y + 56f, "wifi", "TIKTOK LIVE", 0, B_TIKTOK, 19f);
        if (live.isRunning()) {
            float dx = r - 20f;
            paint.setStyle(Paint.Style.FILL);
            paint.setColor(statusColor(live.status));
            canvas.drawCircle(dx, y + 18f, 5f, paint);
            text(canvas, live.status, dx - 8f - 40f, y + 18f, 9.5f, statusColor(live.status), 3f, 78f);
        }
        y += 56f + 10f;
        float hw = (w - 10f) / 2f;
        drawEntry(canvas, l, y, l + hw, y + 56f, "gift", "HADIAH", 0, B_GIFTS, 16f);
        drawEntry(canvas, l + hw + 10f, y, r, y + 56f, "bolt", "EVENT", 0, B_T_EVENTS, 16f);
        y += 56f + 10f;
        drawEntry(canvas, l, y, r, y + 56f, "palette", "MAP & KARAKTER", 0, B_LOOKS, 18f);
        y += 56f + 10f;
        drawEntry(canvas, l, y, l + hw, y + 56f, "gear", "PENGATURAN", 0, B_SETTINGS, 14f);
        drawEntry(canvas, l + hw + 10f, y, r, y + 56f, "flask", "MOD", 0, B_MODS, 16f);
        y += 56f + 12f;

        float hy = h - 48f;
        float avail = hy - 14f - y;
        float bh = Math.min(66f, (avail - 6f) / 2f);
        if (bh >= 26f && bannerYt != null && bannerTt != null) {
            float bw = Math.min(w, bh * 640f / 142f);
            blit(canvas, bannerYt, cx - bw / 2f, y, cx + bw / 2f, y + bh, true);
            blit(canvas, bannerTt, cx - bw / 2f, y + bh + 6f, cx + bw / 2f, y + bh * 2f + 6f, true);
            addHit(new RectF(cx - bw / 2f, y, cx + bw / 2f, y + bh), B_LINK_YT);
            addHit(new RectF(cx - bw / 2f, y + bh + 6f, cx + bw / 2f, y + bh * 2f + 6f), B_LINK_TT);
        }
        textRaw(canvas, "A/D jalan  W/Spasi lompat  E blok  F blok depan  X gali  1-8 hadiah", cx, hy, 10.5f, 0xffffffff, 3.5f);
        textRaw(canvas, "Klik kiri pasang  |  klik kanan gali  |  Esc jeda", cx, hy + 17f, 10.5f, 0xffffffff, 3.5f);
    }

    private void drawModScreen(Canvas canvas) {
        drawMenuBackground(canvas, 0xc4000000);
        float h = logicalHeight(), cx = WORLD_W / 2f;
        drawTitle(canvas, "MOD", 30f);
        textRaw(canvas, mods.mods.size() + " mod  -  aktif " + mods.enabledCount(), cx, 54f, 11f, 0xffffffff, 3f);
        String path = mods.root() == null ? "" : mods.root().getPath();
        text(canvas, path, cx, 72f, 9.5f, 0xffffe14a, 3f, 480f);
        float l = 12f, r = WORLD_W - 12f, y = 86f;
        float rowH = 54f;
        int maxRows = Math.max(1, (int) ((h - y - 190f) / (rowH + 6f)));
        int shown = Math.min(mods.mods.size(), Math.min(maxRows, 40));
        for (int k = 0; k < shown; k++) {
            ModManager.Mod m = mods.mods.get(k);
            drawPlate(canvas, l, y, r, y + rowH, m.enabled ? 0xff1b2230 : 0xff15171e);
            String title = m.name + (m.version.length() > 0 ? "  v" + m.version : "") + (m.author.length() > 0 ? "  - " + m.author : "");
            text(canvas, title, l + 14f + 150f, y + 16f, 13f, 0xffffffff, 4f, 300f);
            String info = m.error.length() > 0 ? "ERROR: " + m.error
                    : m.files + " file  -  " + m.gifts.size() + " gift" + (m.description.length() > 0 ? "  -  " + m.description : "");
            text(canvas, info, l + 14f + 150f, y + 36f, 10f, m.error.length() > 0 ? 0xffff8a7a : 0xffdddddd, 3f, 300f);
            if (m.example) drawChip(canvas, r - 100f, y + 10f, r - 10f, y + rowH - 10f, "CONTOH", 5, 0, 11f);
            else drawChip(canvas, r - 100f, y + 10f, r - 10f, y + rowH - 10f, m.enabled ? "ON" : "OFF", m.enabled ? 3 : 4, B_MOD_TOG + k, 13f);
            y += rowH + 6f;
        }
        if (mods.mods.isEmpty()) {
            textRaw(canvas, "Belum ada mod. Salin folder mod ke path di atas,", cx, y + 20f, 11.5f, 0xffffffff, 3f);
            textRaw(canvas, "lalu tekan MUAT ULANG.", cx, y + 38f, 11.5f, 0xffffffff, 3f);
            y += 56f;
        }
        y = Math.max(y + 4f, h - 186f);
        String[] help = {
                "Ganti gambar/suara: taruh file dengan path SAMA seperti di assets",
                "(mis. blocks/block_00.png, sounds/sfx_place.wav) di folder mod.",
                "Tambah fitur: file mod.json (gift & event -> efek). Lihat",
                "README.md dan folder contoh_mod di zip proyek.",
                "Folder Android/data kadang perlu file manager khusus."};
        for (int i = 0; i < help.length; i++) textRaw(canvas, help[i], cx, y + i * 14f, 10f, 0xffcfd6e6, 3f);
        y += help.length * 14f + 6f;
        drawEntry(canvas, l + 2f, y, cx - 6f, y + 44f, "refresh", "MUAT ULANG", 0, B_MOD_RELOAD, 15f);
        drawEntry(canvas, cx + 6f, y, r - 2f, y + 44f, "home", "KEMBALI", 1, B_BACK, 15f);
    }

    private void drawPauseScreen(Canvas canvas) {
        float h = logicalHeight();
        fill(canvas, 0, 0, WORLD_W, h, 0xc0000000);
        float cx = WORLD_W / 2f;
        float pw = 350f, ph = 470f;
        float pl = cx - pw / 2f, pt = Math.max(8f, (h - ph) / 2f);
        drawPlate(canvas, pl, pt, pl + pw, pt + ph, 0xee161922);
        textRaw(canvas, "JEDA", cx, pt + 34f, 32f, 0xffffd34a, 6f);
        textRaw(canvas, "event & efek tetap berjalan saat jeda", cx, pt + 58f, 10.5f, 0xffdddddd, 3f);
        float l = pl + 24f, r = pl + pw - 24f;
        float y = pt + 74f;
        drawEntry(canvas, l, y, r, y + 50f, "play", "LANJUT", 1, B_RESUME, 22f);
        y += 50f + 8f;
        drawEntry(canvas, l, y, r, y + 42f, "wifi", live.isRunning() ? "TIKTOK  [" + live.status + "]" : "TIKTOK LIVE", 0, B_TIKTOK, 16f);
        y += 42f + 8f;
        float hw = (r - l - 8f) / 2f;
        drawEntry(canvas, l, y, l + hw, y + 42f, "gift", "HADIAH", 0, B_GIFTS, 15f);
        drawEntry(canvas, l + hw + 8f, y, r, y + 42f, "bolt", "EVENT", 0, B_T_EVENTS, 15f);
        y += 42f + 8f;
        drawEntry(canvas, l, y, r, y + 42f, "gear", "PENGATURAN", 0, B_SETTINGS, 16f);
        y += 42f + 8f;
        drawEntry(canvas, l, y, r, y + 42f, "refresh", "ULANG", 0, B_RETRY, 16f);
        y += 42f + 8f;
        drawEntry(canvas, l, y, r, y + 42f, "home", "MENU UTAMA", 2, B_MENU, 16f);
    }

    private void drawTitle(Canvas canvas, String title, float y) {
        textRaw(canvas, title, WORLD_W / 2f, y, 32f, 0xffffd34a, 6f);
    }

    private String sec(int s) { return s + " dtk"; }

    private void drawSettingsScreen(Canvas canvas) {
        drawMenuBackground(canvas, 0xb8000000);
        float h = logicalHeight();
        float cx = WORLD_W / 2f;
        drawTitle(canvas, "PENGATURAN", 34f);
        float w = 460f, l = cx - w / 2f, r = cx + w / 2f;
        // tabs
        String[] tabs = {"UMUM", "GAME", "EFEK", "SUARA"};
        String[] tg = {"gear", "trophy", "bolt", "sound_on"};
        float tw = (w - 18f) / 4f, y = 62f;
        for (int i = 0; i < 4; i++) {
            float x = l + i * (tw + 6f);
            drawChipIcon(canvas, x, y, x + tw, y + 40f, glyph(tg[i]), tabs[i], i == settingsTab ? 3 : 0, B_TAB + i, 12f);
        }
        y += 40f + 10f;
        float rowH = clampFloat((h - 200f) / 8f - 7f, 40f, 52f), gap = 7f;
        if (settingsTab == 0) {
            rowH = clampFloat(Math.min(rowH, (h - y - 64f - 56f) / 10f - gap), 32f, 52f);
            drawToggleRow(canvas, l, r, y, rowH, "tap", "TOMBOL DI LAYAR", cfg.showButtons, 1);
            y += rowH + gap;
            drawToggleRow(canvas, l, r, y, rowH, "list", "NOTIF TIKTOK DI LAYAR", cfg.feed, 3);
            y += rowH + gap;
            drawToggleRow(canvas, l, r, y, rowH, "plus", "BLOK TAK TERBATAS", cfg.unlimited, 2);
            y += rowH + gap;
            drawToggleRow(canvas, l, r, y, rowH, "eye", "HUD TRANSPARAN", cfg.hudTransparent, 10);
            y += rowH + gap;
            drawStepRow(canvas, l, r, y, rowH, "timer", "KECEPATAN PASANG", GameSettings.SPEED_NAMES[cfg.speed], 9, false);
            y += rowH + gap;
            drawStepRow(canvas, l, r, y, rowH, "back", "HUD TURUN", String.valueOf(cfg.hudOffset), 0, true);
            y += rowH + gap;
            drawToggleRow(canvas, l, r, y, rowH, "user", "NAMA PEMAIN (TIKTOK)", cfg.namePlayer, 18);
            y += rowH + gap;
            drawToggleRow(canvas, l, r, y, rowH, "eye", "ZOOM OTOMATIS", cfg.autoZoom, 19);
            y += rowH + gap;
            drawStepRow(canvas, l, r, y, rowH, "gear", "BAHASA / LANGUAGE", cfg.lang == 0 ? "INDONESIA" : "ENGLISH", 15, false);
            y += rowH + gap;
            drawEntry(canvas, l, y, r, y + rowH, "tap", "ATUR POSISI & UKURAN TOMBOL", 3, B_BTN_EDIT, 15f);
            y += rowH + gap;
        } else if (settingsTab == 1) {
            drawToggleRow(canvas, l, r, y, rowH, "heart", "PEMAIN BISA MATI", cfg.mortal, 4);
            y += rowH + gap;
            drawToggleRow(canvas, l, r, y, rowH, "eye", "TAMPILKAN NYAWA (HP)", cfg.showHp, 5);
            y += rowH + gap;
            drawStepRow(canvas, l, r, y, rowH, "refresh", "HIDUP LAGI", sec(cfg.respawnSec), 10, true);
            y += rowH + gap;
            drawToggleRow(canvas, l, r, y, rowH, "plus", "BLOK JATUH (GRAVITASI)", cfg.blockGravity, 9);
            y += rowH + gap;
            drawStepRow(canvas, l, r, y, rowH, "trophy", "TARGET MENANG", String.valueOf(cfg.winTarget), 1, true);
            y += rowH + gap;
            drawStepRow(canvas, l, r, y, rowH, "timer", "HITUNGAN MUNDUR", String.valueOf(cfg.countdownStart), 2, true);
            y += rowH + gap;
            drawStepRow(canvas, l, r, y, rowH, "refresh", "KECEPATAN HITUNG",
                    String.format(Locale.US, "%.1f dtk", cfg.countdownStep / 10f), 3, true);
            y += rowH + gap;
            drawStepRow(canvas, l, r, y, rowH, "gift", "TILE GIFT+EVENT DI ATAS", String.valueOf(cfg.tileCount), 8, true);
            y += rowH + gap;
        } else if (settingsTab == 2) {
            rowH = clampFloat(Math.min(rowH, (h - y - 64f) / 14f - gap), 28f, 52f);
            drawStepRow(canvas, l, r, y, rowH, "bolt", "DURASI TORNADO", sec(cfg.tornadoSec), 4, true);
            y += rowH + gap;
            drawStepRow(canvas, l, r, y, rowH, "gear", "DURASI ROBOT", sec(cfg.robotSec), 5, true);
            y += rowH + gap;
            drawStepRow(canvas, l, r, y, rowH, "eye", "DURASI MONSTER", sec(cfg.monsterSec), 6, true);
            y += rowH + gap;
            drawStepRow(canvas, l, r, y, rowH, "bolt", "DURASI BOS API", sec(cfg.bossSec), 13, true);
            y += rowH + gap;
            drawStepRow(canvas, l, r, y, rowH, "timer", "DURASI PELEMPAR TNT", sec(cfg.throwerSec), 14, true);
            y += rowH + gap;
            drawStepRow(canvas, l, r, y, rowH, "heart", "PERISAI PER 1X", sec(cfg.shieldSec), 7, true);
            y += rowH + gap;
            drawToggleRow(canvas, l, r, y, rowH, "user", "NAMA DI TORNADO", cfg.nameTornado, 11);
            y += rowH + gap;
            drawToggleRow(canvas, l, r, y, rowH, "user", "NAMA DI ROBOT", cfg.nameRobot, 12);
            y += rowH + gap;
            drawToggleRow(canvas, l, r, y, rowH, "user", "NAMA DI MONSTER", cfg.nameMonster, 13);
            y += rowH + gap;
            drawToggleRow(canvas, l, r, y, rowH, "user", "NAMA DI PELEMPAR TNT", cfg.nameThrower, 14);
            y += rowH + gap;
            drawToggleRow(canvas, l, r, y, rowH, "user", "NAMA DI BOS", cfg.nameBoss, 15);
            y += rowH + gap;
            drawToggleRow(canvas, l, r, y, rowH, "user", "NAMA DI RUDAL", cfg.nameMissile, 16);
            y += rowH + gap;
            drawToggleRow(canvas, l, r, y, rowH, "user", "NAMA DI BOR", cfg.nameDrill, 17);
            y += rowH + gap;
            textRaw(canvas, "Durasi dihitung tiap efek dikirim. Perisai x3 = 3 kali durasi.", cx, y + 8f, 10.5f, 0xffdddddd, 3f);
            y += 26f;
        } else {
            drawToggleRow(canvas, l, r, y, rowH, cfg.sound ? "sound_on" : "sound_off", "EFEK SUARA", cfg.sound, 0);
            y += rowH + gap;
            drawStepRow(canvas, l, r, y, rowH, "sound_on", "VOLUME EFEK", cfg.sfxVol + "%", 11, true);
            y += rowH + gap;
            drawToggleRow(canvas, l, r, y, rowH, "play", "MUSIK LATAR", cfg.musicOn, 7);
            y += rowH + gap;
            drawStepRow(canvas, l, r, y, rowH, "sound_on", "VOLUME MUSIK", cfg.musicVol + "%", 12, true);
            y += rowH + gap;
            drawToggleRow(canvas, l, r, y, rowH, "tap", "SUARA KLIK TOMBOL", cfg.clickSound, 8);
            y += rowH + gap;
        }
        y = Math.max(y + 6f, 0f);
        float by = Math.max(y, Math.min(h - 64f, y + 8f));
        drawEntry(canvas, l, by, cx - 6f, by + 46f, "trash", "RESET", 2, B_RESET, 16f);
        drawEntry(canvas, cx + 6f, by, r, by + 46f, "back", "KEMBALI", 1, B_BACK, 16f);
    }

    private int giftPages() { return (GameSettings.GIFTS + GIFT_PAGE - 1) / GIFT_PAGE; }

    private void drawGiftsScreen(Canvas canvas) {
        drawMenuBackground(canvas, 0xc4000000);
        float h = logicalHeight();
        float cx = WORLD_W / 2f;
        giftPage = clamp(giftPage, 0, giftPages() - 1);
        drawTitle(canvas, "HADIAH LIVE", 30f);
        textRaw(canvas, "Aktif " + cfg.activeGifts() + "  -  tampil di atas " + cfg.shownGifts() + "/" + cfg.tileCount
                + "  -  hal " + (giftPage + 1) + "/" + giftPages() + "   (gift tersembunyi tetap memicu efek)", cx, 55f, 10f, 0xffffffff, 3f);
        float top = 68f, bottomReserve = 100f;
        float rowH = Math.max(100f, Math.min(116f, (h - top - bottomReserve) / GIFT_PAGE - 4f));
        float y = top;
        for (int k = 0; k < GIFT_PAGE; k++) {
            int i = giftPage * GIFT_PAGE + k;
            if (i >= GameSettings.GIFTS) break;
            drawGiftSettingRow(canvas, i, y, rowH);
            y += rowH + 4f;
        }
        y = Math.max(y + 2f, Math.min(h - bottomReserve + 4f, y + 4f));
        drawEntry(canvas, 14f, y, cx - 6f, y + 40f, "back", "SEBELUMNYA", 0, B_PAGE_PREV, 14f);
        drawEntry(canvas, cx + 6f, y, WORLD_W - 14f, y + 40f, "play", "BERIKUTNYA", 0, B_PAGE_NEXT, 14f);
        y += 40f + 8f;
        drawEntry(canvas, 14f, y, cx - 6f, y + 42f, "trash", "RESET HADIAH", 2, B_RESET_GIFTS, 14f);
        drawEntry(canvas, cx + 6f, y, WORLD_W - 14f, y + 42f, "home", "KEMBALI", 1, B_BACK, 14f);
    }

    /** Two lines: [icon] [name .......... ON eye TES] / [effect][-][n][+][tile text]. */
    private void drawGiftSettingRow(Canvas c, int i, float y, float h) {
        GameSettings.Gift g = cfg.gifts[i];
        float l = 8f, r = WORLD_W - 8f;
        drawPlate(c, l, y, r, y + h, g.on ? 0xff1b2230 : 0xff15171e);
        float is = Math.min(h - 14f, 60f);
        float ix = l + 9f, iy = y + (h - is) / 2f;
        RectF ir = new RectF(ix, iy, ix + is, iy + is);
        addHit(ir, B_G_ICON + i);
        roundRect(c, ir.left - 2f, ir.top - 2f, ir.right + 2f, ir.bottom + 2f, 6f, 0xff0b0c10);
        roundRect(c, ir.left, ir.top, ir.right, ir.bottom, 5f, 0xff2a2f40);
        blit(c, giftBitmap(g.name, g.icon), ir.left + 3f, ir.top + 3f, ir.right - 3f, ir.bottom - 3f, true);
        text(c, "#" + (i + 1), ir.left + 11f, ir.top + 7f, 9.5f, 0xffffffff, 3f, 20f);
        float x0 = ix + is + 8f;
        float ch = (h - 26f) / 3f;
        float y1 = y + 7f, y2 = y1 + ch + 6f, y3 = y2 + ch + 6f;
        float xr = r - 8f;
        drawChip(c, xr - 50f, y1, xr, y1 + ch, "TES", 0, B_G_TEST + i, 12f);
        xr -= 54f;
        drawChipIcon(c, xr - 44f, y1, xr, y1 + ch, glyph(g.show ? "eye" : "eye_off"), "", g.show ? 3 : 4, B_G_SHOW + i, 11f);
        xr -= 48f;
        drawChip(c, xr - 48f, y1, xr, y1 + ch, g.on ? "ON" : "OFF", g.on ? 3 : 4, B_G_ON + i, 12f);
        xr -= 52f;
        boolean empty = g.name == null || g.name.trim().length() == 0;
        String nm = empty ? "(pilih gift...)" : g.name.trim();
        int coin = empty ? 0 : GiftCatalog.coinsOf(g.name);
        drawChip(c, x0, y1, xr, y1 + ch, nm + (coin > 0 ? "  (" + coin + ")" : ""), empty ? 5 : 0, B_G_NAME + i, 13f);
        float x = x0;
        drawChipIcon(c, x, y2, x + 118f, y2 + ch, fxIcon[g.effect], GameSettings.EFFECT_NAMES[g.effect], 0, B_G_EFFECT + i, 12f);
        x += 118f + 4f;
        drawChip(c, x, y2, x + 26f, y2 + ch, "-", 0, B_G_MINUS + i, 17f);
        x += 26f;
        drawChip(c, x, y2, x + 42f, y2 + ch, String.valueOf(g.amount), 5, B_G_AMOUNT + i, 14f);
        x += 42f;
        drawChip(c, x, y2, x + 26f, y2 + ch, "+", 0, B_G_PLUS + i, 17f);
        x += 26f + 4f;
        boolean custom = g.label != null && g.label.trim().length() > 0;
        drawChip(c, x, y2, r - 8f, y2 + ch, custom ? g.label.trim() : "teks " + g.autoLabel(),
                custom ? 0 : 5, B_G_LABEL + i, 12f);
        drawSoundRow(c, x0, r - 8f, y3, ch, g.sound, g.soundName, B_G_SND + i, B_G_SNDX + i);
    }

    /** [ SUARA: file ........ ] [x]  - pick / clear an own effect sound. */
    private void drawSoundRow(Canvas c, float x0, float xr, float y, float ch, String path, String name, int idPick, int idClear) {
        boolean has = path != null && path.length() > 0;
        if (has) {
            drawChip(c, xr - 36f, y, xr, y + ch, "X", 2, idClear, 13f);
            xr -= 40f;
        }
        String nm = has ? (name == null || name.length() == 0 ? "suara sendiri" : name) : "SUARA: bawaan (tap = pilih file)";
        drawChipIcon(c, x0, y, xr, y + ch, glyph("sound_on"), nm, has ? 3 : 0, idPick, 11.5f);
    }

    // ---- gift name picker (with search) ------------------------------------------------
    private String[] pickList() {
        if (pickCache != null && pickQuery.equals(pickCacheQuery)) return pickCache;
        java.util.ArrayList<String> out = new java.util.ArrayList<>();
        String q = pickQuery.trim().toLowerCase();
        if (cfg.recent != null) {
            for (String s : cfg.recent.split("\\|")) {
                if (s.trim().length() == 0 || (q.length() > 0 && !s.toLowerCase().contains(q))) continue;
                boolean dup = false;
                for (String o : out) if (GameSettings.norm(o).equals(GameSettings.norm(s))) dup = true;
                if (!dup) out.add(s.trim());
            }
        }
        java.util.ArrayList<String> known = new java.util.ArrayList<>(), rest = new java.util.ArrayList<>();
        for (String s : GiftCatalog.NAMES) {
            if (q.length() > 0 && !s.toLowerCase().contains(q) && !GameSettings.localName(s).contains(q)) continue;
            boolean dup = false;
            for (String o : out) if (GameSettings.norm(o).equals(GameSettings.norm(s))) dup = true;
            if (dup) continue;
            if (GiftCatalog.iconFor(s) != GiftCatalog.GENERIC_ICON) known.add(s); else rest.add(s);
        }
        out.addAll(known);
        out.addAll(rest);
        pickCache = out.toArray(new String[0]);
        pickCacheQuery = pickQuery;
        return pickCache;
    }

    private int catalogIndex(String name) { return GiftCatalog.indexOf(name); }

    private boolean isRecent(String name) {
        if (cfg.recent == null) return false;
        String n = GameSettings.norm(name);
        for (String s : cfg.recent.split("\\|")) if (GameSettings.norm(s).equals(n) && n.length() > 0) return true;
        return false;
    }

    private void drawPickScreen(Canvas canvas) {
        drawMenuBackground(canvas, 0xc8000000);
        float h = logicalHeight(), cx = WORLD_W / 2f;
        String[] list = pickList();
        int pages = Math.max(1, (list.length + PICK_PAGE - 1) / PICK_PAGE);
        pickPage = clamp(pickPage, 0, pages - 1);
        GameSettings.Gift g = cfg.gifts[clamp(pickSlot, 0, GameSettings.GIFTS - 1)];
        drawTitle(canvas, "PILIH GIFT", 30f);
        textRaw(canvas, "Slot #" + (pickSlot + 1) + "  -  " + list.length + " gift  -  hal " + (pickPage + 1) + "/" + pages
                + "  -  hijau = pernah masuk saat live", cx, 55f, 10f, 0xffffffff, 3f);
        float top = 66f;
        drawChipIcon(canvas, 14f, top, WORLD_W - 14f, top + 38f, glyph("list"),
                pickQuery.length() == 0 ? "CARI NAMA GIFT..." : "\"" + pickQuery + "\"  (ketuk untuk ubah)",
                pickQuery.length() == 0 ? 5 : 3, B_PICK_SEARCH, 14f);
        top += 46f;
        float bw = (WORLD_W - 14f * 2f - 8f) / 2f;
        float bh = Math.max(40f, Math.min(50f, (h - top - 150f) / (PICK_PAGE / 2) - 6f));
        for (int k = 0; k < PICK_PAGE; k++) {
            int idx = pickPage * PICK_PAGE + k;
            if (idx >= list.length) break;
            float x = 14f + (k % 2) * (bw + 8f), y = top + (k / 2) * (bh + 6f);
            String name = list[idx];
            int ci = catalogIndex(name);
            boolean cur = GameSettings.norm(name).equals(GameSettings.norm(g.name));
            drawChipIcon(canvas, x, y, x + bw, y + bh, giftBitmap(name, GiftCatalog.iconFor(name)),
                    name + (ci >= 0 ? " (" + GiftCatalog.COINS[ci] + ")" : ""),
                    cur ? 3 : (isRecent(name) ? 3 : 0), B_PICK_ITEM + k, 12.5f);
            if (cur) fill(canvas, x + 4f, y + bh - 6f, x + bw - 4f, y + bh - 3f, 0xffffe14a);
        }
        float y = top + (PICK_PAGE / 2) * (bh + 6f) + 4f;
        drawEntry(canvas, 14f, y, cx - 6f, y + 40f, "back", "SEBELUMNYA", 0, B_PAGE_PREV, 14f);
        drawEntry(canvas, cx + 6f, y, WORLD_W - 14f, y + 40f, "play", "BERIKUTNYA", 0, B_PAGE_NEXT, 14f);
        y += 40f + 8f;
        float tw = (WORLD_W - 28f - 16f) / 3f;
        drawChip(canvas, 14f, y, 14f + tw, y + 42f, "KETIK NAMA", 0, B_PICK_MANUAL, 13f);
        drawChip(canvas, 22f + tw, y, 22f + 2 * tw, y + 42f, "KOSONGKAN", 2 == 0 ? 0 : 4, B_PICK_CLEAR, 13f);
        drawChip(canvas, 30f + 2 * tw, y, WORLD_W - 14f, y + 42f, "KEMBALI", 3, B_BACK, 13f);
    }

    // ---- effect picker (grid of all effects) --------------------------------------------------
    private int fxKind = 0, fxIdx = 0;        // 0 = gift slot, 1 = event rule
    private static final String[] FX_DESC = {"Blok muncul di arena", "TNT muncul di pemain", "TNT jatuh dari langit", "Hanya notifikasi",
            "Tambah nyawa", "Kebal sementara", "Sambaran petir", "Sapu & tarik blok", "Robot membantu", "Meteor jatuh", "Monster menyerang",
            "Rudal nuklir jatuh", "Pemain lempar TNT", "Naga semburkan api", "Bor menembus blok"};

    private int currentFx() {
        return fxKind == 0 ? cfg.gifts[clamp(fxIdx, 0, GameSettings.GIFTS - 1)].effect
                : cfg.rules[clamp(fxIdx, 0, GameSettings.EVENTS - 1)].effect;
    }

    private void openFxPicker(int kind, int idx) { fxKind = kind; fxIdx = idx; open(SCREEN_FX); }

    private void drawFxScreen(Canvas canvas) {
        drawMenuBackground(canvas, 0xd0000000);
        float cx = WORLD_W / 2f;
        drawTitle(canvas, "PILIH EFEK", 30f);
        String who = fxKind == 0 ? "Gift #" + (fxIdx + 1) + " " + cfg.gifts[clamp(fxIdx, 0, GameSettings.GIFTS - 1)].name
                : "Event " + GameSettings.EVENT_NAMES[clamp(fxIdx, 0, GameSettings.EVENTS - 1)];
        textRaw(canvas, who + "  -  ketuk efek untuk memilih", cx, 56f, 11f, 0xffffffff, 3f);
        int cur = currentFx();
        float gap = 8f, cw = (WORLD_W - 28f - 2f * gap) / 3f, ch = 108f, top = 74f;
        for (int k = 0; k < GameSettings.EFFECTS; k++) {
            float x = 14f + (k % 3) * (cw + gap), y = top + (k / 3) * (ch + gap);
            RectF rr = new RectF(x, y, x + cw, y + ch);
            addHit(rr, B_FX_ITEM + k);
            roundRect(canvas, x, y, x + cw, y + ch, 12f, k == cur ? 0xffffe14a : 0xff0b0c10);
            roundRect(canvas, x + 3f, y + 3f, x + cw - 3f, y + ch - 3f, 10f, k == cur ? 0xff2f9a42 : (pressedAt(rr) ? 0xff3a4058 : 0xff20263a));
            blitFit(canvas, fxIcon[k], x + cw / 2f - 28f, y + 8f, x + cw / 2f + 28f, y + 64f);
            text(canvas, GameSettings.EFFECT_NAMES[k], x + cw / 2f, y + 74f, 14f, 0xffffffff, 4f, cw - 10f);
            text(canvas, FX_DESC[k], x + cw / 2f, y + 94f, 9.5f, 0xffbfc8d8, 2.5f, cw - 8f);
        }
        float y = top + ((GameSettings.EFFECTS + 2) / 3) * (ch + gap) + 4f;
        drawEntry(canvas, 14f, y, WORLD_W - 14f, y + 46f, "home", "KEMBALI", 1, B_BACK, 16f);
    }

    // ---- icon picker -----------------------------------------------------------------------
    private int[] iconList = null;

    private int[] iconIds() {
        if (iconList == null) {
            java.util.ArrayList<Integer> a = new java.util.ArrayList<>();
            for (int i = 0; i < GameSettings.EFFECTS; i++) a.add(i);
            a.add(GiftCatalog.GENERIC_ICON);                 // AUTO = picture from the website
            iconList = new int[a.size()];
            for (int i = 0; i < iconList.length; i++) iconList[i] = a.get(i);
        }
        return iconList;
    }

    private void drawIconsScreen(Canvas canvas) {
        drawMenuBackground(canvas, 0xc8000000);
        float h = logicalHeight(), cx = WORLD_W / 2f;
        int[] ids = iconIds();
        int pages = Math.max(1, (ids.length + ICON_PAGE - 1) / ICON_PAGE);
        iconPage = clamp(iconPage, 0, pages - 1);
        GameSettings.Gift g = cfg.gifts[clamp(pickSlot, 0, GameSettings.GIFTS - 1)];
        drawTitle(canvas, "PILIH GAMBAR", 30f);
        textRaw(canvas, "Slot #" + (pickSlot + 1) + "  -  hal " + (iconPage + 1) + "/" + pages
                + "  -  AUTO = gambar dari website", cx, 55f, 10f, 0xffffffff, 3f);
        float top = 70f, cell = 76f, gap = (WORLD_W - 28f - 6 * cell) / 5f;
        for (int k = 0; k < ICON_PAGE; k++) {
            int idx = iconPage * ICON_PAGE + k;
            if (idx >= ids.length) break;
            float x = 14f + (k % 6) * (cell + gap), y = top + (k / 6) * (cell + 6f);
            RectF rr = new RectF(x, y, x + cell, y + cell);
            addHit(rr, B_ICON_ITEM + k);
            boolean cur = ids[idx] == g.icon;
            roundRect(canvas, x, y, x + cell, y + cell, 8f, 0xff0b0c10);
            roundRect(canvas, x + 2f, y + 2f, x + cell - 2f, y + cell - 2f, 7f, cur ? 0xff2f9a42 : (pressedAt(rr) ? 0xff3a4058 : 0xff20263a));
            blit(canvas, iconBitmap(ids[idx]), x + 8f, y + 8f, x + cell - 8f, y + cell - 8f, true);
            if (ids[idx] == GiftCatalog.GENERIC_ICON) textRaw(canvas, "AUTO", x + cell / 2f, y + cell - 9f, 11f, 0xffffe14a, 4f);
        }
        float y = top + 6 * (cell + 6f) + 4f;
        drawEntry(canvas, 14f, y, cx - 6f, y + 40f, "back", "SEBELUMNYA", 0, B_PAGE_PREV, 14f);
        drawEntry(canvas, cx + 6f, y, WORLD_W - 14f, y + 40f, "play", "BERIKUTNYA", 0, B_PAGE_NEXT, 14f);
        y += 40f + 8f;
        drawEntry(canvas, 14f, y, WORLD_W - 14f, y + 44f, "home", "KEMBALI", 1, B_BACK, 15f);
    }

    // ---- TikTok connection ---------------------------------------------------------------
    private void drawTikTokScreen(Canvas canvas) {
        drawMenuBackground(canvas, 0xc4000000);
        float h = logicalHeight(), cx = WORLD_W / 2f;
        drawTitle(canvas, "TIKTOK LIVE", 32f);
        float w = 470f, l = cx - w / 2f, r = cx + w / 2f;
        float y = 56f, rowH = 44f, gap = 7f;
        boolean direct = cfg.liveMode == 0;
        float hw = (w - 8f) / 2f;
        drawChipIcon(canvas, l, y, l + hw, y + 40f, glyph("wifi"), "LANGSUNG (DI GAME)", direct ? 3 : 0, B_T_MODE, 12f);
        drawChipIcon(canvas, l + hw + 8f, y, r, y + 40f, glyph("gear"), "NODE.JS BRIDGE", direct ? 0 : 3, B_T_MODE2, 12f);
        y += 40f + gap + 2f;
        drawValueRow(canvas, l, r, y, rowH, "user", "USERNAME", cfg.user.length() == 0 ? "(isi @username TikTok)" : "@" + cfg.user, B_T_USER);
        y += rowH + gap;
        if (direct) {
            String k = cfg.apiKey == null ? "" : cfg.apiKey.trim();
            String shown = k.length() == 0 ? "(WAJIB - tap lalu tempel)"
                    : (k.length() <= 6 ? "******" : k.substring(0, 3) + "..." + k.substring(k.length() - 3));
            drawValueRow(canvas, l, r, y, rowH, "keyboard", "API KEY", shown, B_T_KEY);
            y += rowH + gap;
            drawEntry(canvas, l, y, r, y + 38f, "wifi", "AMBIL API KEY GRATIS (eulerstream.com)", 0, B_T_WEB, 12f);
            y += 38f + gap;
        } else {
            drawValueRow(canvas, l, r, y, rowH, "map", "HOST", cfg.host.length() == 0 ? "(isi host)" : cfg.host, B_T_HOST);
            y += rowH + gap;
            drawValueRow(canvas, l, r, y, rowH, "list", "PORT", String.valueOf(cfg.port), B_T_PORT);
            y += rowH + gap;
        }
        drawToggleRow(canvas, l, r, y, rowH, "refresh", "HUBUNG OTOMATIS", cfg.autoConnect, 6);
        y += rowH + gap + 2f;
        boolean on = live.isRunning();
        drawEntry(canvas, l, y, r, y + 58f, on ? "cross" : "play", on ? "BERHENTI" : "MULAI TERHUBUNG", on ? 2 : 1, B_T_START, 21f);
        y += 58f + 10f;

        String st = on ? live.status : "MATI";
        int col = statusColor(st);
        drawPlate(canvas, l, y, r, y + 54f, 0xff12151f);
        paint.setStyle(Paint.Style.FILL);
        paint.setColor(col);
        canvas.drawCircle(l + 20f, y + 19f, 6f, paint);
        textRaw(canvas, "STATUS: " + st + (on && live.viewers > 0 ? "   penonton " + live.viewers : ""),
                cx + 6f, y + 19f, 13f, col, 3f);
        String msg = on ? live.message : "Belum terhubung";
        text(canvas, msg == null ? "" : msg, cx, y + 40f, 11f, 0xffdddddd, 3f, w - 24f);
        y += 54f + 10f;

        float bw = (w - 16f) / 3f;
        drawEntry(canvas, l, y, l + bw, y + 46f, "bolt", "EVENT", 0, B_T_EVENTS, 14f);
        drawEntry(canvas, l + bw + 8f, y, l + 2 * bw + 8f, y + 46f, "gift", "HADIAH", 0, B_T_GIFTS, 14f);
        drawEntry(canvas, l + 2 * bw + 16f, y, r, y + 46f, "flask", "TES", 0, B_T_TEST, 14f);
        y += 46f + 10f;
        String[] help = direct ? new String[] {
                "Mode langsung: game terhubung sendiri lewat WebSocket (wss://ws.eulerstream.com),",
                "tanpa Node.js. Isi @username yang sedang LIVE lalu tekan MULAI TERHUBUNG.",
                "API key WAJIB (server Euler menolak tanpa key). Gratis: eulerstream.com > daftar > API Keys.",
                "Bridge Node.js lama tetap bisa dipakai lewat tombol NODE.JS BRIDGE."
        } : new String[] {
                "Mode bridge: game membaca bridge Node.js milikmu (TIKTOMC) lewat WebSocket.",
                "Di bridge: MINECRAFT_OUTBOUND_ENABLED=false  dan  WS_PORT=25601.",
                "Satu HP: jalankan Node di Termux, host 127.0.0.1. HP + PC: isi IP PC."
        };
        for (int i = 0; i < help.length; i++) textRaw(canvas, help[i], cx, y + i * 15f, 9.8f, 0xffffffff, 3f);
        y += help.length * 15f + 8f;
        drawEntry(canvas, l, y, r, y + 44f, "home", "KEMBALI", 1, B_BACK, 16f);
    }

    /** Row whose value chip is wide (text fields). */
    private void drawValueRow(Canvas c, float l, float r, float y, float h, String gl, String label, String value, int id) {
        RectF rect = new RectF(l, y, r, y + h);
        addHit(rect, id);
        drawPlate(c, l, y, r, y + h, pressedAt(rect) ? 0xff2d3345 : 0xff1b1f2b);
        drawGlyph(c, gl, l + 26f, y + h / 2f, 24f);
        text(c, label, l + 52f + 36f, y + h / 2f, 13f, 0xffffffff, 4f, 74f);
        drawChip(c, l + 138f, y + 7f, r - 10f, y + h - 7f, value, 5, -1, 13f);
    }

    // ---- event rules ----------------------------------------------------------------------
    private void drawEventsScreen(Canvas canvas) {
        drawMenuBackground(canvas, 0xc8000000);
        float h = logicalHeight(), cx = WORLD_W / 2f;
        drawTitle(canvas, "EVENT TIKTOK", 30f);
        textRaw(canvas, "Aksi saat event masuk. Mata = tampil sbg tile di atas (gift diatur di HADIAH)",
                cx, 55f, 10.5f, 0xffffffff, 3f);
        float l = 8f, r = WORLD_W - 8f;
        float y = 66f, rowH = 78f;
        for (int i = 0; i < GameSettings.EVENTS; i++) {
            GameSettings.Rule ru = cfg.rules[i];
            drawPlate(canvas, l, y, r, y + rowH, ru.on ? 0xff1b2230 : 0xff15171e);
            float is = 40f, iy = y + 6f;
            blitFit(canvas, evIcon[i], l + 4f, iy - 2f, l + 12f + is + 8f, iy + is + 2f);
            text(canvas, GameSettings.EVENT_NAMES[i], l + 8f + is / 2f, y + rowH - 14f, 10f, 0xffffffff, 3f, is + 14f);
            float ch = (rowH - 22f) / 2f, y1 = y + 7f, y2 = y1 + ch + 8f;
            float x0 = l + 66f, x = x0;
            drawChip(canvas, x, y1, x + 40f, y1 + ch, ru.on ? "ON" : "OFF", ru.on ? 3 : 4, B_E_ON + i, 11.5f);
            x += 44f;
            drawChip(canvas, x, y1, x + 58f, y1 + ch, ru.notify ? "NOTIF" : "TANPA", ru.notify ? 3 : 4, B_E_NOTIF + i, 10.5f);
            x += 62f;
            drawChipIcon(canvas, x, y1, x + 44f, y1 + ch, glyph(ru.show ? "eye" : "eye_off"), "", ru.show ? 3 : 4, B_E_SHOW + i, 11f);
            x += 48f;
            drawChip(canvas, x, y1, r - 8f, y1 + ch, "TES", 0, B_E_TEST + i, 11.5f);
            x = x0;
            drawChipIcon(canvas, x, y2, x + 112f, y2 + ch, fxIcon[ru.effect], GameSettings.EFFECT_NAMES[ru.effect], 0, B_E_EFFECT + i, 10.5f);
            x += 116f;
            drawChip(canvas, x, y2, x + 24f, y2 + ch, "-", 0, B_E_MINUS + i, 16f);
            x += 24f;
            drawChip(canvas, x, y2, x + 36f, y2 + ch, String.valueOf(ru.amount), 5, B_E_AMOUNT + i, 13f);
            x += 36f;
            drawChip(canvas, x, y2, x + 24f, y2 + ch, "+", 0, B_E_PLUS + i, 16f);
            x += 28f;
            drawSoundRow(canvas, x, r - 8f, y2, ch, ru.sound, ru.soundName, B_E_SND + i, B_E_SNDX + i);
            y += rowH + 4f;
        }
        // LIKE rule fires once per N likes.
        drawPlate(canvas, l, y, r, y + 48f, 0xff1b1f2b);
        drawGlyph(canvas, "heart", l + 20f, y + 24f, 22f);
        text(canvas, "LIKE: aksi tiap", l + 100f, y + 24f, 13f, 0xffffffff, 4f, 130f);
        float ch = 28f, cy0 = y + 10f, x = l + 200f;
        drawChip(canvas, x, cy0, x + 28f, cy0 + ch, "-", 0, B_LIKE_MINUS, 16f);
        x += 28f;
        drawChip(canvas, x, cy0, x + 56f, cy0 + ch, String.valueOf(cfg.likeEvery), 5, B_LIKE_AMT, 14f);
        x += 56f;
        drawChip(canvas, x, cy0, x + 28f, cy0 + ch, "+", 0, B_LIKE_PLUS, 16f);
        text(canvas, "like", x + 52f, y + 24f, 13f, 0xffffffff, 4f, 40f);
        y += 48f + 10f;
        drawEntry(canvas, 14f, y, cx - 6f, y + 44f, "trash", "RESET EVENT", 2, B_E_RESET, 15f);
        drawEntry(canvas, cx + 6f, y, WORLD_W - 14f, y + 44f, "home", "KEMBALI", 1, B_BACK, 15f);
    }

    // ---- map + character ------------------------------------------------------------------
    private void drawLooksScreen(Canvas canvas) {
        applyLook();
        drawMenuBackground(canvas, 0xc0000000);
        float h = logicalHeight(), cx = WORLD_W / 2f;
        drawTitle(canvas, "MAP & KARAKTER", 34f);
        // Map card
        float y = 64f;
        textRaw(canvas, "MAP AREA", cx, y, 15f, 0xffffffff, 4f);
        y += 14f;
        float pw = 300f, ph = 150f, pl = cx - pw / 2f;
        drawPlate(canvas, pl - 6f, y, pl + pw + 6f, y + ph + 12f, 0xff10131b);
        if (arena != null) {
            int aw = arena.getWidth(), ah = arena.getHeight();
            int sh = Math.min(ah, (int) (aw * ph / pw));
            int sy = Math.max(0, Math.min(ah - sh, (int) (ah * 0.56f)));
            tmp.set(pl, y + 6f, pl + pw, y + 6f + ph);
            paint.setAlpha(255); paint.setFilterBitmap(true);
            canvas.drawBitmap(arena, new Rect(0, sy, aw, sy + sh), tmp, paint);
            paint.setFilterBitmap(false);
        }
        drawChip(canvas, pl - 56f, y + ph / 2f - 20f, pl - 14f, y + ph / 2f + 22f, "<", 0, B_MAP_PREV, 22f);
        drawChip(canvas, pl + pw + 14f, y + ph / 2f - 20f, pl + pw + 56f, y + ph / 2f + 22f, ">", 0, B_MAP_NEXT, 22f);
        y += ph + 12f + 20f;
        textRaw(canvas, GameSettings.MAP_NAMES[cfg.map] + "  (" + (cfg.map + 1) + "/" + GameSettings.MAPS + ")",
                cx, y, 18f, 0xffffd34a, 5f);

        // Character card
        y += 36f;
        textRaw(canvas, "KARAKTER", cx, y, 15f, 0xffffffff, 4f);
        y += 14f;
        float cw = 150f, chh = 170f, cl = cx - cw / 2f;
        drawPlate(canvas, cl - 6f, y, cl + cw + 6f, y + chh + 12f, 0xff10131b);
        Bitmap pv = previewOf(cfg.character);
        if (pv != null) {
            float sc2 = Math.min((cw - 10f) / pv.getWidth(), (chh - 6f) / pv.getHeight());
            float bw2 = pv.getWidth() * sc2, bh2 = pv.getHeight() * sc2;
            blit(canvas, pv, cx - bw2 / 2f, y + 6f + (chh - bh2), cx + bw2 / 2f, y + 6f + chh, false);
        }
        drawChip(canvas, cl - 56f, y + chh / 2f - 20f, cl - 14f, y + chh / 2f + 22f, "<", 0, B_CHAR_PREV, 22f);
        drawChip(canvas, cl + cw + 14f, y + chh / 2f - 20f, cl + cw + 56f, y + chh / 2f + 22f, ">", 0, B_CHAR_NEXT, 22f);
        y += chh + 12f + 20f;
        textRaw(canvas, GameSettings.CHAR_NAMES[cfg.character] + "  (" + (cfg.character + 1) + "/" + GameSettings.CHARS + ")",
                cx, y, 18f, 0xffffd34a, 5f);
        y += 22f;
        drawButton(canvas, cx - 150f, y, cx + 150f, y + 48f, "KEMBALI", 1, B_BACK, 18f);
    }

    // ---- world objects ------------------------------------------------------------
    private void drawPlacedBlocks(Canvas canvas) {
        long t = now();
        for (int row = BUILD_LIMIT_ROW; row < ROWS; row++) {
            float base = worldToScreenY(GRID_Y + row * CELL);
            for (int col = 0; col < COLS; col++) {
                int type = blocks[row][col];
                if (type < 0) continue;
                float y = base + blockDrop[row * COLS + col];
                if (y > logicalHeight() || y + CELL < areaTop()) continue;
                float x = GRID_X + col * CELL;
                long placed = blockPlacedAt[row][col];
                float age = placed > 0L ? (t - placed) / 1_000_000_000f : 9f;
                if (age >= 0f && age < 0.26f && blockDrop[row * COLS + col] >= 0f) {
                    // pop-in: starts small, overshoots, settles (ease out back)
                    float k = age / 0.26f, s1 = k - 1f;
                    float sc = 0.55f + 0.45f * (1f + 2.2f * s1 * s1 * s1 + 1.2f * s1 * s1);
                    float w = CELL * sc, cxp = x + CELL / 2f, cyb = y + CELL;
                    blit(canvas, blockTextures[type], cxp - w / 2f, cyb - w, cxp + w / 2f, cyb, false);
                } else {
                    blit(canvas, blockTextures[type], x, y, x + CELL, y + CELL, false);
                }
                if (age >= 0f && age < 0.6f) {
                    int a = (int) (200 * (1f - age / 0.6f));
                    fill(canvas, x, y, x + CELL, y + CELL, (a << 24) | 0x00ffffff);
                }
            }
        }
    }

    private void drawPlacementTarget(Canvas canvas) {
        int col, row;
        boolean valid;
        if (breakMode) {
            if (mouseActive && hoverCol >= 0) { col = hoverCol; row = hoverRow; }
            else { col = targetCol; row = targetRow; }
            valid = col >= 0 && row >= 0 && blocks[row][col] >= 0;
        } else if (mouseActive && hoverCol >= 0 && hoverRow >= 0) {
            col = hoverCol; row = hoverRow;
            valid = blocks[row][col] < 0;
        } else {
            col = playerColumn(); row = feetRow();
            valid = row >= BUILD_LIMIT_ROW && blocks[row][col] < 0;
        }
        if (col < 0 || col >= COLS || row < BUILD_LIMIT_ROW || row >= ROWS) return;
        float x = GRID_X + col * CELL;
        float y = worldToScreenY(GRID_Y + row * CELL);
        RectF cell = new RectF(x + 1.5f, y + 1.5f, x + CELL - 1.5f, y + CELL - 1.5f);
        if (!breakMode && valid && blockTextures[materialForRow(row)] != null) {
            paint.setAlpha(90);
            canvas.drawBitmap(blockTextures[materialForRow(row)], null, cell, paint);
            paint.setAlpha(255);
        }
        if (placementFrame != null) drawBitmap(canvas, placementFrame, cell);
        paint.setStyle(Paint.Style.STROKE);
        paint.setStrokeWidth(3f);
        paint.setColor(breakMode ? 0xffff5555 : (valid ? 0xff42ef69 : 0xffffa030));
        canvas.drawRect(cell, paint);
        paint.setStyle(Paint.Style.FILL);
    }

    /** TNT sprite: red block, lit fuse, then flashes white right before the explosion. */
    private void drawTnt(Canvas canvas) {
        for (int i = 0; i < MAX_TNT; i++) {
            if (!tntOn[i]) continue;
            int frame = 0;
            float f = tntFuse[i];
            float pulse = 0f;
            if (f >= 0f) {
                float elapsed = TNT_FUSE - f;
                frame = elapsed < 0.35f ? 1 : 2;
                if (f < 0.55f) {
                    frame = 3 + Math.min(3, (int) ((0.55f - f) / 0.55f * 4f));
                    pulse = (0.55f - f) * 6f;
                }
            }
            float w = CELL * 1.04f + pulse, h = w * 200f / 150f;
            float cx = GRID_X + tntCol[i] * CELL + CELL / 2f;
            float bottom = worldToScreenY(tntY[i] + CELL) + 1.5f + pulse * 0.5f;
            blit(canvas, tntFrames[frame], cx - w / 2f, bottom - h, cx + w / 2f, bottom, false);
        }
    }

    private void drawPlayer(Canvas canvas) {
        if (dead) return;
        boolean spr = isSprint();
        int action = !grounded ? 2 : ((leftHeld || rightHeld) ? (spr ? 1 : 0) : 0);
        int frame = action == 2 ? jumpFrame : (action == 1 ? runFrame : walkFrame);
        Bitmap sprite = characterFrames[action][frame];
        if (sprite == null) return;
        float unit = PLAYER_H / (233f * 0.93f);
        float w = sprite.getWidth() * unit, h = sprite.getHeight() * unit;
        float feet = worldToScreenY(playerFeet) + characterBottom[action][frame] * h;
        tmp.set(playerX - w / 2, feet - h, playerX + w / 2, feet);
        long t = now();
        boolean placing = t < playerPlaceUntilNanos;
        if (placing) {
            float k = (playerPlaceUntilNanos - t) / 220000000f;
            float pulse = (float) Math.sin((1f - k) * Math.PI);
            tmp.offset(facingRight ? pulse * 4f : -pulse * 4f, 0f);
        }
        canvas.save();
        if (!facingRight) canvas.scale(-1, 1, playerX, 0);
        drawBitmap(canvas, sprite, tmp);
        canvas.restore();
        if (cfg.namePlayer && cfg.user.trim().length() > 0) drawNameTag(canvas, "@" + cfg.user.trim(), playerX, tmp.top - 6f, 1f);
        float cxp = playerX, cyp = worldToScreenY(playerFeet) - PLAYER_H * 0.5f;
        if (shieldOn()) {
            float rad = PLAYER_H * 0.66f + (float) Math.sin(gameClock * 5f) * 1.5f + shieldHit * 8f;
            paint.setStyle(Paint.Style.FILL);
            paint.setColor(((int) (46 + shieldHit * 150) << 24) | 0x0050b8ff);
            canvas.drawCircle(cxp, cyp, rad, paint);
            paint.setStyle(Paint.Style.STROKE);
            paint.setStrokeWidth(2.6f);
            paint.setColor(((int) (170 + shieldHit * 80) << 24) | 0x008ae0ff);
            canvas.drawCircle(cxp, cyp, rad, paint);
            paint.setStrokeWidth(1.4f);
            paint.setColor(0x55ffffff);
            canvas.drawCircle(cxp - rad * 0.28f, cyp - rad * 0.3f, rad * 0.5f, paint);
            paint.setStyle(Paint.Style.FILL);
        }
        if (healT > 0f) {
            float k = 1f - healT / 1.4f;
            float s = 30f;
            float hx = cxp, hy = cyp - PLAYER_H * 0.45f - k * 40f;
            paint.setAlpha((int) (255 * Math.min(1f, healT * 2f)));
            blit(canvas, fxIcon[GameSettings.E_HEAL], hx - s / 2f, hy - s / 2f, hx + s / 2f, hy + s / 2f, true);
            paint.setAlpha(255);
        }
        if (hurtFlash > 0f) {
            fill(canvas, cxp - PLAYER_HALF_W - 4f, cyp - PLAYER_H * 0.5f, cxp + PLAYER_HALF_W + 4f, cyp + PLAYER_H * 0.5f,
                    ((int) (110 * hurtFlash / 0.35f) << 24) | 0x00ff2020);
        }
    }

    private void drawEffects(Canvas canvas) {
        drawTornadoes(canvas);
        drawRobots(canvas);
        drawMeteors(canvas);
        drawBolts(canvas);
        drawMonster(canvas);
        drawNukes(canvas);
        drawDrills(canvas);
        drawThrowers(canvas);
        drawBoss(canvas);
        // Explosion sprite animation (spark -> fireball -> smoke).
        for (int i = 0; i < MAX_FX; i++) {
            if (fxT[i] < 0f) continue;
            int frame = Math.min(7, (int) (fxT[i] / FX_TIME * 8f));
            float s = fxS[i], cx = fxX[i], cy = worldToScreenY(fxY[i]);
            blit(canvas, boomFrames[frame], cx - s / 2f, cy - s / 2f, cx + s / 2f, cy + s / 2f, false);
        }
        drawDebris(canvas);
        for (int i = 0; i < MAX_PARTICLES; i++) {
            if (plife[i] <= 0f) continue;
            float a = Math.min(1f, plife[i] * 2.5f);
            int c = ((int) (255 * a) << 24) | (pcol[i] & 0x00ffffff);
            float sy = worldToScreenY(py[i]);
            fill(canvas, px[i] - 2.5f, sy - 2.5f, px[i] + 2.5f, sy + 2.5f, c);
        }
        if (flash > 0.01f) fill(canvas, -exX() - 2f, areaTop(), WORLD_W + exX() + 2f, areaTop() + (controlTop() - areaTop()) / zoom, ((int) (flash * 150f) << 24) | 0x00ffffff);
    }

    private void drawDebris(Canvas canvas) {
        for (int i = 0; i < MAX_DEBRIS; i++) {
            if (dbLife[i] <= 0f) continue;
            Bitmap tex = blockTextures[dbType[i]];
            if (tex == null) continue;
            float sy = worldToScreenY(dbY[i]);
            float s = 15f;
            canvas.save();
            canvas.rotate(dbRot[i], dbX[i], sy);
            paint.setAlpha((int) (255 * Math.min(1f, dbLife[i] * 2.5f)));
            tmp.set(dbX[i] - s / 2f, sy - s / 2f, dbX[i] + s / 2f, sy + s / 2f);
            canvas.drawBitmap(tex, null, tmp, paint);
            paint.setAlpha(255);
            canvas.restore();
        }
    }

    /** Small dark plate with the sender's name, centred on cx. */
    private void drawNameTag(Canvas canvas, String name, float cx, float cy, float alpha) {
        if (name == null || name.length() == 0 || alpha <= 0.02f) return;
        String s = name.length() > 14 ? name.substring(0, 13) + "." : name;
        paint.setTypeface(Typeface.create("sans-serif-black", Typeface.BOLD));
        paint.setTextSize(11f);
        float w = paint.measureText(s) + 14f;
        cx = clampFloat(cx, w / 2f + 2f, WORLD_W - w / 2f - 2f);
        roundRect(canvas, cx - w / 2f, cy - 9f, cx + w / 2f, cy + 9f, 6f, ((int) (190 * alpha) << 24) | 0x00101218);
        boolean lit = literal; literal = true;
        textRaw(canvas, s, cx, cy, 11f, ((int) (255 * alpha) << 24) | 0x00ffffff, 0f);
        literal = lit;
    }

    private void drawTornadoes(Canvas canvas) {
        for (int i = 0; i < MAX_TORNADO; i++) {
            if (!twOn[i]) continue;
            Bitmap f = tornadoFrames[((int) (gameClock * 9f) + i) % 3];
            float sy = worldToScreenY(twY[i]);
            float fade = Math.min(1f, twLife[i] * 1.5f);
            float h = CELL * 4.6f, w = f == null ? 96f : h * f.getWidth() / f.getHeight();
            paint.setAlpha((int) (255 * fade));
            if (f != null) {
                tmp.set(twX[i] - w / 2f, sy + 4f - h, twX[i] + w / 2f, sy + 4f);
                canvas.drawBitmap(f, null, tmp, paint);
            }
            paint.setAlpha(255);
            if (cfg.nameTornado) drawNameTag(canvas, twName[i], twX[i], sy - h - 8f, fade);
        }
    }

    private void drawRobots(Canvas canvas) {
        for (int i = 0; i < MAX_ROBOT; i++) {
            if (!rbOn[i]) continue;
            int frame = rbOut[i] || rbTR[i] < 0 ? 0 : (rbHold[i] > 0.02f ? 2 : 1);
            Bitmap f = robotFrames[frame];
            float cx = rbX[i], cy = worldToScreenY(rbY[i]) + (float) Math.sin(gameClock * 6f + i * 1.7f) * 2.5f;
            float h = 42f, w = f == null ? 42f : h * f.getWidth() / f.getHeight();
            float fade = rbOut[i] ? Math.max(0f, rbFade[i]) : 1f;
            paint.setAlpha((int) (255 * fade));
            if (f != null) {
                tmp.set(cx - w / 2f, cy - h * 0.85f, cx + w / 2f, cy + h * 0.15f);
                canvas.drawBitmap(f, null, tmp, paint);
            }
            paint.setAlpha(255);
            if (cfg.nameRobot) drawNameTag(canvas, rbName[i], cx, cy - h * 0.85f - 10f, fade);
        }
    }

    private void drawMeteors(Canvas canvas) {
        for (int i = 0; i < MAX_METEOR; i++) {
            if (!mtOn[i]) continue;
            float sy = worldToScreenY(mtY[i]);
            float len = (float) Math.sqrt(mtVx[i] * mtVx[i] + mtVy[i] * mtVy[i]);
            float ux = mtVx[i] / Math.max(1f, len), uy = mtVy[i] / Math.max(1f, len);
            paint.setStyle(Paint.Style.FILL);
            for (int k = 6; k >= 1; k--) {
                float r = 15f - k * 2f;
                int a = 120 - k * 16;
                paint.setColor((a << 24) | 0x00ff7a1e);
                canvas.drawCircle(mtX[i] - ux * k * 12f, sy - uy * k * 12f, r, paint);
            }
            // The icon flies toward its lower left, so turn it to follow the real direction.
            float ang = (float) Math.toDegrees(Math.atan2(mtVy[i], mtVx[i])) - 135f;
            canvas.save();
            canvas.rotate(ang, mtX[i], sy);
            blit(canvas, fxIcon[GameSettings.E_METEOR], mtX[i] - 30f, sy - 30f, mtX[i] + 30f, sy + 30f, true);
            canvas.restore();
        }
    }

    private void drawBolts(Canvas canvas) {
        for (int i = 0; i < MAX_BOLT; i++) {
            if (blT[i] < 0f) continue;
            float cx = GRID_X + blCol[i] * CELL + CELL / 2f;
            float y0 = areaTop() - 20f, y1 = worldToScreenY(blY[i]);
            int seed = (int) (blT[i] * 45f) + blCol[i] * 7;
            float prevX = cx + 6f;
            float a = 1f - blT[i] / BOLT_TIME;
            int glow = ((int) (110 * a) << 24) | 0x00ffe55a;
            int core = ((int) (255 * a) << 24) | 0x00fffbe0;
            int n = 0;
            for (float y = y0; y < y1; y += 24f, n++) {
                float nx = cx + (((seed + n * 53) % 29) - 14f) * (y + 24f >= y1 ? 0.15f : 0.5f);
                float h = Math.min(24f, y1 - y);
                fill(canvas, Math.min(prevX, nx) - 6f, y, Math.max(prevX, nx) + 6f, y + h, glow);
                fill(canvas, Math.min(prevX, nx) - 1.5f, y, Math.max(prevX, nx) + 1.5f, y + h, core);
                prevX = nx;
            }
            paint.setStyle(Paint.Style.FILL);
            paint.setColor(glow);
            canvas.drawCircle(cx, y1, 24f * (0.6f + a), paint);
        }
    }

    /** The monster: head sprite on top, a huge pink beam down to the ground while it fires. */
    private void drawMonster(Canvas canvas) {
        if (!moOn) return;
        int frame = moPhase == 0 ? 0 : (moPhase == 1 ? 1 : 2);
        Bitmap f = monsterFrames[frame];
        float sy = worldToScreenY(moY);
        float w = 150f, h = f == null ? 110f : w * f.getHeight() / f.getWidth();
        float mouthY = sy + h * 0.5f;
        if (moPhase == 2 || (moPhase == 3 && moAlpha > 0.1f)) {
            float bottom = worldToScreenY(monsterBeamBottom());
            float pulse = 1f + 0.12f * (float) Math.sin(gameClock * 38f);
            float a = moPhase == 3 ? moAlpha : 1f;
            fill(canvas, moX - 34f * pulse, mouthY, moX + 34f * pulse, bottom, ((int) (70 * a) << 24) | 0x00ff2a9a);
            fill(canvas, moX - 22f * pulse, mouthY, moX + 22f * pulse, bottom, ((int) (150 * a) << 24) | 0x00ff5ab4);
            fill(canvas, moX - 11f * pulse, mouthY, moX + 11f * pulse, bottom, ((int) (235 * a) << 24) | 0x00ffe2f2);
            paint.setStyle(Paint.Style.FILL);
            paint.setColor(((int) (120 * a) << 24) | 0x00ff5ab4);
            canvas.drawCircle(moX, bottom, 40f * pulse, paint);
            paint.setColor(((int) (230 * a) << 24) | 0x00ffffff);
            canvas.drawCircle(moX, bottom, 20f * pulse, paint);
            for (int k = 0; k < 6; k++) {
                float yy = mouthY + ((gameClock * 420f + k * 97f) % Math.max(60f, bottom - mouthY));
                float xx = moX + (float) Math.sin(gameClock * 9f + k * 1.3f) * 30f;
                fill(canvas, xx - 2.5f, yy - 2.5f, xx + 2.5f, yy + 2.5f, 0xffffc8ea);
            }
        } else if (moPhase == 1) {
            float k = Math.min(1f, moT / 0.95f);
            paint.setStyle(Paint.Style.FILL);
            paint.setColor(((int) (90 + 120 * k) << 24) | 0x00ff5ab4);
            canvas.drawCircle(moX, mouthY, 10f + 22f * k, paint);
            paint.setColor(0xffffe2f2);
            canvas.drawCircle(moX, mouthY, 5f + 8f * k, paint);
        }
        if (cfg.nameMonster) drawNameTag(canvas, moName, moX, sy - 10f, moAlpha);
        if (f != null) {
            paint.setAlpha((int) (255 * moAlpha));
            float shakeX = moPhase == 1 ? (float) Math.sin(gameClock * 60f) * 2f : 0f;
            tmp.set(moX - w / 2f + shakeX, sy, moX + w / 2f + shakeX, sy + h);
            canvas.drawBitmap(f, null, tmp, paint);
            paint.setAlpha(255);
        }
    }

    // ---- HUD ----------------------------------------------------------------------
    /** Transparent HUD (no panel behind it): layers | trophies | percent, then the progress bar. */
    private void drawHud(Canvas canvas) {
        float top = hudTop(), off = hudOff();
        if (!cfg.hudTransparent) fill(canvas, 0, 0, WORLD_W, top, MAP_SKY[cfg.map]);
        canvas.save();
        canvas.translate(0f, off);
        int layers = layerCount();

        // Left: cube + "layers/40", the pair centered in its zone.
        String lt = layers + "/" + ROWS;
        float numH = 20f, cubeW = 33f, cubeH = cubeW * 151f / 131f, gap = 7f;
        float numW = Math.min(atlasWidth(lt, numH), 96f);
        float gx = 84f - (cubeW + gap + numW) / 2f;
        blit(canvas, hudCube, gx, 26f - cubeH / 2f, gx + cubeW, 26f + cubeH / 2f, true);
        drawAtlasTextFit(canvas, lt, gx + cubeW + gap + numW / 2f, 26f, numH, 96f);

        // Center: trophy plate, the number sits in the middle of the dark panel.
        float tw = 196f, th = tw * 162f / 791f, tl = (WORLD_W - tw) / 2f, tt = 26f - th / 2f;
        blit(canvas, hudTrophy, tl, tt, tl + tw, tt + th, true);
        drawAtlasTextFit(canvas, winCount + "/" + Math.max(1, cfg.winTarget), tl + tw / 2f, tt + th * 0.52f, 15f, tw * 0.36f);

        // Right: percent, centered between the trophy and the pause button.
        drawAtlasTextFit(canvas, areaPercent() + "%", 408f, 26f, numH, 78f);

        // Row 2: segmented progress bar (15 compartments) = filled layers.
        float bx = 7f, by = 52f, bw = 498f, bh = bw * 151f / 2016f;
        blit(canvas, hudBar, bx, by, bx + bw, by + bh, true);
        float k = bw / 2016f;
        float fillSegs = layers / (float) ROWS * (BAR_SEG.length / 2);
        for (int i = 0; i < BAR_SEG.length / 2; i++) {
            float part = Math.max(0f, Math.min(1f, fillSegs - i));
            if (part <= 0f) continue;
            float l = bx + BAR_SEG[i * 2] * k;
            float r = l + (BAR_SEG[i * 2 + 1] - BAR_SEG[i * 2]) * k * part;
            float t = by + 38f * k, b = by + 100f * k;
            fill(canvas, l, t, r, b, 0xff2fd24a);
            fill(canvas, l, t, r, t + (b - t) * 0.35f, 0xff7cf08a);
        }
        canvas.restore();
        drawPauseControl(canvas);

    }

    private void drawPauseControl(Canvas canvas) {
        boolean pr = pressedAt(pauseRect);
        drawPlate(canvas, pauseRect.left, pauseRect.top + 2f, pauseRect.right, pauseRect.bottom - 2f,
                pr ? 0xff3a4058 : 0xdd191c26);
        float cx = pauseRect.centerX(), cy = pauseRect.centerY();
        fill(canvas, cx - 7f, cy - 8f, cx - 2.5f, cy + 8f, 0xffffffff);
        fill(canvas, cx + 2.5f, cy - 8f, cx + 7f, cy + 8f, 0xffffffff);
    }

    /** Small round badge with the effect picture (petir, tornado, ...) in a corner of a gift tile. */
    private void drawEffectBadge(Canvas canvas, int effect, float x, float y, float s) {
        if (effect < 0 || effect >= GameSettings.EFFECTS || fxIcon[effect] == null) return;
        paint.setStyle(Paint.Style.FILL);
        paint.setColor(0xe0101218);
        canvas.drawCircle(x + s / 2f, y + s / 2f, s / 2f + 1f, paint);
        blit(canvas, fxIcon[effect], x + 2f, y + 2f, x + s - 2f, y + s - 2f, true);
    }

    private void drawGiftRow(Canvas canvas) {
        for (int k = 0; k < giftCount; k++) {
            RectF r = giftRects[k];
            boolean active = false, flash;
            if (tileEv[k]) {
                int ei = giftIdx[k];
                GameSettings.Rule ru = cfg.rules[ei];
                flash = ruleFlash[ei] > 0f;
                drawPlate(canvas, r.left, r.top, r.right, r.bottom, 0xcc16283a);
                if (ei == GameSettings.EV_GIFT) {
                    blitFit(canvas, evIcon[ei], r.left + 6f, r.top + 5f, r.right - 6f, r.top + 5f + (r.width() - 12f));
                    text(canvas, GameSettings.EVENT_SHORT[ei], r.centerX(), r.bottom - 9f, 11f, 0xff9fe8ff, 4f, r.width() - 4f);
                } else {
                    blitFit(canvas, evIcon[ei], r.left + 3f, r.top + 8f, r.right - 3f, r.bottom - 3f);   // badge already carries its name
                }
                drawEffectBadge(canvas, ru.effect, r.right - 22f, r.top + 1f, 21f);
            } else {
                GameSettings.Gift g = cfg.gifts[giftIdx[k]];
                active = g.effect == GameSettings.E_SHIELD && shieldOn();
                flash = giftFlash[giftIdx[k]] > 0f;
                drawPlate(canvas, r.left, r.top, r.right, r.bottom, 0xcc1a1d28);
                float iw = r.width() - 10f;
                blit(canvas, giftBitmap(g.name, g.icon), r.left + 5f, r.top + 5f, r.left + 5f + iw, r.top + 5f + iw, true);
                drawEffectBadge(canvas, g.effect, r.left + 1f, r.top + 1f, 21f);
                text(canvas, g.shownLabel(), r.centerX(), r.bottom - 9f, 12f, 0xffffffff, 4f, r.width() - 6f);
            }
            if (flash || active) {
                paint.setStyle(Paint.Style.STROKE);
                paint.setStrokeWidth(2.5f);
                paint.setColor(active ? 0xff5ad8ff : 0xffffe14a);
                canvas.drawRoundRect(r, 8f, 8f, paint);
                paint.setStyle(Paint.Style.FILL);
            }
        }
    }

    private void drawMinimap(Canvas canvas) {
        float x0 = 495.5f, x1 = 508f;
        float top = hudTop() + 6f, bottom = controlTop() - 8f, h = bottom - top;
        if (h < 40f) return;
        float gridH = ROWS * CELL;
        fill(canvas, x0 - 1.5f, top - 3f, x1 + 1.5f, bottom + 1.5f, 0xff0a0d18);
        fill(canvas, x0, top, x1, bottom, 0xff1c2340);
        fill(canvas, x0, top - 2f, x1, top + 1f, 0xffffc928);
        float rowH = h / ROWS;
        for (int r = 0; r < ROWS; r++) {
            int type = -1;
            for (int c = 0; c < COLS && type < 0; c++) type = blocks[r][c];
            if (type < 0) continue;
            float y = top + r * rowH;
            fill(canvas, x0 + 1f, y + 0.4f, x1 - 1f, y + rowH, blockColor[type]);
        }
        float vTop = top + clampFloat((cameraY - GRID_Y) / gridH, 0f, 1f) * h;
        float vBot = top + clampFloat((cameraY + viewH() - GRID_Y) / gridH, 0f, 1f) * h;
        paint.setStyle(Paint.Style.STROKE);
        paint.setStrokeWidth(1.2f);
        paint.setColor(0xccffffff);
        canvas.drawRect(x0 - 1f, vTop, x1 + 1f, Math.max(vTop + 4f, vBot), paint);
        float py2 = top + clampFloat((playerFeet - PLAYER_H * 0.5f - GRID_Y) / gridH, 0f, 1f) * h;
        paint.setStyle(Paint.Style.FILL);
        paint.setColor(0xffff9a3c);
        canvas.drawCircle(x0 - 3.5f, py2, 2.4f, paint);
    }

    /** Height of the bottom-left panel (HP bar + lives, shield timer); the feed stacks above it. */
    private float bottomPanelH() {
        float h = 0f;
        if (cfg.mortal && cfg.showHp) h += 150f * 134f / 641f + 6f;
        if (shieldOn()) h += 34f;
        return h;
    }

    /** Bottom-left, just above the control buttons: HP bar + extra lives, shield timer. */
    private void drawHpPanel(Canvas canvas) {
        float x = 8f, y = controlTop() - bottomPanelH() - 6f;
        if (cfg.mortal && cfg.showHp) {
            float w = 150f, h = w * 134f / 641f;
            float k = w / 641f;
            blit(canvas, hudHp, x, y, x + w, y + h, true);
            float ix0 = x + 130f * k, ix1 = x + 596f * k, iy0 = y + 46f * k, iy1 = y + 92f * k;
            float f = clampFloat(hp / 100f, 0f, 1f);
            if (f > 0f) {
                int c1 = shieldOn() ? 0xff4ad0ff : 0xffe02a2a, c2 = shieldOn() ? 0xff9ae8ff : 0xffff6a6a;
                fill(canvas, ix0, iy0, ix0 + (ix1 - ix0) * f, iy1, c1);
                fill(canvas, ix0, iy0, ix0 + (ix1 - ix0) * f, iy0 + (iy1 - iy0) * 0.35f, c2);
            }
            if (lives > 0) {
                blit(canvas, fxIcon[GameSettings.E_HEAL], x + w + 4f, y + h / 2f - 11f, x + w + 26f, y + h / 2f + 11f, true);
                textRaw(canvas, "x" + lives, x + w + 44f, y + h / 2f, 15f, 0xffffffff, 4f);
            }
            y += h + 6f;
        }
        if (shieldOn()) {
            int sec = (int) Math.ceil(shieldUntil - gameClock);
            drawPlate(canvas, x, y, x + 92f, y + 28f, 0xcc10202c);
            blit(canvas, fxIcon[GameSettings.E_SHIELD], x + 6f, y + 3f, x + 28f, y + 25f, true);
            textRaw(canvas, (sec / 60) + ":" + (sec % 60 < 10 ? "0" : "") + (sec % 60), x + 58f, y + 14f, 14f, 0xff9ae8ff, 4f);
        }
    }

    /** "MATI" title in the middle of the screen while the player waits to respawn. */
    private void drawDeadBanner(Canvas canvas) {
        if (!dead) return;
        float cx = WORLD_W * 0.5f, cy = (areaTop() + controlTop()) * 0.5f;
        roundRect(canvas, cx - 130f, cy - 52f, cx + 130f, cy + 52f, 18f, 0xc0200a0e);
        paint.setStyle(Paint.Style.STROKE);
        paint.setStrokeWidth(3.5f);
        paint.setColor(0xffff5a4a);
        tmp.set(cx - 130f, cy - 52f, cx + 130f, cy + 52f);
        canvas.drawRoundRect(tmp, 18f, 18f, paint);
        paint.setStyle(Paint.Style.FILL);
        text(canvas, "MATI", cx, cy - 16f, 40f, 0xffff6a5a, 7f, 220f);
        text(canvas, "HIDUP LAGI " + (int) Math.ceil(Math.max(0f, deadT)) + "s", cx, cy + 28f, 14f, 0xffffffff, 4f, 230f);
    }

    private void drawFeed(Canvas canvas) {
        if (!cfg.feed) return;
        float baseY = controlTop() - 24f - bottomPanelH();
        for (int i = 0; i < FEED_LINES; i++) {
            if (feedText[i] == null) continue;
            float left = feedUntil[i] - gameClock;
            if (left <= 0f) { feedText[i] = null; continue; }
            float y = baseY - i * 24f;
            int a = (int) (255 * Math.min(1f, left * 1.5f));
            paint.setTypeface(Typeface.create("sans-serif-black", Typeface.BOLD));
            float size = 12f;
            paint.setTextSize(size);
            String ft = feedText[i];
            float w = paint.measureText(ft);
            while (w > 262f && ft.length() > 4) { ft = ft.substring(0, ft.length() - 2).trim() + "\u2026"; w = paint.measureText(ft); }
            roundRect(canvas, 4f, y - 11f, 40f + w, y + 11f, 8f, (a / 2 << 24));
            paint.setAlpha(a);
            blit(canvas, giftBitmap(feedName[i], feedIcon[i]), 7f, y - 10f, 27f, y + 10f, true);
            paint.setAlpha(255);
            literal = true;
            textRaw(canvas, ft, 33f + w / 2f, y, size, (a << 24) | (feedColor[i] & 0x00ffffff), 3f);
            literal = false;
        }
    }

    private void drawToast(Canvas canvas) {
        float k = Math.min(1f, (toastUntil - gameClock) * 3f);
        if (k <= 0f) return;
        boolean lit = literal; literal = true;
        text(canvas, toastText, WORLD_W / 2f, hudTop() + 52f, 22f, 0xffffffff, 6f, 440f);
        literal = lit;
    }

    /** Full-arena countdown with its title; also the "cancelled" notice after a layer was destroyed. */
    private void drawRoundCountdown(Canvas canvas) {
        float cx = WORLD_W * 0.5f;
        float cy = hudTop() + (controlTop() - hudTop()) * 0.42f;
        if (countdownValue < 0) {
            float a = Math.min(1f, cancelT);
            roundRect(canvas, cx - 120f, cy - 30f, cx + 120f, cy + 30f, 14f, ((int) (170 * a) << 24));
            text(canvas, "BATAL!", cx, cy - 8f, 26f, ((int) (255 * a) << 24) | 0x00ff6a5a, 6f, 220f);
            text(canvas, "ADA LAYER YANG HANCUR", cx, cy + 16f, 11f, ((int) (255 * a) << 24) | 0x00ffffff, 3f, 220f);
            return;
        }
        roundRect(canvas, cx - 96f, cy - 86f, cx + 96f, cy + 78f, 18f, 0xb9000000);
        paint.setStyle(Paint.Style.STROKE);
        paint.setStrokeWidth(4f);
        paint.setColor(0xffffc928);
        tmp.set(cx - 96f, cy - 86f, cx + 96f, cy + 78f);
        canvas.drawRoundRect(tmp, 18f, 18f, paint);
        paint.setStyle(Paint.Style.FILL);
        text(canvas, "ARENA PENUH!", cx, cy - 62f, 19f, 0xffffd34a, 5f, 170f);
        text(canvas, "MENANG DALAM", cx, cy - 40f, 10.5f, 0xffffffff, 3f, 170f);
        drawAtlasText(canvas, String.valueOf(countdownValue), cx, cy + 20f, 76f);
    }

    private Rect fontSource(char ch) {
        switch (ch) {
            case '0': return new Rect(254, 529, 369, 649);
            case '1': return new Rect(395, 529, 484, 649);
            case '2': return new Rect(499, 529, 613, 649);
            case '3': return new Rect(627, 529, 739, 649);
            case '4': return new Rect(751, 529, 872, 649);
            case '5': return new Rect(890, 529, 1005, 649);
            case '6': return new Rect(1022, 529, 1139, 649);
            case '7': return new Rect(1155, 529, 1266, 649);
            case '8': return new Rect(1285, 529, 1399, 649);
            case '9': return new Rect(1416, 529, 1533, 649);
            case '/': return new Rect(1432, 655, 1520, 765);
            case '%': return new Rect(643, 763, 758, 873);
            default: return null;
        }
    }

    private float atlasWidth(String text, float targetHeight) {
        float total = 0f;
        for (int i = 0; i < text.length(); i++) {
            Rect r = fontSource(text.charAt(i));
            if (r != null) total += targetHeight * (r.width() / (float) r.height()) + 2f;
        }
        return total > 0f ? total - 2f : 0f;
    }

    private void drawAtlasTextFit(Canvas canvas, String text, float cx, float cy, float h, float maxW) {
        float w = atlasWidth(text, h);
        if (w > maxW && w > 0f) h = h * maxW / w;
        drawAtlasText(canvas, text, cx, cy, h);
    }

    private void drawAtlasText(Canvas canvas, String text, float centerX, float centerY, float targetHeight) {
        if (fontAtlas == null || text == null || text.length() == 0) return;
        float x = centerX - atlasWidth(text, targetHeight) / 2f;
        for (int i = 0; i < text.length(); i++) {
            Rect src = fontSource(text.charAt(i));
            if (src == null) continue;
            float w = targetHeight * src.width() / (float) src.height();
            tmp.set(x, centerY - targetHeight / 2f, x + w, centerY + targetHeight / 2f);
            paint.setAlpha(255);
            paint.setFilterBitmap(false);
            canvas.drawBitmap(fontAtlas, src, tmp, paint);
            x += w + 2f;
        }
    }

    private void drawControls(Canvas canvas) {
        Bitmap[] images = {leftImage, rightImage, runImage, pickImage, blockImage, jumpImage};
        final int[] roles = {ROLE_LEFT, ROLE_RIGHT, ROLE_RUN, ROLE_PICK, ROLE_BUILD, ROLE_JUMP};
        for (int i = 0; i < 6; i++) {
            boolean held = false;
            for (int p = 0; p < touches.size(); p++) {
                if (touches.valueAt(p).role == roles[i]) { held = true; break; }
            }
            if (i == 0 && keyLeft) held = true;
            if (i == 1 && keyRight) held = true;
            if (i == 4 && keyBuild) held = true;
            if (i == 5 && keyJump) held = true;
            boolean active = (i == 2 && isSprint()) || (i == 3 && breakMode);
            if (active) {
                paint.setStyle(Paint.Style.FILL);
                paint.setColor(i == 3 ? 0x5537cfff : 0x55ffc928);
                canvas.drawRoundRect(icon[i], 18, 18, paint);
            }
            tmp.set(icon[i]);
            if (held) {
                float cx = tmp.centerX(), cy = tmp.centerY();
                tmp.inset(tmp.width() * 0.055f, tmp.height() * 0.055f);
                tmp.offset(cx - tmp.centerX(), cy - tmp.centerY());
            }
            drawBitmap(canvas, images[i], tmp);
            if (i == 4 && !cfg.unlimited) {
                drawAtlasTextFit(canvas, String.valueOf(inventory), icon[i].centerX(), icon[i].top - 7f, 13f, 44f);
            }
        }
    }

    // ================================================================================
    // Game rules
    // ================================================================================
    /** Back into the game that is already there (leaving to the menu does not clear the area). */
    private void continueGame() {
        if (!gameExists) { startGame(); return; }
        if (hp <= 0f) hp = 100f;
        dead = false;
        sessionActive = true;
        screen = SCREEN_GAME;
        lastFrameNanos = 0L;
    }

    private void startGame() {
        gameExists = true;
        resetGame();
        sessionActive = true;
        screen = SCREEN_GAME;
    }

    private void resetGame() {
        for (int r = 0; r < ROWS; r++) {
            for (int c = 0; c < COLS; c++) { blocks[r][c] = -1; blockPlacedAt[r][c] = 0L; }
        }
        playerX = GRID_X + (COLS * CELL) / 2f;
        playerFeet = FLOOR_Y;
        velocityY = 0f;
        cameraY = 0f; cameraTarget = 0f;
        grounded = true; wasGrounded = true;
        facingRight = true;
        targetCol = -1; targetRow = -1;
        countdownValue = -1; cdClock = 0f; cancelT = 0f; winCount = 0;
        inventory = MAX_INVENTORY; hp = 100f; lives = 0; dead = false; likeAcc = 0;
        shieldUntil = -1f; toastUntil = -1f;
        rainLeft = 0; shake = 0f; gameClock = 0f; hurtFlash = 0f; shieldHit = 0f; healT = 0f; winFlashT = 0f;
        buildCooldown = 0f; gridCooldown = 0f;
        breakMode = false;
        clearEffects();
        releaseAllInput();
        lastFrameNanos = 0L;
    }

    private void clearEffects() {
        for (int i = 0; i < MAX_TNT; i++) tntOn[i] = false;
        for (int i = 0; i < MAX_PARTICLES; i++) plife[i] = 0f;
        for (int i = 0; i < MAX_FX; i++) fxT[i] = -1f;
        for (int i = 0; i < MAX_TORNADO; i++) twOn[i] = false;
        for (int i = 0; i < MAX_ROBOT; i++) { rbOn[i] = false; rbTR[i] = -1; rbTC[i] = -1; rbName[i] = ""; }
        for (int i = 0; i < pendWho.length; i++) pendWho[i].clear();
        protectUntil = -1f; deadT = 0f; moName = "";
        for (int i = 0; i < MAX_METEOR; i++) mtOn[i] = false;
        for (int i = 0; i < MAX_BOLT; i++) blT[i] = -1f;
        for (int i = 0; i < MAX_DEBRIS; i++) dbLife[i] = 0f;
        moOn = false;
        for (int i = 0; i < MAX_NUKE; i++) { nkOn[i] = false; nkBoom[i] = false; nkName[i] = ""; }
        for (int i = 0; i < MAX_DRILL; i++) { drOn[i] = false; drName[i] = ""; }
        for (int i = 0; i < MAX_THROWER; i++) { thOn[i] = false; thPend[i] = false; thName[i] = ""; }
        zoom = 1f; zoomHold = 0f;
        for (int i = 0; i < MAX_THROWN; i++) pjOn[i] = false;
        bsOn = false; bsName = "";
        for (int i = 0; i < pend.length; i++) pend[i] = 0;
        for (int i = 0; i < blockDrop.length; i++) { blockDrop[i] = 0f; blockDropV[i] = 0f; }
        for (int i = 0; i < FEED_LINES; i++) feedText[i] = null;
        flash = 0f;
        while (live.poll() != null) { }
        for (int i = 0; i < GameSettings.GIFTS; i++) giftFlash[i] = 0f;
        for (int i = 0; i < GameSettings.EVENTS; i++) ruleFlash[i] = 0f;
    }

    private void resetBoardAfterWin() {
        for (int r = 0; r < ROWS; r++) for (int c = 0; c < COLS; c++) {
            blocks[r][c] = -1;
            blockPlacedAt[r][c] = 0L;
        }
        playerX = GRID_X + (COLS * CELL) / 2f;
        playerFeet = FLOOR_Y;
        velocityY = 0f;
        grounded = true;
        cameraY = 0f; cameraTarget = 0f;
        facingRight = true;
        targetCol = -1; targetRow = -1;
        hp = 100f;
        clearEffects();
    }

    private void toast(String text) {
        if (text == null || text.length() == 0) return;
        toastText = T(text);
        toastUntil = gameClock + 1.6f;
    }

    /** Notification toast in the "name > text" format. */
    private void toastWho(String who, String text) {
        if (text == null || text.length() == 0) return;
        toastText = (who == null || who.length() == 0 ? "" : who + " > ") + T(text);
        toastUntil = gameClock + 1.6f;
    }

    private void deny(String text) {
        toast(text);
        if (gameClock - lastPlaceSound > 0.15f) { lastPlaceSound = gameClock; play(sNoGo, 0.5f, 1f); }
    }

    private boolean canAct() { return screen == SCREEN_GAME && !dead; }

    private boolean withinRange(int col, int row) {
        float playerRow = (playerFeet - GRID_Y) / CELL;
        float dx = col - playerColumn(), dy = row - playerRow;
        return Math.sqrt(dx * dx + dy * dy) <= 10.0;
    }

    private boolean cellOverlapsPlayer(int col, int row) {
        if (dead) return false;
        float l = GRID_X + col * CELL, t = GRID_Y + row * CELL;
        return playerX + PLAYER_HALF_W > l + 1f && playerX - PLAYER_HALF_W < l + CELL - 1f
                && t + CELL > playerFeet - PLAYER_H + 1f && t < playerFeet - 1f;
    }

    private boolean canSpend() { return cfg.unlimited || inventory > 0; }

    private void spend() {
        if (!cfg.unlimited && inventory > 0) inventory--;
    }

    /** A block may only be put where it touches something: the floor, a block below, beside or above. */
    private boolean supported(int col, int row) {
        if (row >= ROWS - 1) return true;
        if (blocks[row + 1][col] >= 0) return true;
        if (col > 0 && blocks[row][col - 1] >= 0) return true;
        if (col < COLS - 1 && blocks[row][col + 1] >= 0) return true;
        return row > 0 && blocks[row - 1][col] >= 0;
    }

    private void playPut(float vol) {
        putRot = (putRot + 1 + rnd.nextInt(1)) % 2;
        play(sPuts[putRot], vol, 0.94f + rnd.nextFloat() * 0.12f);
    }

    private void afterPlace(int col, int row) {
        blockPlacedAt[row][col] = now();
        spawnBurst(GRID_X + col * CELL + CELL / 2f, GRID_Y + row * CELL + CELL / 2f,
                blockColor[blocks[row][col]], 3, 90f);
        if (gameClock - lastPlaceSound > 0.05f) {
            lastPlaceSound = gameClock;
            playPut(0.8f);
        }
        playerPlaceUntilNanos = now() + 200000000L;
    }

    /**
     * Minecraft pillar placement: a block appears in the cell under the player's feet and the
     * player is moved straight on top of it. In mid-air the block goes into the highest cell below
     * that still touches something (up to 3 cells down) and the player falls onto it.
     */
    private boolean placeUnderPlayer() {
        if (!canAct()) return false;
        int row = feetRow();
        if (row < BUILD_LIMIT_ROW) { deny("SUDAH PALING ATAS"); return false; }
        if (row >= ROWS) return false;
        int first = clamp((int) ((playerX - PLAYER_HALF_W - GRID_X) / CELL), 0, COLS - 1);
        int last = clamp((int) ((playerX + PLAYER_HALF_W - GRID_X) / CELL), 0, COLS - 1);
        int near = playerColumn();
        int[] order;
        if (first == last) {
            order = new int[]{near};
        } else {
            // standing on the line between two columns: left and right take turns
            int other = near == first ? last : first;
            order = underCol == near ? new int[]{other, near} : new int[]{near, other};
        }
        String why = "";
        for (int c : order) {
            String r = placeUnderCell(c, row);
            if (r == null) { underCol = c; return true; }
            if (r.length() > 0) why = r;
        }
        if (why.length() > 0) deny(why);
        return false;
    }

    /** One column of the place-under button. Returns null when placed, else the reason ("" = silent). */
    private String placeUnderCell(int col, int row) {
        if (blocks[row][col] >= 0) return "";
        int target = -1;
        if (cfg.blockGravity) {
            target = row;
            while (target + 1 < ROWS && blocks[target + 1][col] < 0) target++;
        } else {
            for (int r = row; r < ROWS && r <= row + 3; r++) {
                if (blocks[r][col] >= 0) break;
                if (supported(col, r)) { target = r; break; }
            }
            if (target < 0) return "TIDAK ADA PENOPANG";
        }
        if (!canSpend()) return "BLOK HABIS";
        if (target != row) {
            blocks[target][col] = pickType(target);
            blockDrop[target * COLS + col] = -(target - row) * CELL;
            blockDropV[target * COLS + col] = 0f;
            spend();
            afterPlace(col, target);
            blockPlacedAt[target][col] = 0L;                  // pop animation plays when it lands
            return null;
        }
        float newFeet = GRID_Y + row * CELL;
        if (blockedAt(playerX, newFeet - PLAYER_H, newFeet)) return "ATAP TERHALANG";
        blocks[row][col] = pickType(row);
        spend();
        playerFeet = newFeet;
        velocityY = 0f;
        grounded = true;
        afterPlace(col, row);
        return null;
    }

    /**
     * Places a block into an empty cell (tap / mouse click). The tapped cell only has to touch something;
     * with "blok jatuh" on, the block then falls down its column until it rests on something.
     */
    private boolean placeAt(int col, int row) { return placeCell(col, row, true); }

    private boolean placeCell(int col, int row, boolean needSupport) {
        if (!canAct()) return false;
        if (col < 0 || col >= COLS || row < BUILD_LIMIT_ROW || row >= ROWS) return false;
        if (blocks[row][col] >= 0) return false;
        if (cellOverlapsPlayer(col, row)) {
            if (col == playerColumn() && row == feetRow()) return placeUnderPlayer();
            deny("ADA PLAYER");
            return false;
        }
        if (!withinRange(col, row)) { deny("TERLALU JAUH"); return false; }
        if (needSupport && !supported(col, row)) { deny("TIDAK ADA PENOPANG"); return false; }
        if (!canSpend()) { deny("BLOK HABIS"); return false; }
        int target = row;
        if (cfg.blockGravity) {
            while (target + 1 < ROWS && blocks[target + 1][col] < 0) target++;
            for (int r = row; r <= target; r++) {
                if (cellOverlapsPlayer(col, r)) { deny("PLAYER DI BAWAH"); return false; }
            }
        }
        if (col != playerColumn()) facingRight = col > playerColumn();
        blocks[target][col] = pickType(target);
        if (target != row) {
            blockDrop[target * COLS + col] = -(target - row) * CELL;
            blockDropV[target * COLS + col] = 0f;
        }
        spend();
        afterPlace(col, target);
        if (target != row) blockPlacedAt[target][col] = 0L;   // pop animation plays when it lands
        return true;
    }

    /** First empty cell of a column, counted from the floor (-1 when the column is full). */
    private int lowestEmptyRow(int c) {
        for (int r = ROWS - 1; r >= BUILD_LIMIT_ROW; r--) if (blocks[r][c] < 0) return r;
        return -1;
    }

    /** BLOK effect: n blocks appear at once in the arena, lowest layer first, left to right. */
    private int fillBlocks(int n) {
        boolean[] skip = new boolean[COLS];
        int placed = 0;
        for (int k = 0; k < n; k++) {
            int bc = -1, br = -1;
            for (int c = 0; c < COLS; c++) {
                if (skip[c]) continue;
                int r = lowestEmptyRow(c);
                if (r > br) { br = r; bc = c; }
            }
            if (bc < 0) break;
            if (cellOverlapsPlayer(bc, br)) {
                float newFeet = GRID_Y + br * CELL;
                if (br == feetRow() && !blockedAt(playerX, newFeet - PLAYER_H, newFeet)) {
                    blocks[br][bc] = pickType(br);
                    blockPlacedAt[br][bc] = now();
                    playerFeet = newFeet; velocityY = 0f; grounded = true;
                    placed++;
                } else {
                    skip[bc] = true; k--;
                }
                continue;
            }
            blocks[br][bc] = pickType(br);
            blockPlacedAt[br][bc] = now();
            blockDrop[br * COLS + bc] = -CELL * 1.2f;
            blockDropV[br * COLS + bc] = 0f;
            spawnBurst(GRID_X + bc * CELL + CELL / 2f, GRID_Y + br * CELL + CELL / 2f, blockColor[blocks[br][bc]], 2, 90f);
            placed++;
        }
        if (placed > 0 && gameClock - lastPlaceSound > 0.05f) {
            lastPlaceSound = gameClock;
            playPut(0.85f);
        }
        return placed;
    }

    /**
     * Bedrock style "place in front": the block goes into the cell the player is facing. It uses the
     * feet level; when that cell is taken it goes on top, when there is a hole it goes into the hole.
     */
    private boolean placeFront() {
        if (!canAct()) return false;
        int col = playerColumn() + (facingRight ? 1 : -1);
        if (col < 0 || col >= COLS) { deny("PINGGIR ARENA"); return false; }
        int fr = feetRow();
        int[] order = {fr, fr - 1, fr + 1, fr - 2};
        for (int r : order) {
            if (r < BUILD_LIMIT_ROW || r >= ROWS || blocks[r][col] >= 0) continue;
            if (cellOverlapsPlayer(col, r)) continue;
            boolean bridge = cfg.blockGravity && grounded && r == fr;
            if (!bridge && !supported(col, r)) continue;
            return placeCell(col, r, !bridge);
        }
        deny("TIDAK ADA PENOPANG");
        return false;
    }

    private void killBlock(int c, int r, int burst, int debris) {
        int type = blocks[r][c];
        if (type < 0) return;
        float cx = GRID_X + c * CELL + CELL / 2f, cy = GRID_Y + r * CELL + CELL / 2f;
        if (burst > 0) spawnBurst(cx, cy, blockColor[type], burst, 200f);
        if (debris > 0) spawnDebris(cx, cy, type, debris);
        blocks[r][c] = -1;
        blockPlacedAt[r][c] = 0L;
        blockDrop[r * COLS + c] = 0f;
    }

    private void recheckGround() {
        if (grounded && !hasSurfaceAtFeet(playerX, playerFeet)) { grounded = false; velocityY = 0f; }
    }

    private boolean breakBlockAt(int col, int row) {
        if (col < 0 || col >= COLS || row < BUILD_LIMIT_ROW || row >= ROWS) return false;
        if (blocks[row][col] < 0 || !withinRange(col, row)) return false;
        killBlock(col, row, 7, 1);
        if (inventory < MAX_INVENTORY) inventory++;
        play(sBreak, 0.7f, 0.95f + rnd.nextFloat() * 0.2f);
        // Blocks above never fall. Only the player can lose its footing.
        recheckGround();
        return true;
    }

    private void mineFront() {
        int col = playerColumn() + (facingRight ? 1 : -1);
        if (col < 0 || col >= COLS) return;
        int feetRow = (int) Math.floor((playerFeet - 2f - GRID_Y) / CELL);
        int[] order = {feetRow, feetRow + 1, feetRow - 1};
        for (int r : order) {
            if (breakBlockAt(col, r)) { targetCol = col; targetRow = r; return; }
        }
    }

    private void mineDown() {
        int col = playerColumn();
        int row = (int) Math.floor((playerFeet + 2f - GRID_Y) / CELL);
        if (breakBlockAt(col, row)) { targetCol = col; targetRow = row; }
    }

    // ---- layers / countdown / win ------------------------------------------------------
    private void updateCountdown(float dt) {
        if (winFlashT > 0f) winFlashT -= dt;
        if (cancelT > 0f) cancelT -= dt;
        boolean full = layerCount() >= ROWS;
        if (countdownValue < 0) {
            if (full && !dead) {
                countdownValue = Math.max(3, cfg.countdownStart);
                cdClock = cfg.countdownStep / 10f;
                play(sTick, 0.8f, 1f);
            }
            return;
        }
        if (!full) {                                      // a layer was destroyed: the countdown is cancelled
            countdownValue = -1;
            cancelT = 2.2f;
            play(sCancel, 0.9f, 1f);
            toast("HITUNG MUNDUR BATAL!");
            return;
        }
        cdClock -= dt;
        if (cdClock <= 0f) {
            countdownValue--;
            if (countdownValue <= 0) { winRound(); return; }
            cdClock = cfg.countdownStep / 10f;
            play(sTick, 0.8f, countdownValue <= 3 ? 1.45f : 1f);
        }
    }

    private void winRound() {
        winCount = Math.min(Math.max(1, cfg.winTarget), winCount + 1);
        countdownValue = -1;
        play(sWin, 1f, 1f);
        resetBoardAfterWin();
        winFlashT = 2.5f;
        toast(winCount >= cfg.winTarget ? "TARGET MENANG TERCAPAI!" : "MENANG!  " + winCount + "/" + cfg.winTarget);
    }

    // ---- TNT / gifts / events -------------------------------------------------------
    private boolean spawnTnt(int col, float fuse) {
        if (col < 0 || col >= COLS) return false;
        int slot = -1;
        for (int i = 0; i < MAX_TNT; i++) if (!tntOn[i]) { slot = i; break; }
        if (slot < 0) return false;
        float surface = GRID_Y + topBlockRow(col) * CELL;
        float y = Math.max(GRID_Y - CELL, cameraY - CELL);
        y = Math.min(y, surface - CELL);
        tntOn[slot] = true;
        tntCol[slot] = col;
        tntY[slot] = y;
        tntVy[slot] = 0f;
        tntFuse[slot] = fuse;
        return true;
    }

    /** TNT that is placed straight on a spot (thrown by the TNT thrower); the fuse starts when it rests. */
    private boolean spawnTntAt(int col, float y) {
        if (col < 0 || col >= COLS) return false;
        for (int i = 0; i < MAX_TNT; i++) {
            if (tntOn[i]) continue;
            tntOn[i] = true; tntCol[i] = col; tntY[i] = y; tntVy[i] = 0f; tntFuse[i] = -1f;
            return true;
        }
        return false;
    }

    /** slot = index into the list of gifts that are currently shown. */
    private void triggerShownGift(int slot) {
        layoutGifts();
        if (slot < 0 || slot >= giftCount) return;
        if (tileEv[slot]) triggerEvent(giftIdx[slot]); else triggerGift(giftIdx[slot]);
    }

    /** Manual tap on an event tile: runs the rule like a real event (also when the rule is switched off). */
    private void triggerEvent(int idx) {
        if (!canAct() || idx < 0 || idx >= GameSettings.EVENTS) return;
        LiveClient.Event e = new LiveClient.Event();
        e.user = "kamu"; e.count = idx == GameSettings.EV_LIKE ? Math.max(1, cfg.likeEvery) : 1; e.text = "halo semua";
        if (idx == GameSettings.EV_GIFT) {
            GameSettings.Rule r = cfg.rules[idx];
            ruleFlash[idx] = 0.45f;
            applyEffect(r.effect, r.amount, "kamu");
            if (!playCustom(r.sound)) playEventSound(sGift);
            addFeed(feedGift("kamu", 1, T("gift")), 0xffffe14a, GiftCatalog.GENERIC_ICON);
            toastWho("kamu", GameSettings.toast(r.effect, r.amount));
        } else {
            fireRuleForced(idx, "kamu", e);
        }
    }

    /** Manual tap / key on a gift tile: same effect a viewer's gift would have. */
    private void triggerGift(int i) {
        if (!canAct() || i < 0 || i >= GameSettings.GIFTS) return;
        fireGiftSlot(i, "kamu", 1);
    }

    /** One gift slot fired: runs exactly its configured effect (amount x count) and posts the notification. */
    private void fireGiftSlot(int i, String who, int count) {
        GameSettings.Gift g = cfg.gifts[i];
        count = Math.max(1, count);
        giftFlash[i] = 0.45f;
        applyEffect(g.effect, g.amount * count, who);
        if (!playCustom(g.sound)) playEventSound(sGift);
        String nm = g.name == null || g.name.trim().length() == 0 ? "gift" : GameSettings.localName(g.name);
        addFeed(feedGift(who, count, nm), 0xffffe14a, g.icon, g.name);
        toastWho(who, GameSettings.toast(g.effect, g.amount * count));
    }

    private void playEventSound(int id) {
        if (gameClock - lastEventSnd < 0.12f) return;
        lastEventSnd = gameClock;
        play(id, 0.6f, 1f);
    }

    /** Runs an effect now (instant ones) or queues it (spawned ones appear one after another). */
    private void applyEffect(int effect, int amount) { applyEffect(effect, amount, null); }

    private void applyEffect(int effect, int amount, String who) {
        effect = Math.max(0, Math.min(GameSettings.EFFECTS - 1, effect));
        amount = Math.max(1, Math.min(amount, GameSettings.EFFECT_MAX[effect] * 3));
        switch (effect) {
            case GameSettings.E_BLOCK: fillBlocks(amount); break;
            case GameSettings.E_RAIN: rainLeft = Math.min(120, rainLeft + amount); rainClock = 0f; break;
            case GameSettings.E_NONE: break;                       // KOSONG: nothing happens, only the notification
            case GameSettings.E_HEAL:
                lives = Math.min(9, lives + amount);
                hp = 100f;
                healT = 1.4f;
                play(sHeal, 0.9f, 1f);
                break;
            case GameSettings.E_SHIELD:
                shieldUntil = Math.max(shieldUntil, gameClock) + amount * cfg.shieldSec;
                play(sShieldOn, 0.9f, 1f);
                break;
            default: {
                int before = pend[effect];
                pend[effect] = Math.min(100, before + amount);
                if (effect == GameSettings.E_TORNADO || effect == GameSettings.E_ROBOT || effect == GameSettings.E_MONSTER
                        || effect == GameSettings.E_MISSILE || effect == GameSettings.E_THROWER || effect == GameSettings.E_BOSS
                        || effect == GameSettings.E_DRILL) {
                    for (int k = before; k < pend[effect]; k++) pendWho[effect].add(who == null ? "" : who);
                }
                break;
            }
        }
    }

    private String popWho(int effect) {
        java.util.ArrayList<String> l = pendWho[effect];
        return l.isEmpty() ? "" : l.remove(0);
    }

    private void updatePending(float dt) {
        pendClock -= dt;
        if (pendClock > 0f) return;
        pendClock = 0.2f;
        if (pend[GameSettings.E_TNT] > 0 && spawnTntOnPlayer()) pend[GameSettings.E_TNT]--;
        if (pend[GameSettings.E_LIGHTNING] > 0) { strikeLightning(rnd.nextInt(COLS)); pend[GameSettings.E_LIGHTNING]--; }
        if (pend[GameSettings.E_TORNADO] > 0 && spawnTornado(peekWho(GameSettings.E_TORNADO))) { popWho(GameSettings.E_TORNADO); pend[GameSettings.E_TORNADO]--; }
        if (pend[GameSettings.E_ROBOT] > 0 && spawnRobot(peekWho(GameSettings.E_ROBOT))) { popWho(GameSettings.E_ROBOT); pend[GameSettings.E_ROBOT]--; }
        if (pend[GameSettings.E_METEOR] > 0 && spawnMeteor(rnd.nextInt(COLS))) pend[GameSettings.E_METEOR]--;
        if (pend[GameSettings.E_MONSTER] > 0 && !moOn) { spawnMonster(popWho(GameSettings.E_MONSTER)); pend[GameSettings.E_MONSTER]--; }
        if (pend[GameSettings.E_MISSILE] > 0 && spawnNuke(peekWho(GameSettings.E_MISSILE))) { popWho(GameSettings.E_MISSILE); pend[GameSettings.E_MISSILE]--; }
        if (pend[GameSettings.E_THROWER] > 0 && spawnThrower(peekWho(GameSettings.E_THROWER))) { popWho(GameSettings.E_THROWER); pend[GameSettings.E_THROWER]--; }
        if (pend[GameSettings.E_BOSS] > 0 && !bsOn) { spawnBoss(popWho(GameSettings.E_BOSS)); pend[GameSettings.E_BOSS]--; }
        if (pend[GameSettings.E_DRILL] > 0 && spawnDrill(peekWho(GameSettings.E_DRILL))) { popWho(GameSettings.E_DRILL); pend[GameSettings.E_DRILL]--; }
    }

    private String peekWho(int effect) {
        java.util.ArrayList<String> l = pendWho[effect];
        return l.isEmpty() ? "" : l.get(0);
    }

    private float surfaceY(int col) {
        return GRID_Y + topBlockRow(clamp(col, 0, COLS - 1)) * CELL;
    }

    private void spawnFx(float cx, float cy, float size) {
        for (int k = 0; k < MAX_FX; k++) {
            if (fxT[k] < 0f) { fxT[k] = 0f; fxX[k] = cx; fxY[k] = cy; fxS[k] = size; return; }
        }
    }

    // ---- damage / lives -------------------------------------------------------------
    private void damagePlayer(float amount) {
        if (dead || gameClock < protectUntil) return;
        if (shieldOn()) {
            shieldHit = 0.4f;
            if (gameClock - lastShieldSnd > 0.3f) { lastShieldSnd = gameClock; play(sShieldBlock, 0.7f, 1f); }
            return;
        }
        if (!cfg.mortal) return;
        hp -= amount;
        hurtFlash = 0.35f;
        if (gameClock - lastHurtSnd > 0.25f) { lastHurtSnd = gameClock; play(sHurt, 0.7f, 1f); }
        if (hp <= 0f) {
            if (lives > 0) { lives--; hp = 100f; toast("NYAWA TAMBAHAN DIPAKAI!"); play(sHeal, 0.8f, 0.8f); }
            else die();
        }
    }

    /** Death: no menu. The player is gone for cfg.respawnSec seconds and then comes back by itself. */
    private void die() {
        dead = true;
        hp = 0f;
        deadT = Math.max(1, cfg.respawnSec);
        play(sDie, 1f, 1f);
        spawnBurst(playerX, playerFeet - PLAYER_H * 0.5f, 0xffff4a4a, 18, 260f);
        releaseAllInput();
    }

    private void respawn() {
        dead = false;
        hp = 100f;
        deadT = 0f;
        int col = COLS / 2;
        playerX = GRID_X + col * CELL + CELL / 2f;
        playerFeet = surfaceY(col);
        velocityY = 0f;
        grounded = true;
        protectUntil = gameClock + 3f;
        healT = 1.4f;
        hurtFlash = 0f;
        cameraTarget = clampFloat(playerFeet - viewH() * PLAYER_SCREEN_RATIO, minCamera(), maxCamera());
        toast("HIDUP LAGI!");
        play(sHeal, 0.9f, 1f);
        spawnBurst(playerX, playerFeet - PLAYER_H * 0.5f, 0xff7aff9a, 14, 220f);
    }

    // ---- debris (blocks flying away) --------------------------------------------------
    private void spawnDebris(float x, float y, int type, int n) {
        for (int k = 0; k < n; k++) {
            int slot = -1;
            for (int i = 0; i < MAX_DEBRIS; i++) if (dbLife[i] <= 0f) { slot = i; break; }
            if (slot < 0) return;
            dbX[slot] = x + (rnd.nextFloat() - 0.5f) * 16f;
            dbY[slot] = y;
            dbVx[slot] = (rnd.nextFloat() - 0.5f) * 260f;
            dbVy[slot] = -(260f + rnd.nextFloat() * 340f);
            dbRot[slot] = rnd.nextFloat() * 360f;
            dbLife[slot] = 0.8f + rnd.nextFloat() * 0.8f;
            dbType[slot] = type;
        }
    }

    private void updateDebris(float dt) {
        for (int i = 0; i < MAX_DEBRIS; i++) {
            if (dbLife[i] <= 0f) continue;
            dbLife[i] -= dt;
            dbVy[i] += 1300f * dt;
            dbX[i] += dbVx[i] * dt;
            dbY[i] += dbVy[i] * dt;
            dbRot[i] += dbVx[i] * dt * 2.2f;
        }
    }

    // -- lightning: a deep bolt that bores down the column
    private void strikeLightning(int col) {
        col = clamp(col, 0, COLS - 1);
        int top = topBlockRow(col);
        float y = top < ROWS ? GRID_Y + top * CELL : FLOOR_Y;
        for (int k = 0; k < MAX_BOLT; k++) {
            if (blT[k] < 0f) { blT[k] = 0f; blCol[k] = col; blY[k] = y; break; }
        }
        float cx = GRID_X + col * CELL + CELL / 2f;
        for (int k = 0; k < LIGHTNING_DEPTH; k++) {
            int row = top + k;
            if (row >= ROWS || blocks[row][col] < 0) break;
            killBlock(col, row, 6, 1);
        }
        for (int dc = -1; dc <= 1; dc += 2) {               // the sides get scorched too
            int c = col + dc;
            if (c < 0 || c >= COLS) continue;
            int tr = topBlockRow(c);
            if (tr < ROWS && tr >= top - 1) killBlock(c, tr, 4, 1);
        }
        spawnBurst(cx, y, 0xfffff08a, 14, 280f);
        flash = 0.55f;
        shake = Math.max(shake, 0.8f);
        play(sLightning, 1f, 1f);
        if (Math.abs(playerX - cx) < CELL * 0.8f && playerFeet <= y + CELL * 2f) damagePlayer(22f);
        recheckGround();
    }

    // -- tornado: falls from above, then walks sideways and only wrecks what blocks its path
    //    (at most TORNADO_REACH rows above the ground it stands on). It never digs down.
    private static final int TORNADO_REACH = 5;           // rows above its feet that count as 'in the way'
    private static final int TORNADO_PULL_DEPTH = 5;      // rows below its feet it can pull blocks from
    private final float[] twPull = new float[MAX_TORNADO];

    /** Top of the first block at / under the given y in a column (the floor when the column is empty). */
    private float groundBelow(int col, float y) {
        col = clamp(col, 0, COLS - 1);
        int r0 = Math.max(0, (int) Math.ceil((y - GRID_Y - 0.5f) / CELL));
        for (int r = r0; r < ROWS; r++) if (blocks[r][col] >= 0) return GRID_Y + r * CELL;
        return FLOOR_Y;
    }

    private boolean spawnTornado(String who) {
        for (int i = 0; i < MAX_TORNADO; i++) {
            if (twOn[i]) continue;
            boolean fromLeft = rnd.nextBoolean();
            twOn[i] = true;
            twName[i] = who == null ? "" : who;
            twDir[i] = fromLeft ? 1 : -1;
            twX[i] = fromLeft ? GRID_X + CELL * 0.5f : GRID_X + COLS * CELL - CELL * 0.5f;
            twLife[i] = Math.max(2, cfg.tornadoSec);
            twHit[i] = 0.1f;
            twPull[i] = 0.7f;
            twVy[i] = 0f;
            twY[i] = cameraY - CELL * 5.5f;      // starts above the screen and falls
            play(sTornado, 0.8f, 1f);
            return true;
        }
        return false;
    }

    /** Is there a block in the way of tornado i in the column ahead (rows reach above its feet)? Returns the row or -1. */
    private int tornadoObstacle(int col, float feet) {
        int surf = (int) Math.round((feet - GRID_Y) / CELL);
        for (int r = surf - 1; r >= surf - TORNADO_REACH; r--) {
            if (r >= 0 && r < ROWS && blocks[r][col] >= 0) return r;
        }
        return -1;
    }

    private void updateTornado(float dt) {
        for (int i = 0; i < MAX_TORNADO; i++) {
            if (!twOn[i]) continue;
            twLife[i] -= dt;
            if (twLife[i] <= 0f) {
                spawnBurst(twX[i], twY[i] - 30f, 0xffd8e4f0, 10, 180f);
                twOn[i] = false;
                continue;
            }
            int col = clamp((int) ((twX[i] - GRID_X) / CELL), 0, COLS - 1);
            float ground = groundBelow(col, twY[i]);
            boolean onGround = twY[i] >= ground - 0.5f;
            if (!onGround) {                                   // gravity: no teleporting down
                twVy[i] = Math.min(900f, twVy[i] + 2200f * dt);
                twY[i] += twVy[i] * dt;
                if (twY[i] >= ground) {
                    twY[i] = ground;
                    if (twVy[i] > 300f) spawnBurst(twX[i], twY[i], 0xffd8e4f0, 6, 150f);
                    twVy[i] = 0f;
                    onGround = true;
                }
            } else {
                twY[i] = ground;
                twVy[i] = 0f;
            }
            if (onGround) {
                int next = col + twDir[i];
                if (next < 0 || next >= COLS) {
                    twDir[i] = -twDir[i];
                } else {
                    float boundary = GRID_X + (twDir[i] > 0 ? col + 1 : col) * CELL;
                    float edge = twX[i] + twDir[i] * CELL * 0.5f;
                    boolean atEdge = twDir[i] > 0 ? edge >= boundary - 0.5f : edge <= boundary + 0.5f;
                    int obst = tornadoObstacle(next, twY[i]);
                    if (obst >= 0 && atEdge) {
                        twHit[i] -= dt;
                        if (twHit[i] <= 0f) {                 // wreck only what blocks the way, lowest block first
                            twHit[i] = 0.11f;
                            int surf = (int) Math.round((twY[i] - GRID_Y) / CELL);
                            for (int r = surf - 1; r >= surf - TORNADO_REACH; r--) {
                                if (r >= 0 && blocks[r][next] >= 0) { killBlock(next, r, 3, 2); break; }
                            }
                        }
                    } else {
                        twX[i] += twDir[i] * 72f * dt;
                    }
                }
                float lo = GRID_X + CELL * 0.4f, hi = GRID_X + COLS * CELL - CELL * 0.4f;
                twX[i] = clampFloat(twX[i], lo, hi);
            }
            if (onGround) {                                       // pull random blocks out from under it (up to 5 rows deep)
                twPull[i] -= dt;
                if (twPull[i] <= 0f) {
                    twPull[i] = 0.5f + rnd.nextFloat() * 0.25f;
                    int pc = clamp((int) ((twX[i] - GRID_X) / CELL), 0, COLS - 1);
                    int surf0 = (int) Math.round((twY[i] - GRID_Y) / CELL);
                    int[] cand = new int[TORNADO_PULL_DEPTH];
                    int n = 0;
                    for (int r = surf0; r < surf0 + TORNADO_PULL_DEPTH && r < ROWS; r++) {
                        if (r >= 0 && blocks[r][pc] >= 0) cand[n++] = r;
                    }
                    if (n > 0) {
                        int pr = cand[rnd.nextInt(n)];
                        float bx = GRID_X + pc * CELL + CELL / 2f, by = GRID_Y + pr * CELL + CELL / 2f;
                        killBlock(pc, pr, 6, 3);
                        spawnBurst(bx, by, 0xffd8e4f0, 4, 120f);
                        play(sBreak, 0.45f, 0.7f + rnd.nextFloat() * 0.2f);
                    }
                }
            }
            float top = twY[i] - CELL * 4.6f;
            if (Math.abs(playerX - twX[i]) < CELL * 0.55f && playerFeet > top
                    && playerFeet < twY[i] + CELL * 1.2f && !shieldOn() && !dead) {
                velocityY = -520f; grounded = false;
            }
        }
    }

    // -- helper robots: each one has its own column, fills the lowest layer first, flies off when done
    private boolean spawnRobot(String who) {
        for (int i = 0; i < MAX_ROBOT; i++) {
            if (rbOn[i]) continue;
            // own place: the column farthest from every other robot
            int best = rnd.nextInt(COLS);
            float bestD = -1f;
            for (int c = 0; c < COLS; c++) {
                float md = 99f;
                for (int j = 0; j < MAX_ROBOT; j++) {
                    if (j == i || !rbOn[j] || rbOut[j]) continue;
                    md = Math.min(md, Math.abs(c - rbCol[j]));
                    if (rbTC[j] >= 0) md = Math.min(md, Math.abs(c - rbTC[j]));
                }
                md += rnd.nextFloat() * 0.5f;
                if (md > bestD) { bestD = md; best = c; }
            }
            rbOn[i] = true;
            rbOut[i] = false;
            rbName[i] = who == null ? "" : who;
            rbCol[i] = best;
            rbDir[i] = 1;
            rbLife[i] = Math.max(5, cfg.robotSec);
            rbAct[i] = 0.3f;
            rbHold[i] = 0f;
            rbIdle[i] = 0f;
            rbFade[i] = 1f;
            rbTR[i] = -1; rbTC[i] = -1;
            rbX[i] = GRID_X + (0.5f + best) * CELL;
            rbY[i] = cameraY - 70f - rnd.nextInt(40);   // enters from above the screen
            play(sRobot, 0.7f, 1f);
            return true;
        }
        return false;
    }

    private boolean reservedByOther(int r, int c, int me) {
        for (int j = 0; j < MAX_ROBOT; j++) if (j != me && rbOn[j] && !rbOut[j] && rbTC[j] == c) return true;
        return false;
    }

    /** Next cell: the lowest free cell of a column nobody else works on; lower layers first, spread apart. */
    private void pickRobotTarget(int i) {
        rbTR[i] = -1; rbTC[i] = -1;
        float bestScore = -1e9f;
        for (int c = 0; c < COLS; c++) {
            int r = lowestEmptyRow(c);
            if (r < 0 || cellOverlapsPlayer(c, r) || reservedByOther(r, c, i)) continue;
            float md = 4f;
            for (int j = 0; j < MAX_ROBOT; j++) {
                if (j == i || !rbOn[j] || rbOut[j]) continue;
                md = Math.min(md, Math.abs(c - (rbTC[j] >= 0 ? rbTC[j] : rbCol[j])));
            }
            float score = r * 100f + md * 8f - Math.abs(c - rbCol[i]) * 0.5f;
            if (score > bestScore) { bestScore = score; rbTR[i] = r; rbTC[i] = c; }
        }
    }

    private void updateRobots(float dt) {
        for (int i = 0; i < MAX_ROBOT; i++) {
            if (!rbOn[i]) continue;
            if (rbOut[i]) {                                   // finished: fly up and vanish, no teleport
                rbY[i] -= 240f * dt;
                rbFade[i] -= dt / 1.6f;
                if (rbFade[i] <= 0f || rbY[i] < cameraY - 90f) {
                    spawnBurst(rbX[i], rbY[i], 0xffb9c1d0, 6, 140f);
                    rbOn[i] = false; rbTR[i] = -1; rbTC[i] = -1;
                }
                continue;
            }
            rbLife[i] -= dt;
            if (rbLife[i] <= 0f) { rbOut[i] = true; rbTR[i] = -1; rbTC[i] = -1; continue; }
            if (rbTR[i] >= 0 && (blocks[rbTR[i]][rbTC[i]] >= 0 || lowestEmptyRow(rbTC[i]) != rbTR[i])) { rbTR[i] = -1; rbTC[i] = -1; }
            if (rbTR[i] < 0) {
                rbAct[i] -= dt;
                if (rbAct[i] <= 0f) { rbAct[i] = 0.25f; pickRobotTarget(i); }
            }
            if (rbTR[i] < 0) {
                rbIdle[i] += dt;
                if (rbIdle[i] > 2.5f) { rbOut[i] = true; continue; }   // nothing left to build
            } else {
                rbIdle[i] = 0f;
            }
            float hx, hy;
            if (rbTR[i] >= 0) {
                hx = GRID_X + rbTC[i] * CELL + CELL / 2f;
                hy = GRID_Y + rbTR[i] * CELL - 8f;
            } else {
                hx = GRID_X + (0.5f + rbCol[i]) * CELL;
                hy = Math.min(vTop() + 40f, surfaceY(rbCol[i]) - CELL * 1.6f);
            }
            float dx = hx - rbX[i], dy = hy - rbY[i];
            float d = (float) Math.sqrt(dx * dx + dy * dy);
            if (d > 0.01f) {
                float step = Math.min(d, Math.min(280f, d * 6f + 30f) * dt);
                rbX[i] += dx / d * step;
                rbY[i] += dy / d * step;
            }
            if (rbTR[i] >= 0 && Math.abs(hx - rbX[i]) < 5f && Math.abs(hy - rbY[i]) < 5f) {
                rbHold[i] += dt;
                if (rbHold[i] >= 0.22f) {
                    rbHold[i] = 0f;
                    int r = rbTR[i], c = rbTC[i];
                    if (blocks[r][c] < 0 && lowestEmptyRow(c) == r && !cellOverlapsPlayer(c, r)) {
                        blocks[r][c] = pickType(r);
                        blockPlacedAt[r][c] = now();
                        spawnBurst(GRID_X + c * CELL + CELL / 2f, GRID_Y + r * CELL + CELL / 2f,
                                0xfffff2a0, 4, 110f);
                        play(sRobotPlace, 0.55f, 0.9f + rnd.nextFloat() * 0.25f);
                    }
                    pickRobotTarget(i);
                }
            } else {
                rbHold[i] = 0f;
            }
        }
    }

    // -- meteor
    private boolean spawnMeteor(int col) {
        for (int i = 0; i < MAX_METEOR; i++) {
            if (mtOn[i]) continue;
            col = clamp(col, 0, COLS - 1);
            float tx = GRID_X + col * CELL + CELL / 2f;
            float surface = surfaceY(col);
            float sy = Math.min(cameraY - 60f, surface - 420f);
            float sx = clampFloat(tx + (rnd.nextBoolean() ? -1f : 1f) * (60f + rnd.nextInt(110)),
                    GRID_X - 20f, GRID_X + COLS * CELL + 20f);
            float vy = 640f;
            float t = Math.max(0.3f, (surface - sy) / vy);
            mtOn[i] = true;
            mtX[i] = sx; mtY[i] = sy;
            mtVx[i] = (tx - sx) / t;
            mtVy[i] = vy;
            play(sMeteorFall, 0.8f, 1f);
            return true;
        }
        return false;
    }

    private void updateMeteors(float dt) {
        for (int i = 0; i < MAX_METEOR; i++) {
            if (!mtOn[i]) continue;
            mtX[i] += mtVx[i] * dt;
            mtY[i] += mtVy[i] * dt;
            if (rnd.nextInt(3) == 0) spawnBurst(mtX[i], mtY[i], 0xffff9a1e, 1, 60f);
            int col = clamp((int) ((mtX[i] - GRID_X) / CELL), 0, COLS - 1);
            float surface = surfaceY(col);
            if (mtY[i] + 12f >= surface) {
                mtOn[i] = false;
                int row = Math.min(ROWS - 1, topBlockRow(col));
                blastAt(col, row, GRID_X + col * CELL + CELL / 2f, surface, 2.6f, CELL * 4.6f, false);
            }
        }
    }

    // -- monster: charges and then sweeps a huge beam across the arena, wiping out whole columns
    private void spawnMonster(String who) {
        moName = who == null ? "" : who;
        moOn = true;
        moPhase = 0;
        moT = 0f;
        moDig = 0f;
        moAlpha = 0f;
        moX = GRID_X + (1f + rnd.nextInt(COLS - 2)) * CELL;
        moDir = moX < GRID_X + COLS * CELL / 2f ? 1f : -1f;
        moY = cameraY - 100f;
        play(sMonster, 1f, 1f);
        shake = Math.max(shake, 0.6f);
    }

    private float monsterBeamBottom() {
        int c = clamp((int) ((moX - GRID_X) / CELL), 0, COLS - 1);
        return Math.max(moY + 90f, Math.min(surfaceY(c), FLOOR_Y));
    }

    private void updateMonster(float dt) {
        if (!moOn) return;
        moT += dt;
        moY += ((vTop() + 70f) - moY) * Math.min(1f, dt * 5f);
        if (moPhase == 0) {
            moAlpha = Math.min(1f, moAlpha + dt * 1.6f);
            if (moT >= 1.0f) { moPhase = 1; moT = 0f; play(sCharge, 0.9f, 1f); }
        } else if (moPhase == 1) {
            if (moT >= 0.95f) { moPhase = 2; moT = 0f; play(sBeam, 1f, 1f); flash = 0.6f; }
        } else if (moPhase == 2) {
            moX += moDir * 62f * dt;
            float lo = GRID_X + CELL * 0.6f, hi = GRID_X + COLS * CELL - CELL * 0.6f;
            if (moX < lo) { moX = lo; moDir = 1f; }
            if (moX > hi) { moX = hi; moDir = -1f; }
            shake = Math.max(shake, 0.55f);
            moDig -= dt;
            float bottom = monsterBeamBottom();
            if (moDig <= 0f) {
                moDig = 0.045f;
                int c0 = clamp((int) ((moX - 30f - GRID_X) / CELL), 0, COLS - 1);
                int c1 = clamp((int) ((moX + 30f - GRID_X) / CELL), 0, COLS - 1);
                for (int c = c0; c <= c1; c++) {
                    for (int k = 0; k < 3; k++) {
                        int row = topBlockRow(c);
                        if (row < ROWS) killBlock(c, row, 4, 1);
                    }
                }
                spawnBurst(moX, bottom, 0xffff5aa0, 4, 300f);
                recheckGround();
            }
            if (Math.abs(playerX - moX) < 34f && playerFeet > moY + 40f) damagePlayer(70f * dt);
            if (moT >= Math.max(3, cfg.monsterSec)) { moPhase = 3; moT = 0f; }
        } else {
            moAlpha = Math.max(0f, moAlpha - dt * 1.5f);
            if (moAlpha <= 0f) {
                spawnBurst(moX, moY, 0xffb040ff, 12, 220f);
                moOn = false;
            }
        }
    }

    private void updateBolts(float dt) {
        for (int i = 0; i < MAX_BOLT; i++) {
            if (blT[i] < 0f) continue;
            blT[i] += dt;
            if (blT[i] > BOLT_TIME) blT[i] = -1f;
        }
        flash = Math.max(0f, flash - dt * 2.4f);
    }

    private void updateDrops(float dt) {
        for (int idx = 0; idx < blockDrop.length; idx++) {
            if (blockDrop[idx] >= 0f) continue;
            blockDropV[idx] = Math.min(1500f, blockDropV[idx] + 2800f * dt);
            blockDrop[idx] += blockDropV[idx] * dt;
            if (blockDrop[idx] >= 0f) {
                blockDrop[idx] = 0f;
                blockDropV[idx] = 0f;
                int r = idx / COLS, c = idx % COLS;
                if (blocks[r][c] >= 0) {
                    blockPlacedAt[r][c] = now();
                    spawnBurst(GRID_X + c * CELL + CELL / 2f, GRID_Y + r * CELL + CELL, blockColor[blocks[r][c]], 5, 110f);
                    playPut(0.6f);
                }
            }
        }
    }

    // -- TNT explosion (smaller than before; meteors use blastAt directly)
    private void explode(int i) {
        int col = tntCol[i];
        int row = Math.round((tntY[i] - GRID_Y) / CELL);
        float cx = GRID_X + col * CELL + CELL / 2f, cy = tntY[i] + CELL / 2f;
        tntOn[i] = false;
        blastAt(col, row, cx, cy, 2.1f, CELL * 3.7f, true);
    }

    private void blastAt(int col, int row, float cx, float cy, float radius, float fxSize, boolean tnt) {
        float r2 = radius * radius + 0.1f;
        int reach = (int) Math.ceil(radius);
        for (int dr = -reach; dr <= reach; dr++) {
            for (int dc = -reach; dc <= reach; dc++) {
                if (dr * dr + dc * dc > r2) continue;
                int r = row + dr, c = col + dc;
                if (r < BUILD_LIMIT_ROW || r >= ROWS || c < 0 || c >= COLS || blocks[r][c] < 0) continue;
                killBlock(c, r, 4, rnd.nextInt(3) == 0 ? 1 : 0);
            }
        }
        for (int j = 0; j < MAX_TNT; j++) {   // chain reaction
            if (!tntOn[j]) continue;
            float dx = GRID_X + tntCol[j] * CELL + CELL / 2f - cx, dy = tntY[j] + CELL / 2f - cy;
            if (Math.sqrt(dx * dx + dy * dy) < CELL * (radius + 0.4f) && (tntFuse[j] < 0f || tntFuse[j] > 0.12f)) {
                tntFuse[j] = 0.12f;
            }
        }
        spawnFx(cx, cy, fxSize);
        spawnBurst(cx, cy, 0xffff9a1e, 10, 280f);
        spawnBurst(cx, cy, 0xff555555, 6, 200f);
        shake = Math.max(shake, tnt ? 0.7f : 0.9f);
        if (blastSnd != 0) { play(blastSnd, 1f, 1f); blastSnd = 0; }
        else if (tnt) play(rnd.nextBoolean() ? sBoom1 : sBoom2, 1f, 0.93f + rnd.nextFloat() * 0.14f);
        else play(sMeteorHit, 1f, 1f);

        float pdx = playerX - cx, pdy = (playerFeet - PLAYER_H * 0.5f) - cy;
        float dist = (float) Math.sqrt(pdx * pdx + pdy * pdy);
        float reachPx = CELL * (radius + 0.2f);
        if (dist < reachPx) {
            damagePlayer(12f + 38f * (1f - dist / reachPx));
            if (!shieldOn()) { velocityY = -520f; grounded = false; }
        }
        recheckGround();
    }


    // ================================================================================
    // v28: TNT on the player, auto zoom, RUDAL (nuclear missile), PELEMPAR TNT (boy), BOS (dragon), BOR (drill)
    // ================================================================================
    /** TNT that appears right at the player (the next ones a little to the sides). */
    private boolean spawnTntOnPlayer() {
        final int[] off = {0, -1, 1, -2, 2};
        int base = playerColumn();
        for (int k = 0; k < off.length; k++) {
            int col = base + off[(tntRot + k) % off.length];
            if (col < 0 || col >= COLS) continue;
            float y = Math.min(playerFeet - CELL, surfaceY(col) - CELL);
            if (spawnTntAt(col, y)) { tntRot = (tntRot + k + 1) % off.length; return true; }
        }
        return false;
    }

    private boolean bigEffectOn() {
        if (moOn || bsOn) return true;
        for (int i = 0; i < MAX_NUKE; i++) if (nkOn[i]) return true;
        for (int i = 0; i < MAX_DRILL; i++) if (drOn[i]) return true;
        return pend[GameSettings.E_MONSTER] > 0 || pend[GameSettings.E_MISSILE] > 0
                || pend[GameSettings.E_BOSS] > 0 || pend[GameSettings.E_DRILL] > 0;
    }

    /** Zooms out while a monster / dragon / missile / drill is around so nothing leaves the screen at the bottom. */
    private void updateZoom(float dt) {
        if (bigEffectOn()) zoomHold = 1.6f; else zoomHold = Math.max(0f, zoomHold - dt);
        float want = (cfg.autoZoom && zoomHold > 0f) ? ZOOM_OUT : 1f;
        zoom += (want - zoom) * Math.min(1f, dt * 3.2f);
        if (Math.abs(zoom - want) < 0.003f) zoom = want;
    }

    // -- RUDAL: a huge nuclear missile falls straight down and ends in a mushroom cloud
    private boolean spawnNuke(String who) {
        for (int i = 0; i < MAX_NUKE; i++) {
            if (nkOn[i]) continue;
            int col = rnd.nextInt(COLS);
            for (int tries = 0; tries < 6; tries++) {
                boolean clash = false;
                for (int k = 0; k < MAX_NUKE; k++) {
                    if (nkOn[k] && !nkBoom[k] && Math.abs(nkX[k] - (GRID_X + col * CELL + CELL / 2f)) < CELL * 3f) clash = true;
                }
                if (!clash) break;
                col = rnd.nextInt(COLS);
            }
            nkOn[i] = true; nkBoom[i] = false;
            nkX[i] = GRID_X + col * CELL + CELL / 2f;
            nkY[i] = vTop() - 440f;
            nkVy[i] = 360f; nkT[i] = 0f; nkBy[i] = 0f;
            nkName[i] = who == null ? "" : who;
            play(sWhistle, 0.9f, 1f);
            return true;
        }
        return false;
    }

    private void updateNukes(float dt) {
        for (int i = 0; i < MAX_NUKE; i++) {
            if (!nkOn[i]) continue;
            nkT[i] += dt;
            if (nkBoom[i]) {
                if (nkT[i] < 0.9f) shake = Math.max(shake, 1.1f);
                if (nkT[i] >= 2.3f) nkOn[i] = false;
                continue;
            }
            nkVy[i] = Math.min(1500f, nkVy[i] + 900f * dt);
            nkY[i] += nkVy[i] * dt;
            int col = clamp((int) Math.floor((nkX[i] - GRID_X) / CELL), 0, COLS - 1);
            boolean hit = nkY[i] >= Math.min(surfaceY(col), FLOOR_Y) - 4f;
            if (!hit && !dead && Math.abs(nkX[i] - playerX) < 32f && nkY[i] >= playerFeet - PLAYER_H) hit = true;
            if (hit) explodeNuke(i);
        }
    }

    private void explodeNuke(int i) {
        nkBoom[i] = true; nkT[i] = 0f;
        float by = Math.min(nkY[i], FLOOR_Y);
        nkBy[i] = by;
        int col = clamp((int) Math.floor((nkX[i] - GRID_X) / CELL), 0, COLS - 1);
        int row = clamp((int) Math.floor((by + CELL * 0.5f - GRID_Y) / CELL), BUILD_LIMIT_ROW, ROWS - 1);
        blastSnd = sNuke;
        blastAt(col, row, nkX[i], by, 5.4f, CELL * 8f, false);
        spawnBurst(nkX[i], by, 0xffffe14a, 16, 420f);
        spawnBurst(nkX[i], by, 0xffff5a1e, 12, 340f);
        spawnBurst(nkX[i], by - CELL * 2f, 0xff555555, 8, 220f);
        flash = 1f;
        shake = Math.max(shake, 1.8f);
        recheckGround();
    }

    private void drawNukes(Canvas canvas) {
        for (int i = 0; i < MAX_NUKE; i++) {
            if (!nkOn[i]) continue;
            if (!nkBoom[i]) {
                float sx = nkX[i], sy = worldToScreenY(nkY[i]);
                if (nukeBody != null) {
                    float w = nukeBody.getWidth(), h = nukeBody.getHeight();
                    blit(canvas, nukeBody, sx - w / 2f, sy - h + 7f, sx + w / 2f, sy + 7f, true);
                }
                if (cfg.nameMissile) drawNameTag(canvas, nkName[i], sx, sy - 210f, 1f);
            } else {
                int f = Math.min(4, (int) (nkT[i] / 0.22f));
                float a = nkT[i] > 1.6f ? Math.max(0f, 1f - (nkT[i] - 1.6f) / 0.7f) : 1f;
                Bitmap b = nukeBoom[f];
                if (b == null || a <= 0f) continue;
                float s = 1.25f, w = b.getWidth() * s, h = b.getHeight() * s;
                float sx = nkX[i], sy = worldToScreenY(nkBy[i]);
                paint.setAlpha((int) (255 * a));
                paint.setFilterBitmap(true);
                tmp.set(sx - w / 2f, sy + 12f - h, sx + w / 2f, sy + 12f);
                canvas.drawBitmap(b, null, tmp, paint);
                paint.setFilterBitmap(false);
                paint.setAlpha(255);
            }
        }
    }

    // -- thrower: a boy runs along the top and lobs TNT onto the blocks
    private float throwerTargetY() { return vTop() + 178f; }

    private boolean spawnThrower(String who) {
        for (int i = 0; i < MAX_THROWER; i++) {
            if (thOn[i]) continue;
            boolean left = (i == 1 && thOn[0]) ? thX[0] > GRID_X + COLS * CELL / 2f : rnd.nextBoolean();
            thOn[i] = true; thIn[i] = false; thOut[i] = false; thPend[i] = false;
            thName[i] = who == null ? "" : who;
            thT[i] = 0f; thClock[i] = 0.5f; thPose[i] = 0f;
            thX[i] = left ? GRID_X - 50f : GRID_X + COLS * CELL + 50f;
            thDir[i] = left ? 1 : -1;
            thY[i] = throwerTargetY();
            play(sThrow, 0.5f, 0.8f);
            return true;
        }
        return false;
    }

    private void throwTnt(int i) {
        int col = rnd.nextInt(4) == 0 ? clamp(playerColumn() + rnd.nextInt(5) - 2, 0, COLS - 1) : rnd.nextInt(COLS);
        for (int k = 0; k < MAX_THROWN; k++) {
            if (pjOn[k]) continue;
            float tx = GRID_X + col * CELL + CELL / 2f, ty = surfaceY(col) - CELL / 2f;
            float sx = thX[i] + thDir[i] * 14f, sy = thY[i] - 40f;
            float g = 1500f, T = 0.7f + Math.max(0f, ty - sy) / 1800f + Math.abs(tx - sx) / 1500f;
            pjOn[k] = true; pjCol[k] = col; pjRot[k] = 0f;
            pjX[k] = sx; pjY[k] = sy;
            pjVx[k] = (tx - sx) / T;
            pjVy[k] = (ty - sy - 0.5f * g * T * T) / T;
            play(sThrow, 0.7f, 0.9f + rnd.nextFloat() * 0.3f);
            return;
        }
    }

    private void updateThrowers(float dt) {
        float lo = GRID_X + CELL * 0.5f, hi = GRID_X + COLS * CELL - CELL * 0.5f;
        for (int i = 0; i < MAX_THROWER; i++) {
            if (!thOn[i]) continue;
            thT[i] += dt;
            thPose[i] = Math.max(0f, thPose[i] - dt);
            if (thPend[i] && thPose[i] <= 0.33f) { thPend[i] = false; throwTnt(i); }
            thY[i] += (throwerTargetY() - thY[i]) * Math.min(1f, dt * 6f);
            float spd = thPose[i] > 0f ? 0f : (thOut[i] ? 130f : 92f);
            thX[i] += thDir[i] * spd * dt;
            if (!thOut[i]) {
                if (!thIn[i]) { if (thX[i] >= lo && thX[i] <= hi) thIn[i] = true; }
                else {
                    if (thX[i] < lo) { thX[i] = lo; thDir[i] = 1; }
                    if (thX[i] > hi) { thX[i] = hi; thDir[i] = -1; }
                    thClock[i] -= dt;
                    if (thClock[i] <= 0f && thPose[i] <= 0f) {
                        thClock[i] = 0.2f + rnd.nextFloat() * 0.3f;
                        thPose[i] = 0.45f; thPend[i] = true;
                    }
                    if (thT[i] >= Math.max(3, cfg.throwerSec) && thPose[i] <= 0f) {
                        thOut[i] = true;
                        thDir[i] = thX[i] < GRID_X + COLS * CELL / 2f ? -1 : 1;
                    }
                }
            } else if (thX[i] < GRID_X - 80f || thX[i] > GRID_X + COLS * CELL + 80f) {
                thOn[i] = false;
            }
        }
        for (int k = 0; k < MAX_THROWN; k++) {
            if (!pjOn[k]) continue;
            pjVy[k] += 1500f * dt;
            pjX[k] += pjVx[k] * dt;
            pjY[k] += pjVy[k] * dt;
            pjRot[k] += 520f * dt;
            float surface = surfaceY(pjCol[k]);
            if (pjVy[k] > 0f && pjY[k] + CELL * 0.5f >= surface) {
                pjOn[k] = false;
                if (!spawnTntAt(pjCol[k], surface - CELL)) spawnBurst(pjX[k], surface, 0xffffb347, 6, 160f);
            } else if (pjY[k] > FLOOR_Y + 200f) {
                pjOn[k] = false;
            }
        }
    }

    private void drawThrowers(Canvas canvas) {
        for (int k = 0; k < MAX_THROWN; k++) {
            if (!pjOn[k]) continue;
            float sx = pjX[k], sy = worldToScreenY(pjY[k]);
            float w = CELL * 0.95f, h = w * 200f / 150f;
            canvas.save();
            canvas.rotate(pjRot[k], sx, sy);
            blit(canvas, tntFrames[0], sx - w / 2f, sy - h / 2f, sx + w / 2f, sy + h / 2f, false);
            canvas.restore();
        }
        for (int i = 0; i < MAX_THROWER; i++) {
            if (!thOn[i]) continue;
            int f;
            if (thPose[i] > 0f) {
                float el = 0.45f - thPose[i];
                f = el < 0.12f ? 4 : (el < 0.24f ? 5 : (el < 0.36f ? 6 : 7));
            } else {
                f = 1 + ((int) (gameClock * 8f) + i) % 3;
            }
            float sy0 = worldToScreenY(thY[i]);
            roundRect(canvas, thX[i] - 26f, sy0 + 1f, thX[i] + 26f, sy0 + 10f, 4f, 0xff5a3b22);
            fill(canvas, thX[i] - 22f, sy0 + 2f, thX[i] + 22f, sy0 + 5f, 0xff9a6a3c);
            Bitmap sprite = thrFrames[f];
            float s = 0.42f;
            if (sprite != null) {
                float l = thX[i] - 80.85f * s, t = sy0 - 195f * s;
                canvas.save();
                if (thDir[i] < 0) canvas.scale(-1, 1, thX[i], 0);
                blit(canvas, sprite, l, t, l + sprite.getWidth() * s, t + sprite.getHeight() * s, true);
                canvas.restore();
            }
            if (cfg.nameThrower) drawNameTag(canvas, thName[i], thX[i], sy0 - 195f * 0.42f - 8f, 1f);
        }
    }

    // -- boss: a dragon (side view) that breathes a sweeping stream of fire and melts everything it touches
    private static final float[][] DRAGON_MOUTH = {{14, 105}, {18, 98}, {24, 92}, {28, 92}, {24, 92}, {24, 95}, {36, 72}, {28, 88}};
    private static final float DRAGON_S = 1.13f, DRAGON_W = 265f, DRAGON_H = 185f;

    private int dragonMouthIdx() {
        if (bsPhase == 1) return 6;
        if (bsPhase == 2) return ((int) (gameClock * 8f) % 2 == 0) ? 6 : 7;
        return (int) (gameClock * 9f) % 6;
    }
    private float bsMouthX() { return bsX + (bsFace > 0 ? (DRAGON_W / 2f - DRAGON_MOUTH[dragonMouthIdx()][0]) : (DRAGON_MOUTH[dragonMouthIdx()][0] - DRAGON_W / 2f)) * DRAGON_S; }
    private float bsMouthY() { return bsY + DRAGON_MOUTH[dragonMouthIdx()][1] * DRAGON_S; }
    private float bossTopY() { return vTop() + 30f; }

    private void spawnBoss(String who) {
        bsName = who == null ? "" : who;
        bsOn = true; bsPhase = 0; bsT = 0f; bsDig = 0f; bsSnd = 0f; bsBlast = 0f;
        boolean fromLeft = rnd.nextBoolean();
        bsFace = fromLeft ? 1 : -1;
        bsX = fromLeft ? GRID_X - 220f : GRID_X + COLS * CELL + 220f;
        bsY = bossTopY();
        bsAimX = bsX; bsAimY = FLOOR_Y;
        play(sBoss, 1f, 1f);
        shake = Math.max(shake, 0.6f);
    }

    private void updateBoss(float dt) {
        if (!bsOn) return;
        bsT += dt;
        bsY += (bossTopY() - bsY) * Math.min(1f, dt * 4f);
        float mid = GRID_X + COLS * CELL / 2f;
        if (bsPhase == 0) {
            bsX += bsFace * 200f * dt;
            shake = Math.max(shake, 0.3f);
            if ((bsFace > 0 && bsX >= mid) || (bsFace < 0 && bsX <= mid) || bsT > 4f) { bsPhase = 1; bsT = 0f; play(sCharge, 1f, 0.8f); }
        } else if (bsPhase == 1) {
            if (rnd.nextInt(2) == 0) spawnBurst(bsMouthX(), bsMouthY(), 0xffffa030, 1, 160f);
            if (bsT >= 1.0f) { bsPhase = 2; bsT = 0f; bsSnd = 0f; bsBlast = 0f; flash = Math.max(flash, 0.5f); }
        } else if (bsPhase == 2) {
            float lo = GRID_X + CELL * 2f, hi = GRID_X + COLS * CELL - CELL * 2f;
            bsX += bsFace * 36f * dt;
            if (bsX < lo) { bsX = lo; bsFace = 1; }
            if (bsX > hi) { bsX = hi; bsFace = -1; }
            bsAimX = clampFloat(bsX + bsFace * CELL * 2.2f + (float) Math.sin(bsT * 1.35f) * CELL * 2.6f, GRID_X + CELL * 0.6f, GRID_X + COLS * CELL - CELL * 0.6f);
            int ac = clamp((int) ((bsAimX - GRID_X) / CELL), 0, COLS - 1);
            bsAimY = Math.min(surfaceY(ac), FLOOR_Y);
            shake = Math.max(shake, 0.7f);
            bsSnd -= dt;
            if (bsSnd <= 0f) { bsSnd = 1.9f; play(sFlame, 0.85f, 1f); }
            bsDig -= dt;
            if (bsDig <= 0f) {
                bsDig = 0.05f;
                int c0 = clamp((int) ((bsAimX - CELL * 1.3f - GRID_X) / CELL), 0, COLS - 1);
                int c1 = clamp((int) ((bsAimX + CELL * 1.3f - GRID_X) / CELL), 0, COLS - 1);
                for (int c = c0; c <= c1; c++) {
                    for (int k = 0; k < 4; k++) {
                        int row = topBlockRow(c);
                        if (row < ROWS) killBlock(c, row, 4, 1);
                    }
                }
                spawnBurst(bsAimX, bsAimY, 0xffff7a1a, 5, 340f);
                spawnBurst(bsAimX, bsAimY, 0xffffe14a, 3, 260f);
                recheckGround();
            }
            bsBlast -= dt;
            if (bsBlast <= 0f) { bsBlast = 0.65f; spawnFx(bsAimX, bsAimY - CELL * 0.5f, CELL * 3.2f); }
            float mx = bsMouthX(), my = bsMouthY(), py = playerFeet - PLAYER_H * 0.5f;
            if (!dead && bsAimY > my) {
                float t = clampFloat((py - my) / (bsAimY - my), 0f, 1f);
                float xl = mx + (bsAimX - mx) * t;
                if (py > my && Math.abs(playerX - xl) < 34f + 18f * t) damagePlayer(95f * dt);
            }
            if (bsT >= Math.max(3, cfg.bossSec)) { bsPhase = 3; bsT = 0f; }
        } else {
            bsX += bsFace * 240f * dt;
            if (bsX < GRID_X - 260f || bsX > GRID_X + COLS * CELL + 260f || bsT > 5f) bsOn = false;
        }
    }

    private void drawBoss(Canvas canvas) {
        if (!bsOn) return;
        int mi = dragonMouthIdx();
        Bitmap f = mi < 6 ? dragonF[mi] : dragonR[mi - 6];
        float sy = worldToScreenY(bsY);
        float w = DRAGON_W * DRAGON_S, h = DRAGON_H * DRAGON_S;
        float mouthX = bsMouthX(), mouthY = worldToScreenY(bsMouthY());
        if (bsPhase == 2) {
            float ay = worldToScreenY(bsAimY);
            int n = 24;
            paint.setStyle(Paint.Style.FILL);
            for (int k = 0; k <= n; k++) {
                float t = k / (float) n;
                float x = mouthX + (bsAimX - mouthX) * t + (float) Math.sin(gameClock * 17f + k * 0.9f) * (2f + 12f * t);
                float y = mouthY + (ay - mouthY) * t;
                float r = (14f + 34f * t) * (0.9f + 0.2f * (float) Math.sin(gameClock * 26f + k));
                paint.setColor(0x69ff2a00);
                canvas.drawCircle(x, y, r, paint);
                paint.setColor(0x96ff7a00);
                canvas.drawCircle(x, y, r * 0.72f, paint);
                paint.setColor(0xcdffd23a);
                canvas.drawCircle(x, y, r * 0.44f, paint);
                paint.setColor(0xebfff6c8);
                canvas.drawCircle(x, y, r * 0.2f, paint);
            }
            float pulse = 1f + 0.18f * (float) Math.sin(gameClock * 30f);
            paint.setColor(0x78ff4a00);
            canvas.drawCircle(bsAimX, ay, 62f * pulse, paint);
            paint.setColor(0xbeffa020);
            canvas.drawCircle(bsAimX, ay, 40f * pulse, paint);
            paint.setColor(0xebfff2a0);
            canvas.drawCircle(bsAimX, ay, 20f * pulse, paint);
            for (int k = 0; k < 8; k++) {
                float ph = (gameClock * 1.6f + k * 0.37f) % 1f;
                float ex = bsAimX + (float) Math.sin(k * 2.3f + gameClock * 3f) * 46f;
                float ey = ay - ph * 90f;
                fill(canvas, ex - 2f, ey - 2f, ex + 2f, ey + 2f, ((int) (230 * (1f - ph)) << 24) | 0x00ffc040);
            }
        } else if (bsPhase == 1) {
            float k = Math.min(1f, bsT / 1.0f);
            paint.setStyle(Paint.Style.FILL);
            paint.setColor(((int) (80 + 110 * k) << 24) | 0x00ff7a00);
            canvas.drawCircle(mouthX, mouthY, 12f + 36f * k, paint);
            paint.setColor(((int) (140 + 90 * k) << 24) | 0x00ffe27a);
            canvas.drawCircle(mouthX, mouthY, 6f + 16f * k, paint);
        }
        if (f != null) {
            canvas.save();
            if (bsFace > 0) canvas.scale(-1, 1, bsX, 0);
            blit(canvas, f, bsX - w / 2f, sy, bsX + w / 2f, sy + h, true);
            canvas.restore();
        }
        if (cfg.nameBoss) drawNameTag(canvas, bsName, bsX, sy - 6f, 1f);
    }

    // -- BOR: a drill machine falls, bores down through the blocks and leaves again
    private boolean spawnDrill(String who) {
        for (int i = 0; i < MAX_DRILL; i++) {
            if (drOn[i]) continue;
            int col = 1 + rnd.nextInt(COLS - 2);
            for (int tries = 0; tries < 6; tries++) {
                boolean clash = false;
                for (int k = 0; k < MAX_DRILL; k++) if (drOn[k] && Math.abs(drCol[k] - col) < 2) clash = true;
                if (!clash) break;
                col = 1 + rnd.nextInt(COLS - 2);
            }
            drOn[i] = true; drState[i] = 0; drCol[i] = col;
            drX[i] = GRID_X + col * CELL + CELL / 2f;
            drY[i] = vTop() - 30f;
            drT[i] = 0f; drDust[i] = 0f; drSnd[i] = 0f; drFade[i] = 1f;
            drRow[i] = (int) Math.floor((surfaceY(col) - GRID_Y) / CELL) - 1;
            drName[i] = who == null ? "" : who;
            play(sWhistle, 0.5f, 1.5f);
            return true;
        }
        return false;
    }

    private void updateDrills(float dt) {
        for (int i = 0; i < MAX_DRILL; i++) {
            if (!drOn[i]) continue;
            drT[i] += dt;
            int col = drCol[i];
            if (drState[i] == 0) {
                drY[i] += 640f * dt;
                if (drY[i] >= Math.min(surfaceY(col), FLOOR_Y)) { drState[i] = 1; drT[i] = 0f; drSnd[i] = 0f; shake = Math.max(shake, 0.6f); }
            } else if (drState[i] == 1) {
                drY[i] += 190f * dt;
                drSnd[i] -= dt;
                if (drSnd[i] <= 0f) { drSnd[i] = 0.9f; play(sDrill, 0.7f, 1f); }
                shake = Math.max(shake, 0.4f);
                int rowTip = Math.min(ROWS - 1, (int) Math.floor((drY[i] + CELL * 0.5f - GRID_Y) / CELL));
                boolean any = false;
                while (drRow[i] < rowTip) {
                    drRow[i]++;
                    int r = drRow[i];
                    if (r < BUILD_LIMIT_ROW) continue;
                    for (int c = col - 1; c <= col + 1; c++) {
                        if (c >= 0 && c < COLS && blocks[r][c] >= 0) { killBlock(c, r, 4, 1); any = true; }
                    }
                }
                if (any) recheckGround();
                drDust[i] -= dt;
                if (drDust[i] <= 0f) {
                    drDust[i] = 0.08f;
                    spawnBurst(drX[i], Math.min(drY[i], FLOOR_Y), 0xff9a7a52, 2, 230f);
                    spawnBurst(drX[i], Math.min(drY[i], FLOOR_Y), 0xff6b6b6b, 1, 170f);
                }
                if (drT[i] >= 6.5f || drY[i] >= FLOOR_Y - 10f) { drState[i] = 2; drT[i] = 0f; }
            } else {
                drY[i] -= 520f * dt;
                drFade[i] -= dt * 0.9f;
                if (drFade[i] <= 0f || drY[i] < vTop() - 120f) drOn[i] = false;
            }
            if (!dead && Math.abs(drX[i] - playerX) < 40f && drY[i] > playerFeet - PLAYER_H - 10f && drY[i] - 150f < playerFeet) {
                damagePlayer(60f * dt);
            }
        }
    }

    private void drawDrills(Canvas canvas) {
        for (int i = 0; i < MAX_DRILL; i++) {
            if (!drOn[i]) continue;
            int f = drState[i] == 0 ? ((int) (gameClock * 14f) + i) % 4 : 4 + ((int) (gameClock * 16f) + i) % 8;
            Bitmap b = drillFrames[f];
            float s = 0.5f, tip = f < 4 ? 392f : 345f;
            float sx = drX[i], sy = worldToScreenY(drY[i]);
            float a = drState[i] == 2 ? Math.max(0f, drFade[i]) : 1f;
            if (b != null) {
                paint.setAlpha((int) (255 * a));
                paint.setFilterBitmap(true);
                tmp.set(sx - b.getWidth() * s / 2f, sy - tip * s, sx + b.getWidth() * s / 2f, sy - tip * s + b.getHeight() * s);
                canvas.drawBitmap(b, null, tmp, paint);
                paint.setFilterBitmap(false);
                paint.setAlpha(255);
            }
            if (cfg.nameDrill) drawNameTag(canvas, drName[i], sx, sy - tip * s - 8f, a);
        }
    }

    // ---- TikTok events ---------------------------------------------------------------
    private void addFeed(String text, int color, int icon) { addFeed(text, color, icon, null); }

    /** gift = gift name (lets the feed show the web picture when the icon is the automatic one). */
    private void addFeed(String text, int color, int icon, String gift) {
        if (!cfg.feed) return;
        for (int i = FEED_LINES - 1; i > 0; i--) {
            feedText[i] = feedText[i - 1]; feedUntil[i] = feedUntil[i - 1]; feedColor[i] = feedColor[i - 1];
            feedIcon[i] = feedIcon[i - 1]; feedName[i] = feedName[i - 1];
        }
        feedText[0] = text; feedUntil[0] = gameClock + 6f; feedColor[0] = color; feedIcon[0] = icon; feedName[0] = gift;
    }

    private void pollLive() {
        LiveClient.Event e;
        int n = 0;
        while (n++ < 12 && (e = live.poll()) != null) handleLive(e);
        if (recentDirty && gameClock - lastRecentSave > 8f) {
            recentDirty = false;
            lastRecentSave = gameClock;
            cfg.save();
        }
    }

    private int ruleFor(String type) {
        if (type.equals("follow")) return GameSettings.EV_FOLLOW;
        if (type.equals("share")) return GameSettings.EV_SHARE;
        if (type.equals("join")) return GameSettings.EV_JOIN;
        if (type.equals("like")) return GameSettings.EV_LIKE;
        if (type.equals("chat")) return GameSettings.EV_CHAT;
        if (type.equals("subscribe")) return GameSettings.EV_SUB;
        return -1;
    }

    private void handleLive(LiveClient.Event e) {
        String who = e.user == null || e.user.length() == 0 ? "anonymous" : e.user;
        if (e.type.equals("gift")) {
            String name = e.giftName == null ? "" : e.giftName;
            if (name.length() > 0) {
                cfg.rememberGift(name);
                recentDirty = true;
                if (e.giftPic != null && e.giftPic.length() > 0) giftWeb.register(name, e.giftPic);
            }
            int n = Math.max(1, e.count);
            int slot = cfg.findGiftIndex(name, e.giftId);
            if (slot >= 0) { fireGiftSlot(slot, who, n); return; }
            ModManager.ModGift mg = mods.giftFor(name);
            if (mg != null && !mg.actions.isEmpty()) {
                for (ModManager.Action a : mg.actions) applyEffect(a.effect, a.amount * n, who);
                playEventSound(sGift);
                String nm = mg.label.length() > 0 ? mg.label : GameSettings.localName(name);
                addFeed(feedGift(who, n, nm), 0xffffe14a, GiftCatalog.GENERIC_ICON, name);
                toastWho(who, GameSettings.toast(mg.actions.get(0).effect, mg.actions.get(0).amount * n));
                return;
            }
            GameSettings.Rule r = cfg.rules[GameSettings.EV_GIFT];
            if (!r.on) return;
            applyEffect(r.effect, r.amount * n, who);
            ruleFlash[GameSettings.EV_GIFT] = 0.45f;
            if (!playCustom(r.sound)) playEventSound(sGift);
            if (r.notify) addFeed(feedGift(who, n, name.length() > 0 ? GameSettings.localName(name) : T("gift")),
                    0xffffe14a, GiftCatalog.GENERIC_ICON, name);
            return;
        }
        int idx = ruleFor(e.type);
        if (idx < 0) return;
        GameSettings.Rule r = cfg.rules[idx];
        int times = 1;
        if (idx == GameSettings.EV_LIKE) {
            likeAcc += Math.max(1, e.count);
            int every = Math.max(1, cfg.likeEvery);
            times = likeAcc / every;
            likeAcc %= every;
            if (times <= 0) return;
        }
        if (r.on) fireRule(idx, who, e, times);
        java.util.List<ModManager.Action> extra = mods.eventActions(e.type);
        if (extra != null) for (ModManager.Action a : extra) applyEffect(a.effect, a.amount * times, who);
    }

    private void fireRule(int idx, String who, LiveClient.Event e, int times) {
        GameSettings.Rule r = cfg.rules[idx];
        applyEffect(r.effect, r.amount * times, who);
        ruleFlash[idx] = 0.45f;
        int snd = idx == GameSettings.EV_FOLLOW ? sFollow : idx == GameSettings.EV_SHARE ? sShare
                : idx == GameSettings.EV_JOIN ? sJoin : idx == GameSettings.EV_LIKE ? sLike
                : idx == GameSettings.EV_CHAT ? sChat : sGift;
        if (!playCustom(r.sound)) playEventSound(snd);
        if (!r.notify) return;
        String line;
        switch (idx) {
            case GameSettings.EV_FOLLOW: line = feedLine(who, "mengikuti kamu"); break;
            case GameSettings.EV_SHARE: line = feedLine(who, "membagikan live"); break;
            case GameSettings.EV_JOIN: line = feedLine(who, "masuk live"); break;
            case GameSettings.EV_LIKE: line = feedLine(who, "menyukai live") + (e != null && e.count > 1 ? " (" + e.count + "x)" : ""); break;
            case GameSettings.EV_CHAT: line = who + " > " + (e != null && e.text != null && e.text.trim().length() > 0 ? e.text.trim() : T("komentar")); break;
            default: line = feedLine(who, "subscribe"); break;
        }
        addFeed(line, 0xff7fe6ff, GameSettings.effectIcon(r.effect));
    }

    private void ensureSession() {
        if (!sessionActive) { continueGame(); }
    }

    /** "TES" for an event rule: same path as a real event, straight into the game. */
    private void testRule(int idx) {
        ensureSession();
        LiveClient.Event e = new LiveClient.Event();
        e.user = "penonton";
        e.count = idx == GameSettings.EV_LIKE ? Math.max(1, cfg.likeEvery) : 1;
        e.text = "halo semua";
        if (idx == GameSettings.EV_GIFT) {
            cfg.rules[idx].notify = cfg.rules[idx].notify;
            GameSettings.Rule r = cfg.rules[idx];
            ruleFlash[idx] = 0.45f;
            applyEffect(r.effect, r.amount, "penonton");
            if (!playCustom(r.sound)) playEventSound(sGift);
            addFeed(feedGift("penonton", 1, T("gift")), 0xffffe14a, GiftCatalog.GENERIC_ICON);
            toastWho("penonton", GameSettings.toast(r.effect, r.amount));
        } else {
            GameSettings.Rule r = cfg.rules[idx];
            fireRuleForced(idx, "penonton", e);
        }
        screen = SCREEN_GAME;
        lastFrameNanos = now();
    }

    private void fireRuleForced(int idx, String who, LiveClient.Event e) {
        GameSettings.Rule r = cfg.rules[idx];
        boolean on = r.on;
        r.on = true;
        likeAcc = 0;
        fireRule(idx, who, e, 1);
        r.on = on;
        toastWho(who, GameSettings.toast(r.effect, r.amount));
    }

    /** "TES" for a gift slot: runs exactly what a viewer's gift would do. */
    private void testGift(int i) {
        ensureSession();
        fireGiftSlot(i, "penonton", 1);
        screen = SCREEN_GAME;
        lastFrameNanos = now();
    }

    private void spawnBurst(float x, float y, int color, int n, float speed) {
        for (int k = 0; k < n; k++) {
            int slot = -1;
            for (int i = 0; i < MAX_PARTICLES; i++) if (plife[i] <= 0f) { slot = i; break; }
            if (slot < 0) return;
            double ang = rnd.nextDouble() * Math.PI * 2.0;
            float sp = speed * (0.35f + rnd.nextFloat() * 0.65f);
            px[slot] = x; py[slot] = y;
            pvx[slot] = (float) Math.cos(ang) * sp;
            pvy[slot] = (float) Math.sin(ang) * sp - 90f;
            plife[slot] = 0.5f + rnd.nextFloat() * 0.5f;
            pcol[slot] = color;
        }
    }

    // ================================================================================
    // Physics
    // ================================================================================
    private boolean hasSurfaceAtFeet(float x, float feet) {
        if (Math.abs(feet - FLOOR_Y) < 2f) return true;
        int col = (int) ((x - GRID_X) / CELL);
        if (col < 0 || col >= COLS) return false;
        for (int row = BUILD_LIMIT_ROW; row < ROWS; row++) {
            if (blocks[row][col] < 0) continue;
            float top = GRID_Y + row * CELL;
            if (Math.abs(feet - top) < 2f) return true;
        }
        return false;
    }

    private float landingSurface(float x, float oldFeet, float newFeet) {
        float best = Float.POSITIVE_INFINITY;
        if (oldFeet <= FLOOR_Y && newFeet >= FLOOR_Y) best = FLOOR_Y;
        int col = (int) ((x - GRID_X) / CELL);
        if (col < 0 || col >= COLS) return best;
        for (int row = BUILD_LIMIT_ROW; row < ROWS; row++) {
            if (blocks[row][col] < 0) continue;
            float top = GRID_Y + row * CELL;
            if (oldFeet <= top + 1f && newFeet >= top - 1f && top < best) best = top;
        }
        return best;
    }

    private float ceilingSurface(float x, float oldTop, float newTop) {
        float best = Float.NEGATIVE_INFINITY;
        float left = x - PLAYER_HALF_W, right = x + PLAYER_HALF_W;
        int first = clamp((int) ((left - GRID_X) / CELL), 0, COLS - 1);
        int last = clamp((int) ((right - GRID_X) / CELL), 0, COLS - 1);
        for (int col = first; col <= last; col++) {
            for (int row = BUILD_LIMIT_ROW; row < ROWS; row++) {
                if (blocks[row][col] < 0) continue;
                float bottom = GRID_Y + (row + 1) * CELL;
                if (oldTop >= bottom - 1f && newTop <= bottom + 1f && bottom > best) best = bottom;
            }
        }
        return best;
    }

    private boolean blockedAt(float x, float top, float feet) {
        float left = x - PLAYER_HALF_W, right = x + PLAYER_HALF_W;
        int first = clamp((int) ((left - GRID_X) / CELL), 0, COLS - 1);
        int last = clamp((int) ((right - GRID_X) / CELL), 0, COLS - 1);
        for (int col = first; col <= last; col++) {
            for (int row = BUILD_LIMIT_ROW; row < ROWS; row++) {
                if (blocks[row][col] < 0) continue;
                float l = GRID_X + col * CELL, r = l + CELL;
                float t = GRID_Y + row * CELL, b = t + CELL;
                if (right > l + 1f && left < r - 1f && feet > t + 1f && top < b - 1f) return true;
            }
        }
        return false;
    }

    private void resolvePlayerOverlap() {
        float top = playerFeet - PLAYER_H;
        if (!blockedAt(playerX, top, playerFeet)) return;
        for (float d = 2f; d <= CELL * 2f; d += 2f) {
            float left = clampFloat(playerX - d, GRID_X + PLAYER_HALF_W, GRID_X + COLS * CELL - PLAYER_HALF_W);
            if (!blockedAt(left, top, playerFeet)) { playerX = left; return; }
            float right = clampFloat(playerX + d, GRID_X + PLAYER_HALF_W, GRID_X + COLS * CELL - PLAYER_HALF_W);
            if (!blockedAt(right, top, playerFeet)) { playerX = right; return; }
        }
        for (float lift = 2f; lift <= PLAYER_H; lift += 2f) {
            if (!blockedAt(playerX, top - lift, playerFeet - lift)) {
                playerFeet -= lift;
                velocityY = 0f;
                grounded = hasSurfaceAtFeet(playerX, playerFeet);
                return;
            }
        }
    }

    private void updatePhysics() {
        long t = now();
        if (lastFrameNanos == 0) lastFrameNanos = t;
        float dt = Math.min(0.032f, (t - lastFrameNanos) / 1_000_000_000f);
        lastFrameNanos = t;
        if (dt <= 0f) return;
        gameClock += dt;

        // Everything keeps running while paused / in menus (the session stays alive until "menu utama").
        updateEffects(dt);
        updateTnt(dt);
        pollLive();
        updateZoom(dt);
        updatePending(dt);
        updateTornado(dt);
        updateRobots(dt);
        updateMeteors(dt);
        updateMonster(dt);
        updateNukes(dt);
        updateThrowers(dt);
        updateBoss(dt);
        updateDrills(dt);
        updateBolts(dt);
        updateDrops(dt);
        updateCountdown(dt);
        if (dead) {
            deadT -= dt;
            if (deadT > 0f) return;
            respawn();
        }

        if (screen == SCREEN_GAME) {
            regenClock += dt;
            if (regenClock >= 0.25f) {
                regenClock = 0f;
                if (inventory < MAX_INVENTORY) inventory++;
            }
            // Held actions repeat at the configured build speed.
            buildCooldown -= dt;
            gridCooldown -= dt;
            mineCooldown -= dt;
            if (buildHeld && buildCooldown <= 0f) {
                placeUnderPlayer();
                buildCooldown = cfg.placeInterval();
            }
            if (gridHeld && targetCol >= 0 && targetRow >= 0 && gridCooldown <= 0f) {
                if (gridMine || breakMode) breakBlockAt(targetCol, targetRow);
                else placeAt(targetCol, targetRow);
                gridCooldown = (gridMine || breakMode) ? Math.max(0.08f, cfg.placeInterval()) : cfg.placeInterval();
            }
            if (keyMineFront && mineCooldown <= 0f) { mineFront(); mineCooldown = 0.15f; }
            if (keyMineDown && mineCooldown <= 0f) { mineDown(); mineCooldown = 0.15f; }
        }
        updatePlayer(dt);
    }

    private void updateEffects(float dt) {
        updateDebris(dt);
        hurtFlash = Math.max(0f, hurtFlash - dt);
        shieldHit = Math.max(0f, shieldHit - dt);
        healT = Math.max(0f, healT - dt);
        for (int i = 0; i < GameSettings.GIFTS; i++) if (giftFlash[i] > 0f) giftFlash[i] -= dt;
        for (int i = 0; i < GameSettings.EVENTS; i++) if (ruleFlash[i] > 0f) ruleFlash[i] -= dt;
        shake = Math.max(0f, shake - dt * 3f);
        for (int i = 0; i < MAX_FX; i++) {
            if (fxT[i] < 0f) continue;
            fxT[i] += dt;
            if (fxT[i] > FX_TIME) fxT[i] = -1f;
        }
        for (int i = 0; i < MAX_PARTICLES; i++) {
            if (plife[i] <= 0f) continue;
            plife[i] -= dt;
            pvy[i] += 700f * dt;
            px[i] += pvx[i] * dt;
            py[i] += pvy[i] * dt;
        }
    }

    private void updateTnt(float dt) {
        if (rainLeft > 0) {
            rainClock -= dt;
            if (rainClock <= 0f) {
                rainClock = 0.28f;
                rainLeft--;
                spawnTnt(rnd.nextInt(COLS), -1f);
            }
        }
        for (int i = 0; i < MAX_TNT; i++) {
            if (!tntOn[i]) continue;
            float surface = GRID_Y + topBlockRow(tntCol[i]) * CELL;
            boolean supported = tntY[i] + CELL >= surface - 0.5f;
            if (!supported) {
                tntVy[i] = Math.min(1100f, tntVy[i] + 1600f * dt);
                tntY[i] += tntVy[i] * dt;
                if (tntY[i] + CELL >= surface) {
                    tntY[i] = surface - CELL;
                    tntVy[i] = 0f;
                    if (tntFuse[i] < 0f) { tntFuse[i] = TNT_FUSE; play(sFuse2, 0.7f, 1f); }
                }
            } else {
                tntY[i] = surface - CELL;
                tntVy[i] = 0f;
                if (tntFuse[i] < 0f) { tntFuse[i] = TNT_FUSE; play(sFuse2, 0.7f, 1f); }
            }
            if (tntFuse[i] >= 0f) {
                tntFuse[i] -= dt;
                if (tntFuse[i] <= 0f) explode(i);
            }
        }
    }

    private void updatePlayer(float dt) {
        boolean spr = isSprint();
        float speed = spr ? 245f : 145f;
        float dx = 0f;
        if (leftHeld && !rightHeld) { dx = -speed * dt; facingRight = false; }
        if (rightHeld && !leftHeld) { dx = speed * dt; facingRight = true; }

        resolvePlayerOverlap();

        float candidateX = clampFloat(playerX + dx, GRID_X + PLAYER_HALF_W, GRID_X + COLS * CELL - PLAYER_HALF_W);
        if (Math.abs(dx) > 0.001f) {
            if (!blockedAt(candidateX, playerFeet - PLAYER_H, playerFeet)) {
                playerX = candidateX;
            } else {
                float low = 0f, high = 1f;
                for (int i = 0; i < 12; i++) {
                    float mid = (low + high) * 0.5f;
                    float test = playerX + (candidateX - playerX) * mid;
                    if (blockedAt(test, playerFeet - PLAYER_H, playerFeet)) high = mid;
                    else low = mid;
                }
                playerX = playerX + (candidateX - playerX) * low;
            }
        }

        if (grounded && !hasSurfaceAtFeet(playerX, playerFeet)) grounded = false;

        if ((jumpRequested || jumpHeld) && grounded) {
            velocityY = -JUMP_SPEED;
            grounded = false;
            play(sJump, 0.7f, 1f);
        }
        jumpRequested = false;

        wasGrounded = grounded;
        if (!grounded) {
            float oldFeet = playerFeet;
            float oldTop = oldFeet - PLAYER_H;
            velocityY += GRAVITY * dt;
            float nextFeet = oldFeet + velocityY * dt;
            float nextTop = nextFeet - PLAYER_H;

            if (velocityY < 0f) {
                float ceiling = ceilingSurface(playerX, oldTop, nextTop);
                if (ceiling != Float.NEGATIVE_INFINITY) {
                    nextFeet = ceiling + PLAYER_H;
                    velocityY = 0f;
                }
            } else {
                float landing = landingSurface(playerX, oldFeet, nextFeet);
                if (landing != Float.POSITIVE_INFINITY) {
                    nextFeet = landing;
                    impactVy = velocityY;
                    velocityY = 0f;
                    grounded = true;
                }
            }
            playerFeet = nextFeet;
            if (grounded && !wasGrounded && impactVy > 380f) play(sLand, 0.6f, 1f);
        } else {
            velocityY = 0f;
        }

        // Camera follows the player vertically.
        float desiredCamera = playerFeet - viewH() * PLAYER_SCREEN_RATIO;
        cameraTarget = clampFloat(desiredCamera, minCamera(), maxCamera());
        cameraY += (cameraTarget - cameraY) * Math.min(1f, dt * 8f);

        animationClock += dt;
        if (!grounded) {
            if (animationClock > 0.11f) { jumpFrame = (jumpFrame + 1) % 5; animationClock = 0f; }
        } else if (leftHeld != rightHeld) {
            float delay = spr ? 0.075f : 0.13f;
            if (animationClock > delay) {
                if (spr) runFrame = (runFrame + 1) % 5;
                else walkFrame = (walkFrame + 1) % 5;
                animationClock = 0f;
            }
            stepClock += dt;
            float iv = spr ? 0.17f : 0.30f;
            if (stepClock >= iv) { stepClock = 0f; stepRot = (stepRot + 1 + rnd.nextInt(2)) % 3; play(spr ? sRuns[stepRot] : sSteps[stepRot], 0.55f, 0.95f + rnd.nextFloat() * 0.1f); }
        } else {
            walkFrame = 0; animationClock = 0f; stepClock = 0.1f;
        }
    }

    // ================================================================================
    // Input: touch + mouse
    // ================================================================================
    private int roleAt(float x, float y) {
        hitArg = -1;
        layoutGifts();
        if (x >= pauseRect.left - 6f && x <= pauseRect.right + 6f
                && y >= pauseRect.top - 4f && y <= pauseRect.bottom + 6f) return ROLE_PAUSE;
        if (dead) return ROLE_NONE;
        if (cfg.showButtons) {
            layoutControls();
            final int[] roles = {ROLE_LEFT, ROLE_RIGHT, ROLE_RUN, ROLE_PICK, ROLE_BUILD, ROLE_JUMP};
            for (int i = 0; i < 6; i++) if (hit[i].contains(x, y)) return roles[i];
        }
        for (int k = 0; k < giftCount; k++) {
            if (giftRects[k].contains(x, y)) { hitArg = k; return ROLE_GIFT; }
        }
        float wx = worldX(x);
        if (y >= hudTop() && y < controlTop() && wx >= GRID_X && wx < GRID_X + COLS * CELL) return ROLE_GRID;
        return ROLE_NONE;
    }

    private void updateTarget(float x, float y) {
        int col = (int) Math.floor((worldX(x) - GRID_X) / CELL);
        int row = (int) Math.floor((worldY(y) - areaTop() + cameraY - GRID_Y) / CELL);
        targetCol = (col >= 0 && col < COLS) ? col : -1;
        targetRow = (row >= 0 && row < ROWS) ? row : -1;
    }

    private void updateHover(float x, float y) {
        int col = (int) Math.floor((worldX(x) - GRID_X) / CELL);
        int row = (int) Math.floor((worldY(y) - areaTop() + cameraY - GRID_Y) / CELL);
        boolean inside = y >= hudTop() && y < controlTop() && col >= 0 && col < COLS;
        hoverCol = inside ? col : -1;
        hoverRow = (inside && row >= 0 && row < ROWS) ? row : -1;
    }

    private void addPointer(MotionEvent e, int index) {
        int id = e.getPointerId(index);
        float x = toLogicalX(e.getX(index)), y = toLogicalY(e.getY(index));
        boolean mouse = e.getToolType(index) == MotionEvent.TOOL_TYPE_MOUSE;
        int role = roleAt(x, y);
        TouchPoint t = new TouchPoint(role, x, y);
        t.arg = hitArg;
        t.mouse = mouse;
        touches.put(id, t);

        mouseActive = mouse;
        if (mouse) updateHover(x, y);

        if (role == ROLE_PAUSE) {
            pressCenterX = x; pressCenterY = y;
            pressUntilNanos = now() + 220000000L;
        } else if (role == ROLE_RUN) {
            sprintToggle = !sprintToggle;
        } else if (role == ROLE_PICK) {
            breakMode = !breakMode;
        } else if (role == ROLE_BUILD) {
            breakMode = false;
            placeUnderPlayer();
            buildCooldown = cfg.placeInterval() * 2f;
        } else if (role == ROLE_JUMP) {
            jumpRequested = true;
        } else if (role == ROLE_GIFT) {
            triggerShownGift(t.arg);
        } else if (role == ROLE_GRID) {
            updateTarget(x, y);
            boolean right = mouse && (e.getButtonState() & MotionEvent.BUTTON_SECONDARY) != 0;
            gridMine = right;
            gridHeld = true;
            if (right || breakMode) breakBlockAt(targetCol, targetRow);
            else placeAt(targetCol, targetRow);
            gridCooldown = cfg.placeInterval() * 2f;
        }
        refreshHeldButtons();
    }

    private void updatePointers(MotionEvent e) {
        for (int i = 0; i < e.getPointerCount(); i++) {
            int id = e.getPointerId(i);
            TouchPoint t = touches.get(id);
            if (t == null) continue;
            t.x = toLogicalX(e.getX(i));
            t.y = toLogicalY(e.getY(i));
            if ((t.role == ROLE_LEFT || t.role == ROLE_RIGHT) && t.y >= controlTop() && t.x >= 0f && t.x < 164f) {
                t.role = t.x < 83f ? ROLE_LEFT : ROLE_RIGHT;
            }
            if (t.role == ROLE_GRID) {
                int oc = targetCol, orow = targetRow;
                updateTarget(t.x, t.y);
                if (t.mouse) updateHover(t.x, t.y);
                // Dragging onto a new cell acts right away (no waiting for the repeat timer).
                if (gridHeld && (targetCol != oc || targetRow != orow) && targetCol >= 0 && targetRow >= 0) {
                    if (gridMine || breakMode) breakBlockAt(targetCol, targetRow);
                    else placeAt(targetCol, targetRow);
                    gridCooldown = cfg.placeInterval();
                }
            }
        }
        refreshHeldButtons();
    }

    private void releasePointer(MotionEvent e, int index) {
        int id = e.getPointerId(index);
        TouchPoint t = touches.get(id);
        if (t != null && t.role == ROLE_GRID) {
            gridHeld = false;
            gridMine = false;
        } else if (t != null && t.role == ROLE_PAUSE) {
            pauseGame();
            pressUntilNanos = now() + 140000000L;
        }
        touches.remove(id);
        refreshHeldButtons();
    }

    private void refreshHeldButtons() {
        touchLeft = touchRight = touchJump = touchBuild = false;
        for (int i = 0; i < touches.size(); i++) {
            int role = touches.valueAt(i).role;
            if (role == ROLE_LEFT) touchLeft = true;
            if (role == ROLE_RIGHT) touchRight = true;
            if (role == ROLE_JUMP) touchJump = true;
            if (role == ROLE_BUILD) touchBuild = true;
        }
        leftHeld = touchLeft || keyLeft || padLeft;
        rightHeld = touchRight || keyRight || padRight;
        jumpHeld = touchJump || keyJump;
        buildHeld = touchBuild || keyBuild;
    }

    private void releaseAllInput() {
        touches.clear();
        keyLeft = keyRight = keyJump = keyBuild = keyShift = keyMineFront = keyMineDown = false;
        padLeft = padRight = false;
        gridHeld = false; gridMine = false;
        jumpRequested = false;
        refreshHeldButtons();
    }

    @Override public boolean onTouchEvent(MotionEvent event) {
        int action = event.getActionMasked();
        int index = event.getActionIndex();

        if (screen == SCREEN_BTNS && buttonsEditorTouch(event)) { invalidate(); return true; }
        if (screen != SCREEN_GAME) {
            if (action == MotionEvent.ACTION_DOWN) {
                pressCenterX = toLogicalX(event.getX(index));
                pressCenterY = toLogicalY(event.getY(index));
                pressUntilNanos = now() + 220000000L;
            } else if (action == MotionEvent.ACTION_UP) {
                int id = uiAt(toLogicalX(event.getX(index)), toLogicalY(event.getY(index)));
                pressUntilNanos = now() + 140000000L;
                if (id >= 0) onUi(id);
            }
            invalidate();
            return true;
        }

        switch (action) {
            case MotionEvent.ACTION_DOWN:
            case MotionEvent.ACTION_POINTER_DOWN:
                addPointer(event, index);
                break;
            case MotionEvent.ACTION_MOVE:
                updatePointers(event);
                break;
            case MotionEvent.ACTION_POINTER_UP:
                releasePointer(event, index);
                break;
            case MotionEvent.ACTION_UP:
                releasePointer(event, index);
                touches.clear();
                gridHeld = false;
                gridMine = false;
                refreshHeldButtons();
                break;
            case MotionEvent.ACTION_CANCEL:
                touches.clear();
                gridHeld = false;
                gridMine = false;
                jumpRequested = false;
                refreshHeldButtons();
                break;
            default:
                break;
        }
        invalidate();
        return true;
    }

    /** Mouse hover and gamepad sticks arrive as generic motion events. */
    @Override public boolean onGenericMotionEvent(MotionEvent e) {
        int src = e.getSource();
        int action = e.getActionMasked();
        if ((src & InputDevice.SOURCE_JOYSTICK) == InputDevice.SOURCE_JOYSTICK
                && action == MotionEvent.ACTION_MOVE) {
            float ax = e.getAxisValue(MotionEvent.AXIS_X);
            float hat = e.getAxisValue(MotionEvent.AXIS_HAT_X);
            padLeft = ax < -0.45f || hat < -0.5f;
            padRight = ax > 0.45f || hat > 0.5f;
            refreshHeldButtons();
            return true;
        }
        if (action == MotionEvent.ACTION_HOVER_MOVE || action == MotionEvent.ACTION_HOVER_ENTER) {
            mouseActive = true;
            updateHover(toLogicalX(e.getX()), toLogicalY(e.getY()));
            return true;
        }
        if (action == MotionEvent.ACTION_HOVER_EXIT) {
            hoverCol = -1; hoverRow = -1;
            return true;
        }
        return super.onGenericMotionEvent(e);
    }

    // ================================================================================
    // Menu actions
    // ================================================================================
    private void open(int target) {
        if (target == screen) return;
        backTo[target] = screen;
        screen = target;
        if (target == SCREEN_GIFTS || target == SCREEN_PICK) giftWeb.ensureCatalog();
        if (target == SCREEN_GIFTS) giftPage = 0;
        if (target == SCREEN_SETTINGS) settingsTab = 0;
    }

    private void leaveTo(int target) {
        screen = target;
        if (target == SCREEN_MENU) { lastFrameNanos = 0L; sessionActive = false; dead = false; }
    }

    private void goBack() {
        int t = backTo[screen];
        leaveTo(t == screen ? SCREEN_MENU : t);
    }

    private int stepFor(int effect) {
        return (effect == GameSettings.E_BLOCK || effect == GameSettings.E_HEAL) ? 5 : 1;
    }

    private void toggleSetting(int k) {
        switch (k) {
            case 0: cfg.sound = !cfg.sound; break;
            case 1: cfg.showButtons = !cfg.showButtons; break;
            case 2: cfg.unlimited = !cfg.unlimited; break;
            case 3: cfg.feed = !cfg.feed; break;
            case 4: cfg.mortal = !cfg.mortal; break;
            case 5: cfg.showHp = !cfg.showHp; break;
            case 6: cfg.autoConnect = !cfg.autoConnect; break;
            case 7: cfg.musicOn = !cfg.musicOn; break;
            case 8: cfg.clickSound = !cfg.clickSound; break;
            case 9: cfg.blockGravity = !cfg.blockGravity; break;
            case 10: cfg.hudTransparent = !cfg.hudTransparent; break;
            case 11: cfg.nameTornado = !cfg.nameTornado; break;
            case 12: cfg.nameRobot = !cfg.nameRobot; break;
            case 13: cfg.nameMonster = !cfg.nameMonster; break;
            case 14: cfg.nameThrower = !cfg.nameThrower; break;
            case 15: cfg.nameBoss = !cfg.nameBoss; break;
            case 16: cfg.nameMissile = !cfg.nameMissile; break;
            case 17: cfg.nameDrill = !cfg.nameDrill; break;
            case 18: cfg.namePlayer = !cfg.namePlayer; break;
            case 19: cfg.autoZoom = !cfg.autoZoom; break;
            default: return;
        }
        cfg.save();
        applyMusic();
    }

    private static int clampInt(int v, int lo, int hi) { return Math.max(lo, Math.min(hi, v)); }

    /** dir = -1 / +1 for the - and + chips, 0 = type the value. */
    private void stepSetting(final int k, int dir) {
        switch (k) {
            case 0: cfg.hudOffset = clampInt(cfg.hudOffset + dir * 8, 0, 80); break;
            case 1: cfg.winTarget = clampInt(cfg.winTarget + dir, 1, 99); break;
            case 2: cfg.countdownStart = clampInt(cfg.countdownStart + dir, 1, 60); break;
            case 3: cfg.countdownStep = clampInt(cfg.countdownStep + dir, 2, 50); break;
            case 4: cfg.tornadoSec = clampInt(cfg.tornadoSec + dir, 3, 120); break;
            case 5: cfg.robotSec = clampInt(cfg.robotSec + dir * 5, 5, 300); break;
            case 6: cfg.monsterSec = clampInt(cfg.monsterSec + dir, 3, 60); break;
            case 7: cfg.shieldSec = clampInt(cfg.shieldSec + dir * 10, 10, 600); break;
            case 8: cfg.tileCount = clampInt(cfg.tileCount + dir, 1, GameSettings.SHOWN_MAX); layoutGifts(); break;
            case 9: cfg.speed = (cfg.speed + 1) % GameSettings.SPEED_NAMES.length; break;
            case 10: cfg.respawnSec = clampInt(cfg.respawnSec + dir, 1, 60); break;
            case 11: cfg.sfxVol = clampInt(cfg.sfxVol + dir * 10, 0, 100); if (dir != 0) { play(sPlace, 0.8f, 1f); } break;
            case 12: cfg.musicVol = clampInt(cfg.musicVol + dir * 10, 0, 100); break;
            case 13: cfg.bossSec = clampInt(cfg.bossSec + dir, 3, 60); break;
            case 14: cfg.throwerSec = clampInt(cfg.throwerSec + dir, 3, 60); break;
            case 15: cfg.lang = 1 - cfg.lang; break;
            default: return;
        }
        if (dir == 0 && k != 9 && k != 15) {
            String title; String cur;
            switch (k) {
                case 0: title = "HUD turun (0-80)"; cur = String.valueOf(cfg.hudOffset); break;
                case 1: title = "Target menang (1-99)"; cur = String.valueOf(cfg.winTarget); break;
                case 2: title = "Hitungan mundur awal (1-60)"; cur = String.valueOf(cfg.countdownStart); break;
                case 3: title = "Detik per angka hitung (0.2-5.0)"; cur = String.format(Locale.US, "%.1f", cfg.countdownStep / 10f); break;
                case 4: title = "Durasi tornado, detik (3-120)"; cur = String.valueOf(cfg.tornadoSec); break;
                case 5: title = "Durasi robot, detik (5-300)"; cur = String.valueOf(cfg.robotSec); break;
                case 6: title = "Durasi monster, detik (3-60)"; cur = String.valueOf(cfg.monsterSec); break;
                case 7: title = "Perisai per 1x, detik (10-600)"; cur = String.valueOf(cfg.shieldSec); break;
                case 10: title = "Hidup lagi setelah, detik (1-60)"; cur = String.valueOf(cfg.respawnSec); break;
                case 11: title = "Volume efek (0-100)"; cur = String.valueOf(cfg.sfxVol); break;
                case 12: title = "Volume musik (0-100)"; cur = String.valueOf(cfg.musicVol); break;
                case 13: title = "Durasi bos api, detik (3-60)"; cur = String.valueOf(cfg.bossSec); break;
                case 14: title = "Durasi pelempar TNT, detik (3-60)"; cur = String.valueOf(cfg.throwerSec); break;
                default: title = "Jumlah tile tampil (1-16)"; cur = String.valueOf(cfg.tileCount); break;
            }
            askText(title, cur, false, 6, new TextResult() {
                @Override public void done(String s) {
                    try {
                        float f = Float.parseFloat(s.trim().replace(',', '.'));
                        int v = Math.round(f);
                        switch (k) {
                            case 0: cfg.hudOffset = clampInt(v, 0, 80); break;
                            case 1: cfg.winTarget = clampInt(v, 1, 99); break;
                            case 2: cfg.countdownStart = clampInt(v, 1, 60); break;
                            case 3: cfg.countdownStep = clampInt(Math.round(f * 10f), 2, 50); break;
                            case 4: cfg.tornadoSec = clampInt(v, 3, 120); break;
                            case 5: cfg.robotSec = clampInt(v, 5, 300); break;
                            case 6: cfg.monsterSec = clampInt(v, 3, 60); break;
                            case 7: cfg.shieldSec = clampInt(v, 10, 600); break;
                            case 8: cfg.tileCount = clampInt(v, 1, GameSettings.SHOWN_MAX); layoutGifts(); break;
                            case 10: cfg.respawnSec = clampInt(v, 1, 60); break;
                            case 11: cfg.sfxVol = clampInt(v, 0, 100); break;
                            case 12: cfg.musicVol = clampInt(v, 0, 100); break;
                            case 13: cfg.bossSec = clampInt(v, 3, 60); break;
                            case 14: cfg.throwerSec = clampInt(v, 3, 60); break;
                            default: break;
                        }
                    } catch (Exception ignored) { return; }
                    cfg.save();
                    applyMusic();
                }
            });
            return;
        }
        cfg.save();
        applyMusic();
    }

    private void onUi(int id) {
        playUi();
        if (id >= B_G_TEST && id < B_G_TEST + GameSettings.GIFTS) { cfg.save(); testGift(id - B_G_TEST); return; }
        if (id >= B_G_SND && id < B_G_SND + GameSettings.GIFTS) { pickSound(0, id - B_G_SND); return; }
        if (id >= B_G_SNDX && id < B_G_SNDX + GameSettings.GIFTS) { clearSound(0, id - B_G_SNDX); return; }
        if (id >= B_E_SHOW && id < B_E_SHOW + GameSettings.EVENTS) { int e = id - B_E_SHOW; cfg.rules[e].show = !cfg.rules[e].show; cfg.save(); return; }
        if (id >= B_E_SND && id < B_E_SND + GameSettings.EVENTS) { pickSound(1, id - B_E_SND); return; }
        if (id >= B_E_SNDX && id < B_E_SNDX + GameSettings.EVENTS) { clearSound(1, id - B_E_SNDX); return; }
        if (id >= B_G_ON && id < B_G_LABEL + GameSettings.GIFTS) { onGiftUi(id); return; }
        if (id >= B_E_ON && id < B_E_TEST + GameSettings.EVENTS) { onEventUi(id); return; }
        if (id >= B_PICK_ITEM && id < B_PICK_ITEM + PICK_PAGE) { onPickItem(id - B_PICK_ITEM); return; }
        if (id == B_BTN_EDIT) { if (!cfg.showButtons) { cfg.showButtons = true; cfg.save(); } btnSel = 4; btnDrag = -1; open(SCREEN_BTNS); return; }
        if (id == B_BE_SM || id == B_BE_SP) {
            int d = id == B_BE_SP ? 10 : -10;
            cfg.btnSc[btnSel] = clamp(cfg.btnSc[btnSel] + d, 50, 220);
            moveBtn(btnSel, rectCx(btnSel), rectCy(btnSel)); cfg.save(); return;
        }
        if (id == B_BE_AM || id == B_BE_AP) {
            int d = id == B_BE_AP ? 10 : -10;
            for (int i = 0; i < GameSettings.BTNS; i++) { cfg.btnSc[i] = clamp(cfg.btnSc[i] + d, 50, 220); moveBtn(i, rectCx(i), rectCy(i)); }
            cfg.save(); return;
        }
        if (id == B_BE_RESET) { cfg.resetButtons(); cfg.save(); return; }
        if (id >= B_FX_ITEM && id < B_FX_ITEM + GameSettings.EFFECTS) {
            int fx = id - B_FX_ITEM;
            if (fxKind == 0) { GameSettings.Gift g = cfg.gifts[clamp(fxIdx, 0, GameSettings.GIFTS - 1)]; g.effect = fx; g.clampAmount(); }
            else { GameSettings.Rule r = cfg.rules[clamp(fxIdx, 0, GameSettings.EVENTS - 1)]; r.effect = fx; r.clampAmount(); }
            cfg.save();
            goBack();
            return;
        }
        if (id >= B_ICON_ITEM && id < B_ICON_ITEM + ICON_PAGE) {
            int[] ids = iconIds();
            int idx = iconPage * ICON_PAGE + (id - B_ICON_ITEM);
            if (idx >= 0 && idx < ids.length) {
                cfg.gifts[clamp(pickSlot, 0, GameSettings.GIFTS - 1)].icon = ids[idx];
                cfg.save();
                goBack();
            }
            return;
        }
        if (id >= B_TOG && id < B_TOG + 20) { toggleSetting(id - B_TOG); return; }
        if (id >= B_STEP_M && id < B_STEP_M + 20) { stepSetting(id - B_STEP_M, -1); return; }
        if (id >= B_STEP_V && id < B_STEP_V + 20) { stepSetting(id - B_STEP_V, 0); return; }
        if (id >= B_STEP_P && id < B_STEP_P + 20) { stepSetting(id - B_STEP_P, 1); return; }
        if (id >= B_TAB && id < B_TAB + 4) { settingsTab = id - B_TAB; return; }
        if (id >= B_MOD_TOG && id < B_MOD_TOG + 40) {
            int k = id - B_MOD_TOG;
            if (k < mods.mods.size()) { ModManager.Mod m = mods.mods.get(k); mods.setEnabled(m, !m.enabled); }
            return;
        }
        switch (id) {
            case B_PLAY: continueGame(); break;
            case B_RESET_AREA: startGame(); break;
            case B_LINK_YT: openLink(GameSettings.LINK_YT); return;
            case B_LINK_TT: openLink(GameSettings.LINK_TT); return;
            case B_GIFTS: open(SCREEN_GIFTS); break;
            case B_SETTINGS: open(SCREEN_SETTINGS); break;
            case B_MODS: open(SCREEN_MOD); break;
            case B_MOD_RELOAD: beginLoad(SCREEN_MOD); break;
            case B_TIKTOK: open(SCREEN_TIKTOK); break;
            case B_LOOKS: open(SCREEN_LOOKS); break;
            case B_T_EVENTS: open(SCREEN_EVENTS); break;
            case B_T_GIFTS: open(SCREEN_GIFTS); break;
            case B_RESUME: resumeGame(); break;
            case B_RETRY: startGame(); break;
            case B_MENU: leaveTo(SCREEN_MENU); break;
            case B_RESET: cfg.resetDefaults(); cfg.save(); layoutGifts(); break;
            case B_RESET_GIFTS: cfg.resetGifts(); cfg.save(); break;
            case B_E_RESET: cfg.resetRules(); cfg.save(); break;
            case B_BACK: goBack(); break;
            case B_PAGE_PREV:
                if (screen == SCREEN_PICK) pickPage = Math.max(0, pickPage - 1);
                else if (screen == SCREEN_ICONS) iconPage = Math.max(0, iconPage - 1);
                else giftPage = (giftPage + giftPages() - 1) % giftPages();
                break;
            case B_PAGE_NEXT:
                if (screen == SCREEN_PICK) pickPage++;
                else if (screen == SCREEN_ICONS) iconPage++;
                else giftPage = (giftPage + 1) % giftPages();
                break;
            case B_MAP_PREV: cfg.map = (cfg.map + GameSettings.MAPS - 1) % GameSettings.MAPS; cfg.save(); break;
            case B_MAP_NEXT: cfg.map = (cfg.map + 1) % GameSettings.MAPS; cfg.save(); break;
            case B_CHAR_PREV: cfg.character = (cfg.character + GameSettings.CHARS - 1) % GameSettings.CHARS; cfg.save(); break;
            case B_CHAR_NEXT: cfg.character = (cfg.character + 1) % GameSettings.CHARS; cfg.save(); break;
            case B_T_MODE:
            case B_T_MODE2:
                if (live.isRunning()) live.stop();
                cfg.liveMode = id == B_T_MODE ? 0 : 1;
                cfg.save();
                break;
            case B_T_KEY:
                askText("API key Euler Stream (tempel di sini)", cfg.apiKey == null ? "" : cfg.apiKey, false, 120, new TextResult() {
                    @Override public void done(String s) { cfg.apiKey = s.trim(); cfg.save(); }
                });
                break;
            case B_T_WEB:
                try {
                    android.content.Intent it = new android.content.Intent(android.content.Intent.ACTION_VIEW,
                            android.net.Uri.parse("https://www.eulerstream.com"));
                    it.addFlags(android.content.Intent.FLAG_ACTIVITY_NEW_TASK);
                    getContext().startActivity(it);
                } catch (Throwable t) { toast("TIDAK BISA MEMBUKA BROWSER"); }
                return;
            case B_T_HOST:
                askText("Host bridge (127.0.0.1 atau IP PC)", cfg.host, false, 60, new TextResult() {
                    @Override public void done(String s) { cfg.host = s.trim(); cfg.save(); }
                });
                break;
            case B_T_PORT:
                askText("Port bridge (contoh 25601)", String.valueOf(cfg.port), true, 5, new TextResult() {
                    @Override public void done(String s) {
                        try { cfg.port = Math.max(1, Math.min(65535, Integer.parseInt(s.trim()))); } catch (Exception ignored) { return; }
                        cfg.save();
                    }
                });
                break;
            case B_T_USER:
                askText("Username TikTok (tanpa @)", cfg.user, false, 40, new TextResult() {
                    @Override public void done(String s) { cfg.user = s.trim().replace("@", ""); cfg.save(); }
                });
                break;
            case B_T_START:
                if (live.isRunning()) live.stop();
                else { cfg.save(); startLive(); }
                break;
            case B_T_TEST: testLive(); break;
            case B_LIKE_MINUS: cfg.likeEvery = Math.max(1, cfg.likeEvery - (cfg.likeEvery > 20 ? 10 : 1)); cfg.save(); break;
            case B_LIKE_PLUS: cfg.likeEvery = Math.min(500, cfg.likeEvery + (cfg.likeEvery >= 20 ? 10 : 1)); cfg.save(); break;
            case B_LIKE_AMT:
                askText("Aksi tiap berapa like (1-500)", String.valueOf(cfg.likeEvery), true, 3, new TextResult() {
                    @Override public void done(String s) {
                        try { cfg.likeEvery = Math.max(1, Math.min(500, Integer.parseInt(s.trim()))); } catch (Exception ignored) { return; }
                        cfg.save();
                    }
                });
                break;
            case B_PICK_SEARCH:
                askText("Cari nama gift", pickQuery, false, 30, new TextResult() {
                    @Override public void done(String s) { pickQuery = s.trim(); pickCache = null; pickPage = 0; }
                });
                break;
            case B_PICK_MANUAL: {
                final GameSettings.Gift g = cfg.gifts[clamp(pickSlot, 0, GameSettings.GIFTS - 1)];
                askText("Nama gift persis seperti di TikTok", g.name == null ? "" : g.name, false, 30, new TextResult() {
                    @Override public void done(String s) {
                        g.name = s.trim();
                        if (g.name.length() > 0) { g.on = true; g.icon = GiftCatalog.iconFor(g.name); }
                        cfg.save();
                        leaveTo(backTo[SCREEN_PICK]);
                    }
                });
                break;
            }
            case B_PICK_CLEAR: {
                GameSettings.Gift g = cfg.gifts[clamp(pickSlot, 0, GameSettings.GIFTS - 1)];
                g.name = ""; g.on = false; g.show = false;
                cfg.save();
                goBack();
                break;
            }
            default: break;
        }
    }

    /** "TES" on the TikTok screen: one follow + the first active gift, straight into the game. */
    private void testLive() {
        ensureSession();
        LiveClient.Event e = new LiveClient.Event();
        e.type = "follow"; e.user = "penonton";
        live.inject(e);
        for (GameSettings.Gift g : cfg.gifts) {
            if (!g.on || g.name == null || g.name.trim().length() == 0) continue;
            LiveClient.Event ge = new LiveClient.Event();
            ge.type = "gift"; ge.user = "penonton"; ge.giftName = g.name; ge.count = 1;
            live.inject(ge);
            break;
        }
        screen = SCREEN_GAME;
        lastFrameNanos = now();
    }

    private void onPickItem(int k) {
        String[] list = pickList();
        int idx = pickPage * PICK_PAGE + k;
        if (idx < 0 || idx >= list.length) return;
        GameSettings.Gift g = cfg.gifts[clamp(pickSlot, 0, GameSettings.GIFTS - 1)];
        g.name = list[idx];
        g.on = true;
        g.icon = GiftCatalog.iconFor(g.name);
        cfg.save();
        goBack();
    }

    private void onEventUi(int id) {
        int base;
        if (id >= B_E_TEST) base = B_E_TEST;
        else if (id >= B_E_PLUS) base = B_E_PLUS;
        else if (id >= B_E_AMOUNT) base = B_E_AMOUNT;
        else if (id >= B_E_MINUS) base = B_E_MINUS;
        else if (id >= B_E_EFFECT) base = B_E_EFFECT;
        else if (id >= B_E_NOTIF) base = B_E_NOTIF;
        else base = B_E_ON;
        final int i = id - base;
        if (i < 0 || i >= GameSettings.EVENTS) return;
        final GameSettings.Rule r = cfg.rules[i];
        switch (base) {
            case B_E_ON: r.on = !r.on; break;
            case B_E_NOTIF: r.notify = !r.notify; break;
            case B_E_EFFECT: openFxPicker(1, i); return;
            case B_E_MINUS: r.amount -= stepFor(r.effect); r.clampAmount(); break;
            case B_E_PLUS: r.amount += stepFor(r.effect); r.clampAmount(); break;
            case B_E_AMOUNT:
                askText("Jumlah (1-" + GameSettings.EFFECT_MAX[r.effect] + ")", String.valueOf(r.amount), true, 3,
                        new TextResult() {
                            @Override public void done(String s) {
                                try { r.amount = Integer.parseInt(s.trim()); } catch (Exception ignored) { return; }
                                r.clampAmount();
                                cfg.save();
                            }
                        });
                return;
            case B_E_TEST:
                cfg.save();
                testRuleInGame(i);
                return;
            default: return;
        }
        cfg.save();
    }

    private void testRuleInGame(int idx) {
        testRule(idx);
        screen = SCREEN_GAME;
        if (lastFrameNanos == 0L) resetGame();
        lastFrameNanos = now();
    }

    private void onGiftUi(int id) {
        int base;
        if (id >= B_G_LABEL) base = B_G_LABEL;
        else if (id >= B_G_PLUS) base = B_G_PLUS;
        else if (id >= B_G_AMOUNT) base = B_G_AMOUNT;
        else if (id >= B_G_MINUS) base = B_G_MINUS;
        else if (id >= B_G_EFFECT) base = B_G_EFFECT;
        else if (id >= B_G_NAME) base = B_G_NAME;
        else if (id >= B_G_ICON) base = B_G_ICON;
        else if (id >= B_G_SHOW) base = B_G_SHOW;
        else base = B_G_ON;
        int i = id - base;
        if (i < 0 || i >= GameSettings.GIFTS) return;
        final GameSettings.Gift g = cfg.gifts[i];
        switch (base) {
            case B_G_ON: g.on = !g.on; break;
            case B_G_SHOW: g.show = !g.show; break;
            case B_G_ICON: pickSlot = i; iconPage = 0; open(SCREEN_ICONS); break;
            case B_G_NAME: pickSlot = i; pickPage = 0; open(SCREEN_PICK); break;
            case B_G_EFFECT: openFxPicker(0, i); return;
            case B_G_MINUS: g.amount -= stepFor(g.effect); g.clampAmount(); break;
            case B_G_PLUS: g.amount += stepFor(g.effect); g.clampAmount(); break;
            case B_G_AMOUNT:
                askText("Jumlah (1-" + GameSettings.EFFECT_MAX[g.effect] + ")", String.valueOf(g.amount), true, 3,
                        new TextResult() {
                            @Override public void done(String s) {
                                try { g.amount = Integer.parseInt(s.trim()); } catch (Exception ignored) { return; }
                                g.clampAmount();
                                cfg.save();
                            }
                        });
                return;
            case B_G_LABEL:
                askText("Teks hadiah (kosong = otomatis)", g.label == null ? "" : g.label, false, 9,
                        new TextResult() {
                            @Override public void done(String s) {
                                g.label = s.trim();
                                cfg.save();
                            }
                        });
                return;
            default: return;
        }
        cfg.save();
    }

    /** Simple text / number prompt (works with the on-screen and a hardware keyboard). */
    private void askText(String title, String initial, boolean numeric, final int maxLen, final TextResult cb) {
        try {
            final EditText input = new EditText(getContext());
            input.setText(initial);
            input.setSingleLine(true);
            input.setInputType(numeric ? InputType.TYPE_CLASS_NUMBER : InputType.TYPE_CLASS_TEXT);
            input.setSelectAllOnFocus(true);
            new AlertDialog.Builder(getContext())
                    .setTitle(T(title))
                    .setView(input)
                    .setPositiveButton("OK", new DialogInterface.OnClickListener() {
                        @Override public void onClick(DialogInterface d, int which) {
                            String s = input.getText().toString();
                            if (s.length() > maxLen) s = s.substring(0, maxLen);
                            cb.done(s);
                        }
                    })
                    .setNegativeButton(cfg.lang == 0 ? "Batal" : "Cancel", null)
                    .show();
        } catch (Throwable ignored) { }
    }

    // ================================================================================
    // Input: keyboard / gamepad buttons / activity hooks
    // ================================================================================
    public void pauseGame() {
        if (screen != SCREEN_GAME) return;
        screen = SCREEN_PAUSE;
        if (recentDirty) { recentDirty = false; cfg.save(); }
        releaseAllInput();
    }

    private void openLink(String url) {
        try {
            android.content.Intent it = new android.content.Intent(android.content.Intent.ACTION_VIEW, android.net.Uri.parse(url));
            it.addFlags(android.content.Intent.FLAG_ACTIVITY_NEW_TASK);
            getContext().startActivity(it);
        } catch (Throwable t) { toast("TIDAK BISA MEMBUKA BROWSER"); }
    }

    private void resumeGame() {
        screen = SCREEN_GAME;
        lastFrameNanos = now();
    }

    /** Called from Activity.onPause. */
    public void onHostPause() {
        pauseGame();
        releaseAllInput();
        hostActive = false;
        applyMusic();
    }

    /** Back button. Returns true when the game consumed it. */
    public boolean handleBack() {
        if (screen == SCREEN_GAME) { pauseGame(); return true; }
        if (screen == SCREEN_PAUSE) { resumeGame(); return true; }
        if (screen != SCREEN_MENU) { goBack(); return true; }
        return false;
    }

    @Override public void onWindowFocusChanged(boolean hasWindowFocus) {
        super.onWindowFocusChanged(hasWindowFocus);
        hostActive = hasWindowFocus;
        applyMusic();
        if (!hasWindowFocus) {
            if (screen == SCREEN_GAME) pauseGame();
            releaseAllInput();
        }
    }

    @Override protected void onDetachedFromWindow() {
        release();
        super.onDetachedFromWindow();
    }

    @Override public boolean onKeyDown(int keyCode, KeyEvent event) {
        return handleKeyEvent(event) || super.onKeyDown(keyCode, event);
    }

    @Override public boolean onKeyUp(int keyCode, KeyEvent event) {
        return handleKeyEvent(event) || super.onKeyUp(keyCode, event);
    }

    /**
     * Keyboard / gamepad handling. The activity forwards every key event here, so
     * input works even when the view does not hold focus (Bluetooth / OTG keyboards).
     */
    public boolean handleKeyEvent(KeyEvent e) {
        int code = e.getKeyCode();
        boolean down = e.getAction() == KeyEvent.ACTION_DOWN;
        boolean up = e.getAction() == KeyEvent.ACTION_UP;
        if (!down && !up) return false;
        boolean fresh = down && e.getRepeatCount() == 0;
        if (code == KeyEvent.KEYCODE_BACK) return false;   // handled by Activity.onBackPressed

        if (screen == SCREEN_MENU) {
            if (fresh && isConfirmKey(code)) { startGame(); return true; }
            if (fresh && code == KeyEvent.KEYCODE_O) { open(SCREEN_SETTINGS); return true; }
            if (fresh && code == KeyEvent.KEYCODE_G) { open(SCREEN_GIFTS); return true; }
            if (fresh && code == KeyEvent.KEYCODE_T) { open(SCREEN_TIKTOK); return true; }
            if (fresh && code == KeyEvent.KEYCODE_L) { open(SCREEN_LOOKS); return true; }
            if (fresh && code == KeyEvent.KEYCODE_M) { open(SCREEN_MOD); return true; }
            return code == KeyEvent.KEYCODE_ESCAPE;
        }
        if (screen == SCREEN_SETTINGS) {
            if (fresh && (isConfirmKey(code) || code == KeyEvent.KEYCODE_ESCAPE)) { goBack(); return true; }
            if (fresh && code == KeyEvent.KEYCODE_S) { toggleSetting(0); return true; }
            if (fresh && code == KeyEvent.KEYCODE_B) { toggleSetting(1); return true; }
            if (fresh && code == KeyEvent.KEYCODE_U) { toggleSetting(2); return true; }
            if (fresh && code == KeyEvent.KEYCODE_DPAD_LEFT) { settingsTab = (settingsTab + 2) % 3; return true; }
            if (fresh && code == KeyEvent.KEYCODE_DPAD_RIGHT) { settingsTab = (settingsTab + 1) % 3; return true; }
            return false;
        }
        if (screen == SCREEN_GIFTS) {
            if (fresh && (isConfirmKey(code) || code == KeyEvent.KEYCODE_ESCAPE)) { goBack(); return true; }
            if (fresh && code == KeyEvent.KEYCODE_DPAD_LEFT) { onUi(B_PAGE_PREV); return true; }
            if (fresh && code == KeyEvent.KEYCODE_DPAD_RIGHT) { onUi(B_PAGE_NEXT); return true; }
            if (fresh && code >= KeyEvent.KEYCODE_1 && code <= KeyEvent.KEYCODE_6) {
                int i = giftPage * GIFT_PAGE + (code - KeyEvent.KEYCODE_1);
                if (i < GameSettings.GIFTS) onUi(B_G_ON + i);
                return true;
            }
            return false;
        }
        if (screen == SCREEN_TIKTOK) {
            if (fresh && code == KeyEvent.KEYCODE_ESCAPE) { goBack(); return true; }
            if (fresh && isConfirmKey(code)) { onUi(B_T_START); return true; }
            return false;
        }
        if (screen == SCREEN_EVENTS || screen == SCREEN_PICK || screen == SCREEN_FX || screen == SCREEN_BTNS) {
            if (fresh && code == KeyEvent.KEYCODE_ESCAPE) { goBack(); return true; }
            return false;
        }
        if (screen == SCREEN_LOOKS) {
            if (fresh && (isConfirmKey(code) || code == KeyEvent.KEYCODE_ESCAPE)) { goBack(); return true; }
            if (fresh && code == KeyEvent.KEYCODE_DPAD_LEFT) { onUi(B_MAP_PREV); return true; }
            if (fresh && code == KeyEvent.KEYCODE_DPAD_RIGHT) { onUi(B_MAP_NEXT); return true; }
            if (fresh && code == KeyEvent.KEYCODE_DPAD_UP) { onUi(B_CHAR_PREV); return true; }
            if (fresh && code == KeyEvent.KEYCODE_DPAD_DOWN) { onUi(B_CHAR_NEXT); return true; }
            return false;
        }
        if (screen == SCREEN_PAUSE) {
            if (fresh && (isConfirmKey(code) || code == KeyEvent.KEYCODE_ESCAPE || code == KeyEvent.KEYCODE_P
                    || code == KeyEvent.KEYCODE_BUTTON_START)) { resumeGame(); return true; }
            if (fresh && code == KeyEvent.KEYCODE_R) { startGame(); return true; }
            if (fresh && code == KeyEvent.KEYCODE_M) { leaveTo(SCREEN_MENU); return true; }
            if (fresh && code == KeyEvent.KEYCODE_O) { open(SCREEN_SETTINGS); return true; }
            if (fresh && code == KeyEvent.KEYCODE_G) { open(SCREEN_GIFTS); return true; }
            if (fresh && code == KeyEvent.KEYCODE_T) { open(SCREEN_TIKTOK); return true; }
            return false;
        }

        // ---- in game ----
        switch (code) {
            case KeyEvent.KEYCODE_A:
            case KeyEvent.KEYCODE_DPAD_LEFT:
                keyLeft = down; break;
            case KeyEvent.KEYCODE_D:
            case KeyEvent.KEYCODE_DPAD_RIGHT:
                keyRight = down; break;
            case KeyEvent.KEYCODE_W:
            case KeyEvent.KEYCODE_DPAD_UP:
            case KeyEvent.KEYCODE_SPACE:
            case KeyEvent.KEYCODE_BUTTON_A:
                if (fresh) jumpRequested = true;
                keyJump = down; break;
            case KeyEvent.KEYCODE_SHIFT_LEFT:
            case KeyEvent.KEYCODE_SHIFT_RIGHT:
            case KeyEvent.KEYCODE_BUTTON_R1:
                keyShift = down; break;
            case KeyEvent.KEYCODE_E:
            case KeyEvent.KEYCODE_ENTER:
            case KeyEvent.KEYCODE_NUMPAD_ENTER:
            case KeyEvent.KEYCODE_BUTTON_X:
            case KeyEvent.KEYCODE_BUTTON_R2:
                if (fresh) {
                    breakMode = false;
                    placeUnderPlayer();
                    buildCooldown = cfg.placeInterval() * 2f;
                }
                keyBuild = down; break;
            case KeyEvent.KEYCODE_F:
                if (fresh) placeFront();
                break;
            case KeyEvent.KEYCODE_S:
            case KeyEvent.KEYCODE_DPAD_DOWN:
                keyMineDown = down; if (down) mineCooldown = Math.min(mineCooldown, 0f); break;
            case KeyEvent.KEYCODE_X:
            case KeyEvent.KEYCODE_Z:
            case KeyEvent.KEYCODE_CTRL_LEFT:
            case KeyEvent.KEYCODE_CTRL_RIGHT:
            case KeyEvent.KEYCODE_BUTTON_B:
                keyMineFront = down; if (down) mineCooldown = Math.min(mineCooldown, 0f); break;
            case KeyEvent.KEYCODE_Q:
            case KeyEvent.KEYCODE_BUTTON_Y:
                if (fresh) { breakMode = !breakMode; toast(breakMode ? "MODE BELIUNG" : "MODE BLOK"); }
                break;
            case KeyEvent.KEYCODE_P:
            case KeyEvent.KEYCODE_ESCAPE:
            case KeyEvent.KEYCODE_BUTTON_START:
            case KeyEvent.KEYCODE_MENU:
                if (fresh) pauseGame();
                break;
            default:
                if (code >= KeyEvent.KEYCODE_1 && code <= KeyEvent.KEYCODE_8) {
                    if (fresh) triggerShownGift(code - KeyEvent.KEYCODE_1);
                } else if (code >= KeyEvent.KEYCODE_NUMPAD_1 && code <= KeyEvent.KEYCODE_NUMPAD_8) {
                    if (fresh) triggerShownGift(code - KeyEvent.KEYCODE_NUMPAD_1);
                } else {
                    return false;
                }
        }
        refreshHeldButtons();
        return true;
    }

    private boolean isConfirmKey(int code) {
        return code == KeyEvent.KEYCODE_ENTER || code == KeyEvent.KEYCODE_NUMPAD_ENTER
                || code == KeyEvent.KEYCODE_SPACE || code == KeyEvent.KEYCODE_DPAD_CENTER
                || code == KeyEvent.KEYCODE_BUTTON_A || code == KeyEvent.KEYCODE_BUTTON_START;
    }
}
