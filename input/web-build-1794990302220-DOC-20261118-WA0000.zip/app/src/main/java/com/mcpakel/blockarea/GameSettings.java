package com.mcpakel.blockarea;

import android.content.Context;
import android.content.SharedPreferences;

/** Persistent settings: sound, HUD, look (map / character), TikTok connection, gift slots and event rules. */
public final class GameSettings {
    public static final int GIFTS = 24;          // gift slots (each reacts to one TikTok gift)
    public static final int SHOWN_MAX = 16;      // tiles (gifts + events) in the top rows: 8 per row
    public static final int SCHEMA = 23;         // bump -> old gift/event slots are reset to the new defaults
    public static final int E_BLOCK = 0, E_TNT = 1, E_RAIN = 2, E_NONE = 3, E_HEAL = 4, E_SHIELD = 5,
            E_LIGHTNING = 6, E_TORNADO = 7, E_ROBOT = 8, E_METEOR = 9, E_MONSTER = 10;
    public static final int EFFECTS = 11;
    public static final String[] EFFECT_NAMES = {"BLOK", "TNT", "HUJAN TNT", "KOSONG", "NYAWA", "PERISAI",
            "PETIR", "TORNADO", "ROBOT", "METEOR", "MONSTER"};
    public static final int[] EFFECT_MAX = {100, 50, 30, 1, 20, 30, 30, 5, 8, 20, 3};
    public static final int[] EFFECT_COLOR = {0xff47d16a, 0xffe0a030, 0xff4fc3d9, 0xff8a90a0, 0xffff6a7a,
            0xff4fa8ff, 0xfff3e24a, 0xff8fb3d9, 0xff9ad0f0, 0xffff7a3a, 0xffff3a8a};
    /** Icon ids 0..EFFECTS-1 are the effect pictures (same index as the effect); 100+ are gift sprites. */
    public static int effectIcon(int effect) { return Math.max(0, Math.min(EFFECTS - 1, effect)); }
    public static final int MIN_ICON_GIFT = GiftCatalog.SPRITE_BASE;
    public static final String[] SPEED_NAMES = {"NORMAL", "CEPAT", "SUPER"};
    public static final float[] SPEED_INTERVAL = {0.12f, 0.065f, 0.03f};

    public static final int EV_FOLLOW = 0, EV_SHARE = 1, EV_JOIN = 2, EV_LIKE = 3, EV_CHAT = 4, EV_SUB = 5,
            EV_GIFT = 6;
    public static final int EVENTS = 7;
    public static final String[] EVENT_NAMES = {"FOLLOW", "SHARE", "MASUK LIVE", "LIKE", "KOMENTAR",
            "SUBSCRIBE", "GIFT LAIN"};

    public static final String[] EVENT_SHORT = {"FOLLOW", "SHARE", "MASUK", "LIKE", "KOMEN", "SUB", "GIFT"};

    public static final String[] MAP_NAMES = {"PADANG RUMPUT", "NETHER MALAM"};
    public static final String[] CHAR_NAMES = {"STEVE", "PINKY"};
    public static final int MAPS = 2, CHARS = 2;

    /** One gift slot: reacts to a TikTok gift name and may show as a tile in the top row. */
    public static final class Gift {
        public boolean on, show;
        public int icon, effect, amount;
        public String label = "", name = "";
        public String sound = "", soundName = "";      // own effect sound (copied into the app), "" = default

        public String autoLabel() { return GameSettings.autoLabel(effect, amount); }

        /** Custom text when set, otherwise generated from the amount. */
        public String shownLabel() {
            String t = label == null ? "" : label.trim();
            return t.length() > 0 ? t : autoLabel();
        }

        public String toast() { return GameSettings.toast(effect, amount); }

        public void clampAmount() { amount = GameSettings.clampAmount(effect, amount); }
    }

    /** Reaction to a TikTok event (follow, share, ...). */
    public static final class Rule {
        public boolean on, notify, show;               // show = tile in the top row like a gift
        public int effect, amount;
        public String sound = "", soundName = "";
        public void clampAmount() { amount = GameSettings.clampAmount(effect, amount); }
    }

    public static String autoLabel(int effect, int amount) {
        switch (effect) {
            case E_BLOCK:
            case E_HEAL: return "+" + amount;
            case E_NONE: return "-";
            default: return "x" + amount;
        }
    }

    public static String toast(int effect, int amount) {
        switch (effect) {
            case E_BLOCK: return "+" + amount + " BLOK";
            case E_TNT: return amount + " TNT";
            case E_RAIN: return "HUJAN TNT x" + amount;
            case E_NONE: return "";
            case E_HEAL: return "NYAWA +" + amount;
            case E_SHIELD: return amount + " PERISAI";
            case E_LIGHTNING: return amount + " PETIR";
            case E_TORNADO: return amount + " TORNADO";
            case E_ROBOT: return amount + " ROBOT";
            case E_MONSTER: return amount + " MONSTER";
            default: return amount + " METEOR";
        }
    }

    public static int clampAmount(int effect, int amount) {
        return Math.max(1, Math.min(EFFECT_MAX[Math.max(0, Math.min(EFFECTS - 1, effect))], amount));
    }

    // slot defaults: gift name, icon, effect, amount, on/show
    private static final Object[][] DEFAULTS = {
            {"Rose", E_TNT, 1, true, true}, {"GG", E_BLOCK, 5, true, true},
            {"Finger Heart", E_LIGHTNING, 1, true, true}, {"Doughnut", E_TORNADO, 1, true, true},
            {"Cap", E_ROBOT, 1, true, true}, {"Corgi", E_METEOR, 1, true, true},
            {"Little Crown", E_HEAL, 1, true, true}, {"Sunglasses", E_SHIELD, 1, true, true},
            {"Galaxy", E_MONSTER, 1, true, false}};

    // events: on, notify, effect, amount
    private static final Object[][] EVENT_DEFAULTS = {
            {true, true, E_TNT, 1}, {true, true, E_TNT, 2}, {false, false, E_BLOCK, 5}, {false, false, E_BLOCK, 5},
            {false, false, E_BLOCK, 2}, {true, true, E_METEOR, 1}, {false, true, E_TNT, 1}};

    public boolean sound = true;                 // efek suara
    public boolean musicOn = true, clickSound = true;
    public int sfxVol = 80, musicVol = 45;       // 0..100
    public boolean blockGravity = true;          // blok yang dipasang jatuh sampai menumpu
    public int respawnSec = 5;                   // detik sampai hidup lagi setelah mati
    public boolean hudTransparent = true;        // HUD tanpa latar langit, arena terlihat di belakangnya
    public String modOff = "";                   // mod yang dimatikan, dipisah '|'
    public boolean showButtons = true;
    public boolean unlimited = false;
    public boolean feed = true;                  // show TikTok notifications on screen
    public boolean autoConnect = false;
    public int liveMode = 0;                     // 0 = langsung (di dalam game), 1 = lewat Node.js bridge
    public String apiKey = "";                   // kunci API untuk mode langsung
    public int winTarget = 10;                   // jumlah kemenangan
    public int countdownStart = 10;              // hitungan mundur awal
    public int countdownStep = 10;               // detik per hitungan, dalam persepuluh detik
    public boolean mortal = true;                // pemain bisa mati
    public boolean showHp = true;                // tampilkan nyawa di HUD
    public int tornadoSec = 12, robotSec = 30, monsterSec = 8, shieldSec = 60;
    public int speed = 1;
    public int hudOffset = 0;                    // pushes the HUD down (notch / camera cut-out)
    public int map = 0, character = 0;
    public int likeEvery = 10;                   // LIKE rule fires once per N likes
    public String host = "127.0.0.1", user = "";
    public int port = 25601;
    public String recent = "";                   // recently seen live gift names, '|' separated
    public int tileCount = 8;                    // jumlah gift yang tampil di baris atas (1..SHOWN_MAX)
    public final Gift[] gifts = new Gift[GIFTS];
    public final Rule[] rules = new Rule[EVENTS];
    private final SharedPreferences prefs;

    public GameSettings(Context context) {
        SharedPreferences p = null;
        try { p = context.getSharedPreferences("blockrush_settings", Context.MODE_PRIVATE); } catch (Throwable ignored) { }
        prefs = p;
        for (int i = 0; i < GIFTS; i++) gifts[i] = new Gift();
        for (int i = 0; i < EVENTS; i++) rules[i] = new Rule();
        resetDefaults();
        load();
    }

    public void resetDefaults() {
        sound = true; showButtons = true; unlimited = false; speed = 1; feed = true; hudOffset = 0;
        winTarget = 10; countdownStart = 10; countdownStep = 10; mortal = true; showHp = true;
        tornadoSec = 12; robotSec = 30; monsterSec = 8; shieldSec = 60; tileCount = 8;
        musicOn = true; clickSound = true; sfxVol = 80; musicVol = 45; blockGravity = true; respawnSec = 5;
        hudTransparent = true;
        resetGifts();
        resetRules();
    }

    public void resetGifts() {
        for (int i = 0; i < GIFTS; i++) {
            Gift g = gifts[i];
            if (i < DEFAULTS.length) {
                g.name = (String) DEFAULTS[i][0]; g.icon = GiftCatalog.iconFor(g.name);
                g.effect = (Integer) DEFAULTS[i][1]; g.amount = (Integer) DEFAULTS[i][2];
                g.on = (Boolean) DEFAULTS[i][3]; g.show = (Boolean) DEFAULTS[i][4];
            } else {
                g.name = ""; g.icon = GiftCatalog.GENERIC_ICON; g.effect = E_TNT; g.amount = 1; g.on = false; g.show = false;
            }
            g.label = ""; g.sound = ""; g.soundName = "";
        }
    }

    public void resetRules() {
        for (int i = 0; i < EVENTS; i++) {
            Rule r = rules[i];
            r.on = (Boolean) EVENT_DEFAULTS[i][0]; r.notify = (Boolean) EVENT_DEFAULTS[i][1];
            r.effect = (Integer) EVENT_DEFAULTS[i][2]; r.amount = (Integer) EVENT_DEFAULTS[i][3];
            r.show = false; r.sound = ""; r.soundName = "";
        }
        likeEvery = 10;
    }

    /** Number of tiles shown in the top rows: shown gifts first, then shown events (hidden ones still fire). */
    public int shownGifts() {
        int n = 0, max = Math.min(SHOWN_MAX, tileCount);
        for (Gift g : gifts) if (g.on && g.show && n < max) n++;
        for (Rule r : rules) if (r.on && r.show && n < max) n++;
        return n;
    }

    public int activeGifts() {
        int n = 0;
        for (Gift g : gifts) if (g.on) n++;
        return n;
    }

    public float placeInterval() { return SPEED_INTERVAL[Math.max(0, Math.min(SPEED_INTERVAL.length - 1, speed))]; }

    /** Finds the active gift slot for a TikTok gift (by name, ignoring case / spaces / plural s, or by id). */
    public Gift findGift(String giftName, int giftId) {
        int i = findGiftIndex(giftName, giftId);
        return i < 0 ? null : gifts[i];
    }

    /** Index of the active slot for this gift (exact name, Indonesian alias, or numeric id); -1 if none. */
    public int findGiftIndex(String giftName, int giftId) {
        String n = norm(giftName);
        for (int i = 0; i < gifts.length; i++) {
            Gift g = gifts[i];
            if (!g.on || g.name == null || g.name.trim().length() == 0) continue;
            String m = norm(g.name);
            if (m.length() > 0 && m.equals(n)) return i;
            if (giftId > 0 && m.equals(String.valueOf(giftId))) return i;
        }
        return -1;
    }

    private static final String[] LOCAL = {"rose", "mawar", "doughnut", "donat", "ice cream cone", "es krim",
            "finger heart", "jari hati", "cap", "topi", "sunglasses", "kacamata hitam", "little crown", "mahkota kecil",
            "galaxy", "galaksi", "lion", "singa", "cake slice", "kue", "thumbs up", "jempol", "perfume", "parfum",
            "swan", "angsa", "train", "kereta", "fireworks", "kembang api", "confetti", "konfeti", "money gun",
            "pistol uang", "sports car", "mobil sport", "hand heart", "hati tangan", "heart", "hati", "coffee", "kopi",
            "paper crane", "bangau kertas", "groove guitar", "gitar", "spinning soccer", "bola"};

    /** Name shown in notifications: Indonesian where known ("mawar", "donat"), else the TikTok name. */
    public static String localName(String name) {
        if (name == null) return "";
        String k = name.trim().toLowerCase();
        for (int i = 0; i + 1 < LOCAL.length; i += 2) if (LOCAL[i].equals(k)) return LOCAL[i + 1];
        return name.trim();
    }

    /** Exact name key (letters / digits only, lower case). "Rose" and "Roses" are different gifts. */
    public static String norm(String s) {
        if (s == null) return "";
        StringBuilder b = new StringBuilder();
        for (int i = 0; i < s.length(); i++) {
            char c = Character.toLowerCase(s.charAt(i));
            if ((c >= 'a' && c <= 'z') || (c >= '0' && c <= '9')) b.append(c);
        }
        String k = b.toString();
        for (int i = 0; i + 1 < ALIAS.length; i += 2) if (ALIAS[i].equals(k)) return ALIAS[i + 1];
        return k;
    }

    /** Indonesian TikTok names -> the English catalog name (already normalised). */
    private static final String[] ALIAS = {"mawar", "rose", "donat", "doughnut", "eskrim", "icecreamcone",
            "topi", "cap", "kacamatahitam", "sunglasses", "jarihati", "fingerheart", "hatijari", "fingerheart",
            "tanganhati", "handheart", "anjingcorgi", "corgi", "galaksi", "galaxy", "singa", "lion"};

    public void rememberGift(String name) {
        if (name == null || name.trim().length() == 0) return;
        String n = name.trim().replace("|", " ");
        StringBuilder b = new StringBuilder(n);
        int count = 1;
        for (String s : recent.split("\\|")) {
            if (s.length() == 0 || norm(s).equals(norm(n)) || count >= 16) continue;
            b.append('|').append(s);
            count++;
        }
        recent = b.toString();
    }

    private void load() {
        if (prefs == null) return;
        try {
            sound = prefs.getBoolean("sound", sound);
            musicOn = prefs.getBoolean("musicOn", musicOn);
            clickSound = prefs.getBoolean("clickSound", clickSound);
            sfxVol = Math.max(0, Math.min(100, prefs.getInt("sfxVol", sfxVol)));
            musicVol = Math.max(0, Math.min(100, prefs.getInt("musicVol", musicVol)));
            blockGravity = prefs.getBoolean("blockGravity", blockGravity);
            respawnSec = Math.max(1, Math.min(120, prefs.getInt("respawnSec", respawnSec)));
            hudTransparent = prefs.getBoolean("hudTransparent", hudTransparent);
            modOff = prefs.getString("modOff", modOff);
            showButtons = prefs.getBoolean("buttons", showButtons);
            unlimited = prefs.getBoolean("unlimited", unlimited);
            feed = prefs.getBoolean("feed", feed);
            autoConnect = prefs.getBoolean("auto", autoConnect);
            speed = Math.max(0, Math.min(SPEED_NAMES.length - 1, prefs.getInt("speed", speed)));
            hudOffset = Math.max(0, Math.min(80, prefs.getInt("hud", hudOffset)));
            map = Math.max(0, Math.min(MAPS - 1, prefs.getInt("map", map)));
            character = Math.max(0, Math.min(CHARS - 1, prefs.getInt("char", character)));
            likeEvery = Math.max(1, Math.min(500, prefs.getInt("likeEvery", likeEvery)));
            host = prefs.getString("host", host);
            user = prefs.getString("user", user);
            port = Math.max(1, Math.min(65535, prefs.getInt("port", port)));
            recent = prefs.getString("recent", recent);
            apiKey = prefs.getString("apiKey", apiKey);
            liveMode = Math.max(0, Math.min(1, prefs.getInt("liveMode", liveMode)));
            winTarget = Math.max(1, Math.min(99, prefs.getInt("win", winTarget)));
            countdownStart = Math.max(3, Math.min(99, prefs.getInt("cdStart", countdownStart)));
            countdownStep = Math.max(3, Math.min(30, prefs.getInt("cdStep", countdownStep)));
            mortal = prefs.getBoolean("mortal", mortal);
            showHp = prefs.getBoolean("showHp", showHp);
            tornadoSec = Math.max(2, Math.min(120, prefs.getInt("tornadoSec", tornadoSec)));
            robotSec = Math.max(5, Math.min(300, prefs.getInt("robotSec", robotSec)));
            monsterSec = Math.max(3, Math.min(60, prefs.getInt("monsterSec", monsterSec)));
            shieldSec = Math.max(5, Math.min(600, prefs.getInt("shieldSec", shieldSec)));
            tileCount = Math.max(1, Math.min(SHOWN_MAX, prefs.getInt("tiles", tileCount)));
            if (prefs.getInt("schema", 0) < SCHEMA) return;     // old gift / event slots: keep the new defaults
            for (int i = 0; i < GIFTS; i++) {
                Gift g = gifts[i];
                String k = "g" + i + "_";
                g.on = prefs.getBoolean(k + "on", g.on);
                g.show = prefs.getBoolean(k + "show", g.show);
                g.icon = prefs.getInt(k + "icon", g.icon);
                if (g.icon < 0 || (g.icon >= EFFECTS && g.icon < GiftCatalog.SPRITE_BASE) || g.icon > GiftCatalog.GENERIC_ICON)
                    g.icon = GiftCatalog.iconFor(g.name);
                g.effect = Math.max(0, Math.min(EFFECTS - 1, prefs.getInt(k + "effect", g.effect)));
                g.amount = prefs.getInt(k + "amount", g.amount);
                g.label = prefs.getString(k + "label", g.label);
                g.name = prefs.getString(k + "name", g.name);
                g.sound = prefs.getString(k + "snd", g.sound);
                g.soundName = prefs.getString(k + "sndn", g.soundName);
                g.clampAmount();
            }
            for (int i = 0; i < EVENTS; i++) {
                Rule r = rules[i];
                String k = "e" + i + "_";
                r.on = prefs.getBoolean(k + "on", r.on);
                r.notify = prefs.getBoolean(k + "notify", r.notify);
                r.effect = Math.max(0, Math.min(EFFECTS - 1, prefs.getInt(k + "effect", r.effect)));
                r.amount = prefs.getInt(k + "amount", r.amount);
                r.show = prefs.getBoolean(k + "show", r.show);
                r.sound = prefs.getString(k + "snd", r.sound);
                r.soundName = prefs.getString(k + "sndn", r.soundName);
                r.clampAmount();
            }
        } catch (Throwable ignored) { }
    }

    public void save() {
        if (prefs == null) return;
        try {
            SharedPreferences.Editor e = prefs.edit();
            e.putBoolean("sound", sound);
            e.putBoolean("musicOn", musicOn);
            e.putBoolean("clickSound", clickSound);
            e.putInt("sfxVol", sfxVol);
            e.putInt("musicVol", musicVol);
            e.putBoolean("blockGravity", blockGravity);
            e.putInt("respawnSec", respawnSec);
            e.putBoolean("hudTransparent", hudTransparent);
            e.putString("modOff", modOff == null ? "" : modOff);
            e.putBoolean("buttons", showButtons);
            e.putBoolean("unlimited", unlimited);
            e.putBoolean("feed", feed);
            e.putBoolean("auto", autoConnect);
            e.putInt("speed", speed);
            e.putInt("hud", hudOffset);
            e.putInt("map", map);
            e.putInt("char", character);
            e.putInt("likeEvery", likeEvery);
            e.putInt("schema", SCHEMA);
            e.putString("apiKey", apiKey == null ? "" : apiKey);
            e.putInt("liveMode", liveMode);
            e.putInt("win", winTarget);
            e.putInt("cdStart", countdownStart);
            e.putInt("cdStep", countdownStep);
            e.putBoolean("mortal", mortal);
            e.putBoolean("showHp", showHp);
            e.putInt("tornadoSec", tornadoSec);
            e.putInt("robotSec", robotSec);
            e.putInt("monsterSec", monsterSec);
            e.putInt("shieldSec", shieldSec);
            e.putInt("tiles", tileCount);
            e.putString("host", host == null ? "" : host);
            e.putString("user", user == null ? "" : user);
            e.putInt("port", port);
            e.putString("recent", recent == null ? "" : recent);
            for (int i = 0; i < GIFTS; i++) {
                Gift g = gifts[i];
                String k = "g" + i + "_";
                e.putBoolean(k + "on", g.on);
                e.putBoolean(k + "show", g.show);
                e.putInt(k + "icon", g.icon);
                e.putInt(k + "effect", g.effect);
                e.putInt(k + "amount", g.amount);
                e.putString(k + "label", g.label == null ? "" : g.label);
                e.putString(k + "name", g.name == null ? "" : g.name);
                e.putString(k + "snd", g.sound == null ? "" : g.sound);
                e.putString(k + "sndn", g.soundName == null ? "" : g.soundName);
            }
            for (int i = 0; i < EVENTS; i++) {
                Rule r = rules[i];
                String k = "e" + i + "_";
                e.putBoolean(k + "on", r.on);
                e.putBoolean(k + "notify", r.notify);
                e.putInt(k + "effect", r.effect);
                e.putInt(k + "amount", r.amount);
                e.putBoolean(k + "show", r.show);
                e.putString(k + "snd", r.sound == null ? "" : r.sound);
                e.putString(k + "sndn", r.soundName == null ? "" : r.soundName);
            }
            e.apply();
        } catch (Throwable ignored) { }
    }
}
