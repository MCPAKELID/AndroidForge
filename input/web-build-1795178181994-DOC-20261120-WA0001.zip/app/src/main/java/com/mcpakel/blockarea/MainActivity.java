package com.mcpakel.blockarea;

import android.app.Activity;
import android.content.Intent;
import android.database.Cursor;
import android.net.Uri;
import android.provider.OpenableColumns;
import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import android.os.Build;
import android.os.Bundle;
import android.view.KeyEvent;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;

public class MainActivity extends Activity {
    private AreaView view;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        getWindow().setFlags(
                WindowManager.LayoutParams.FLAG_FULLSCREEN | WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON,
                WindowManager.LayoutParams.FLAG_FULLSCREEN | WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        if (Build.VERSION.SDK_INT >= 28) {
            // Draw behind the camera notch instead of leaving a black bar.
            getWindow().getAttributes().layoutInDisplayCutoutMode =
                    WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES;
        }
        applyImmersive();
        view = new AreaView(this);
        view.setSoundPicker(new AreaView.SoundPicker() {
            @Override public void pick(int kind, int index) { openSoundPicker(kind, index); }
        });
        setContentView(view);
    }

    // ---- own effect sound per gift / event ---------------------------------------------------
    private static final int REQ_SOUND = 7301;
    private int soundKind, soundIndex;

    private void openSoundPicker(int kind, int index) {
        soundKind = kind; soundIndex = index;
        Intent it = new Intent(Intent.ACTION_GET_CONTENT);
        it.setType("audio/*");
        it.addCategory(Intent.CATEGORY_OPENABLE);
        startActivityForResult(Intent.createChooser(it, "Pilih file suara"), REQ_SOUND);
    }

    @SuppressWarnings("deprecation")
    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode != REQ_SOUND || resultCode != RESULT_OK || data == null || data.getData() == null) return;
        final Uri uri = data.getData();
        final int kind = soundKind, index = soundIndex;
        new Thread(new Runnable() {
            @Override public void run() {
                try {
                    String name = null;
                    Cursor c = getContentResolver().query(uri, null, null, null, null);
                    if (c != null) {
                        try {
                            int ni = c.getColumnIndex(OpenableColumns.DISPLAY_NAME);
                            if (ni >= 0 && c.moveToFirst()) name = c.getString(ni);
                        } finally { c.close(); }
                    }
                    if (name == null || name.length() == 0) name = "suara";
                    String ext = ".mp3";
                    int dot = name.lastIndexOf('.');
                    if (dot > 0 && name.length() - dot <= 6) ext = name.substring(dot);
                    File dir = new File(getFilesDir(), "sfx");
                    dir.mkdirs();
                    final File out = new File(dir, (kind == 0 ? "g" : "e") + index + "_" + System.currentTimeMillis() + ext);
                    InputStream in = getContentResolver().openInputStream(uri);
                    if (in == null) return;
                    OutputStream os = new FileOutputStream(out);
                    try {
                        byte[] buf = new byte[16384];
                        long total = 0; int n;
                        while ((n = in.read(buf)) > 0) {
                            total += n;
                            if (total > 6L * 1024 * 1024) { os.close(); in.close(); out.delete(); return; }   // effect sounds are short
                            os.write(buf, 0, n);
                        }
                    } finally { try { os.close(); } catch (Exception ignored) { } try { in.close(); } catch (Exception ignored) { } }
                    final String shown = dot > 0 ? name.substring(0, dot) : name;
                    runOnUiThread(new Runnable() {
                        @Override public void run() { if (view != null) view.onSoundPicked(kind, index, out.getAbsolutePath(), shown); }
                    });
                } catch (Throwable ignored) { }
            }
        }, "SoundCopy").start();
    }

    @SuppressWarnings("deprecation")
    private void applyImmersive() {
        getWindow().getDecorView().setSystemUiVisibility(
                View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
                | View.SYSTEM_UI_FLAG_FULLSCREEN
                | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
                | View.SYSTEM_UI_FLAG_LAYOUT_STABLE);
    }

    @Override
    public void onWindowFocusChanged(boolean hasFocus) {
        super.onWindowFocusChanged(hasFocus);
        if (hasFocus) applyImmersive();
    }

    /** Every key (Bluetooth / OTG keyboard, gamepad) goes to the game first. */
    @Override
    public boolean dispatchKeyEvent(KeyEvent event) {
        if (view != null && view.handleKeyEvent(event)) return true;
        return super.dispatchKeyEvent(event);
    }

    @SuppressWarnings("deprecation")
    @Override
    public void onBackPressed() {
        if (view != null && view.handleBack()) return;
        super.onBackPressed();
    }

    @Override
    protected void onPause() {
        super.onPause();
        if (view != null) view.onHostPause();
    }

    @Override
    protected void onDestroy() {
        if (view != null) view.release();
        super.onDestroy();
    }
}
