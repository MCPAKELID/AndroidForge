package com.mcpakel.blockarea;

import android.graphics.Bitmap;
import android.graphics.BitmapFactory;

import java.io.BufferedReader;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLDecoder;
import java.util.Collections;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Gift pictures straight from the web. The gift page of streamtoearn.io lists every TikTok gift with its
 * picture on the TikTok CDN (alt text = "<name> TikTok gift"). The page is read once (cached on disk),
 * then every picture is downloaded the first time it is needed and cached as a file.
 * Live events that carry a picture URL feed the same table.
 */
public final class GiftWeb {
    private static final String PAGE = "https://streamtoearn.io/gifts?region=ID";
    private static final String UA = "Mozilla/5.0 (Linux; Android 12; Mobile) AppleWebKit/537.36 (KHTML, like Gecko) "
            + "Chrome/120.0 Mobile Safari/537.36";
    private static final long RETRY_MS = 90_000L;

    private final File dir;
    private final Map<String, String> urls = new ConcurrentHashMap<>();
    private final Map<String, Bitmap> bitmaps = new ConcurrentHashMap<>();
    private final Map<String, Long> failed = new ConcurrentHashMap<>();
    private final Set<String> pending = Collections.synchronizedSet(new HashSet<String>());
    private final ExecutorService pool = Executors.newFixedThreadPool(3);
    private volatile boolean catalogBusy = false;
    private volatile long catalogTried = 0L;
    public volatile String status = "";

    public GiftWeb(File cacheDir) {
        dir = new File(cacheDir, "gifticons");
        try { dir.mkdirs(); } catch (Throwable ignored) { }
        readCatalogFile();
    }

    public int known() { return urls.size(); }

    public void shutdown() { try { pool.shutdownNow(); } catch (Throwable ignored) { } }

    /** Loads the gift list from the website when we do not have it yet (background, retried every 90 s). */
    public void ensureCatalog() {
        if (catalogBusy || !urls.isEmpty()) return;
        long t = System.currentTimeMillis();
        if (t - catalogTried < RETRY_MS) return;
        catalogTried = t;
        catalogBusy = true;
        try {
            pool.execute(new Runnable() {
                @Override public void run() {
                    try {
                        status = "Mengambil daftar gift...";
                        String html = httpText(PAGE);
                        int n = parse(html);
                        if (n >= 20) { writeCatalogFile(); status = n + " gambar gift"; }
                        else status = "Daftar gift tidak terbaca";
                    } catch (Throwable e) {
                        status = "Tanpa internet: gambar gift pakai bawaan";
                    } finally {
                        catalogBusy = false;
                    }
                }
            });
        } catch (Throwable e) { catalogBusy = false; }
    }

    /** Picture URL sent by a live event (more reliable than the page). */
    public void register(String name, String url) {
        if (name == null || url == null || url.length() < 10 || !url.startsWith("http")) return;
        String key = GameSettings.norm(name);
        if (key.length() == 0) return;
        String old = urls.put(key, url);
        if (old != null && !old.equals(url)) { bitmaps.remove(key); failed.remove(key); }
    }

    /** Cached picture, or null while it is still being downloaded (a request is started on the first call). */
    public Bitmap get(String name) {
        if (name == null) return null;
        String key = GameSettings.norm(name);
        if (key.length() == 0) return null;
        Bitmap b = bitmaps.get(key);
        if (b != null) return b;
        String url = urls.get(key);
        if (url == null) { ensureCatalog(); return null; }
        Long f = failed.get(key);
        if (f != null && System.currentTimeMillis() - f < RETRY_MS) return null;
        if (!pending.add(key)) return null;
        final String k = key, u = url;
        try {
            pool.execute(new Runnable() {
                @Override public void run() {
                    try {
                        Bitmap bm = fetch(k, u);
                        if (bm != null) bitmaps.put(k, bm); else failed.put(k, System.currentTimeMillis());
                    } catch (Throwable e) {
                        failed.put(k, System.currentTimeMillis());
                    } finally {
                        pending.remove(k);
                    }
                }
            });
        } catch (Throwable e) { pending.remove(key); }
        return null;
    }

    // ---- download / decode ---------------------------------------------------------------
    private Bitmap fetch(String key, String url) throws Exception {
        File f = new File(dir, Integer.toHexString(key.hashCode()) + "_" + Integer.toHexString(url.hashCode()) + ".img");
        if (!f.exists() || f.length() < 100) {
            File tmp = new File(dir, f.getName() + ".part");
            byte[] data = httpBytes(url, 600_000);
            FileOutputStream out = new FileOutputStream(tmp);
            out.write(data);
            out.close();
            if (!tmp.renameTo(f)) return null;
        }
        Bitmap b = BitmapFactory.decodeFile(f.getAbsolutePath());
        if (b == null) { f.delete(); return null; }
        return b;
    }

    private static HttpURLConnection open(String url) throws Exception {
        HttpURLConnection c = (HttpURLConnection) new URL(url).openConnection();
        c.setConnectTimeout(8000);
        c.setReadTimeout(12000);
        c.setRequestProperty("User-Agent", UA);
        c.setRequestProperty("Accept", "*/*");
        c.setRequestProperty("Accept-Language", "id,en;q=0.8");
        c.setInstanceFollowRedirects(true);
        return c;
    }

    private static byte[] httpBytes(String url, int max) throws Exception {
        HttpURLConnection c = open(url);
        try {
            if (c.getResponseCode() != 200) throw new Exception("HTTP " + c.getResponseCode());
            InputStream in = c.getInputStream();
            ByteArrayOutputStream bo = new ByteArrayOutputStream();
            byte[] buf = new byte[8192];
            int n;
            while ((n = in.read(buf)) > 0) {
                bo.write(buf, 0, n);
                if (bo.size() > max) throw new Exception("too big");
            }
            in.close();
            return bo.toByteArray();
        } finally {
            c.disconnect();
        }
    }

    private static String httpText(String url) throws Exception {
        return new String(httpBytes(url, 6_000_000), "UTF-8");
    }

    // ---- page parsing --------------------------------------------------------------------
    private static final Pattern IMG = Pattern.compile("<img\\b[^>]*>", Pattern.CASE_INSENSITIVE | Pattern.DOTALL);
    private static final Pattern ALT = Pattern.compile("\\balt\\s*=\\s*(\"([^\"]*)\"|'([^']*)')", Pattern.CASE_INSENSITIVE);
    private static final Pattern CDN = Pattern.compile(
            "https?(?::|%3A)(?://|%2F%2F)[^\"'\\s&)<>]*tiktokcdn[^\"'\\s&)<>]*", Pattern.CASE_INSENSITIVE);

    /** Reads every {@code <img alt="NAME TikTok gift" src=...tiktokcdn...>} into the table. Returns how many were found. */
    int parse(String html) {
        if (html == null) return 0;
        int count = 0;
        Matcher m = IMG.matcher(html);
        while (m.find()) {
            String tag = m.group();
            Matcher a = ALT.matcher(tag);
            if (!a.find()) continue;
            String alt = a.group(2) != null ? a.group(2) : a.group(3);
            alt = decodeEntities(alt).trim();
            int cut = alt.toLowerCase().lastIndexOf(" tiktok gift");
            if (cut <= 0) continue;
            String name = alt.substring(0, cut).trim();
            Matcher c = CDN.matcher(tag);
            if (name.length() == 0 || !c.find()) continue;
            String url = c.group();
            try { if (url.contains("%")) url = URLDecoder.decode(url, "UTF-8"); } catch (Exception ignored) { }
            url = url.replace("&amp;", "&");
            String key = GameSettings.norm(name);
            if (key.length() == 0 || urls.containsKey(key)) continue;
            urls.put(key, url);
            count++;
        }
        return count;
    }

    private static String decodeEntities(String s) {
        return s.replace("&#39;", "'").replace("&#x27;", "'").replace("&apos;", "'").replace("&quot;", "\"")
                .replace("&lt;", "<").replace("&gt;", ">").replace("&amp;", "&");
    }

    // ---- disk cache of the table ----------------------------------------------------------
    private File catalogFile() { return new File(dir, "catalog.tsv"); }

    private void writeCatalogFile() {
        try {
            StringBuilder sb = new StringBuilder();
            for (Map.Entry<String, String> e : urls.entrySet()) sb.append(e.getKey()).append('\t').append(e.getValue()).append('\n');
            FileOutputStream out = new FileOutputStream(catalogFile());
            out.write(sb.toString().getBytes("UTF-8"));
            out.close();
        } catch (Throwable ignored) { }
    }

    private void readCatalogFile() {
        File f = catalogFile();
        if (!f.exists()) return;
        try {
            BufferedReader r = new BufferedReader(new InputStreamReader(new java.io.FileInputStream(f), "UTF-8"));
            String line;
            while ((line = r.readLine()) != null) {
                int t = line.indexOf('\t');
                if (t > 0) urls.put(line.substring(0, t), line.substring(t + 1));
            }
            r.close();
        } catch (Throwable ignored) { }
    }
}
