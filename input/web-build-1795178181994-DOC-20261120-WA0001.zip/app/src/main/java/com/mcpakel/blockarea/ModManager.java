package com.mcpakel.blockarea;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Mod support. Every folder inside <code>mods/</code> (in the app's files folder) is a mod:
 * <ul>
 *   <li>Any file put in the same relative path as a game asset replaces it
 *       (<code>ui/fx_tnt.png</code>, <code>blocks/block_00.png</code>, <code>sounds/sfx_place.wav</code>,
 *       <code>music/bgm.wav</code>, <code>fx/robot_0.png</code>, ...).</li>
 *   <li><code>mod.json</code> can add new gift reactions ("gifts") and extra actions for TikTok events ("events").</li>
 * </ul>
 */
public final class ModManager {
    public static final class Action {
        public int effect, amount;
    }

    public static final class ModGift {
        public String name = "", label = "", iconPath = "";
        public final List<Action> actions = new ArrayList<>();
        Bitmap icon;
        boolean iconTried;
    }

    public static final class Mod {
        public String id = "", name = "", version = "", author = "", description = "";
        public File dir;
        public boolean enabled = true, example = false;
        public int files = 0;
        public final List<ModGift> gifts = new ArrayList<>();
        public final Map<String, List<Action>> events = new HashMap<>();
        public String error = "";
    }

    private final File root;
    private final GameSettings cfg;
    public final List<Mod> mods = new ArrayList<>();

    public ModManager(Context context, GameSettings cfg) {
        this.cfg = cfg;
        File base = null;
        try { base = context.getExternalFilesDir(null); } catch (Throwable ignored) { }
        if (base == null) base = context.getCacheDir();
        root = new File(base, "mods");
        scan();
    }

    public File root() { return root; }

    public void scan() {
        mods.clear();
        try {
            if (!root.exists()) root.mkdirs();
            File[] dirs = root.listFiles();
            if (dirs == null || dirs.length == 0) {
                writeSample();
                dirs = root.listFiles();
            }
            if (dirs == null) return;
            Arrays.sort(dirs);
            for (File d : dirs) {
                if (!d.isDirectory() || d.getName().startsWith(".")) continue;
                mods.add(readMod(d));
            }
        } catch (Throwable ignored) { }
    }

    private Mod readMod(File d) {
        Mod m = new Mod();
        m.dir = d;
        m.id = d.getName();
        m.name = d.getName();
        m.files = countFiles(d, true);
        File js = new File(d, "mod.json");
        if (js.exists()) {
            try {
                String text = readAll(js);
                Object o = new LiveClient.Json(text).read();
                if (o instanceof Map) fill(m, (Map<?, ?>) o);
            } catch (Throwable t) {
                m.error = "mod.json tidak valid: " + t.getMessage();
            }
        }
        m.enabled = !m.example && !isOff(m.id);
        return m;
    }

    private void fill(Mod m, Map<?, ?> o) {
        m.name = s(o.get("name"), m.name);
        m.version = s(o.get("version"), "");
        m.author = s(o.get("author"), "");
        m.description = s(o.get("description"), "");
        m.example = Boolean.TRUE.equals(o.get("example"));
        Object g = o.get("gifts");
        if (g instanceof List) {
            for (Object x : (List<?>) g) {
                if (!(x instanceof Map)) continue;
                Map<?, ?> gm = (Map<?, ?>) x;
                ModGift mg = new ModGift();
                mg.name = s(gm.get("name"), "");
                mg.label = s(gm.get("label"), "");
                mg.iconPath = s(gm.get("icon"), "");
                readActions(gm.get("actions"), mg.actions);
                if (mg.name.length() > 0 && !mg.actions.isEmpty()) m.gifts.add(mg);
            }
        }
        Object ev = o.get("events");
        if (ev instanceof Map) {
            for (Map.Entry<?, ?> e : ((Map<?, ?>) ev).entrySet()) {
                List<Action> list = new ArrayList<>();
                readActions(e.getValue(), list);
                if (!list.isEmpty()) m.events.put(String.valueOf(e.getKey()).toLowerCase(), list);
            }
        }
    }

    private static void readActions(Object o, List<Action> out) {
        if (!(o instanceof List)) return;
        for (Object x : (List<?>) o) {
            if (!(x instanceof Map)) continue;
            Map<?, ?> am = (Map<?, ?>) x;
            int eff = effectByName(s(am.get("effect"), ""));
            if (eff < 0) continue;
            Action a = new Action();
            a.effect = eff;
            int amt = 1;
            Object ao = am.get("amount");
            if (ao instanceof Double) amt = (int) Math.round((Double) ao);
            a.amount = Math.max(1, Math.min(GameSettings.EFFECT_MAX[eff] * 3, amt));
            out.add(a);
        }
    }

    /** "TNT", "tornado", "hujan tnt", "nyawa" / "life", ... (any case, spaces ignored). -1 when unknown. */
    public static int effectByName(String s) {
        String k = s.toLowerCase().replace(" ", "").replace("_", "").replace("-", "");
        String[][] names = {
                {"blok", "block"}, {"tnt"}, {"hujantnt", "rain", "tntrain"}, {"kosong", "none", "empty", "turbo", "speed"},
                {"nyawa", "life", "heal", "heart"}, {"perisai", "shield"}, {"petir", "lightning", "bolt"},
                {"tornado"}, {"robot"}, {"meteor"}, {"monster"},
                {"rudal", "missile", "rocket", "roket"}, {"pelempar", "pelemparnt", "pelemparbom", "thrower", "lempar"},
                {"bos", "boss", "naga", "dragon", "api"}, {"bor", "drill", "mesinbor"}};
        for (int i = 0; i < names.length && i < GameSettings.EFFECTS; i++) {
            for (String n : names[i]) if (n.equals(k)) return i;
        }
        return -1;
    }

    private static String s(Object o, String def) {
        return o instanceof String ? (String) o : def;
    }

    // ---- enable / disable ------------------------------------------------------------------
    private boolean isOff(String id) {
        if (cfg.modOff == null) return false;
        for (String s : cfg.modOff.split("\\|")) if (s.equals(id)) return true;
        return false;
    }

    public void setEnabled(Mod m, boolean on) {
        if (m.example) return;
        StringBuilder sb = new StringBuilder();
        if (cfg.modOff != null) for (String s : cfg.modOff.split("\\|")) if (s.length() > 0 && !s.equals(m.id)) sb.append(s).append('|');
        if (!on) sb.append(m.id).append('|');
        cfg.modOff = sb.toString();
        cfg.save();
        m.enabled = on;
    }

    public int enabledCount() {
        int n = 0;
        for (Mod m : mods) if (m.enabled) n++;
        return n;
    }

    // ---- asset overrides -------------------------------------------------------------------
    /** File of an override for the asset path, or null. Mods are checked in name order, the last one wins. */
    public File find(String assetPath) {
        File hit = null;
        for (Mod m : mods) {
            if (!m.enabled) continue;
            File f = new File(m.dir, assetPath);
            if (f.isFile() && f.length() > 0) hit = f;
        }
        return hit;
    }

    public InputStream open(String assetPath) {
        File f = find(assetPath);
        if (f == null) return null;
        try { return new FileInputStream(f); } catch (Throwable t) { return null; }
    }

    // ---- gift / event extensions -----------------------------------------------------------
    public ModGift giftFor(String name) {
        String k = GameSettings.norm(name);
        if (k.length() == 0) return null;
        for (int i = mods.size() - 1; i >= 0; i--) {
            Mod m = mods.get(i);
            if (!m.enabled) continue;
            for (ModGift g : m.gifts) if (GameSettings.norm(g.name).equals(k)) return g;
        }
        return null;
    }

    public List<Action> eventActions(String type) {
        List<Action> out = new ArrayList<>();
        for (Mod m : mods) {
            if (!m.enabled) continue;
            List<Action> a = m.events.get(type);
            if (a != null) out.addAll(a);
        }
        return out;
    }

    public Bitmap iconOf(ModGift g) {
        if (g.icon != null || g.iconTried) return g.icon;
        g.iconTried = true;
        if (g.iconPath.length() == 0) return null;
        for (Mod m : mods) {
            if (!m.gifts.contains(g)) continue;
            File f = new File(m.dir, g.iconPath);
            if (f.isFile()) g.icon = BitmapFactory.decodeFile(f.getAbsolutePath());
        }
        return g.icon;
    }

    // ---- helpers ---------------------------------------------------------------------------
    private static int countFiles(File d, boolean top) {
        int n = 0;
        File[] fs = d.listFiles();
        if (fs == null) return 0;
        for (File f : fs) {
            if (f.isDirectory()) n += countFiles(f, false);
            else if (!(top && (f.getName().equals("mod.json") || f.getName().toLowerCase().startsWith("readme")))) n++;
        }
        return n;
    }

    private static String readAll(File f) throws Exception {
        FileInputStream in = new FileInputStream(f);
        java.io.ByteArrayOutputStream bo = new java.io.ByteArrayOutputStream();
        byte[] buf = new byte[4096];
        int n;
        while ((n = in.read(buf)) > 0) bo.write(buf, 0, n);
        in.close();
        return new String(bo.toByteArray(), "UTF-8");
    }

    private void writeSample() {
        try {
            File d = new File(root, "contoh_mod");
            d.mkdirs();
            write(new File(d, "mod.json"), "{\n"
                    + "  \"name\": \"Contoh Mod\",\n"
                    + "  \"version\": \"1.0\",\n"
                    + "  \"author\": \"kamu\",\n"
                    + "  \"description\": \"Gift Lion = 3 TNT + 1 meteor, share = 1 petir. Hapus baris example agar aktif.\",\n"
                    + "  \"example\": true,\n"
                    + "  \"gifts\": [\n"
                    + "    { \"name\": \"Lion\", \"label\": \"BADAI\",\n"
                    + "      \"actions\": [ {\"effect\": \"TNT\", \"amount\": 3}, {\"effect\": \"METEOR\", \"amount\": 1} ] }\n"
                    + "  ],\n"
                    + "  \"events\": {\n"
                    + "    \"share\": [ {\"effect\": \"PETIR\", \"amount\": 1} ]\n"
                    + "  }\n"
                    + "}\n");
            write(new File(d, "README.txt"),
                    "MOD BLOCK RUSH\n"
                    + "==============\n"
                    + "Satu folder di dalam 'mods' = satu mod. Aktifkan / matikan di menu MOD.\n\n"
                    + "1) GANTI TEXTURE / SUARA\n"
                    + "   Taruh file dengan nama & lokasi yang sama dengan aset game di dalam folder mod ini:\n"
                    + "     ui/fx_tnt.png  fx_tornado.png  fx_robot.png  fx_monster.png  fx_lightning.png ...  (ikon efek)\n"
                    + "     ui/control_*.png, ui/hud_*.png, ui/ic_*.png        (tombol, HUD, ikon menu)\n"
                    + "     blocks/block_00.png ... block_NN.png               (tekstur blok)\n"
                    + "     fx/robot_0..2.png  tornado_0..2.png  monster_0..2.png  tnt_0..6.png  boom_0..7.png\n"
                    + "     gift/g<nomor>.png                                  (gambar gift bawaan)\n"
                    + "     menu/background.jpg                                (latar menu)\n"
                    + "     sounds/sfx_*.wav   music/bgm.wav                   (suara & musik)\n"
                    + "   Contoh: mods/mod_saya/ui/fx_tnt.png mengganti gambar TNT.\n\n"
                    + "2) TAMBAH GIFT / EVENT (mod.json)\n"
                    + "   \"gifts\":  gift baru + daftar aksi. effect: BLOK, TNT, HUJAN TNT, KOSONG, NYAWA, PERISAI,\n"
                    + "              PETIR, TORNADO, ROBOT, METEOR, MONSTER. amount = jumlah.\n"
                    + "              \"icon\": \"gift/lion.png\" (opsional, relatif ke folder mod), \"label\": teks di bawah ikon.\n"
                    + "   \"events\": aksi tambahan saat follow / share / join / like / chat / subscribe.\n"
                    + "   Gift yang sudah kamu atur sendiri di menu HADIAH tetap diutamakan.\n\n"
                    + "Setelah mengubah file, buka menu MOD lalu tekan MUAT ULANG.\n");
        } catch (Throwable ignored) { }
    }

    private static void write(File f, String text) throws Exception {
        FileOutputStream out = new FileOutputStream(f);
        out.write(text.getBytes("UTF-8"));
        out.close();
    }
}
