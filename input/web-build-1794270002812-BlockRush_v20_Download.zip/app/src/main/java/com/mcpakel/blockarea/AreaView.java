package com.mcpakel.blockarea;

import android.app.Activity;
import android.content.Context;
import android.content.SharedPreferences;
import android.content.res.Configuration;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Rect;
import android.graphics.RectF;
import android.graphics.Typeface;
import android.util.SparseArray;
import android.view.MotionEvent;
import android.view.InputDevice;
import android.view.KeyEvent;
import android.view.View;

import java.io.IOException;

public class AreaView extends View {
    private static final float WORLD_W = 512f;
    private static final float BOARD_H = 1935f;
    private static final float MAX_CONTROL_H = 384f;
    private static final float MIN_CONTROL_H = 140f;
    private static final int COLS = 10, ROWS = 40, BLOCK_TYPES = 48;
    private static final int BUILD_LIMIT_ROW = 0;
        private static final float GRID_X = 41f, GRID_Y = 132f, CELL = 43f;
    private static final float PLAYER_H = CELL * 2f;
    private static final float PLAYER_HALF_W = CELL * 0.32f;
    private static final float GRAVITY = 1850f, JUMP_SPEED = 720f;
    private static final float HUD_HEIGHT = 94f;
    private static final float PLAYER_SCREEN_RATIO = 0.72f;

    private static final int ROLE_NONE=0, ROLE_LEFT=1, ROLE_RIGHT=2, ROLE_JUMP=3,
            ROLE_RUN=4, ROLE_PICK=5, ROLE_BUILD=6, ROLE_GRID=7, ROLE_PAUSE=8;
    private static final int SCREEN_MENU=0, SCREEN_GAME=1, SCREEN_PAUSE=2, SCREEN_SETTINGS=3;

    private static final class TouchPoint {
        int role;
        float x,y;
        TouchPoint(int role,float x,float y){this.role=role;this.x=x;this.y=y;}
    }

    private final Paint paint = new Paint();
    private final int[][] blocks = new int[ROWS][COLS];
    private final long[][] blockPlacedAt = new long[ROWS][COLS];
    private final RectF[] menuHits = new RectF[4];
    private final RectF[] pauseHits = new RectF[4];
    private final RectF[] settingsHits = new RectF[4];
    private final Bitmap[] blockTextures = new Bitmap[BLOCK_TYPES];
    private final Bitmap[][] characterFrames = new Bitmap[3][5];
    private final SparseArray<TouchPoint> touches = new SparseArray<>();

    private Bitmap arena, hud, hudBlockIcon, hudTrophyFrame, hudHotbarFrame, fontAtlas, placementFrame;
    private Bitmap menuBackground, menuMainButton, menuPauseButton, menuSettingsButton, menuExitButton;
    private Bitmap pauseButton, continueButton, retryButton, menuButton, exitButton;
    private Bitmap soundOnButton, soundOffButton, musicButton, backButton;
    private Bitmap leftImage,rightImage,runImage,pickImage,blockImage,jumpImage;

    // Visible control images and larger touch hitboxes.
    private final RectF[] hit = new RectF[6];
    private final RectF[] icon = new RectF[6];

    private float playerX, playerFeet, velocityY;
    private float cameraY, cameraTarget;
    private final float spawnFeet=GRID_Y+ROWS*CELL;
    private float animationClock;
    private long lastFrameNanos;
    private boolean grounded=true, sprint=false, facingRight=true;
    private boolean leftHeld=false,rightHeld=false,jumpHeld=false,jumpRequested=false;
    private boolean buildMode=false,breakMode=false;
    private boolean buildAimActive=false, buildAimMoved=false;
    private float buildAimStartX, buildAimStartY;
    private int controlMode=0; // 0=automatic, 1=touch, 2=keyboard/mouse only
    private boolean keyboardLeft=false, keyboardRight=false, keyboardJump=false;
    private boolean mouseAimActive=false;
    private int walkFrame=0,runFrame=0,jumpFrame=0;
    private int targetCol=-1,targetRow=-1,previewBlock=0;
    private int maxStackReached=0,brokenCount=0,totalPlaced=0;
    private int screen=SCREEN_MENU;
    private boolean soundEnabled=true, musicEnabled=true;
    private long playerPlaceUntilNanos=0L;
    private float pressCenterX=-1000f,pressCenterY=-1000f;
    private long pressUntilNanos=0L;

    // A newly placed block falls from the top of the arena to the green preview cell.
    private boolean fallingBlockActive=false, fallingLiftPlayer=false;
    private int fallingCol=-1, fallingRow=-1, fallingType=0;
    private float fallingY, fallingStartY, fallingEndY, fallingElapsed, fallingDuration;
    private int countdownValue=-1, winCount=0;
    private long countdownNextNanos=0L;

    public AreaView(Context context) {
        super(context);
        setLayerType(View.LAYER_TYPE_SOFTWARE,null);
        arena=load("area/arena_reference.png");
        hud=load("ui/hud_frame_source.png");
        if(hud!=null){
            // The supplied sheet is separated into transparent frame pieces.
            hudBlockIcon=Bitmap.createBitmap(hud,22,35,220,220);
            hudTrophyFrame=Bitmap.createBitmap(hud,340,0,1375,270);
            hudHotbarFrame=Bitmap.createBitmap(hud,42,285,1950,185);
        }
        SharedPreferences prefs=context.getSharedPreferences("blockrush_settings",Context.MODE_PRIVATE);
        controlMode=prefs.getInt("control_mode",0);
        fontAtlas=load("font/pixel_font.png");
        placementFrame=load("blocks/placement_frame.png");
        leftImage=load("ui/control_left.png");
        rightImage=load("ui/control_right.png");
        runImage=load("ui/control_run.png");
        pickImage=load("ui/control_pickaxe.png");
        blockImage=load("ui/control_block.png");
        jumpImage=load("ui/control_jump.png");
        menuBackground=load("menu/background.jpg");
        menuMainButton=load("menu/menu_main.png");
        menuPauseButton=load("menu/menu_pause.png");
        menuSettingsButton=load("menu/menu_settings.png");
        menuExitButton=load("menu/button_exit.png");
        pauseButton=load("menu/icon_pause.png");
        continueButton=load("menu/button_continue.png");
        retryButton=load("menu/button_retry.png");
        menuButton=load("menu/button_menu.png");
        exitButton=load("menu/button_exit.png");
        soundOnButton=load("menu/icon_volume.png");
        soundOffButton=load("menu/icon_mute.png");
        musicButton=load("menu/icon_music.png");
        backButton=load("menu/button_back.png");

        for(int i=0;i<menuHits.length;i++)menuHits[i]=new RectF();
        for(int i=0;i<pauseHits.length;i++)pauseHits[i]=new RectF();
        for(int i=0;i<settingsHits.length;i++)settingsHits[i]=new RectF();

        for(int i=0;i<BLOCK_TYPES;i++){
            blockTextures[i]=load(String.format(java.util.Locale.US,"blocks/block_%02d.png",i));
        }
        String[] actions={"walk","run","jump"};
        for(int a=0;a<3;a++){
            for(int f=0;f<5;f++){
                characterFrames[a][f]=load("character/"+actions[a]+"_"+f+".png");
            }
        }
        for(int r=0;r<ROWS;r++) for(int c=0;c<COLS;c++) blocks[r][c]=-1;

        playerX=GRID_X+(COLS*CELL)/2f;
        playerFeet=GRID_Y+ROWS*CELL;
        for(int i=0;i<6;i++){hit[i]=new RectF();icon[i]=new RectF();}
        paint.setFilterBitmap(false);
        paint.setAntiAlias(false);
        setFocusable(true);
        setFocusableInTouchMode(true);
        setClickable(true);
        requestFocus();
    }

    private Bitmap load(String path){
        try{return BitmapFactory.decodeStream(getContext().getAssets().open(path));}
        catch(IOException e){return null;}
    }

    private float scale(){return getWidth()/WORLD_W;}
    private float logicalHeight(){return getHeight()/Math.max(0.001f,scale());}
    private float controlHeight(){return Math.min(MAX_CONTROL_H,Math.max(MIN_CONTROL_H,logicalHeight()-BOARD_H));}
    private float controlTop(){return logicalHeight()-controlHeight();}
    private float areaTop(){return Math.min(HUD_HEIGHT+52f,Math.max(0f,controlTop()-360f));}
    private float boardViewportHeight(){return Math.max(360f,controlTop()-areaTop());}
    private float worldToScreenY(float y){return areaTop()+y-cameraY;}
    private int clamp(int value,int min,int max){return Math.max(min,Math.min(max,value));}
    private int playerColumn(){return clamp((int)((playerX-GRID_X)/CELL),0,COLS-1);}

    private int topBlockRow(int col){
        for(int r=BUILD_LIMIT_ROW;r<ROWS;r++) if(blocks[r][col]>=0)return r;
        return ROWS;
    }
    private float supportY(int col){return GRID_Y+topBlockRow(col)*CELL;}
    // Count only the continuous stack connected to the arena floor.
    private int stackHeight(int col){
        int n=0;
        for(int row=ROWS-1;row>=BUILD_LIMIT_ROW;row--){
            if(blocks[row][col]<0)break;
            n++;
        }
        return n;
    }
    private int maxStack(){
        int m=0;for(int c=0;c<COLS;c++)m=Math.max(m,stackHeight(c));
        return m;
    }
    private int blockCount(){
        int n=0;for(int[] row:blocks)for(int v:row)if(v>=0)n++;
        return n;
    }
    // One completed horizontal layer contains all ten cells in a row.
    private int completedRows(){
        int full=0;
        for(int row=0;row<ROWS;row++){
            int count=0;
            for(int col=0;col<COLS;col++)if(blocks[row][col]>=0)count++;
            if(count==COLS)full++;
        }
        return full;
    }
    // Percentage is based on all 400 playable cells.
    private int areaPercent(){
        return Math.min(100,Math.round(blockCount()*100f/(COLS*ROWS)));
    }
    // Five vertical layers use one fixed material before advancing to the next.
    private int materialForRow(int row){
        int layerFromFloor=(ROWS-1)-row;
        return (layerFromFloor / 3) % BLOCK_TYPES;
    }

    private void layoutControls(){
        // Six larger touch targets with safe margins; the visible art and hitboxes match.
        float size=78f;
        float y=controlTop()+(controlHeight()-size)/2f;
        float[] xs={10f,91f,172f,253f,334f,415f};
        for(int i=0;i<6;i++){
            hit[i].set(xs[i]-2f,y-5f,xs[i]+size+2f,y+size+5f);
            icon[i].set(xs[i],y,xs[i]+size,y+size);
        }
    }

    private boolean hardwareInputConnected(){
        if(getResources().getConfiguration().keyboard==Configuration.KEYBOARD_QWERTY)return true;
        for(int id:InputDevice.getDeviceIds()){
            InputDevice d=InputDevice.getDevice(id);
            if(d==null||d.isVirtual())continue;
            int src=d.getSources();
            if((src&InputDevice.SOURCE_KEYBOARD)==InputDevice.SOURCE_KEYBOARD
                    ||(src&InputDevice.SOURCE_MOUSE)==InputDevice.SOURCE_MOUSE)return true;
        }
        return false;
    }

    private boolean useHardwareControls(){
        return controlMode==2||(controlMode==0&&hardwareInputConnected());
    }

    private String controlModeLabel(){
        if(controlMode==1)return "TOUCH";
        if(controlMode==2)return "KEYBOARD / MOUSE";
        return "AUTO";
    }

    private void drawBitmap(Canvas canvas,Bitmap bitmap,RectF dst){
        if(bitmap==null)return;
        paint.setAlpha(255);paint.setFilterBitmap(false);paint.clearShadowLayer();
        canvas.drawBitmap(bitmap,null,dst,paint);
    }

    private void drawBottomSoilBackdrop(Canvas canvas){
        if(arena==null)return;
        float initialCamera=Math.max(1f,spawnFeet-boardViewportHeight()*PLAYER_SCREEN_RATIO);
        float alphaFactor=clampFloat(cameraY/initialCamera,0f,1f);
        if(alphaFactor<=0f)return;
        int srcTop=Math.max(0,arena.getHeight()-112);
        Rect src=new Rect(0,srcTop,arena.getWidth(),arena.getHeight());
        float arenaBottom=areaTop()+BOARD_H-cameraY;
        float backdropTop=Math.min(controlTop(),arenaBottom);
        RectF dst=new RectF(0f,backdropTop,WORLD_W,logicalHeight());
        paint.setAlpha((int)(205f*alphaFactor));
        paint.setFilterBitmap(false);
        canvas.drawBitmap(arena,src,dst,paint);
        paint.setAlpha(255);
    }

    @Override protected void onAttachedToWindow(){
        super.onAttachedToWindow();
        requestFocus();
    }

    @Override protected void onDraw(Canvas canvas){
        super.onDraw(canvas);
        if(getWidth()<=0)return;
        float sc=scale();
        canvas.save();
        canvas.scale(sc,sc);

        if(screen==SCREEN_MENU){
            drawMenuScreen(canvas);
            canvas.restore();
            postInvalidateDelayed(16);
            return;
        }
        if(screen==SCREEN_SETTINGS){
            drawSettingsScreen(canvas);
            canvas.restore();
            postInvalidateDelayed(16);
            return;
        }

        layoutControls();
        if(lastFrameNanos==0){
            float minCamera=-PLAYER_H*1.2f;
            cameraY=clampFloat(spawnFeet-boardViewportHeight()*PLAYER_SCREEN_RATIO,
                    minCamera,Math.max(minCamera,BOARD_H-boardViewportHeight()));
        }

        canvas.drawColor(0xff38a6fd);

        // Keep the same moving world background visible underneath the bottom
        // control row. The control area itself has no opaque blue panel.
        if(arena!=null){
            float arenaTop=areaTop()-cameraY;
            // Keep the arena at a fixed world scale. Stretching it to the screen bottom
            // made the grid drift away from the block coordinates as the camera moved.
            float arenaBottom=arenaTop+BOARD_H;
            drawBitmap(canvas,arena,new RectF(0,arenaTop,WORLD_W,arenaBottom));
            drawBottomSoilBackdrop(canvas);
        }

        // Only the interactive world objects are clipped to the play viewport.
        canvas.save();
        canvas.clipRect(0,areaTop(),WORLD_W,controlTop());
        if(arena==null){
            paint.setColor(0xff20232a);
            canvas.drawRect(0,areaTop(),WORLD_W,controlTop(),paint);
        }
        drawPlacedBlocks(canvas);
        drawFallingBlock(canvas);
        drawPlacementTarget(canvas);
        drawPlayer(canvas);
        canvas.restore();

        drawHud(canvas);
        drawPauseControl(canvas);
        drawControls(canvas);
        if(countdownValue>=0)drawRoundCountdown(canvas);

        if(screen==SCREEN_PAUSE)drawPauseScreen(canvas);

        canvas.restore();

        if(screen==SCREEN_GAME){
            updatePhysics();
        }
        postInvalidateDelayed(16);
    }


    private void drawMenuTitle(Canvas canvas,String text,float centerX,float y,float size){
        paint.setTypeface(Typeface.create("sans-serif-black",Typeface.BOLD));
        paint.setTextAlign(Paint.Align.CENTER);
        paint.setTextSize(size);
        paint.setStrokeWidth(6f);
        paint.setStyle(Paint.Style.STROKE);
        paint.setColor(0xff111318);
        canvas.drawText(text,centerX,y,paint);
        paint.setStyle(Paint.Style.FILL);
        paint.setColor(0xffffffff);
        canvas.drawText(text,centerX,y,paint);
        paint.setStyle(Paint.Style.FILL);
    }

    private void drawMenuScreen(Canvas canvas){
        float h=logicalHeight();
        if(menuBackground!=null){
            float bgW=h*menuBackground.getWidth()/Math.max(1f,menuBackground.getHeight());
            float left=(WORLD_W-bgW)*0.5f;
            drawBitmapMenu(canvas,menuBackground,new RectF(left,0,left+bgW,h));
        }

        float mainW=370f,mainH=mainW*246f/529f;
        float settingsW=380f,settingsH=settingsW*241f/654f;
        float exitW=330f,exitH=exitW*145f/430f;
        float gap=12f;
        float total=mainH+settingsH+exitH+gap*2f;
        float top=(h-total)*0.5f+54f;
        float titleY=Math.max(105f,top-45f);
        drawMenuTitle(canvas,"BLOCK RUSH",WORLD_W*0.5f,titleY,38f);

        RectF r0=new RectF((WORLD_W-mainW)/2f,top,(WORLD_W+mainW)/2f,top+mainH);
        RectF r1=new RectF((WORLD_W-settingsW)/2f,r0.bottom+gap,
                (WORLD_W+settingsW)/2f,r0.bottom+gap+settingsH);
        RectF r2=new RectF((WORLD_W-exitW)/2f,r1.bottom+gap,
                (WORLD_W+exitW)/2f,r1.bottom+gap+exitH);
        menuHits[0].set(r0);menuHits[1].set(r1);menuHits[2].set(r2);
        drawBitmapMenu(canvas,menuMainButton,r0);
        drawBitmapMenu(canvas,menuSettingsButton,r1);
        drawBitmapMenu(canvas,menuExitButton,r2);
    }

    private void drawBitmapMenu(Canvas canvas,Bitmap bitmap,RectF dst){
        if(bitmap==null)return;
        paint.setAlpha(255);
        paint.setFilterBitmap(true);
        paint.clearShadowLayer();
        float cx=(dst.left+dst.right)*0.5f,cy=(dst.top+dst.bottom)*0.5f;
        boolean pressed=System.nanoTime()<pressUntilNanos
                &&pressCenterX>=dst.left&&pressCenterX<=dst.right
                &&pressCenterY>=dst.top&&pressCenterY<=dst.bottom;
        if(pressed){
            float scale=0.94f;
            float w=dst.width()*scale,h=dst.height()*scale;
            RectF animated=new RectF(cx-w/2f,cy-h/2f,cx+w/2f,cy+h/2f);
            canvas.drawBitmap(bitmap,null,animated,paint);
        }else{
            canvas.drawBitmap(bitmap,null,dst,paint);
        }
        paint.setFilterBitmap(false);
    }

    private void drawSettingsScreen(Canvas canvas){
        float h=logicalHeight();
        if(menuBackground!=null){
            float bgW=h*menuBackground.getWidth()/Math.max(1f,menuBackground.getHeight());
            float left=(WORLD_W-bgW)*0.5f;
            drawBitmapMenu(canvas,menuBackground,new RectF(left,0,left+bgW,h));
        }
        float titleW=390f,titleH=titleW*241f/654f;
        drawBitmapMenu(canvas,menuSettingsButton,new RectF((WORLD_W-titleW)/2f,h*0.17f,
                (WORLD_W+titleW)/2f,h*0.17f+titleH));

        float iconSize=88f,iconY=h*0.39f;
        RectF soundRect=new RectF(105f,iconY,105f+iconSize,iconY+iconSize);
        RectF musicRect=new RectF(303f,iconY,303f+iconSize,iconY+iconSize);
        settingsHits[0].set(soundRect);settingsHits[1].set(musicRect);
        drawBitmapMenu(canvas,soundEnabled?soundOnButton:soundOffButton,soundRect);
        drawBitmapMenu(canvas,musicButton,musicRect);
        drawMenuTitle(canvas,"SUARA: "+(soundEnabled?"ON":"OFF"),149f,iconY+iconSize+34f,16f);
        drawMenuTitle(canvas,"MUSIK: "+(musicEnabled?"ON":"OFF"),347f,iconY+iconSize+34f,16f);

        float modeW=350f,modeH=modeW*145f/430f,modeY=h*0.64f;
        RectF modeRect=new RectF((WORLD_W-modeW)/2f,modeY,(WORLD_W+modeW)/2f,modeY+modeH);
        settingsHits[2].set(modeRect);
        paint.setColor(0xff171a22);
        paint.setStyle(Paint.Style.FILL);
        canvas.drawRoundRect(modeRect,16f,16f,paint);
        paint.setColor(0xffffc928);
        paint.setStyle(Paint.Style.STROKE);
        paint.setStrokeWidth(4f);
        canvas.drawRoundRect(modeRect,16f,16f,paint);
        paint.setStyle(Paint.Style.FILL);
        drawMenuTitle(canvas,"KONTROL: "+controlModeLabel(),WORLD_W*0.5f,modeY+modeH*0.61f,17f);

        float backW=300f,backH=backW*152f/608f,backY=h*0.82f;
        RectF backRect=new RectF((WORLD_W-backW)/2f,backY,(WORLD_W+backW)/2f,backY+backH);
        settingsHits[3].set(backRect);
        drawBitmapMenu(canvas,backButton,backRect);
    }

    private void drawPauseControl(Canvas canvas){
        RectF pauseRect=new RectF(234f,98f,278f,142f);
        drawBitmapMenu(canvas,pauseButton,pauseRect);
    }

    private void drawPauseScreen(Canvas canvas){
        float h=logicalHeight();
        paint.setStyle(Paint.Style.FILL);
        paint.setColor(0xb9000000);
        canvas.drawRect(0,0,WORLD_W,h,paint);

        float titleW=280f,titleH=titleW*241f/513f;
        float titleY=Math.max(80f,(h-590f)/2f-95f);
        RectF titleRect=new RectF((WORLD_W-titleW)/2f,titleY,
                (WORLD_W+titleW)/2f,titleY+titleH);
        drawBitmapMenu(canvas,menuPauseButton,titleRect);

        Bitmap[] images={continueButton,retryButton,menuButton,exitButton};
        float[] widths={340f,330f,340f,340f};
        float[] ratios={431f/144f,402f/145f,419f/144f,430f/145f};
        float gap=10f;
        float total=0f;
        for(int i=0;i<4;i++)total+=widths[i]/ratios[i];
        total+=gap*3f;
        float y=(h-total)*0.5f+85f;
        for(int i=0;i<4;i++){
            float w=widths[i],hh=w/ratios[i];
            RectF r=new RectF((WORLD_W-w)/2f,y,(WORLD_W+w)/2f,y+hh);
            pauseHits[i].set(r);
            drawBitmapMenu(canvas,images[i],r);
            y+=hh+gap;
        }
    }

    private void resetGame(){
        for(int r=0;r<ROWS;r++){
            for(int c=0;c<COLS;c++){
                blocks[r][c]=-1;
                blockPlacedAt[r][c]=0L;
            }
        }
        playerX=GRID_X+(COLS*CELL)/2f;
        playerFeet=GRID_Y+ROWS*CELL;
        velocityY=0f;
        cameraY=0f;cameraTarget=0f;
        grounded=true;
        facingRight=true;
        totalPlaced=0;brokenCount=0;maxStackReached=0;
        targetCol=-1;targetRow=-1;
        fallingBlockActive=false;fallingLiftPlayer=false;buildAimActive=false;buildAimMoved=false;
        countdownValue=-1;countdownNextNanos=0L;winCount=0;
        lastFrameNanos=0L;
    }

    private void handleScreenTap(float x,float y){
        if(screen==SCREEN_MENU){
            if(menuHits[0].contains(x,y)){
                resetGame();
                screen=SCREEN_GAME;
            }else if(menuHits[1].contains(x,y)){
                screen=SCREEN_SETTINGS;
            }else if(menuHits[2].contains(x,y)){
                if(getContext() instanceof Activity)((Activity)getContext()).finish();
            }
        }else if(screen==SCREEN_SETTINGS){
            if(settingsHits[0].contains(x,y)){
                soundEnabled=!soundEnabled;
            }else if(settingsHits[1].contains(x,y)){
                musicEnabled=!musicEnabled;
            }else if(settingsHits[2].contains(x,y)){
                controlMode=(controlMode+1)%3;
                getContext().getSharedPreferences("blockrush_settings",Context.MODE_PRIVATE)
                        .edit().putInt("control_mode",controlMode).apply();
            }else if(settingsHits[3].contains(x,y)){
                screen=SCREEN_MENU;
            }
        }else if(screen==SCREEN_PAUSE){
            if(pauseHits[0].contains(x,y)){
                screen=SCREEN_GAME;
                lastFrameNanos=System.nanoTime();
            }else if(pauseHits[1].contains(x,y)){
                resetGame();
                screen=SCREEN_GAME;
            }else if(pauseHits[2].contains(x,y)){
                screen=SCREEN_MENU;
                lastFrameNanos=0L;
            }else if(pauseHits[3].contains(x,y)){
                if(getContext() instanceof Activity)((Activity)getContext()).finish();
            }
        }
    }

    private void drawPlacedBlocks(Canvas canvas){
        for(int row=BUILD_LIMIT_ROW;row<ROWS;row++){
            float y=worldToScreenY(GRID_Y+row*CELL);
            if(y>controlTop()||y+CELL<areaTop())continue;
            for(int col=0;col<COLS;col++){
                if(blocks[row][col]<0)continue;
                int type=blocks[row][col];
                float x=GRID_X+col*CELL;
                drawBitmap(canvas,blockTextures[type],new RectF(x,y,x+CELL,y+CELL));
            }
        }
    }

    private void drawPlacementTarget(Canvas canvas){
        int col=(breakMode||mouseAimActive||buildAimActive&&buildAimMoved)?targetCol:playerColumn();
        int row=(breakMode||mouseAimActive||buildAimActive&&buildAimMoved)?targetRow:topBlockRow(col)-1;
        if(col<0||col>=COLS||row<BUILD_LIMIT_ROW||row>=ROWS||fallingBlockActive)return;
        float x=GRID_X+col*CELL;
        float y=worldToScreenY(GRID_Y+row*CELL);
        RectF cell=new RectF(x+1.5f,y+1.5f,x+CELL-1.5f,y+CELL-1.5f);
        if(!breakMode&&blockTextures[materialForRow(row)]!=null){
            paint.setAlpha(100);
            canvas.drawBitmap(blockTextures[materialForRow(row)],null,cell,paint);
            paint.setAlpha(255);
        }
        if(placementFrame!=null)drawBitmap(canvas,placementFrame,cell);
        paint.setStyle(Paint.Style.STROKE);
        paint.setStrokeWidth(3f);
        paint.setColor(breakMode?0xffff5555:0xff42ef69);
        canvas.drawRect(cell,paint);
        paint.setStyle(Paint.Style.FILL);
    }

    private void drawFallingBlock(Canvas canvas){
        if(!fallingBlockActive||fallingType<0||fallingType>=BLOCK_TYPES)return;
        float y=worldToScreenY(fallingY);
        float x=GRID_X+fallingCol*CELL;
        drawBitmap(canvas,blockTextures[fallingType],new RectF(x,y,x+CELL,y+CELL));
    }

    private void drawPlayer(Canvas canvas){
        int action=!grounded?2:((leftHeld||rightHeld)?(sprint?1:0):0);
        int frame=action==2?jumpFrame:(action==1?runFrame:walkFrame);
        Bitmap sprite=characterFrames[action][frame];
        if(sprite==null)return;
        float h=PLAYER_H,w=h*sprite.getWidth()/Math.max(1f,sprite.getHeight());
        float feet=worldToScreenY(playerFeet);
        RectF dst=new RectF(playerX-w/2,feet-h,playerX+w/2,feet);
        long now=System.nanoTime();
        boolean placing=now<playerPlaceUntilNanos;
        if(placing){
            float t=(playerPlaceUntilNanos-now)/220000000f;
            float pulse=(float)Math.sin((1f-t)*Math.PI);
            dst.offset(facingRight?pulse*5f:-pulse*5f,-pulse*3f);
        }
        canvas.save();
        if(placing)canvas.rotate(facingRight?-7f:7f,playerX,feet-h*0.48f);
        if(!facingRight)canvas.scale(-1,1,playerX,0);
        drawBitmap(canvas,sprite,dst);
        if(placing){
            float pulse=(float)Math.sin((playerPlaceUntilNanos-now)/220000000f*Math.PI);
            float handX=playerX+(facingRight?1f:-1f)*(w*0.22f+pulse*8f);
            float handY=feet-h*0.42f+pulse*4f;
            paint.setColor(0xffffd2a0);
            canvas.drawCircle(handX,handY,4.5f,paint);
        }
        canvas.restore();
    }

    private void drawHud(Canvas canvas){
        // Use the user's supplied transparent Minecraft-style frame sheet.
        if(hudBlockIcon!=null)drawBitmap(canvas,hudBlockIcon,new RectF(2f,0f,57f,57f));
        if(hudTrophyFrame!=null)drawBitmap(canvas,hudTrophyFrame,new RectF(118f,0f,398f,57f));
        if(hudHotbarFrame!=null)drawBitmap(canvas,hudHotbarFrame,new RectF(5f,57f,507f,96f));

        drawAtlasText(canvas,completedRows()+"/40",94f,29f,25f);
        drawAtlasText(canvas,winCount+"/10",258f,30f,23f);
        drawAtlasText(canvas,areaPercent()+"%",463f,29f,24f);

        // Fill only the cells inside the supplied segmented bar frame.
        final int segments=13;
        float innerX=20f,innerY=68f,innerW=472f,innerH=18f;
        float filled=(areaPercent()/100f)*segments;
        paint.setStyle(Paint.Style.FILL);
        for(int i=0;i<segments;i++){
            float part=Math.max(0f,Math.min(1f,filled-i));
            if(part<=0f)continue;
            float cellW=innerW/segments;
            float left=innerX+i*cellW+2f;
            float right=innerX+i*cellW+cellW*part-2f;
            if(right>left){
                paint.setColor(0xff39e64f);
                canvas.drawRoundRect(new RectF(left,innerY,right,innerY+innerH),3f,3f,paint);
            }
        }
    }

    private void drawRoundCountdown(Canvas canvas){
        float cx=WORLD_W*0.5f;
        float cy=areaTop()+boardViewportHeight()*0.46f;
        paint.setStyle(Paint.Style.FILL);
        paint.setColor(0xb9000000);
        canvas.drawRoundRect(new RectF(cx-88f,cy-70f,cx+88f,cy+70f),18f,18f,paint);
        paint.setStyle(Paint.Style.STROKE);
        paint.setStrokeWidth(4f);
        paint.setColor(0xffffc928);
        canvas.drawRoundRect(new RectF(cx-88f,cy-70f,cx+88f,cy+70f),18f,18f,paint);
        paint.setStyle(Paint.Style.FILL);
        drawAtlasText(canvas,String.valueOf(countdownValue),cx,cy,76f);
    }

    private Rect fontSource(char ch){
        switch(ch){
            case '0': return new Rect(254,529,369,649);
            case '1': return new Rect(395,529,484,649);
            case '2': return new Rect(499,529,613,649);
            case '3': return new Rect(627,529,739,649);
            case '4': return new Rect(751,529,872,649);
            case '5': return new Rect(890,529,1005,649);
            case '6': return new Rect(1022,529,1139,649);
            case '7': return new Rect(1155,529,1266,649);
            case '8': return new Rect(1285,529,1399,649);
            case '9': return new Rect(1416,529,1533,649);
            case '/': return new Rect(1432,655,1520,765);
            case '%': return new Rect(643,763,758,873);
            default: return null;
        }
    }

    private void drawAtlasText(Canvas canvas,String text,float centerX,float centerY,float targetHeight){
        if(fontAtlas==null||text==null||text.length()==0)return;
        float total=0f;
        for(int i=0;i<text.length();i++){
            Rect r=fontSource(text.charAt(i));
            if(r!=null)total+=targetHeight*(r.width()/(float)r.height())+2f;
        }
        if(total>0f)total-=2f;
        float x=centerX-total/2f;
        for(int i=0;i<text.length();i++){
            Rect src=fontSource(text.charAt(i));
            if(src==null)continue;
            float w=targetHeight*src.width()/(float)src.height();
            RectF dst=new RectF(x,centerY-targetHeight/2f,x+w,centerY+targetHeight/2f);
            paint.setAlpha(255);
            paint.setFilterBitmap(false);
            canvas.drawBitmap(fontAtlas,src,dst,paint);
            x+=w+2f;
        }
    }

    private void drawControls(Canvas canvas){
        if(useHardwareControls())return;
        Bitmap[] images={leftImage,rightImage,runImage,pickImage,blockImage,jumpImage};
        final int[] roles={ROLE_LEFT,ROLE_RIGHT,ROLE_RUN,ROLE_PICK,ROLE_BUILD,ROLE_JUMP};
        for(int i=0;i<6;i++){
            boolean held=false;
            for(int p=0;p<touches.size();p++)if(touches.valueAt(p).role==roles[i]){held=true;break;}
            boolean active=(i==2&&sprint)||(i==3&&breakMode)||(i==4&&buildAimActive);
            if(active){
                paint.setColor(i==3?0x5537cfff:0x55ffc928);
                paint.setShadowLayer(8,0,0,i==3?0xff37cfff:0xffffc928);
                canvas.drawRoundRect(icon[i],18,18,paint);
                paint.clearShadowLayer();
            }
            RectF dst=new RectF(icon[i]);
            if(held){float cx=dst.centerX(),cy=dst.centerY();dst.inset(4f,4f);dst.offset(cx-dst.centerX(),cy-dst.centerY());}
            drawBitmap(canvas,images[i],dst);
        }
    }

    private boolean withinRange(int col,int row){
        float playerRow=(playerFeet-GRID_Y)/CELL;
        float dx=col-playerColumn(),dy=row-playerRow;
        return Math.sqrt(dx*dx+dy*dy)<=10.0;
    }

    private boolean supportedCell(int row,int col){
        // No floating blocks: every placed block must sit on the floor or directly on another block.
        return row==ROWS-1||blocks[row+1][col]>=0;
    }

    private boolean placeAtCell(int col,int row,boolean liftPlayer){
        if(col<0||col>=COLS||row<BUILD_LIMIT_ROW||row>=ROWS)return false;
        if(blocks[row][col]>=0||!withinRange(col,row))return false;

        // Simulate gravity for a newly placed block: it drops to the lowest
        // available cell in this column, then joins the stack from the bottom up.
        int landingRow=row;
        while(landingRow<ROWS-1&&blocks[landingRow+1][col]<0)landingRow++;
        if(blocks[landingRow][col]>=0||!supportedCell(landingRow,col))return false;
        row=landingRow;

        float top=GRID_Y+row*CELL;
        float bottom=top+CELL;
        int playerCol=playerColumn();
        boolean sameColumn=(col==playerCol);
        boolean underPlayer=sameColumn&&Math.abs(bottom-playerFeet)<CELL*0.35f;
        float playerTop=playerFeet-PLAYER_H;
        float tileLeft=GRID_X+col*CELL,tileRight=tileLeft+CELL;
        boolean horizontalOverlap=playerX+PLAYER_HALF_W>tileLeft+1f
                &&playerX-PLAYER_HALF_W<tileRight-1f;
        boolean overlapsPlayer=horizontalOverlap&&bottom>playerTop+1f&&top<playerFeet-1f;

        // Do not place a tile through the player's body. A tile directly under
        // the feet is allowed and raises the player onto the new stack layer.
        if(overlapsPlayer&&!underPlayer)return false;

        // If the block lands under the player, move the player up by one cell.
        if(underPlayer){
            float newFeet=top;
            float newTop=newFeet-PLAYER_H;
            if(intersectsBlocks(col,newTop,newFeet))return false;
            if(!liftPlayer)return false;
        }

        blocks[row][col]=materialForRow(row);
        blockPlacedAt[row][col]=0L;
        playerPlaceUntilNanos=System.nanoTime()+220000000L;
        totalPlaced++;
        maxStackReached=Math.max(maxStackReached,maxStack());

        if(underPlayer&&liftPlayer){
            playerFeet=top;
            velocityY=0f;
            grounded=true;
        }
        return true;
    }

    // The block button uses the green preview cell above the player's current column.
    // The tile visibly falls from above and settles on the existing stack/floor.
    private void placeUnderPlayer(){
        if(fallingBlockActive||countdownValue>=0)return;
        int col=playerColumn();
        int row=topBlockRow(col)-1;
        startFallingAt(col,row,true);
    }

    private void startFallingAt(int col,int requestedRow,boolean allowLift){
        if(fallingBlockActive||countdownValue>=0)return;
        if(col<0||col>=COLS||requestedRow<BUILD_LIMIT_ROW||requestedRow>=ROWS)return;
        if(blocks[requestedRow][col]>=0)return;
        if(!withinRange(col,requestedRow))return;

        // A block drops in its selected column until it reaches the first supported cell.
        int landingRow=requestedRow;
        while(landingRow<ROWS-1&&blocks[landingRow+1][col]<0)landingRow++;
        if(blocks[landingRow][col]>=0)return;

        float top=GRID_Y+landingRow*CELL;
        float bottom=top+CELL;
        float playerTop=playerFeet-PLAYER_H;
        float tileLeft=GRID_X+col*CELL,tileRight=tileLeft+CELL;
        boolean horizontalOverlap=playerX+PLAYER_HALF_W>tileLeft+1f&&playerX-PLAYER_HALF_W<tileRight-1f;
        boolean underPlayer=horizontalOverlap&&Math.abs(bottom-playerFeet)<CELL*0.32f;
        boolean overlapsPlayer=horizontalOverlap&&bottom>playerTop+1f&&top<playerFeet-1f;
        if(overlapsPlayer&&!underPlayer&&!allowLift)return;
        if(underPlayer&&!allowLift)return;

        fallingLiftPlayer=allowLift&&col==playerColumn();
        fallingCol=col;
        fallingRow=landingRow;
        fallingType=materialForRow(landingRow);
        fallingEndY=top;
        fallingStartY=Math.max(GRID_Y-CELL,fallingEndY-CELL*5f);
        fallingY=fallingStartY;
        fallingElapsed=0f;
        fallingDuration=Math.max(0.24f,Math.min(0.78f,0.24f+(fallingEndY-fallingStartY)/2200f));
        fallingBlockActive=true;
    }

    private void finishBuildAim(){
        if(!buildAimActive)return;
        boolean moved=buildAimMoved;
        int col=targetCol,row=targetRow;
        buildAimActive=false;buildAimMoved=false;
        if(moved&&col>=0&&row>=BUILD_LIMIT_ROW&&row<ROWS){
            boolean lift=col==playerColumn();
            startFallingAt(col,row,lift);
        }else{
            placeUnderPlayer();
        }
    }

    private void finishFallingBlock(){
        if(!fallingBlockActive)return;
        int col=fallingCol,row=fallingRow;
        if(col>=0&&col<COLS&&row>=BUILD_LIMIT_ROW&&row<ROWS&&blocks[row][col]<0){
            blocks[row][col]=fallingType;
            blockPlacedAt[row][col]=System.nanoTime();
            totalPlaced++;
            maxStackReached=Math.max(maxStackReached,maxStack());
            float supportY=GRID_Y+(row+1)*CELL;
            if(fallingLiftPlayer&&playerColumn()==col){
                // Direct placement under the avatar snaps the avatar onto the new block,
                // including when the placement button was tapped during a jump.
                playerFeet=GRID_Y+row*CELL;
                velocityY=0f;
                grounded=true;
            }
        }
        fallingBlockActive=false;
        fallingLiftPlayer=false;
        playerPlaceUntilNanos=System.nanoTime()+260000000L;
        if(blockCount()>=COLS*ROWS&&countdownValue<0){
            countdownValue=15;
            countdownNextNanos=System.nanoTime()+620000000L;
        }
    }

    private void resetBoardAfterWin(){
        for(int r=0;r<ROWS;r++)for(int c=0;c<COLS;c++){
            blocks[r][c]=-1;
            blockPlacedAt[r][c]=0L;
        }
        playerX=GRID_X+(COLS*CELL)/2f;
        playerFeet=GRID_Y+ROWS*CELL;
        velocityY=0f;
        grounded=true;
        cameraY=0f;cameraTarget=0f;
        facingRight=true;
        targetCol=-1;targetRow=-1;
        fallingBlockActive=false;
        lastFrameNanos=0L;
        buildAimActive=false;buildAimMoved=false;
    }

    private void breakBlock(){
        int col=targetCol,row=targetRow;
        if(col<0||row<BUILD_LIMIT_ROW||row>=ROWS)return;
        if(blocks[row][col]<0||!withinRange(col,row))return;
        blocks[row][col]=-1;
        blockPlacedAt[row][col]=0L;
        brokenCount++;
        maxStackReached=maxStack();

        // If the removed tile was the player's floor, release support and let gravity take over.
        if(grounded&&!hasSurfaceAtFeet(playerX,playerFeet)){
            grounded=false;
            velocityY=0f;
        }
    }

    private boolean intersectsBlocks(int col,float top,float feet){
        for(int row=BUILD_LIMIT_ROW;row<ROWS;row++){
            if(blocks[row][col]<0)continue;
            float blockTop=GRID_Y+row*CELL;
            float blockBottom=blockTop+CELL;
            if(feet>blockTop+1f&&top<blockBottom-1f)return true;
        }
        return false;
    }

    private boolean hasSurfaceAtFeet(float x,float feet){
        float floor=GRID_Y+ROWS*CELL;
        if(Math.abs(feet-floor)<2f)return true;

        int col=(int)((x-GRID_X)/CELL);
        if(col<0||col>=COLS)return false;
        for(int row=BUILD_LIMIT_ROW;row<ROWS;row++){
            if(blocks[row][col]<0)continue;
            float top=GRID_Y+row*CELL;
            if(Math.abs(feet-top)<2f)return true;
        }
        return false;
    }

    private float landingSurface(float x,float oldFeet,float newFeet){
        float best=Float.POSITIVE_INFINITY;
        float floor=GRID_Y+ROWS*CELL;
        if(oldFeet<=floor&&newFeet>=floor)best=floor;

        // Only the center of the feet can land on a block. Blocks beside a gap
        // must not act like an invisible bridge under the player's wide sprite.
        int col=(int)((x-GRID_X)/CELL);
        if(col<0||col>=COLS)return best;
        for(int row=BUILD_LIMIT_ROW;row<ROWS;row++){
            if(blocks[row][col]<0)continue;
            float top=GRID_Y+row*CELL;
            if(oldFeet<=top+1f&&newFeet>=top-1f&&top<best)best=top;
        }
        return best;
    }

    private float ceilingSurface(float x,float oldTop,float newTop){
        float best=Float.NEGATIVE_INFINITY;
        float half=PLAYER_HALF_W;
        float left=x-half,right=x+half;
        int first=clamp((int)((left-GRID_X)/CELL),0,COLS-1);
        int last=clamp((int)((right-GRID_X)/CELL),0,COLS-1);
        // On upward motion, collide with the underside only if the player's head crosses it.
        for(int col=first;col<=last;col++){
            for(int row=BUILD_LIMIT_ROW;row<ROWS;row++){
                if(blocks[row][col]<0)continue;
                float bottom=GRID_Y+(row+1)*CELL;
                if(oldTop>=bottom-1f&&newTop<=bottom+1f&&bottom>best)best=bottom;
            }
        }
        return best;
    }

    private boolean blockedAt(float x,float top,float feet){
        float half=PLAYER_HALF_W;
        float left=x-half,right=x+half;
        int first=clamp((int)((left-GRID_X)/CELL),0,COLS-1);
        int last=clamp((int)((right-GRID_X)/CELL),0,COLS-1);
        for(int col=first;col<=last;col++){
            for(int row=BUILD_LIMIT_ROW;row<ROWS;row++){
                if(blocks[row][col]<0)continue;
                float l=GRID_X+col*CELL,r=l+CELL;
                float t=GRID_Y+row*CELL,b=t+CELL;
                if(right>l+1f&&left<r-1f&&feet>t+1f&&top<b-1f)return true;
            }
        }
        return false;
    }

    private void resolvePlayerOverlap(){
        float top=playerFeet-PLAYER_H;
        if(!blockedAt(playerX,top,playerFeet))return;

        // Try small horizontal corrections first, in the direction with the
        // least displacement. This handles being pressed against a block edge.
        for(float d=2f;d<=CELL*2f;d+=2f){
            float left=clampFloat(playerX-d,GRID_X+PLAYER_HALF_W,GRID_X+COLS*CELL-PLAYER_HALF_W);
            if(!blockedAt(left,top,playerFeet)){playerX=left;return;}
            float right=clampFloat(playerX+d,GRID_X+PLAYER_HALF_W,GRID_X+COLS*CELL-PLAYER_HALF_W);
            if(!blockedAt(right,top,playerFeet)){playerX=right;return;}
        }

        // If a tile was placed very close to the sprite, lift the player just
        // enough to clear the overlap while preserving a stable feet position.
        for(float lift=2f;lift<=PLAYER_H;lift+=2f){
            if(!blockedAt(playerX,top-lift,playerFeet-lift)){
                playerFeet-=lift;
                velocityY=0f;
                grounded=hasSurfaceAtFeet(playerX,playerFeet);
                return;
            }
        }
    }

    private void updatePhysics(){
        long now=System.nanoTime();
        if(lastFrameNanos==0)lastFrameNanos=now;
        float dt=Math.min(0.032f,(now-lastFrameNanos)/1_000_000_000f);
        lastFrameNanos=now;

        if(fallingBlockActive){
            fallingElapsed+=dt;
            float t=Math.min(1f,fallingElapsed/Math.max(0.01f,fallingDuration));
            // Ease-out gravity motion: quick fall, soft landing.
            float eased=1f-(1f-t)*(1f-t);
            fallingY=fallingStartY+(fallingEndY-fallingStartY)*eased;
            if(t>=1f)finishFallingBlock();
        }

        if(countdownValue>=0){
            if(now>=countdownNextNanos){
                if(countdownValue==1){
                    winCount=Math.min(10,winCount+1);
                    countdownValue=-1;
                    resetBoardAfterWin();
                    return;
                }
                countdownValue--;
                long delay=countdownValue<=3?1350000000L:620000000L;
                countdownNextNanos=now+delay;
            }
            return;
        }

        float speed=sprint?245f:145f;
        float dx=0f;
        if(leftHeld&&!rightHeld){dx=-speed*dt;facingRight=false;}
        if(rightHeld&&!leftHeld){dx=speed*dt;facingRight=true;}

        // First recover from any tiny overlap caused by contact at block edges.
        resolvePlayerOverlap();

        // Binary-search the last free horizontal position so the player slides
        // cleanly along block faces instead of becoming stuck against them.
        float candidateX=clampFloat(playerX+dx,GRID_X+PLAYER_HALF_W,
                GRID_X+COLS*CELL-PLAYER_HALF_W);
        if(Math.abs(dx)>0.001f){
            if(!blockedAt(candidateX,playerFeet-PLAYER_H,playerFeet)){
                playerX=candidateX;
            }else{
                float low=0f,high=1f;
                for(int i=0;i<12;i++){
                    float mid=(low+high)*0.5f;
                    float test=playerX+(candidateX-playerX)*mid;
                    if(blockedAt(test,playerFeet-PLAYER_H,playerFeet))high=mid;
                    else low=mid;
                }
                playerX=playerX+(candidateX-playerX)*low;
            }
        }

        if(grounded&&!hasSurfaceAtFeet(playerX,playerFeet)){
            grounded=false;
        }

        if(jumpRequested&&grounded){
            velocityY=-JUMP_SPEED;
            grounded=false;
        }
        jumpRequested=false;

        if(!grounded){
            float oldFeet=playerFeet;
            float oldTop=oldFeet-PLAYER_H;
            velocityY+=GRAVITY*dt;
            float nextFeet=oldFeet+velocityY*dt;
            float nextTop=nextFeet-PLAYER_H;

            if(velocityY<0f){
                float ceiling=ceilingSurface(playerX,oldTop,nextTop);
                if(ceiling!=Float.NEGATIVE_INFINITY){
                    nextFeet=ceiling+PLAYER_H;
                    velocityY=0f;
                }
            }else{
                float landing=landingSurface(playerX,oldFeet,nextFeet);
                if(landing!=Float.POSITIVE_INFINITY){
                    nextFeet=landing;
                    velocityY=0f;
                    grounded=true;
                }
            }
            playerFeet=nextFeet;
        }else{
            velocityY=0f;
        }

        // Camera follows the player vertically: climbing moves the arena down on screen.
        // HUD stays fixed above the arena and the bottom controls remain fixed below it.
        float desiredCamera=playerFeet-boardViewportHeight()*PLAYER_SCREEN_RATIO;
        float minCamera=-PLAYER_H*1.2f;
        cameraTarget=clampFloat(desiredCamera,minCamera,Math.max(minCamera,BOARD_H-boardViewportHeight()));
        cameraY+=(cameraTarget-cameraY)*Math.min(1f,dt*7f);

        if(!fallingBlockActive&&blockCount()>=COLS*ROWS&&countdownValue<0){
            countdownValue=15;
            countdownNextNanos=now+620000000L;
        }

        animationClock+=dt;
        if(!grounded){
            if(animationClock>0.11f){jumpFrame=(jumpFrame+1)%5;animationClock=0f;}
        }else if(leftHeld||rightHeld){
            float delay=sprint?0.075f:0.13f;
            if(animationClock>delay){
                if(sprint)runFrame=(runFrame+1)%5;
                else walkFrame=(walkFrame+1)%5;
                animationClock=0f;
            }
        }else{
            walkFrame=0;animationClock=0f;
        }
    }

    private float clampFloat(float v,float min,float max){return Math.max(min,Math.min(max,v));}
    private float toLogicalX(float px){return px/Math.max(0.001f,scale());}
    private float toLogicalY(float py){return py/Math.max(0.001f,scale());}

    private int roleAt(float x,float y){
        // Lock gameplay input during the end-of-round countdown; pause remains available.
        if(countdownValue>=0){
            if(x>=234f&&x<=278f&&y>=98f&&y<=142f)return ROLE_PAUSE;
            return ROLE_NONE;
        }
        // Image order is left, right, run, pickaxe, block, jump;
        // role IDs keep jump separate so it can be held together with movement.
        if(!useHardwareControls()){
            final int[] roles={ROLE_LEFT,ROLE_RIGHT,ROLE_RUN,ROLE_PICK,ROLE_BUILD,ROLE_JUMP};
            for(int i=0;i<6;i++)if(hit[i].contains(x,y))return roles[i];
        }
        if(x>=234f&&x<=278f&&y>=98f&&y<=142f)return ROLE_PAUSE;
        if(y>=areaTop()&&y<controlTop()&&x>=GRID_X&&x<GRID_X+COLS*CELL)return ROLE_GRID;
        return ROLE_NONE;
    }

    private void addPointer(MotionEvent e,int index){
        int id=e.getPointerId(index);
        float x=toLogicalX(e.getX(index)),y=toLogicalY(e.getY(index));
        int role=roleAt(x,y);
        TouchPoint t=new TouchPoint(role,x,y);
        touches.put(id,t);
        if(role==ROLE_PAUSE){
            pressCenterX=x;pressCenterY=y;
            pressUntilNanos=System.nanoTime()+220000000L;
        }
        if(role==ROLE_RUN)sprint=!sprint;
        else if(role==ROLE_PICK){breakMode=!breakMode;buildMode=false;buildAimActive=false;}
        else if(role==ROLE_BUILD){
            breakMode=false;buildMode=true;buildAimActive=true;buildAimMoved=false;
            buildAimStartX=x;buildAimStartY=y;
            targetCol=playerColumn();targetRow=topBlockRow(playerColumn())-1;
        }
        else if(role==ROLE_JUMP)jumpRequested=true;
        if(role==ROLE_GRID)updateTarget(x,y);
        refreshHeldButtons();
    }

    private void updatePointers(MotionEvent e){
        for(int i=0;i<e.getPointerCount();i++){
            int id=e.getPointerId(i);
            TouchPoint t=touches.get(id);
            if(t==null)continue;
            t.x=toLogicalX(e.getX(i));
            t.y=toLogicalY(e.getY(i));
            // A finger may slide between the two directional pads without lifting.
            if((t.role==ROLE_LEFT||t.role==ROLE_RIGHT)&&t.y>=controlTop()&&t.x>=0f&&t.x<172f){
                t.role=t.x<90f?ROLE_LEFT:ROLE_RIGHT;
            }
            if(t.role==ROLE_GRID)updateTarget(t.x,t.y);
            if(t.role==ROLE_BUILD){
                float dx=t.x-buildAimStartX,dy=t.y-buildAimStartY;
                if(Math.abs(dx)+Math.abs(dy)>18f)buildAimMoved=true;
                if(t.y>=areaTop()&&t.y<controlTop()&&t.x>=GRID_X&&t.x<GRID_X+COLS*CELL){
                    updateTarget(t.x,t.y);
                    buildAimMoved=true;
                }
            }
        }
        refreshHeldButtons();
    }

    private void releasePointer(MotionEvent e,int index){
        int id=e.getPointerId(index);
        TouchPoint t=touches.get(id);
        if(t!=null&&t.role==ROLE_GRID){
            float x=toLogicalX(e.getX(index)),y=toLogicalY(e.getY(index));
            updateTarget(x,y);
            if(breakMode)breakBlock();
        }else if(t!=null&&t.role==ROLE_BUILD){
            finishBuildAim();
        }else if(t!=null&&t.role==ROLE_PAUSE){
            screen=SCREEN_PAUSE;
            pressUntilNanos=System.nanoTime()+140000000L;
        }
        touches.remove(id);
        refreshHeldButtons();
    }

    private void refreshHeldButtons(){
        leftHeld=keyboardLeft;rightHeld=keyboardRight;jumpHeld=keyboardJump;
        for(int i=0;i<touches.size();i++){
            int role=touches.valueAt(i).role;
            if(role==ROLE_LEFT)leftHeld=true;
            if(role==ROLE_RIGHT)rightHeld=true;
            if(role==ROLE_JUMP)jumpHeld=true;
        }
    }

    private void updateTarget(float x,float y){
        int col=(int)((x-GRID_X)/CELL);
        int row=(int)((y-areaTop()+cameraY-GRID_Y)/CELL);
        targetCol=(col>=0&&col<COLS)?col:-1;
        targetRow=(row>=0&&row<ROWS)?row:-1;
    }


    @Override public boolean onKeyDown(int keyCode,KeyEvent event){
        if(screen==SCREEN_MENU){
            if(keyCode==KeyEvent.KEYCODE_ENTER||keyCode==KeyEvent.KEYCODE_SPACE){resetGame();screen=SCREEN_GAME;invalidate();return true;}
            if(keyCode==KeyEvent.KEYCODE_S){screen=SCREEN_SETTINGS;invalidate();return true;}
            return super.onKeyDown(keyCode,event);
        }
        if(screen==SCREEN_SETTINGS){
            if(keyCode==KeyEvent.KEYCODE_ESCAPE||keyCode==KeyEvent.KEYCODE_BACK){screen=SCREEN_MENU;invalidate();return true;}
            if(keyCode==KeyEvent.KEYCODE_ENTER){controlMode=(controlMode+1)%3;getContext().getSharedPreferences("blockrush_settings",Context.MODE_PRIVATE).edit().putInt("control_mode",controlMode).apply();invalidate();return true;}
            return super.onKeyDown(keyCode,event);
        }
        if(screen==SCREEN_PAUSE){
            if(keyCode==KeyEvent.KEYCODE_ESCAPE||keyCode==KeyEvent.KEYCODE_BACK||keyCode==KeyEvent.KEYCODE_ENTER||keyCode==KeyEvent.KEYCODE_SPACE){screen=SCREEN_GAME;lastFrameNanos=System.nanoTime();invalidate();return true;}
            if(keyCode==KeyEvent.KEYCODE_R){resetGame();screen=SCREEN_GAME;invalidate();return true;}
            if(keyCode==KeyEvent.KEYCODE_M){screen=SCREEN_MENU;lastFrameNanos=0L;invalidate();return true;}
            return super.onKeyDown(keyCode,event);
        }
        if(screen!=SCREEN_GAME)return super.onKeyDown(keyCode,event);
        if(keyCode==KeyEvent.KEYCODE_DPAD_LEFT||keyCode==KeyEvent.KEYCODE_A){keyboardLeft=true;refreshHeldButtons();return true;}
        if(keyCode==KeyEvent.KEYCODE_DPAD_RIGHT||keyCode==KeyEvent.KEYCODE_D){keyboardRight=true;refreshHeldButtons();return true;}
        if(keyCode==KeyEvent.KEYCODE_SPACE||keyCode==KeyEvent.KEYCODE_DPAD_UP||keyCode==KeyEvent.KEYCODE_W){
            if(!event.isAltPressed()){jumpRequested=true;keyboardJump=true;refreshHeldButtons();}return true;
        }
        if(keyCode==KeyEvent.KEYCODE_SHIFT_LEFT||keyCode==KeyEvent.KEYCODE_SHIFT_RIGHT){sprint=true;return true;}
        if(keyCode==KeyEvent.KEYCODE_E||keyCode==KeyEvent.KEYCODE_ENTER){placeUnderPlayer();return true;}
        if(keyCode==KeyEvent.KEYCODE_Q){breakMode=!breakMode;return true;}
        if(keyCode==KeyEvent.KEYCODE_ESCAPE||keyCode==KeyEvent.KEYCODE_BACK){screen=SCREEN_PAUSE;return true;}
        return super.onKeyDown(keyCode,event);
    }

    @Override public boolean onKeyUp(int keyCode,KeyEvent event){
        if(keyCode==KeyEvent.KEYCODE_DPAD_LEFT||keyCode==KeyEvent.KEYCODE_A){keyboardLeft=false;refreshHeldButtons();return true;}
        if(keyCode==KeyEvent.KEYCODE_DPAD_RIGHT||keyCode==KeyEvent.KEYCODE_D){keyboardRight=false;refreshHeldButtons();return true;}
        if(keyCode==KeyEvent.KEYCODE_SPACE||keyCode==KeyEvent.KEYCODE_DPAD_UP||keyCode==KeyEvent.KEYCODE_W){keyboardJump=false;refreshHeldButtons();return true;}
        if(keyCode==KeyEvent.KEYCODE_SHIFT_LEFT||keyCode==KeyEvent.KEYCODE_SHIFT_RIGHT){sprint=false;return true;}
        return super.onKeyUp(keyCode,event);
    }

    @Override public boolean onGenericMotionEvent(MotionEvent event){
        if((event.getSource()&InputDevice.SOURCE_MOUSE)==InputDevice.SOURCE_MOUSE
                &&event.getAction()==MotionEvent.ACTION_HOVER_MOVE){
            float mx=toLogicalX(event.getX()),my=toLogicalY(event.getY());
            mouseAimActive=my>=areaTop()&&my<controlTop()&&mx>=GRID_X&&mx<GRID_X+COLS*CELL;
            updateTarget(mx,my);
            invalidate();return true;
        }
        return super.onGenericMotionEvent(event);
    }

    @Override public boolean onTouchEvent(MotionEvent event){
        int action=event.getActionMasked();
        int index=event.getActionIndex();

        if(screen==SCREEN_GAME&&(event.getSource()&InputDevice.SOURCE_MOUSE)==InputDevice.SOURCE_MOUSE){
            float mx=toLogicalX(event.getX(index)),my=toLogicalY(event.getY(index));
            if(action==MotionEvent.ACTION_DOWN||action==MotionEvent.ACTION_BUTTON_PRESS){
                if(mx>=234f&&mx<=278f&&my>=98f&&my<=142f){screen=SCREEN_PAUSE;invalidate();return true;}
                updateTarget(mx,my);
                mouseAimActive=my>=areaTop()&&my<controlTop()&&mx>=GRID_X&&mx<GRID_X+COLS*CELL;
                if((event.getButtonState()&MotionEvent.BUTTON_SECONDARY)!=0){breakBlock();}
                else if((event.getButtonState()&MotionEvent.BUTTON_PRIMARY)!=0){
                    int c=targetCol,r=targetRow;
                    if(c>=0&&r>=0)startFallingAt(c,r,c==playerColumn());
                }
                invalidate();return true;
            }
            if(action==MotionEvent.ACTION_UP||action==MotionEvent.ACTION_BUTTON_RELEASE){invalidate();return true;}
        }

        if(screen!=SCREEN_GAME){
            if(action==MotionEvent.ACTION_DOWN){
                pressCenterX=toLogicalX(event.getX(index));
                pressCenterY=toLogicalY(event.getY(index));
                pressUntilNanos=System.nanoTime()+220000000L;
            }else if(action==MotionEvent.ACTION_UP){
                handleScreenTap(toLogicalX(event.getX(index)),toLogicalY(event.getY(index)));
                pressUntilNanos=System.nanoTime()+140000000L;
            }
            invalidate();
            return true;
        }

        if(action==MotionEvent.ACTION_DOWN||action==MotionEvent.ACTION_POINTER_DOWN){
            addPointer(event,index);
            invalidate();
            return true;
        }
        if(action==MotionEvent.ACTION_MOVE){
            updatePointers(event);
            invalidate();
            return true;
        }
        if(action==MotionEvent.ACTION_POINTER_UP){
            releasePointer(event,index);
            invalidate();
            return true;
        }
        if(action==MotionEvent.ACTION_UP){
            releasePointer(event,index);
            touches.clear();
            refreshHeldButtons();
            invalidate();
            return true;
        }
        if(action==MotionEvent.ACTION_CANCEL){
            touches.clear();
            refreshHeldButtons();
            jumpRequested=false;
            buildAimActive=false;buildAimMoved=false;
            invalidate();
            return true;
        }
        return true;
    }
}
