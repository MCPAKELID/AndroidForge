# BlockRush Live Game v20 — AndroidForge Source

## v20 changes

- Replaced the old top HUD with the newly supplied transparent HUD frame sheet. The block counter, trophy/win counter, percentage and segmented fill bar are drawn into the matching frame areas; the unused heart panel is not displayed.
- Increased the six touch controls and their hit areas, with safer spacing from the phone edges.
- The block button now supports press-and-drag aiming: press the block control, drag onto a grid cell, and release to drop a block into that column/cell. A simple tap still drops a block directly under the player and lifts the player onto it.
- Direct block placement remains available while jumping; the player is placed on the new support block when it lands.
- The arena background is now drawn at a fixed world size rather than being stretched to the visible screen height. This prevents the background grid and placed blocks from drifting out of alignment while the camera scrolls.
- A temporary soil strip fills the lower control region near the starting ground and fades as the camera climbs, keeping the touch buttons transparent over the arena later in the run.
- Main-menu, settings and pause buttons are smaller. Their hitboxes and artwork remain screen-fixed rather than following the arena camera.
- Added automatic hardware keyboard/mouse detection. In AUTO mode, touch buttons hide when a physical keyboard or mouse is connected. Settings also allow TOUCH, AUTO or KEYBOARD / MOUSE mode.
- Keyboard: A/D or left/right arrows to move, Space/W/up to jump, Shift to run, E/Enter to place a block under the player, Q to toggle mining, Escape to pause. A mouse left-click places at the hovered cell and right-click mines it.

## Existing gameplay retained

- 10 columns x 40 rows (400 cells).
- Layer material changes every 3 rows.
- Percentage reflects filled cells; row counter reflects complete 10-cell rows.
- Full area triggers the 15-to-1 countdown, then resets the board and increments WIN.

## Build

Import this ZIP with its contents extracted directly into the AndroidForge project workspace. The ZIP root contains `settings.gradle` and `build.gradle`. Build the `app` module with JDK 17 and Android SDK Platform 35.

Application ID: `com.mcpakel.blockarea`  
Version: 2.0 (versionCode 20)

The ZIP structure, asset presence and archive integrity were checked. A full Android APK build and on-device input test could not be run here because this environment does not include Android SDK/Gradle. Please build and test on AndroidForge, especially hardware keyboard/mouse detection and drag-to-aim block placement.
