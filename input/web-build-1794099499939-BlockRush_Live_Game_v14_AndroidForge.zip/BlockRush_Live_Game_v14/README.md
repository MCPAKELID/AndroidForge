# BlockRush Live Game v14 — AndroidForge Source

## v14 changes based on the latest map and gameplay reference

### New arena map
- Replaced the previous arena with the exact newly supplied 691 x 1536 map image.
- The map uses a 12-column by 31-row grid.
- Cell size is 46.25 world units, aligned to the larger squares in the supplied image.
- The hazard line is respected: the top three rows are not buildable.
- The arena background, blocks, player, and touch-to-place coordinates share the same grid origin and camera transform.

### Blocks
- Removed random texture selection.
- Material texture is determined by height above the floor.
- Every five vertical layers use the same material, then the next material in the fixed sequence is used.
- Material sequence begins with grass, dirt, stone, cobblestone, stone bricks, mossy stone bricks, bricks, sandstone, and then other supplied materials.
- Each block occupies one full grid cell and is drawn with a tiny overlap to avoid visible seams.
- Blocks are still placed only on supported cells.

### Level and progress bar
- Level is calculated from the tallest continuous stack connected to the floor.
- Every three layers advances one level: 3 layers = 1/10, 6 = 2/10, up to 30 layers = 10/10.
- The level count is displayed beside the green level bar, not in the trophy panel.
- The trophy panel is blank and reserved for the future WIN feature.
- The green bar fills according to actual stack height.
- The block-area percentage remains displayed in the block panel.

### Rendering fixes
- Fixed the block visibility culling bug: screen-space Y is now compared against the actual arena viewport boundaries, not viewport height alone.
- HUD remains fixed above the arena.
- The camera scrolls the supplied map as the player climbs.
- Controls remain in the separate white control deck below the arena.
- Updated touch-control positions for the narrower 691-unit world width.

## Build in AndroidForge
1. Extract the ZIP.
2. Open `BlockRush_Live_Game_v14` in AndroidForge.
3. Build the `app` module.
4. Java 17, compile SDK 35, min SDK 23.
5. Application ID: `com.mcpakel.blockarea`.

Version: 1.4 (versionCode 14)

`AreaView.java` passed a Java syntax/API-stub compile check. A full Android APK build and on-device gameplay test have not been run in this environment.
